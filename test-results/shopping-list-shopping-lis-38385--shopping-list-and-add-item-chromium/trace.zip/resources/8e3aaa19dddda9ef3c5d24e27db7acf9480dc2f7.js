(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_4fb9f4dc._.js",
  "static/chunks/3cf09_motion-dom_dist_es_09ae94bb._.js",
  "static/chunks/4bb8c_framer-motion_dist_es_fc210b30._.js",
  "static/chunks/50d1e_date-fns_2fbdfe0f._.js",
  "static/chunks/c5101_@supabase_realtime-js_dist_module_4f8b52ae._.js",
  "static/chunks/cd977_@supabase_auth-js_dist_module_7b3787de._.js",
  "static/chunks/node_modules__pnpm_9e8b357c._.js"
],
    source: "dynamic"
});
