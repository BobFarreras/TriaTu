(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/ui/BackButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BackButton",
    ()=>BackButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/navigation.js [app-client] (ecmascript)"); // 👈 Importem el router
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function BackButton({ href, label = "Tornar", className = "", preferReferrer = false, fallbackHref }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const storageKey = ("TURBOPACK compile-time truthy", 1) ? `back-origin:${window.location.pathname}` : "TURBOPACK unreachable";
    // Definim els estils comuns per no repetir codi
    const buttonStyles = `
    flex items-center justify-center gap-2 
    bg-slate-800 hover:bg-slate-700 
    text-white 
    border border-slate-700 hover:border-purple-500/50
    transition-colors shadow-lg
    cursor-pointer
    
    /* MÒBIL: Rodó i petit */
    w-10 h-10 rounded-full
    
    /* ESCRIPTORI: Allargat i amb text */
    sm:w-auto sm:h-auto sm:px-4 sm:py-2 sm:rounded-full
    
    ${className}
  `;
    // Contingut visual del botó (Icona + Text)
    const content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-xl sm:text-lg leading-none pb-1 sm:pb-0",
                children: "🔙"
            }, void 0, false, {
                fileName: "[project]/components/ui/BackButton.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "hidden sm:inline text-xs font-bold uppercase tracking-wide",
                children: label
            }, void 0, false, {
                fileName: "[project]/components/ui/BackButton.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
    // CAS 1: Si tenim una ruta específica (href), fem servir Link (millor per SEO i prefetching)
    if (href) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: href,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                whileHover: {
                    scale: 1.05
                },
                whileTap: {
                    scale: 0.95
                },
                className: buttonStyles,
                children: content
            }, void 0, false, {
                fileName: "[project]/components/ui/BackButton.tsx",
                lineNumber: 58,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/ui/BackButton.tsx",
            lineNumber: 57,
            columnNumber: 7
        }, this);
    }
    // CAS 2: Si volem tornar a l'origen (fora d'aquesta ruta), usem el referrer guardat
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
        type: "button",
        onClick: ()=>{
            if (preferReferrer && ("TURBOPACK compile-time value", "object") !== "undefined" && storageKey) {
                const storedOrigin = sessionStorage.getItem(storageKey);
                if (storedOrigin) {
                    router.push(storedOrigin);
                    return;
                }
                if (fallbackHref) {
                    router.push(fallbackHref);
                    return;
                }
            }
            router.back();
        },
        whileHover: {
            scale: 1.05
        },
        whileTap: {
            scale: 0.95
        },
        className: buttonStyles,
        children: content
    }, void 0, false, {
        fileName: "[project]/components/ui/BackButton.tsx",
        lineNumber: 72,
        columnNumber: 5
    }, this);
}
_s(BackButton, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = BackButton;
var _c;
__turbopack_context__.k.register(_c, "BackButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:6ba89e [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "toggleShoppingItemAction",
    ()=>$$RSC_SERVER_ACTION_1
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"60ca485e124f334bd5af980fa6c0cd3a715a401abb":"toggleShoppingItemAction"},"app/actions/shopping-list-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("60ca485e124f334bd5af980fa6c0cd3a715a401abb", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "toggleShoppingItemAction");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vc2hvcHBpbmctbGlzdC1hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc2VydmVyJztcclxuXHJcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2Uvc2VydmVyJztcclxuaW1wb3J0IHsgY29udGFpbmVyIH0gZnJvbSAnQC9zZXJ2aWNlcy9jb250YWluZXInO1xyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gJ25leHQvY2FjaGUnO1xyXG5pbXBvcnQgeyBkZWJ1ZywgZXJyb3IgYXMgbG9nRXJyb3IgfSBmcm9tICdAL2xpYi9sb2dnZXInO1xyXG5pbXBvcnQgeyB6IH0gZnJvbSAnem9kJztcclxuXHJcbmNvbnN0IEFkZEl0ZW1TY2hlbWEgPSB6Lm9iamVjdCh7XHJcbiAgbmFtZTogei5zdHJpbmcoKS5taW4oMSksXHJcbiAgcXVhbnRpdHk6IHoubnVtYmVyKCkucG9zaXRpdmUoKSxcclxuICB1bml0OiB6LnN0cmluZygpLFxyXG4gIGVtb2ppOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgcHJvZHVjdElkOiB6LnN0cmluZygpLm9wdGlvbmFsKCkubnVsbGFibGUoKSxcclxuICBwcm9kdWN0SW1hZ2U6IHouc3RyaW5nKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpLFxyXG4gIGVzdGltYXRlZENvc3Q6IHoubnVtYmVyKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpLFxyXG4gIHJvb21JZDogei5zdHJpbmcoKS51dWlkKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpXHJcbn0pO1xyXG4vLyDinIUgU2NoZW1hIHBlciB2YWxpZGFjacOzIG1hc3NpdmFcclxuY29uc3QgQmF0Y2hJdGVtU2NoZW1hID0gei5vYmplY3Qoe1xyXG4gIGl0ZW1zOiB6LmFycmF5KEFkZEl0ZW1TY2hlbWEpLFxyXG4gIHJvb21JZDogei5zdHJpbmcoKS51dWlkKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpXHJcbn0pO1xyXG5jb25zdCBUb2dnbGVJdGVtU2NoZW1hID0gei5vYmplY3Qoe1xyXG4gIGl0ZW1JZDogei5zdHJpbmcoKS51dWlkKCksXHJcbiAgaXNDaGVja2VkOiB6LmJvb2xlYW4oKVxyXG59KTtcclxuY29uc3QgUm9vbUlkU2NoZW1hID0gei5zdHJpbmcoKS51dWlkKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpO1xyXG4vLyAxLiBBREQgSVRFTVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYWRkVG9TaG9wcGluZ0xpc3RBY3Rpb24oXHJcbiAgICBuYW1lOiBzdHJpbmcsIFxyXG4gICAgcXVhbnRpdHk6IG51bWJlciwgXHJcbiAgICB1bml0OiBzdHJpbmcsIFxyXG4gICAgZW1vamk/OiBzdHJpbmcsIFxyXG4gICAgcHJvZHVjdElkPzogc3RyaW5nLFxyXG4gICAgcHJvZHVjdEltYWdlPzogc3RyaW5nLFxyXG4gICAgZXN0aW1hdGVkQ29zdD86IG51bWJlcixcclxuICAgIHJvb21JZD86IHN0cmluZyB8IG51bGxcclxuKSB7XHJcbiAgdHJ5IHtcclxuICAgIGRlYnVnKCdbQUNUSU9OXSBhZGRUb1Nob3BwaW5nTGlzdCBzdGFydCcpO1xyXG5cclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICAgIGlmICghdXNlcikgdGhyb3cgbmV3IEVycm9yKFwiVW5hdXRob3JpemVkXCIpO1xyXG5cclxuICAgIGNvbnN0IHZhbGlkYXRpb24gPSBBZGRJdGVtU2NoZW1hLnNhZmVQYXJzZSh7IFxyXG4gICAgICAgIG5hbWUsIHF1YW50aXR5LCB1bml0LCBlbW9qaSwgcHJvZHVjdElkLCBwcm9kdWN0SW1hZ2UsIGVzdGltYXRlZENvc3QsIHJvb21JZFxyXG4gICAgfSk7XHJcbiAgICBcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSB7XHJcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkRhZGVzIGludsOgbGlkZXNcIiB9O1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHVzZUNhc2UgPSBjb250YWluZXIuZ2V0QWRkVG9TaG9wcGluZ0xpc3Qoc3VwYWJhc2UpO1xyXG4gICAgXHJcbiAgICBhd2FpdCB1c2VDYXNlLmV4ZWN1dGUoXHJcbiAgICAgICAgdXNlci5pZCwgXHJcbiAgICAgICAgdmFsaWRhdGlvbi5kYXRhLm5hbWUsIFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5xdWFudGl0eSwgXHJcbiAgICAgICAgdmFsaWRhdGlvbi5kYXRhLnVuaXQsXHJcbiAgICAgICAgdmFsaWRhdGlvbi5kYXRhLmVtb2ppLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5wcm9kdWN0SWQgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5wcm9kdWN0SW1hZ2UgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5lc3RpbWF0ZWRDb3N0IHx8IHVuZGVmaW5lZCxcclxuICAgICAgICB2YWxpZGF0aW9uLmRhdGEucm9vbUlkIHx8IHVuZGVmaW5lZFxyXG4gICAgKTtcclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL3Nob3BwaW5nLWxpc3QnKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxuXHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGxvZ0Vycm9yKCdhZGRUb1Nob3BwaW5nTGlzdCBmYWlsZWQnLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiTm8gcydoYSBwb2d1dCBhZmVnaXIgYSBsYSBsbGlzdGEuXCIgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIDIuIFRPR0dMRSBJVEVNXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB0b2dnbGVTaG9wcGluZ0l0ZW1BY3Rpb24oaXRlbUlkOiBzdHJpbmcsIGlzQ2hlY2tlZDogYm9vbGVhbikge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB2YWxpZGF0aW9uID0gVG9nZ2xlSXRlbVNjaGVtYS5zYWZlUGFyc2UoeyBpdGVtSWQsIGlzQ2hlY2tlZCB9KTtcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRGFkZXMgaW52w6BsaWRlc1wiIH07XHJcblxyXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICAgIGNvbnN0IHJlcG8gPSBjb250YWluZXIuZ2V0U2hvcHBpbmdMaXN0UmVwbyhzdXBhYmFzZSk7IFxyXG4gICAgYXdhaXQgcmVwby50b2dnbGVDaGVjayh2YWxpZGF0aW9uLmRhdGEuaXRlbUlkLCB2YWxpZGF0aW9uLmRhdGEuaXNDaGVja2VkKTtcclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL3Nob3BwaW5nLWxpc3QnKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ3RvZ2dsZVNob3BwaW5nSXRlbSBmYWlsZWQnLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRXJyb3IgYWN0dWFsaXR6YW50XCIgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIDMuIENPTVBMRVRFIFNFU1NJT05cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNvbXBsZXRlU2hvcHBpbmdTZXNzaW9uQWN0aW9uKHJvb21JZD86IHN0cmluZyB8IG51bGwpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgdmFsaWRhdGlvbiA9IFJvb21JZFNjaGVtYS5zYWZlUGFyc2Uocm9vbUlkKTtcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRGFkZXMgaW52w6BsaWRlc1wiIH07XHJcblxyXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICAgIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0gfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpO1xyXG4gICAgaWYgKCF1c2VyKSB0aHJvdyBuZXcgRXJyb3IoJ1VuYXV0aG9yaXplZCcpO1xyXG5cclxuICAgIGNvbnN0IHVzZUNhc2UgPSBjb250YWluZXIuZ2V0Q29tcGxldGVTaG9wcGluZ1Nlc3Npb24oc3VwYWJhc2UpO1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdXNlQ2FzZS5leGVjdXRlKHVzZXIuaWQsIHZhbGlkYXRpb24uZGF0YSB8fCB1bmRlZmluZWQpO1xyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvc2hvcHBpbmctbGlzdCcpO1xyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9pbnZlbnRvcnknKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGNvdW50OiByZXN1bHQuYWRkZWQgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoXCJFcnJvciBjb21wbGV0aW5nIHNob3BwaW5nIHNlc3Npb246XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciBmaW5hbGl0emFudCBsYSBjb21wcmFcIiB9O1xyXG4gIH1cclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYWRkQmF0Y2hUb1Nob3BwaW5nTGlzdEFjdGlvbihpdGVtczogei5pbmZlcjx0eXBlb2YgQWRkSXRlbVNjaGVtYT5bXSwgcm9vbUlkPzogc3RyaW5nIHwgbnVsbCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgICBpZiAoIXVzZXIpIHRocm93IG5ldyBFcnJvcihcIlVuYXV0aG9yaXplZFwiKTtcclxuXHJcbiAgICAvLyBWYWxpZGFyIGRhZGVzXHJcbiAgICBjb25zdCB2YWxpZGF0aW9uID0gQmF0Y2hJdGVtU2NoZW1hLnNhZmVQYXJzZSh7IGl0ZW1zLCByb29tSWQgfSk7XHJcbiAgICBpZiAoIXZhbGlkYXRpb24uc3VjY2VzcykgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkRhZGVzIGludsOgbGlkZXNcIiB9O1xyXG5cclxuICAgIGNvbnN0IHVzZUNhc2UgPSBjb250YWluZXIuZ2V0QWRkVG9TaG9wcGluZ0xpc3Qoc3VwYWJhc2UpO1xyXG5cclxuICAgIC8vIEV4ZWN1dGFyIGVuIHBhcmFswrdsZWwgKG8gcG9kcmllcyBmZXIgdW4gbG9vcCBzZXF1ZW5jaWFsIHNpIHZvbHMgZ2FyYW50aXIgb3JkcmUpXHJcbiAgICBhd2FpdCBQcm9taXNlLmFsbChpdGVtcy5tYXAoaXRlbSA9PiBcclxuICAgICAgdXNlQ2FzZS5leGVjdXRlKFxyXG4gICAgICAgIHVzZXIuaWQsXHJcbiAgICAgICAgaXRlbS5uYW1lLFxyXG4gICAgICAgIGl0ZW0ucXVhbnRpdHksXHJcbiAgICAgICAgaXRlbS51bml0LFxyXG4gICAgICAgIGl0ZW0uZW1vamksXHJcbiAgICAgICAgaXRlbS5wcm9kdWN0SWQgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIGl0ZW0ucHJvZHVjdEltYWdlIHx8IHVuZGVmaW5lZCxcclxuICAgICAgICBpdGVtLmVzdGltYXRlZENvc3QgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5yb29tSWQgfHwgdW5kZWZpbmVkXHJcbiAgICAgIClcclxuICAgICkpO1xyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvc2hvcHBpbmctbGlzdCcpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG5cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoXCJFcnJvciBhZGRpbmcgYmF0Y2g6XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciBndWFyZGFudCBwcm9kdWN0ZXNcIiB9O1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNob3BwaW5nTGlzdERhdGFBY3Rpb24ocm9vbUlkPzogc3RyaW5nIHwgbnVsbCkge1xyXG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgaWYgKCF1c2VyKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGlvbiA9IFJvb21JZFNjaGVtYS5zYWZlUGFyc2Uocm9vbUlkKTtcclxuICBpZiAoIXZhbGlkYXRpb24uc3VjY2VzcykgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkRhZGVzIGludsOgbGlkZXNcIiB9O1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgZ2V0U2hvcHBpbmdMaXN0ID0gY29udGFpbmVyLmdldEdldFNob3BwaW5nTGlzdChzdXBhYmFzZSk7XHJcbiAgICBjb25zdCBnZXRIaXN0b3J5ID0gY29udGFpbmVyLmdldEdldFNob3BwaW5nSGlzdG9yeShzdXBhYmFzZSk7XHJcblxyXG4gICAgY29uc3QgW2l0ZW1zLCBoaXN0b3J5XSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgZ2V0U2hvcHBpbmdMaXN0LmV4ZWN1dGUodXNlci5pZCwgdmFsaWRhdGlvbi5kYXRhIHx8IHVuZGVmaW5lZCksXHJcbiAgICAgIGdldEhpc3RvcnkuZXhlY3V0ZSh1c2VyLmlkLCB2YWxpZGF0aW9uLmRhdGEgfHwgdW5kZWZpbmVkKSxcclxuICAgIF0pO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IHRydWUsXHJcbiAgICAgIGRhdGE6IHtcclxuICAgICAgICBpdGVtczogbWFwSXRlbXNUb1ZpZXdNb2RlbChpdGVtcyksXHJcbiAgICAgICAgaGlzdG9yeTogbWFwSGlzdG9yeVRvVmlld01vZGVsKGhpc3RvcnkpLFxyXG4gICAgICB9LFxyXG4gICAgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ2dldFNob3BwaW5nTGlzdERhdGFBY3Rpb24gZmFpbGVkJywgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIk5vIHMnaGEgcG9ndXQgY2FycmVnYXIgbGEgbGxpc3RhLlwiIH07XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBtYXBJdGVtc1RvVmlld01vZGVsKGl0ZW1zOiBpbXBvcnQoJ0AvY29yZS9kb21haW4vZW50aXRpZXMvU2hvcHBpbmdMaXN0SXRlbScpLlNob3BwaW5nTGlzdEl0ZW1bXSkge1xyXG4gIHJldHVybiBpdGVtcy5tYXAoKGkpID0+ICh7XHJcbiAgICBpZDogaS5wcm9wcy5pZCxcclxuICAgIG5hbWU6IGkucHJvcHMubmFtZSxcclxuICAgIHF1YW50aXR5OiBpLnByb3BzLnF1YW50aXR5LFxyXG4gICAgdW5pdDogaS5wcm9wcy51bml0LFxyXG4gICAgaXNDaGVja2VkOiBpLnByb3BzLmlzQ2hlY2tlZCxcclxuICAgIGVtb2ppOiBpLnByb3BzLmVtb2ppLFxyXG4gICAgcHJvZHVjdElkOiBpLnByb3BzLnByb2R1Y3RJZCA/PyB1bmRlZmluZWQsXHJcbiAgICBwcm9kdWN0SW1hZ2U6IGkucHJvcHMucHJvZHVjdEltYWdlID8/IHVuZGVmaW5lZCxcclxuICAgIGVzdGltYXRlZENvc3Q6IGkucHJvcHMuZXN0aW1hdGVkQ29zdCA/PyB1bmRlZmluZWRcclxuICB9KSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIG1hcEhpc3RvcnlUb1ZpZXdNb2RlbChoaXN0b3J5OiBpbXBvcnQoJ0AvY29yZS9kb21haW4vZW50aXRpZXMvU2hvcHBpbmdTZXNzaW9uJykuU2hvcHBpbmdTZXNzaW9uW10pIHtcclxuICByZXR1cm4gaGlzdG9yeS5tYXAoKGgpID0+ICh7XHJcbiAgICBpZDogaC5wcm9wcy5pZCxcclxuICAgIGNyZWF0ZWRBdDogaC5wcm9wcy5jcmVhdGVkQXQsXHJcbiAgICB0b3RhbENvc3Q6IGgucHJvcHMudG90YWxDb3N0LFxyXG4gICAgaXRlbUNvdW50OiBoLnByb3BzLml0ZW1Db3VudCxcclxuICAgIGl0ZW1zU25hcHNob3Q6IGgucHJvcHMuaXRlbXNTbmFwc2hvdFxyXG4gIH0pKTtcclxufVxyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6ImlUQThFc0IscU1BQUEifQ==
}),
"[project]/app/actions/data:079bca [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "completeShoppingSessionAction",
    ()=>$$RSC_SERVER_ACTION_2
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"40c6f3b4943b4a0f548d04df612c65af754e2c2260":"completeShoppingSessionAction"},"app/actions/shopping-list-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40c6f3b4943b4a0f548d04df612c65af754e2c2260", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "completeShoppingSessionAction");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vc2hvcHBpbmctbGlzdC1hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc2VydmVyJztcclxuXHJcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2Uvc2VydmVyJztcclxuaW1wb3J0IHsgY29udGFpbmVyIH0gZnJvbSAnQC9zZXJ2aWNlcy9jb250YWluZXInO1xyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gJ25leHQvY2FjaGUnO1xyXG5pbXBvcnQgeyBkZWJ1ZywgZXJyb3IgYXMgbG9nRXJyb3IgfSBmcm9tICdAL2xpYi9sb2dnZXInO1xyXG5pbXBvcnQgeyB6IH0gZnJvbSAnem9kJztcclxuXHJcbmNvbnN0IEFkZEl0ZW1TY2hlbWEgPSB6Lm9iamVjdCh7XHJcbiAgbmFtZTogei5zdHJpbmcoKS5taW4oMSksXHJcbiAgcXVhbnRpdHk6IHoubnVtYmVyKCkucG9zaXRpdmUoKSxcclxuICB1bml0OiB6LnN0cmluZygpLFxyXG4gIGVtb2ppOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgcHJvZHVjdElkOiB6LnN0cmluZygpLm9wdGlvbmFsKCkubnVsbGFibGUoKSxcclxuICBwcm9kdWN0SW1hZ2U6IHouc3RyaW5nKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpLFxyXG4gIGVzdGltYXRlZENvc3Q6IHoubnVtYmVyKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpLFxyXG4gIHJvb21JZDogei5zdHJpbmcoKS51dWlkKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpXHJcbn0pO1xyXG4vLyDinIUgU2NoZW1hIHBlciB2YWxpZGFjacOzIG1hc3NpdmFcclxuY29uc3QgQmF0Y2hJdGVtU2NoZW1hID0gei5vYmplY3Qoe1xyXG4gIGl0ZW1zOiB6LmFycmF5KEFkZEl0ZW1TY2hlbWEpLFxyXG4gIHJvb21JZDogei5zdHJpbmcoKS51dWlkKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpXHJcbn0pO1xyXG5jb25zdCBUb2dnbGVJdGVtU2NoZW1hID0gei5vYmplY3Qoe1xyXG4gIGl0ZW1JZDogei5zdHJpbmcoKS51dWlkKCksXHJcbiAgaXNDaGVja2VkOiB6LmJvb2xlYW4oKVxyXG59KTtcclxuY29uc3QgUm9vbUlkU2NoZW1hID0gei5zdHJpbmcoKS51dWlkKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpO1xyXG4vLyAxLiBBREQgSVRFTVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYWRkVG9TaG9wcGluZ0xpc3RBY3Rpb24oXHJcbiAgICBuYW1lOiBzdHJpbmcsIFxyXG4gICAgcXVhbnRpdHk6IG51bWJlciwgXHJcbiAgICB1bml0OiBzdHJpbmcsIFxyXG4gICAgZW1vamk/OiBzdHJpbmcsIFxyXG4gICAgcHJvZHVjdElkPzogc3RyaW5nLFxyXG4gICAgcHJvZHVjdEltYWdlPzogc3RyaW5nLFxyXG4gICAgZXN0aW1hdGVkQ29zdD86IG51bWJlcixcclxuICAgIHJvb21JZD86IHN0cmluZyB8IG51bGxcclxuKSB7XHJcbiAgdHJ5IHtcclxuICAgIGRlYnVnKCdbQUNUSU9OXSBhZGRUb1Nob3BwaW5nTGlzdCBzdGFydCcpO1xyXG5cclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICAgIGlmICghdXNlcikgdGhyb3cgbmV3IEVycm9yKFwiVW5hdXRob3JpemVkXCIpO1xyXG5cclxuICAgIGNvbnN0IHZhbGlkYXRpb24gPSBBZGRJdGVtU2NoZW1hLnNhZmVQYXJzZSh7IFxyXG4gICAgICAgIG5hbWUsIHF1YW50aXR5LCB1bml0LCBlbW9qaSwgcHJvZHVjdElkLCBwcm9kdWN0SW1hZ2UsIGVzdGltYXRlZENvc3QsIHJvb21JZFxyXG4gICAgfSk7XHJcbiAgICBcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSB7XHJcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkRhZGVzIGludsOgbGlkZXNcIiB9O1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHVzZUNhc2UgPSBjb250YWluZXIuZ2V0QWRkVG9TaG9wcGluZ0xpc3Qoc3VwYWJhc2UpO1xyXG4gICAgXHJcbiAgICBhd2FpdCB1c2VDYXNlLmV4ZWN1dGUoXHJcbiAgICAgICAgdXNlci5pZCwgXHJcbiAgICAgICAgdmFsaWRhdGlvbi5kYXRhLm5hbWUsIFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5xdWFudGl0eSwgXHJcbiAgICAgICAgdmFsaWRhdGlvbi5kYXRhLnVuaXQsXHJcbiAgICAgICAgdmFsaWRhdGlvbi5kYXRhLmVtb2ppLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5wcm9kdWN0SWQgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5wcm9kdWN0SW1hZ2UgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5lc3RpbWF0ZWRDb3N0IHx8IHVuZGVmaW5lZCxcclxuICAgICAgICB2YWxpZGF0aW9uLmRhdGEucm9vbUlkIHx8IHVuZGVmaW5lZFxyXG4gICAgKTtcclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL3Nob3BwaW5nLWxpc3QnKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxuXHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGxvZ0Vycm9yKCdhZGRUb1Nob3BwaW5nTGlzdCBmYWlsZWQnLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiTm8gcydoYSBwb2d1dCBhZmVnaXIgYSBsYSBsbGlzdGEuXCIgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIDIuIFRPR0dMRSBJVEVNXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB0b2dnbGVTaG9wcGluZ0l0ZW1BY3Rpb24oaXRlbUlkOiBzdHJpbmcsIGlzQ2hlY2tlZDogYm9vbGVhbikge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB2YWxpZGF0aW9uID0gVG9nZ2xlSXRlbVNjaGVtYS5zYWZlUGFyc2UoeyBpdGVtSWQsIGlzQ2hlY2tlZCB9KTtcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRGFkZXMgaW52w6BsaWRlc1wiIH07XHJcblxyXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICAgIGNvbnN0IHJlcG8gPSBjb250YWluZXIuZ2V0U2hvcHBpbmdMaXN0UmVwbyhzdXBhYmFzZSk7IFxyXG4gICAgYXdhaXQgcmVwby50b2dnbGVDaGVjayh2YWxpZGF0aW9uLmRhdGEuaXRlbUlkLCB2YWxpZGF0aW9uLmRhdGEuaXNDaGVja2VkKTtcclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL3Nob3BwaW5nLWxpc3QnKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ3RvZ2dsZVNob3BwaW5nSXRlbSBmYWlsZWQnLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRXJyb3IgYWN0dWFsaXR6YW50XCIgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIDMuIENPTVBMRVRFIFNFU1NJT05cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNvbXBsZXRlU2hvcHBpbmdTZXNzaW9uQWN0aW9uKHJvb21JZD86IHN0cmluZyB8IG51bGwpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgdmFsaWRhdGlvbiA9IFJvb21JZFNjaGVtYS5zYWZlUGFyc2Uocm9vbUlkKTtcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRGFkZXMgaW52w6BsaWRlc1wiIH07XHJcblxyXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICAgIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0gfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpO1xyXG4gICAgaWYgKCF1c2VyKSB0aHJvdyBuZXcgRXJyb3IoJ1VuYXV0aG9yaXplZCcpO1xyXG5cclxuICAgIGNvbnN0IHVzZUNhc2UgPSBjb250YWluZXIuZ2V0Q29tcGxldGVTaG9wcGluZ1Nlc3Npb24oc3VwYWJhc2UpO1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdXNlQ2FzZS5leGVjdXRlKHVzZXIuaWQsIHZhbGlkYXRpb24uZGF0YSB8fCB1bmRlZmluZWQpO1xyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvc2hvcHBpbmctbGlzdCcpO1xyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9pbnZlbnRvcnknKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGNvdW50OiByZXN1bHQuYWRkZWQgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoXCJFcnJvciBjb21wbGV0aW5nIHNob3BwaW5nIHNlc3Npb246XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciBmaW5hbGl0emFudCBsYSBjb21wcmFcIiB9O1xyXG4gIH1cclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYWRkQmF0Y2hUb1Nob3BwaW5nTGlzdEFjdGlvbihpdGVtczogei5pbmZlcjx0eXBlb2YgQWRkSXRlbVNjaGVtYT5bXSwgcm9vbUlkPzogc3RyaW5nIHwgbnVsbCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgICBpZiAoIXVzZXIpIHRocm93IG5ldyBFcnJvcihcIlVuYXV0aG9yaXplZFwiKTtcclxuXHJcbiAgICAvLyBWYWxpZGFyIGRhZGVzXHJcbiAgICBjb25zdCB2YWxpZGF0aW9uID0gQmF0Y2hJdGVtU2NoZW1hLnNhZmVQYXJzZSh7IGl0ZW1zLCByb29tSWQgfSk7XHJcbiAgICBpZiAoIXZhbGlkYXRpb24uc3VjY2VzcykgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkRhZGVzIGludsOgbGlkZXNcIiB9O1xyXG5cclxuICAgIGNvbnN0IHVzZUNhc2UgPSBjb250YWluZXIuZ2V0QWRkVG9TaG9wcGluZ0xpc3Qoc3VwYWJhc2UpO1xyXG5cclxuICAgIC8vIEV4ZWN1dGFyIGVuIHBhcmFswrdsZWwgKG8gcG9kcmllcyBmZXIgdW4gbG9vcCBzZXF1ZW5jaWFsIHNpIHZvbHMgZ2FyYW50aXIgb3JkcmUpXHJcbiAgICBhd2FpdCBQcm9taXNlLmFsbChpdGVtcy5tYXAoaXRlbSA9PiBcclxuICAgICAgdXNlQ2FzZS5leGVjdXRlKFxyXG4gICAgICAgIHVzZXIuaWQsXHJcbiAgICAgICAgaXRlbS5uYW1lLFxyXG4gICAgICAgIGl0ZW0ucXVhbnRpdHksXHJcbiAgICAgICAgaXRlbS51bml0LFxyXG4gICAgICAgIGl0ZW0uZW1vamksXHJcbiAgICAgICAgaXRlbS5wcm9kdWN0SWQgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIGl0ZW0ucHJvZHVjdEltYWdlIHx8IHVuZGVmaW5lZCxcclxuICAgICAgICBpdGVtLmVzdGltYXRlZENvc3QgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5yb29tSWQgfHwgdW5kZWZpbmVkXHJcbiAgICAgIClcclxuICAgICkpO1xyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvc2hvcHBpbmctbGlzdCcpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG5cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoXCJFcnJvciBhZGRpbmcgYmF0Y2g6XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciBndWFyZGFudCBwcm9kdWN0ZXNcIiB9O1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNob3BwaW5nTGlzdERhdGFBY3Rpb24ocm9vbUlkPzogc3RyaW5nIHwgbnVsbCkge1xyXG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgaWYgKCF1c2VyKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGlvbiA9IFJvb21JZFNjaGVtYS5zYWZlUGFyc2Uocm9vbUlkKTtcclxuICBpZiAoIXZhbGlkYXRpb24uc3VjY2VzcykgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkRhZGVzIGludsOgbGlkZXNcIiB9O1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgZ2V0U2hvcHBpbmdMaXN0ID0gY29udGFpbmVyLmdldEdldFNob3BwaW5nTGlzdChzdXBhYmFzZSk7XHJcbiAgICBjb25zdCBnZXRIaXN0b3J5ID0gY29udGFpbmVyLmdldEdldFNob3BwaW5nSGlzdG9yeShzdXBhYmFzZSk7XHJcblxyXG4gICAgY29uc3QgW2l0ZW1zLCBoaXN0b3J5XSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgZ2V0U2hvcHBpbmdMaXN0LmV4ZWN1dGUodXNlci5pZCwgdmFsaWRhdGlvbi5kYXRhIHx8IHVuZGVmaW5lZCksXHJcbiAgICAgIGdldEhpc3RvcnkuZXhlY3V0ZSh1c2VyLmlkLCB2YWxpZGF0aW9uLmRhdGEgfHwgdW5kZWZpbmVkKSxcclxuICAgIF0pO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IHRydWUsXHJcbiAgICAgIGRhdGE6IHtcclxuICAgICAgICBpdGVtczogbWFwSXRlbXNUb1ZpZXdNb2RlbChpdGVtcyksXHJcbiAgICAgICAgaGlzdG9yeTogbWFwSGlzdG9yeVRvVmlld01vZGVsKGhpc3RvcnkpLFxyXG4gICAgICB9LFxyXG4gICAgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ2dldFNob3BwaW5nTGlzdERhdGFBY3Rpb24gZmFpbGVkJywgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIk5vIHMnaGEgcG9ndXQgY2FycmVnYXIgbGEgbGxpc3RhLlwiIH07XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBtYXBJdGVtc1RvVmlld01vZGVsKGl0ZW1zOiBpbXBvcnQoJ0AvY29yZS9kb21haW4vZW50aXRpZXMvU2hvcHBpbmdMaXN0SXRlbScpLlNob3BwaW5nTGlzdEl0ZW1bXSkge1xyXG4gIHJldHVybiBpdGVtcy5tYXAoKGkpID0+ICh7XHJcbiAgICBpZDogaS5wcm9wcy5pZCxcclxuICAgIG5hbWU6IGkucHJvcHMubmFtZSxcclxuICAgIHF1YW50aXR5OiBpLnByb3BzLnF1YW50aXR5LFxyXG4gICAgdW5pdDogaS5wcm9wcy51bml0LFxyXG4gICAgaXNDaGVja2VkOiBpLnByb3BzLmlzQ2hlY2tlZCxcclxuICAgIGVtb2ppOiBpLnByb3BzLmVtb2ppLFxyXG4gICAgcHJvZHVjdElkOiBpLnByb3BzLnByb2R1Y3RJZCA/PyB1bmRlZmluZWQsXHJcbiAgICBwcm9kdWN0SW1hZ2U6IGkucHJvcHMucHJvZHVjdEltYWdlID8/IHVuZGVmaW5lZCxcclxuICAgIGVzdGltYXRlZENvc3Q6IGkucHJvcHMuZXN0aW1hdGVkQ29zdCA/PyB1bmRlZmluZWRcclxuICB9KSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIG1hcEhpc3RvcnlUb1ZpZXdNb2RlbChoaXN0b3J5OiBpbXBvcnQoJ0AvY29yZS9kb21haW4vZW50aXRpZXMvU2hvcHBpbmdTZXNzaW9uJykuU2hvcHBpbmdTZXNzaW9uW10pIHtcclxuICByZXR1cm4gaGlzdG9yeS5tYXAoKGgpID0+ICh7XHJcbiAgICBpZDogaC5wcm9wcy5pZCxcclxuICAgIGNyZWF0ZWRBdDogaC5wcm9wcy5jcmVhdGVkQXQsXHJcbiAgICB0b3RhbENvc3Q6IGgucHJvcHMudG90YWxDb3N0LFxyXG4gICAgaXRlbUNvdW50OiBoLnByb3BzLml0ZW1Db3VudCxcclxuICAgIGl0ZW1zU25hcHNob3Q6IGgucHJvcHMuaXRlbXNTbmFwc2hvdFxyXG4gIH0pKTtcclxufVxyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6InNUQWdHc0IsME1BQUEifQ==
}),
"[project]/components/onboarding/OnboardingContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OnboardingProvider",
    ()=>OnboardingProvider,
    "useOnboarding",
    ()=>useOnboarding
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
const OnboardingContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function OnboardingProvider({ children }) {
    _s();
    const [isActive, setIsActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [currentStepIndex, setCurrentStepIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [steps, setSteps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // Guardem quin tour estem fent per poder marcar-lo com a vist
    const [currentTourId, setCurrentTourId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const startTour = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OnboardingProvider.useCallback[startTour]": (tourId, newSteps, options = {})=>{
            if ("TURBOPACK compile-time truthy", 1) return;
            //TURBOPACK unreachable
            ;
            // Generem una clau única per aquest tour (ex: triatu_tour_seen_profile-setup)
            const storageKey = undefined;
            const hasSeen = undefined;
        }
    }["OnboardingProvider.useCallback[startTour]"], []);
    // ✅ Aquesta funció tanca el tour i GUANDA LA PREFERÈNCIA
    const finishTour = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OnboardingProvider.useCallback[finishTour]": ()=>{
            setIsActive(false);
            if (currentTourId) {
                // Guardem al navegador que aquest tour ja s'ha fet (o tancat)
                localStorage.setItem(`triatu_tour_seen_${currentTourId}`, 'true');
                console.log(`✅ [Onboarding] Tour '${currentTourId}' marcat com a vist.`);
            }
            // Resetegem per netejar
            setCurrentTourId('');
            setSteps([]);
            setCurrentStepIndex(0);
        }
    }["OnboardingProvider.useCallback[finishTour]"], [
        currentTourId
    ]);
    const nextStep = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OnboardingProvider.useCallback[nextStep]": ()=>{
            setCurrentStepIndex({
                "OnboardingProvider.useCallback[nextStep]": (prev)=>{
                    if (prev < steps.length - 1) {
                        return prev + 1;
                    } else {
                        finishTour(); // Si és l'últim pas, acabem i guardem
                        return prev;
                    }
                }
            }["OnboardingProvider.useCallback[nextStep]"]);
        }
    }["OnboardingProvider.useCallback[nextStep]"], [
        steps.length,
        finishTour
    ]);
    const prevStep = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OnboardingProvider.useCallback[prevStep]": ()=>{
            setCurrentStepIndex({
                "OnboardingProvider.useCallback[prevStep]": (prev)=>prev > 0 ? prev - 1 : prev
            }["OnboardingProvider.useCallback[prevStep]"]);
        }
    }["OnboardingProvider.useCallback[prevStep]"], []);
    // ✅ QUAN FEM CLICK A LA 'X'
    const skipTour = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OnboardingProvider.useCallback[skipTour]": ()=>{
            // Cridem a finishTour(), així que TAMBÉ ES GUARDA al localStorage
            finishTour();
        }
    }["OnboardingProvider.useCallback[skipTour]"], [
        finishTour
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OnboardingContext.Provider, {
        value: {
            isActive,
            currentStepIndex,
            steps,
            startTour,
            nextStep,
            prevStep,
            skipTour,
            finishTour
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/components/onboarding/OnboardingContext.tsx",
        lineNumber: 87,
        columnNumber: 5
    }, this);
}
_s(OnboardingProvider, "LwYR2QbA25DdOIzx6bjCxxgWgng=");
_c = OnboardingProvider;
function useOnboarding() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(OnboardingContext);
    if (!context) {
        throw new Error('useOnboarding must be used within an OnboardingProvider');
    }
    return context;
}
_s1(useOnboarding, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "OnboardingProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/onboarding/TourTrigger.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TourTrigger",
    ()=>TourTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$question$2d$mark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__HelpCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/circle-question-mark.js [app-client] (ecmascript) <export default as HelpCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/onboarding/OnboardingContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function TourTrigger({ steps, className, tourId }) {
    _s();
    const { startTour } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
        whileHover: {
            scale: 1.1,
            rotate: 10
        },
        whileTap: {
            scale: 0.9
        },
        onClick: ()=>{
            // ✅ { force: true } ignora el localStorage i l'activa igualment
            startTour(tourId, steps, {
                force: true
            }); // ✅ Passem l'ID
        },
        className: `
        flex items-center justify-center w-10 h-10 rounded-full 
        bg-slate-800 border border-slate-700 text-slate-400 
        hover:text-purple-400 hover:border-purple-500/50 hover:bg-slate-800/80
        transition-all shadow-lg z-50
        ${className}
      `,
        title: "Repetir la Guia 🆘",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$question$2d$mark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__HelpCircle$3e$__["HelpCircle"], {
            size: 20
        }, void 0, false, {
            fileName: "[project]/components/onboarding/TourTrigger.tsx",
            lineNumber: 34,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/onboarding/TourTrigger.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
}
_s(TourTrigger, "UeKKQgLVCaRaRTAKbwquCHh9TY8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"]
    ];
});
_c = TourTrigger;
var _c;
__turbopack_context__.k.register(_c, "TourTrigger");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/shoppingList/components/ShoppingListItem.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ShoppingListItem",
    ()=>ShoppingListItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
// ARXIU: src/features/shoppingList/components/ShoppingListItem.tsx
'use client';
;
;
function ShoppingListItem({ item, onToggle }) {
    const hasImage = !!item.productImage;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
        layout: true,
        initial: {
            opacity: 0,
            y: 5
        },
        animate: {
            opacity: 1,
            y: 0
        },
        exit: {
            opacity: 0
        },
        className: `
                group flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all select-none
                ${item.isChecked ? 'bg-emerald-950/20 border-emerald-900/30 opacity-60' : 'bg-slate-900 border-slate-800 hover:border-slate-700 hover:bg-slate-800'}
            `,
        onClick: ()=>onToggle(item.id, item.isChecked),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 min-w-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `
                    w-10 h-10 rounded-lg flex items-center justify-center overflow-hidden shrink-0 bg-white p-0.5
                    ${!hasImage && 'bg-transparent p-0'}
                `,
                        children: hasImage && item.productImage ? /* eslint-disable-next-line @next/next/no-img-element */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: item.productImage,
                            alt: item.name,
                            className: "w-full h-full object-contain"
                        }, void 0, false, {
                            fileName: "[project]/features/shoppingList/components/ShoppingListItem.tsx",
                            lineNumber: 48,
                            columnNumber: 25
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-2xl",
                            children: item.emoji || '📦'
                        }, void 0, false, {
                            fileName: "[project]/features/shoppingList/components/ShoppingListItem.tsx",
                            lineNumber: 54,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/shoppingList/components/ShoppingListItem.tsx",
                        lineNumber: 42,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col min-w-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `text-base truncate font-medium ${item.isChecked ? 'line-through text-slate-500' : 'text-slate-200'}`,
                                children: item.name
                            }, void 0, false, {
                                fileName: "[project]/features/shoppingList/components/ShoppingListItem.tsx",
                                lineNumber: 59,
                                columnNumber: 21
                            }, this),
                            item.estimatedCost && !item.isChecked && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[10px] text-emerald-400 font-mono",
                                children: [
                                    item.estimatedCost.toFixed(2),
                                    "€ /ut"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/shoppingList/components/ShoppingListItem.tsx",
                                lineNumber: 63,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/shoppingList/components/ShoppingListItem.tsx",
                        lineNumber: 58,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/shoppingList/components/ShoppingListItem.tsx",
                lineNumber: 41,
                columnNumber: 14
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col items-end pl-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "font-mono text-xs font-bold text-slate-400 bg-slate-950 px-2 py-1 rounded shrink-0",
                        children: [
                            item.quantity,
                            item.unit
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/shoppingList/components/ShoppingListItem.tsx",
                        lineNumber: 72,
                        columnNumber: 18
                    }, this),
                    item.estimatedCost && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[10px] font-mono font-bold text-slate-500 mt-1",
                        children: [
                            (item.estimatedCost * item.quantity).toFixed(2),
                            "€"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/shoppingList/components/ShoppingListItem.tsx",
                        lineNumber: 76,
                        columnNumber: 22
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/shoppingList/components/ShoppingListItem.tsx",
                lineNumber: 71,
                columnNumber: 14
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/shoppingList/components/ShoppingListItem.tsx",
        lineNumber: 27,
        columnNumber: 9
    }, this);
}
_c = ShoppingListItem;
var _c;
__turbopack_context__.k.register(_c, "ShoppingListItem");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ShoppingSessionDetail",
    ()=>ShoppingSessionDetail
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/format.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$ca$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/ca.js [app-client] (ecmascript)");
// ARXIU: src/features/shoppingList/components/history/ShoppingSessionDetail.tsx
'use client';
;
;
;
;
function ShoppingSessionDetail({ session, onClose }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm",
        onClick: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            initial: {
                opacity: 0,
                scale: 0.95,
                y: 20
            },
            animate: {
                opacity: 1,
                scale: 1,
                y: 0
            },
            exit: {
                opacity: 0,
                scale: 0.95
            },
            onClick: (e)=>e.stopPropagation(),
            className: "bg-white text-slate-900 w-full max-w-md rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[80vh]",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-slate-100 p-6 border-b border-dashed border-slate-300 text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-4xl mb-2",
                            children: "🧾"
                        }, void 0, false, {
                            fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                            lineNumber: 26,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-xl font-black uppercase tracking-widest text-slate-700",
                            children: "Rebut de Compra"
                        }, void 0, false, {
                            fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                            lineNumber: 27,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-slate-500 font-mono mt-1",
                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(session.createdAt, "d MMMM yyyy, HH:mm", {
                                locale: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$ca$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ca"]
                            })
                        }, void 0, false, {
                            fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                            lineNumber: 28,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                    lineNumber: 25,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1 overflow-y-auto p-6 space-y-4",
                    children: session.itemsSnapshot.map((item, idx)=>{
                        // ✅ Lògica visual: Té imatge guardada?
                        const hasImage = !!item.productImage;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-between items-start text-sm",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex gap-3 items-center min-w-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-10 h-10 rounded border border-slate-200 bg-slate-50 flex items-center justify-center shrink-0 overflow-hidden",
                                            children: hasImage ? /* eslint-disable-next-line @next/next/no-img-element */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: item.productImage,
                                                alt: item.name,
                                                className: "w-full h-full object-contain p-0.5"
                                            }, void 0, false, {
                                                fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                                                lineNumber: 46,
                                                columnNumber: 45
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xl leading-none",
                                                children: item.emoji || '📦'
                                            }, void 0, false, {
                                                fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                                                lineNumber: 52,
                                                columnNumber: 45
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                                            lineNumber: 43,
                                            columnNumber: 37
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-col min-w-0",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-bold text-slate-800 line-clamp-2 leading-tight",
                                                    children: item.name
                                                }, void 0, false, {
                                                    fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                                                    lineNumber: 57,
                                                    columnNumber: 41
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-slate-500 text-xs font-mono mt-0.5",
                                                    children: [
                                                        item.quantity,
                                                        item.unit,
                                                        " ",
                                                        item.estimatedCost ? `x ${item.estimatedCost.toFixed(2)}€` : ''
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                                                    lineNumber: 60,
                                                    columnNumber: 41
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                                            lineNumber: 56,
                                            columnNumber: 37
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                                    lineNumber: 41,
                                    columnNumber: 33
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "font-mono font-bold text-slate-700 ml-2",
                                    children: item.estimatedCost ? (item.estimatedCost * item.quantity).toFixed(2) + '€' : '-'
                                }, void 0, false, {
                                    fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                                    lineNumber: 65,
                                    columnNumber: 33
                                }, this)
                            ]
                        }, idx, true, {
                            fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                            lineNumber: 40,
                            columnNumber: 29
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                    lineNumber: 34,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-slate-900 text-white p-6 pb-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-between items-center text-slate-400 text-sm mb-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "Items totals"
                                }, void 0, false, {
                                    fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                                    lineNumber: 78,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "font-mono",
                                    children: session.itemCount
                                }, void 0, false, {
                                    fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                                    lineNumber: 79,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                            lineNumber: 77,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-between items-center text-3xl font-black pt-3 border-t border-slate-700/50",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "TOTAL"
                                }, void 0, false, {
                                    fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                                    lineNumber: 82,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-emerald-400",
                                    children: [
                                        session.totalCost.toFixed(2),
                                        "€"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                                    lineNumber: 83,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                            lineNumber: 81,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            className: "w-full mt-5 bg-slate-800 hover:bg-slate-700 py-3.5 rounded-xl font-bold transition-colors text-slate-200",
                            children: "Tancar Rebut"
                        }, void 0, false, {
                            fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                            lineNumber: 86,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
                    lineNumber: 76,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
            lineNumber: 17,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx",
        lineNumber: 16,
        columnNumber: 9
    }, this);
}
_c = ShoppingSessionDetail;
var _c;
__turbopack_context__.k.register(_c, "ShoppingSessionDetail");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/shoppingList/components/ShoppingHistory.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ShoppingHistory",
    ()=>ShoppingHistory
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/format.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$ca$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/ca.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$components$2f$history$2f$ShoppingSessionDetail$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/shoppingList/components/history/ShoppingSessionDetail.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// ARXIU: src/features/shoppingList/components/ShoppingHistory.tsx
'use client';
;
;
;
;
;
function ShoppingHistory({ sessions }) {
    _s();
    const [selectedSession, setSelectedSession] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // 1. Obtenir mesos disponibles únics
    const availableMonths = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ShoppingHistory.useMemo[availableMonths]": ()=>{
            const months = new Set(sessions.map({
                "ShoppingHistory.useMemo[availableMonths]": (s)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(s.createdAt, 'yyyy-MM')
            }["ShoppingHistory.useMemo[availableMonths]"]));
            return Array.from(months).sort().reverse(); // De més recent a més antic
        }
    }["ShoppingHistory.useMemo[availableMonths]"], [
        sessions
    ]);
    const [filterMonth, setFilterMonth] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(availableMonths[0] || '');
    // 2. Filtrar sessions
    const filteredSessions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ShoppingHistory.useMemo[filteredSessions]": ()=>{
            if (!filterMonth) return sessions;
            return sessions.filter({
                "ShoppingHistory.useMemo[filteredSessions]": (s)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(s.createdAt, 'yyyy-MM') === filterMonth
            }["ShoppingHistory.useMemo[filteredSessions]"]);
        }
    }["ShoppingHistory.useMemo[filteredSessions]"], [
        sessions,
        filterMonth
    ]);
    // 3. Calcular estadístiques del mes
    const monthlyTotal = filteredSessions.reduce((acc, s)=>acc + s.totalCost, 0);
    if (sessions.length === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center py-20 bg-slate-900/50 rounded-3xl border border-slate-800 border-dashed",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-4xl mb-4",
                    children: "📜"
                }, void 0, false, {
                    fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                    lineNumber: 46,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-slate-500",
                    children: "No tens historial de compres."
                }, void 0, false, {
                    fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                    lineNumber: 47,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
            lineNumber: 45,
            columnNumber: 13
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                children: selectedSession && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$components$2f$history$2f$ShoppingSessionDetail$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ShoppingSessionDetail"], {
                    session: selectedSession,
                    onClose: ()=>setSelectedSession(null)
                }, void 0, false, {
                    fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                    lineNumber: 56,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                lineNumber: 54,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-slate-900 p-4 rounded-2xl border border-slate-800 space-y-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "text-xs font-bold text-slate-500 uppercase",
                                        children: "Mes"
                                    }, void 0, false, {
                                        fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                                        lineNumber: 68,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        value: filterMonth,
                                        onChange: (e)=>setFilterMonth(e.target.value),
                                        className: "bg-slate-950 border border-slate-800 text-white text-sm rounded-lg px-3 py-1 outline-none focus:border-emerald-500",
                                        children: availableMonths.map((m)=>{
                                            const [year, month] = m.split('-');
                                            const date = new Date(parseInt(year), parseInt(month) - 1);
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: m,
                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(date, 'MMMM yyyy', {
                                                    locale: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$ca$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ca"]
                                                })
                                            }, m, false, {
                                                fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                                                lineNumber: 78,
                                                columnNumber: 37
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                                        lineNumber: 69,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                                lineNumber: 67,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-end justify-between pt-2 border-t border-slate-800",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-slate-400 text-sm",
                                        children: "Despesa total"
                                    }, void 0, false, {
                                        fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                                        lineNumber: 87,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-2xl font-black text-emerald-400",
                                        children: [
                                            monthlyTotal.toFixed(2),
                                            "€"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                                        lineNumber: 88,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                                lineNumber: 86,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                        lineNumber: 66,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-3 pb-32",
                        children: filteredSessions.map((session)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                whileHover: {
                                    scale: 1.01
                                },
                                whileTap: {
                                    scale: 0.98
                                },
                                onClick: ()=>setSelectedSession(session),
                                className: "bg-slate-900 p-4 rounded-xl border border-slate-800 hover:border-emerald-500/30 transition-all cursor-pointer group",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex justify-between items-center mb-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-col",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-slate-200 font-bold capitalize flex items-center gap-2",
                                                        children: [
                                                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(session.createdAt, "d MMM, EEEE", {
                                                                locale: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$ca$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ca"]
                                                            }),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded border border-slate-700 opacity-0 group-hover:opacity-100 transition-opacity",
                                                                children: "Veure detalls"
                                                            }, void 0, false, {
                                                                fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                                                                lineNumber: 108,
                                                                columnNumber: 41
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                                                        lineNumber: 106,
                                                        columnNumber: 37
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-xs text-slate-500",
                                                        children: [
                                                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(session.createdAt, "HH:mm"),
                                                            "h • ",
                                                            session.itemCount,
                                                            " productes"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                                                        lineNumber: 112,
                                                        columnNumber: 37
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                                                lineNumber: 105,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-right",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-emerald-400 font-black text-lg",
                                                    children: [
                                                        session.totalCost.toFixed(2),
                                                        "€"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                                                    lineNumber: 117,
                                                    columnNumber: 37
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                                                lineNumber: 116,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                                        lineNumber: 104,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex gap-1 overflow-hidden opacity-60 group-hover:opacity-100 transition-opacity",
                                        children: [
                                            session.itemsSnapshot.slice(0, 7).map((item, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "w-6 h-6 rounded bg-slate-950 flex items-center justify-center shrink-0 text-[10px] border border-slate-800",
                                                    children: item.emoji || '📦'
                                                }, idx, false, {
                                                    fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                                                    lineNumber: 126,
                                                    columnNumber: 37
                                                }, this)),
                                            session.itemsSnapshot.length > 7 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "w-6 h-6 rounded bg-slate-950 flex items-center justify-center shrink-0 text-[10px] border border-slate-800 text-slate-500",
                                                children: "+"
                                            }, void 0, false, {
                                                fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                                                lineNumber: 134,
                                                columnNumber: 37
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                                        lineNumber: 124,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, session.id, true, {
                                fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                                lineNumber: 97,
                                columnNumber: 25
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                        lineNumber: 95,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/shoppingList/components/ShoppingHistory.tsx",
                lineNumber: 63,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true);
}
_s(ShoppingHistory, "2D+DRZtfTVKv20Z0FudiWG+H6E0=");
_c = ShoppingHistory;
var _c;
__turbopack_context__.k.register(_c, "ShoppingHistory");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:04d964 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "searchProductsAction",
    ()=>$$RSC_SERVER_ACTION_7
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"40d49c562930eb6e6f0eee10da0020fae5257cecd1":"searchProductsAction"},"app/actions/inventory.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40d49c562930eb6e6f0eee10da0020fae5257cecd1", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "searchProductsAction");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vaW52ZW50b3J5LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEFSWElVOiBzcmMvYXBwL2FjdGlvbnMvaW52ZW50b3J5LnRzXHJcbid1c2Ugc2VydmVyJztcclxuXHJcbmltcG9ydCB7IHogfSBmcm9tICd6b2QnO1xyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gJ25leHQvY2FjaGUnO1xyXG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tICdAL2FkYXB0ZXJzL3N1cGFiYXNlL3NlcnZlcic7XHJcbmltcG9ydCB7IGNvbnRhaW5lciB9IGZyb20gJ0Avc2VydmljZXMvY29udGFpbmVyJztcclxuaW1wb3J0IHsgU3RvcmFnZUxvY2F0aW9uIH0gZnJvbSAnQC9jb3JlL2RvbWFpbi9lbnRpdGllcy9TdG9yYWdlTG9jYXRpb24nO1xyXG5pbXBvcnQgeyBJbnZlbnRvcnlJdGVtIH0gZnJvbSAnQC9jb3JlL2RvbWFpbi9lbnRpdGllcy9JbnZlbnRvcnlJdGVtJzsgLy8gQXNzZWd1cmEndCBxdWUgbCdFbnRpdHkgamEgdMOpIHJvb21JZCBhbCBjb25zdHJ1Y3RvciFcclxuaW1wb3J0IHsgRk9PRF9QUkVTRVRTIH0gZnJvbSAnQC9saWIvZm9vZC1wcmVzZXRzJztcclxuaW1wb3J0IHsgRXhwaXJ5U2FmZXR5U2VydmljZSB9IGZyb20gJ0AvY29yZS9hcHBsaWNhdGlvbi9zZXJ2aWNlcy9FeHBpcnlTYWZldHlTZXJ2aWNlJztcclxuaW1wb3J0IHsgRW1vamlNYXRjaGVyU2VydmljZSB9IGZyb20gJ0AvY29yZS9hcHBsaWNhdGlvbi9zZXJ2aWNlcy9FbW9qaU1hdGNoZXJTZXJ2aWNlJztcclxuaW1wb3J0IHsgZXJyb3IgYXMgbG9nRXJyb3IgfSBmcm9tICdAL2xpYi9sb2dnZXInO1xyXG5pbXBvcnQge1xyXG4gIEludmVudG9yeUl0ZW1TY2hlbWEsXHJcbiAgQ29uc3VtZUl0ZW1TY2hlbWEsXHJcbn0gZnJvbSAnQC9jb3JlL2FwcGxpY2F0aW9uL3NjaGVtYXMvaW5wdXRTY2hlbWFzJztcclxuXHJcbi8vIERlZmluaW0gcXXDqCByZXRvcm5lbSBhIGxhIFVJIChTZXJpYWxpdHphYmxlLCBzZW5zZSBjbGFzc2VzKVxyXG5leHBvcnQgaW50ZXJmYWNlIFByb2R1Y3RSZXN1bHQge1xyXG4gIGlkOiBzdHJpbmc7XHJcbiAgbmFtZTogc3RyaW5nO1xyXG4gIHByaWNlOiBudW1iZXI7XHJcbiAgaW1hZ2U6IHN0cmluZztcclxuICBzb3VyY2U6IHN0cmluZztcclxuICBlbW9qaTogc3RyaW5nO1xyXG4gIHRhZ3M6IHN0cmluZ1tdO1xyXG4gIHF1YW50aXR5QW1vdW50PzogbnVtYmVyO1xyXG4gIHF1YW50aXR5VW5pdD86IHN0cmluZztcclxufVxyXG5cclxuLy8gLS0tIEhFTFBFUlMgLS0tXHJcbmZ1bmN0aW9uIGNhbGN1bGF0ZUV4cGlyeURhdGUobmFtZTogc3RyaW5nLCBlbW9qaT86IHN0cmluZyk6IERhdGUgfCB1bmRlZmluZWQge1xyXG4gIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XHJcbiAgY29uc3QgcHJlc2V0ID0gRk9PRF9QUkVTRVRTLmZpbmQocCA9PlxyXG4gICAgcC5uYW1lLnRvTG93ZXJDYXNlKCkgPT09IG5hbWUudG9Mb3dlckNhc2UoKSB8fFxyXG4gICAgKGVtb2ppICYmIHAuZW1vamkgPT09IGVtb2ppKVxyXG4gICk7XHJcbiAgaWYgKHByZXNldCkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gbmV3IERhdGUoKTtcclxuICAgIHJlc3VsdC5zZXREYXRlKG5vdy5nZXREYXRlKCkgKyBwcmVzZXQuZXhwaXJhdGlvbkRheXMpO1xyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxuICB9XHJcbiAgcmV0dXJuIHVuZGVmaW5lZDtcclxufVxyXG5cclxuLy8gQWN0dWFsaXR6ZW0gbCdzY2hlbWEgcGVyIGFjY2VwdGFyIHJvb21JZFxyXG5jb25zdCBCYXRjaEludmVudG9yeVNjaGVtYSA9IHouYXJyYXkoSW52ZW50b3J5SXRlbVNjaGVtYS5vbWl0KHsgdXNlcklkOiB0cnVlIH0pLmV4dGVuZCh7IHJvb21JZDogei5zdHJpbmcoKS5vcHRpb25hbCgpIH0pKTtcclxuXHJcbmZ1bmN0aW9uIGdldFpvZEVycm9yKGVycm9yOiB6LlpvZEVycm9yPHVua25vd24+KTogc3RyaW5nIHsgcmV0dXJuIGVycm9yLmlzc3Vlc1swXT8ubWVzc2FnZSB8fCBcIkRhZGVzIGludsOgbGlkZXNcIjsgfVxyXG5mdW5jdGlvbiBnZXRFcnJvck1lc3NhZ2UoZXJyb3I6IHVua25vd24pOiBzdHJpbmcgeyByZXR1cm4gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBTdHJpbmcoZXJyb3IpOyB9XHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gMC4gR0VUIElOVkVOVE9SWSAoTk9WQSBBQ0NJw5MgUEVSIExMSVNUQVIpXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SW52ZW50b3J5QWN0aW9uKHJvb21JZD86IHN0cmluZykge1xyXG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgaWYgKCF1c2VyKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfTtcclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlcG8gPSBjb250YWluZXIuZ2V0SW52ZW50b3J5UmVwbyhzdXBhYmFzZSk7XHJcbiAgICAvLyBDcmlkZW0gYWwgbm91IG3DqHRvZGUgZGVsIHJlcG8gcXVlIHZhbSBjcmVhciBhbCBwYXMgYW50ZXJpb3JcclxuICAgIGNvbnN0IGl0ZW1zID0gYXdhaXQgcmVwby5maW5kQnlDb250ZXh0KHVzZXIuaWQsIHJvb21JZCk7XHJcblxyXG4gICAgLy8gU2VyaWFsaXR6ZW0gZGF0ZXMgcGVyIGFsIGNsaWVudFxyXG4gICAgY29uc3Qgc2VyaWFsaXplZCA9IGl0ZW1zLm1hcChpID0+ICh7XHJcbiAgICAgIC4uLmkudG9QcmltaXRpdmVzKCksXHJcbiAgICAgIGV4cGlyeURhdGU6IGkuZXhwaXJ5RGF0ZSA/IGkuZXhwaXJ5RGF0ZS50b0lTT1N0cmluZygpIDogbnVsbCxcclxuICAgICAgYWRkZWRBdDogaS5hZGRlZEF0LnRvSVNPU3RyaW5nKCksXHJcbiAgICAgIHJvb21JZDogaS5yb29tSWQgfHwgdW5kZWZpbmVkXHJcbiAgICB9KSk7XHJcblxyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgZGF0YTogc2VyaWFsaXplZCB9O1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldEVycm9yTWVzc2FnZShlcnJvcikgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAxLiBBREQgSVRFTSAoQW1iIHN1cG9ydCBSb29tKVxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFkZEl0ZW1BY3Rpb24oZm9ybURhdGE6IEZvcm1EYXRhKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICAgIGlmICghdXNlcikgdGhyb3cgbmV3IEVycm9yKCdVbmF1dGhvcml6ZWQnKTtcclxuXHJcbiAgICBjb25zdCBuYW1lID0gU3RyaW5nKGZvcm1EYXRhLmdldCgnbmFtZScpIHx8ICdQcm9kdWN0ZScpO1xyXG4gICAgbGV0IGVtb2ppID0gZm9ybURhdGEuZ2V0KCdlbW9qaScpPy50b1N0cmluZygpIHx8ICfwn5OmJztcclxuICAgIGNvbnN0IHJvb21JZCA9IGZvcm1EYXRhLmdldCgncm9vbUlkJyk/LnRvU3RyaW5nKCkgfHwgdW5kZWZpbmVkOyAvLyA8LS0tIExMRUdJTSBFTCBDT05URVhUXHJcblxyXG4gICAgLy8gRU5SSVFVSU1FTlQgRU1PSklcclxuICAgIGlmIChlbW9qaSA9PT0gJ/Cfk6YnIHx8IGVtb2ppID09PSAn8J+bkicpIHtcclxuICAgICAgY29uc3QgYmV0dGVyRW1vamkgPSBFbW9qaU1hdGNoZXJTZXJ2aWNlLmdldEVtb2ppKG5hbWUpO1xyXG4gICAgICBpZiAoYmV0dGVyRW1vamkgIT09ICfwn5OmJykgZW1vamkgPSBiZXR0ZXJFbW9qaTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBsb2NhdGlvbiA9IFN0cmluZyhmb3JtRGF0YS5nZXQoJ2xvY2F0aW9uJykgfHwgJ1BBTlRSWScpO1xyXG4gICAgbGV0IGV4cGlyeVN0cmluZyA9IGZvcm1EYXRhLmdldCgnZXhwaXJ5RGF0ZScpPy50b1N0cmluZygpO1xyXG5cclxuICAgIC8vIFNFR1VSRVRBVCBEQVRBXHJcbiAgICBpZiAoIWV4cGlyeVN0cmluZyB8fCBleHBpcnlTdHJpbmcgPT09ICdudWxsJyB8fCBleHBpcnlTdHJpbmcgPT09ICd1bmRlZmluZWQnIHx8IGV4cGlyeVN0cmluZyA9PT0gJycpIHtcclxuICAgICAgY29uc3Qgc2FmZURhdGVZTUQgPSBFeHBpcnlTYWZldHlTZXJ2aWNlLmFwcGx5U2FmZXR5UnVsZXMobmFtZSwgbG9jYXRpb24sIHVuZGVmaW5lZCk7XHJcbiAgICAgIGV4cGlyeVN0cmluZyA9IG5ldyBEYXRlKHNhZmVEYXRlWU1EKS50b0lTT1N0cmluZygpO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHJhd0RhdGEgPSB7XHJcbiAgICAgIHVzZXJJZDogdXNlci5pZCxcclxuICAgICAgbmFtZTogbmFtZSxcclxuICAgICAgcXVhbnRpdHk6IE51bWJlcihmb3JtRGF0YS5nZXQoJ3F1YW50aXR5JykpLFxyXG4gICAgICB1bml0OiBmb3JtRGF0YS5nZXQoJ3VuaXQnKSxcclxuICAgICAgbG9jYXRpb246IGxvY2F0aW9uLFxyXG4gICAgICBleHBpcnlEYXRlOiBleHBpcnlTdHJpbmcsXHJcbiAgICAgIGVtb2ppOiBlbW9qaSxcclxuICAgICAgcHJvZHVjdElkOiBmb3JtRGF0YS5nZXQoJ3Byb2R1Y3RJZCcpICYmIGZvcm1EYXRhLmdldCgncHJvZHVjdElkJykgIT09ICdudWxsJ1xyXG4gICAgICAgID8gU3RyaW5nKGZvcm1EYXRhLmdldCgncHJvZHVjdElkJykpXHJcbiAgICAgICAgOiBudWxsLFxyXG4gICAgICByb29tSWQ6IHJvb21JZCAvLyA8LS0tIFBBU1NFTSBFTCBST09NIElEIEFMIFZBTElEQVRPUlxyXG4gICAgfTtcclxuXHJcbiAgICAvLyBOZWNlc3NpdGVtIGVzdGVuZHJlIGwnc2NoZW1hIGJhc2UgcGVyIGFjY2VwdGFyIHJvb21JZCBzaSBubyBobyBmYVxyXG4gICAgY29uc3QgdmFsaWRhdGlvbiA9IEludmVudG9yeUl0ZW1TY2hlbWEuZXh0ZW5kKHsgcm9vbUlkOiB6LnN0cmluZygpLm9wdGlvbmFsKCkgfSkuc2FmZVBhcnNlKHJhd0RhdGEpO1xyXG5cclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSB7XHJcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZ2V0Wm9kRXJyb3IodmFsaWRhdGlvbi5lcnJvcikgfTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBmaW5hbERhdGEgPSB2YWxpZGF0aW9uLmRhdGE7XHJcbiAgICBjb25zdCBmaW5hbEV4cGlyeURhdGUgPSBmaW5hbERhdGEuZXhwaXJ5RGF0ZSA/IG5ldyBEYXRlKGZpbmFsRGF0YS5leHBpcnlEYXRlKSA6IHVuZGVmaW5lZDtcclxuXHJcbiAgICAvLyBVU0VNIEVMIFJFUE8gRElSRUNUQU1FTlQgKE8gVXNlQ2FzZSBhY3R1YWxpdHphdClcclxuICAgIC8vIFBlciBzaW1wbGlmaWNhciBpIGV2aXRhciB0b2NhciAxMCBhcnhpdXMgZGUgVXNlQ2FzZSwgYXF1w60gY3JpZGFyZW0gYWwgUmVwbyxcclxuICAgIC8vIGphIHF1ZSBBZGRJdGVtVXNlQ2FzZSBwb3RzZXIgbm8gZXNwZXJhIHJvb21JZC5cclxuICAgIC8vIEwnaWRlYWwgc2VyaWEgYWN0dWFsaXR6YXIgQWRkSXRlbVVzZUNhc2UsIHBlcsOyIGNvbSBxdWUgZWwgUmVwbyBqYSDDqXMgbGxlc3Q6XHJcbiAgICBjb25zdCByZXBvID0gY29udGFpbmVyLmdldEludmVudG9yeVJlcG8oc3VwYWJhc2UpO1xyXG5cclxuICAgIGNvbnN0IG5ld0l0ZW0gPSBJbnZlbnRvcnlJdGVtLmNyZWF0ZSh7XHJcbiAgICAgIGlkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxyXG4gICAgICB1c2VySWQ6IHVzZXIuaWQsXHJcbiAgICAgIHJvb21JZDogZmluYWxEYXRhLnJvb21JZCB8fCBudWxsLCAvLyA8LS0tIEFRVUkgRVMgR1VBUkRBIExBIE1BQUdJQVxyXG4gICAgICBuYW1lOiBTdHJpbmcoZmluYWxEYXRhLm5hbWUpLFxyXG4gICAgICBxdWFudGl0eTogTnVtYmVyKGZpbmFsRGF0YS5xdWFudGl0eSksXHJcbiAgICAgIHVuaXQ6IFN0cmluZyhmaW5hbERhdGEudW5pdCksXHJcbiAgICAgIGxvY2F0aW9uOiBmaW5hbERhdGEubG9jYXRpb24gYXMgU3RvcmFnZUxvY2F0aW9uLFxyXG4gICAgICBleHBpcnlEYXRlOiBmaW5hbEV4cGlyeURhdGUsXHJcbiAgICAgIGVtb2ppOiBTdHJpbmcoZmluYWxEYXRhLmVtb2ppKSxcclxuICAgICAgYWRkZWRBdDogbmV3IERhdGUoKSxcclxuICAgICAgcHJvZHVjdElkOiBmaW5hbERhdGEucHJvZHVjdElkXHJcbiAgICB9KTtcclxuXHJcbiAgICBhd2FpdCByZXBvLnNhdmUobmV3SXRlbSk7XHJcblxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvaW52ZW50b3J5Jyk7XHJcbiAgICBpZiAocm9vbUlkKSByZXZhbGlkYXRlUGF0aChgL3Jvb21zLyR7cm9vbUlkfWApOyAvLyBSZXZhbGlkYXIgc2FsYSBzaSBjYWxcclxuXHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcblxyXG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XHJcbiAgICBsb2dFcnJvcihcIvCfkqUgRXJyb3IgZmF0YWwgYSBhZGRJdGVtQWN0aW9uOlwiLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldEVycm9yTWVzc2FnZShlcnJvcikgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAyLiBDT05TVU1FIElURU0gKFNlbnNlIGNhbnZpcywgbCdJRCDDqXMgw7puaWMpXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY29uc3VtZUl0ZW1BY3Rpb24oaXRlbUlkOiBzdHJpbmcsIGFtb3VudDogbnVtYmVyKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHZhbGlkYXRpb24gPSBDb25zdW1lSXRlbVNjaGVtYS5zYWZlUGFyc2UoeyBpdGVtSWQsIGFtb3VudCB9KTtcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldFpvZEVycm9yKHZhbGlkYXRpb24uZXJyb3IpIH07XHJcblxyXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICAgIGNvbnN0IHVzZUNhc2UgPSBjb250YWluZXIuZ2V0Q29uc3VtZUl0ZW0oc3VwYWJhc2UpO1xyXG4gICAgLy8gRWwgVXNlQ2FzZSBub23DqXMgbmVjZXNzaXRhIGwnSUQuIEVsIFJlcG8gdHJvYmFyw6AgbCdpdGVtIHNpZ3VpIGRlIHNhbGEgbyB1c3VhcmkuXHJcbiAgICBhd2FpdCB1c2VDYXNlLmV4ZWN1dGUodmFsaWRhdGlvbi5kYXRhLml0ZW1JZCwgdmFsaWRhdGlvbi5kYXRhLmFtb3VudCk7XHJcblxyXG4gICAgLy8g4pyFIEFGRUdFSVggQUlYw5IgQUwgRklOQUwgREUgVE9UOlxyXG4gICAgLy8gQWl4w7Igb2JsaWdhIGEgTmV4dC5qcyBhIHJlZnJlc2NhciBsZXMgZGFkZXMgZGUgbGEgcnV0YSAvaW52ZW50b3J5IGF1dG9tw6B0aWNhbWVudFxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9pbnZlbnRvcnknKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxuICB9IGNhdGNoIChlcnJvcjogdW5rbm93bikge1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBnZXRFcnJvck1lc3NhZ2UoZXJyb3IpIH07XHJcbiAgfVxyXG59XHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gMy4gVVBEQVRFIElURU1cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbmludGVyZmFjZSBVcGRhdGVJdGVtRFRPIHsgaWQ6IHN0cmluZzsgbmFtZTogc3RyaW5nOyBxdWFudGl0eTogbnVtYmVyOyB1bml0OiBzdHJpbmc7IGVtb2ppOiBzdHJpbmc7IGV4cGlyeURhdGU/OiBEYXRlIHwgbnVsbDsgbG9jYXRpb24/OiBzdHJpbmc7IHJvb21JZD86IHN0cmluZzsgfVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUl0ZW1BY3Rpb24oaXRlbTogVXBkYXRlSXRlbURUTykge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgICBpZiAoIXVzZXIpIHRocm93IG5ldyBFcnJvcignVW5hdXRob3JpemVkJyk7XHJcblxyXG4gICAgaWYgKCFpdGVtLmlkIHx8ICFpdGVtLm5hbWUpIHRocm93IG5ldyBFcnJvcihcIkRhZGVzIGluY29tcGxldGVzXCIpO1xyXG5cclxuICAgIGNvbnN0IHJlcG8gPSBjb250YWluZXIuZ2V0SW52ZW50b3J5UmVwbyhzdXBhYmFzZSk7XHJcblxyXG4gICAgLy8gUmVjdXBlcmVtIGwnaXRlbSBvcmlnaW5hbCBwZXIgbm8gcGVyZHJlIGVsIHJvb21JZFxyXG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCByZXBvLmZpbmRCeUlkKGl0ZW0uaWQpO1xyXG4gICAgaWYgKCFleGlzdGluZykgdGhyb3cgbmV3IEVycm9yKFwiSXRlbSBub3QgZm91bmRcIik7XHJcblxyXG4gICAgLy8gQ3JlZW0gbGEgbm92YSB2ZXJzacOzIChJbW11dGFibGUpXHJcbiAgICBjb25zdCB1cGRhdGVkID0gSW52ZW50b3J5SXRlbS5jcmVhdGUoe1xyXG4gICAgICAuLi5leGlzdGluZy50b1ByaW1pdGl2ZXMoKSwgLy8gTWFudGVuaW0gZGFkZXMgdmVsbGVzIChjb20gYWRkZWRBdCwgcm9vbUlkLCB1c2VySWQpXHJcbiAgICAgIG5hbWU6IGl0ZW0ubmFtZSxcclxuICAgICAgZW1vamk6IGl0ZW0uZW1vamkgfHwgJ/Cfk6YnLFxyXG4gICAgICBxdWFudGl0eTogaXRlbS5xdWFudGl0eSxcclxuICAgICAgdW5pdDogaXRlbS51bml0LFxyXG4gICAgICBsb2NhdGlvbjogKGl0ZW0ubG9jYXRpb24gYXMgU3RvcmFnZUxvY2F0aW9uKSB8fCBTdG9yYWdlTG9jYXRpb24uUEFOVFJZLFxyXG4gICAgICBleHBpcnlEYXRlOiBpdGVtLmV4cGlyeURhdGUgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAvLyByb29tSWQgZXMgbWFudMOpIGRlIGwnb3JpZ2luYWwgYSB0b1ByaW1pdGl2ZXMoKSwgbyBlbCBwb3RzIGZvcsOnYXIgc2kgdm9sZ3Vlc3NpcyBtb3VyZSdsXHJcbiAgICB9KTtcclxuXHJcbiAgICBhd2FpdCByZXBvLnNhdmUodXBkYXRlZCk7XHJcblxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvaW52ZW50b3J5Jyk7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcbiAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZ2V0RXJyb3JNZXNzYWdlKGVycm9yKSB9O1xyXG4gIH1cclxufVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIDQuIERFTEVURSBJVEVNIChJZ3VhbClcclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVJdGVtQWN0aW9uKGl0ZW1JZDogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGlmICghaXRlbUlkKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiSUQgaW52w6BsaWRcIiB9O1xyXG5cclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICAvLyBBcXXDrSBwb2Ryw61lbSB1c2FyIGVsIFJlcG8gZGlyZWN0YW1lbnQgdGFtYsOpXHJcbiAgICBjb25zdCB1c2VDYXNlID0gY29udGFpbmVyLmdldERlbGV0ZUl0ZW0oc3VwYWJhc2UpO1xyXG4gICAgYXdhaXQgdXNlQ2FzZS5leGVjdXRlKGl0ZW1JZCk7XHJcblxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvaW52ZW50b3J5Jyk7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcbiAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZ2V0RXJyb3JNZXNzYWdlKGVycm9yKSB9O1xyXG4gIH1cclxufVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIDUuIEJVTEsgQUREIElURU1TXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYWRkQmF0Y2hJdGVtc0FjdGlvbihpdGVtczogei5pbmZlcjx0eXBlb2YgQmF0Y2hJbnZlbnRvcnlTY2hlbWE+KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICAgIGlmICghdXNlcikgdGhyb3cgbmV3IEVycm9yKCdVbmF1dGhvcml6ZWQnKTtcclxuXHJcbiAgICBjb25zdCB2YWxpZGF0aW9uID0gQmF0Y2hJbnZlbnRvcnlTY2hlbWEuc2FmZVBhcnNlKGl0ZW1zKTtcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldFpvZEVycm9yKHZhbGlkYXRpb24uZXJyb3IpIH07XHJcblxyXG4gICAgY29uc3QgcmVwbyA9IGNvbnRhaW5lci5nZXRJbnZlbnRvcnlSZXBvKHN1cGFiYXNlKTtcclxuXHJcbiAgICBjb25zdCBlbnRpdGllcyA9IHZhbGlkYXRpb24uZGF0YS5tYXAoZCA9PiB7XHJcbiAgICAgIGxldCBmaW5hbERhdGUgPSBkLmV4cGlyeURhdGUgPyBuZXcgRGF0ZShkLmV4cGlyeURhdGUpIDogdW5kZWZpbmVkO1xyXG4gICAgICBpZiAoIWZpbmFsRGF0ZSkge1xyXG4gICAgICAgIGZpbmFsRGF0ZSA9IGNhbGN1bGF0ZUV4cGlyeURhdGUoZC5uYW1lLCBkLmVtb2ppKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIEludmVudG9yeUl0ZW0uY3JlYXRlKHtcclxuICAgICAgICBpZDogY3J5cHRvLnJhbmRvbVVVSUQoKSxcclxuICAgICAgICB1c2VySWQ6IHVzZXIuaWQsXHJcbiAgICAgICAgcm9vbUlkOiBkLnJvb21JZCB8fCBudWxsLCAvLyA8LS0tIEFRVUkgVEFNQsOJXHJcbiAgICAgICAgbmFtZTogZC5uYW1lLFxyXG4gICAgICAgIHF1YW50aXR5OiBkLnF1YW50aXR5LFxyXG4gICAgICAgIHVuaXQ6IGQudW5pdCxcclxuICAgICAgICBsb2NhdGlvbjogZC5sb2NhdGlvbiBhcyBTdG9yYWdlTG9jYXRpb24sXHJcbiAgICAgICAgZXhwaXJ5RGF0ZTogZmluYWxEYXRlLFxyXG4gICAgICAgIGVtb2ppOiBkLmVtb2ppIHx8ICfwn5OmJyxcclxuICAgICAgICBhZGRlZEF0OiBuZXcgRGF0ZSgpLFxyXG4gICAgICAgIHByb2R1Y3RJZDogZC5wcm9kdWN0SWRcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBhd2FpdCByZXBvLnNhdmVCYXRjaChlbnRpdGllcyk7XHJcblxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvaW52ZW50b3J5Jyk7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcblxyXG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XHJcbiAgICBsb2dFcnJvcignRXJyb3IgaW4gYWRkQmF0Y2hJdGVtc0FjdGlvbjonLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldEVycm9yTWVzc2FnZShlcnJvcikgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyA2LiBRVUlDSyBBRERcclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBxdWlja0FkZEludmVudG9yeUFjdGlvbihcclxuICBuYW1lOiBzdHJpbmcsXHJcbiAgcXVhbnRpdHk6IG51bWJlcixcclxuICB1bml0OiBzdHJpbmcsXHJcbiAgZW1vamk/OiBzdHJpbmcsXHJcbiAgcHJvZHVjdElkPzogc3RyaW5nLFxyXG4gIHJvb21JZD86IHN0cmluZyAvLyA8LS0tIE5PVSBQQVLDgE1FVFJFXHJcbikge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgICBpZiAoIXVzZXIpIHRocm93IG5ldyBFcnJvcihcIlVuYXV0aG9yaXplZFwiKTtcclxuXHJcbiAgICBjb25zdCBleHBpcnlZTUQgPSBFeHBpcnlTYWZldHlTZXJ2aWNlLmFwcGx5U2FmZXR5UnVsZXMobmFtZSwgJ1BBTlRSWScsIHVuZGVmaW5lZCk7XHJcbiAgICBjb25zdCBleHBpcnlEYXRlID0gbmV3IERhdGUoZXhwaXJ5WU1EKTtcclxuXHJcbiAgICBjb25zdCByZXBvID0gY29udGFpbmVyLmdldEludmVudG9yeVJlcG8oc3VwYWJhc2UpO1xyXG5cclxuICAgIGNvbnN0IG5ld0l0ZW0gPSBJbnZlbnRvcnlJdGVtLmNyZWF0ZSh7XHJcbiAgICAgIGlkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxyXG4gICAgICB1c2VySWQ6IHVzZXIuaWQsXHJcbiAgICAgIHJvb21JZDogcm9vbUlkIHx8IG51bGwsIC8vIDwtLS0gR1VBUkRFTVxyXG4gICAgICBuYW1lOiBuYW1lLFxyXG4gICAgICBxdWFudGl0eTogcXVhbnRpdHksXHJcbiAgICAgIHVuaXQ6IHVuaXQsXHJcbiAgICAgIGxvY2F0aW9uOiBTdG9yYWdlTG9jYXRpb24uUEFOVFJZLFxyXG4gICAgICBleHBpcnlEYXRlOiBleHBpcnlEYXRlLFxyXG4gICAgICBlbW9qaTogZW1vamkgfHwgJ/Cfk6YnLFxyXG4gICAgICBhZGRlZEF0OiBuZXcgRGF0ZSgpLFxyXG4gICAgICBwcm9kdWN0SWQ6IHByb2R1Y3RJZCB8fCBudWxsXHJcbiAgICB9KTtcclxuXHJcbiAgICBhd2FpdCByZXBvLnNhdmUobmV3SXRlbSk7XHJcblxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvaW52ZW50b3J5Jyk7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcblxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBsb2dFcnJvcihcIkVycm9yIHF1aWNrIGFkZGluZyB0byBpbnZlbnRvcnk6XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciBhZmVnaW50IGEgbCdpbnZlbnRhcmkuXCIgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyA3LiBTRUFSQ0ggKElndWFsLCBubyBkZXDDqG4gZGUgbGEgc2FsYSlcclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZWFyY2hQcm9kdWN0c0FjdGlvbihxdWVyeTogc3RyaW5nKTogUHJvbWlzZTx7IHN1Y2Nlc3M6IGJvb2xlYW4sIGRhdGE/OiBQcm9kdWN0UmVzdWx0W10sIGVycm9yPzogc3RyaW5nIH0+IHtcclxuICBpZiAoIXF1ZXJ5IHx8IHF1ZXJ5Lmxlbmd0aCA8IDMpIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGRhdGE6IFtdIH07XHJcblxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gICAgY29uc3Qgc2VhcmNoZXIgPSBjb250YWluZXIuZ2V0U2VhcmNoQW5kQ2FjaGVQcm9kdWN0cyhzdXBhYmFzZSk7XHJcbiAgICBjb25zdCBwcm9kdWN0cyA9IGF3YWl0IHNlYXJjaGVyLmV4ZWN1dGUocXVlcnkpO1xyXG5cclxuICAgIGNvbnN0IHNlcmlhbGl6ZWQgPSBwcm9kdWN0cy5tYXAocCA9PiAoe1xyXG4gICAgICBpZDogcC5wcm9wcy5pZCxcclxuICAgICAgbmFtZTogcC5wcm9wcy5uYW1lLFxyXG4gICAgICBwcmljZTogcC5wcm9wcy5wcmljZSxcclxuICAgICAgaW1hZ2U6IHAucHJvcHMuaW1hZ2UsXHJcbiAgICAgIHNvdXJjZTogcC5wcm9wcy5zb3VyY2UsXHJcbiAgICAgIGVtb2ppOiBwLnByb3BzLmVtb2ppLFxyXG4gICAgICB0YWdzOiBwLnByb3BzLnRhZ3NcclxuICAgIH0pKTtcclxuXHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCBkYXRhOiBzZXJpYWxpemVkIH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGxvZ0Vycm9yKFwiRXJyb3IgY2VyY2FudCBwcm9kdWN0ZXM6XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJObyBzJ2hhIHBvZ3V0IGNvbXBsZXRhciBsYSBjZXJjYS5cIiB9O1xyXG4gIH1cclxufVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIDguIERFTEVURSBCQVRDSCAoSWd1YWwpXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlQmF0Y2hJdGVtc0FjdGlvbihpZHM6IHN0cmluZ1tdKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICAgIGlmICghdXNlcikgdGhyb3cgbmV3IEVycm9yKCdVbmF1dGhvcml6ZWQnKTtcclxuXHJcbiAgICBjb25zdCByZXBvID0gY29udGFpbmVyLmdldEludmVudG9yeVJlcG8oc3VwYWJhc2UpO1xyXG4gICAgYXdhaXQgcmVwby5iYXRjaERlbGV0ZShpZHMpO1xyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvZGFzaGJvYXJkL2ludmVudG9yeScpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldEVycm9yTWVzc2FnZShlcnJvcikgfTtcclxuICB9XHJcbn1cclxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJpU0FvVnNCLGlNQUFBIn0=
}),
"[project]/features/inventory/products/useProductSearch.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useProductSearch",
    ()=>useProductSearch
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$04d964__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:04d964 [app-client] (ecmascript) <text/javascript>");
var _s = __turbopack_context__.k.signature();
;
;
// ✅ HELPER: Neteja accents i minúscules per comparar millor
// "Tomàquet" -> "tomaquet"
const normalizeText = (text)=>{
    return text.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
};
function useProductSearch() {
    _s();
    const [activeCategory, setActiveCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [activeSubQuery, setActiveSubQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [manualSearch, setManualSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [results, setResults] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const performSearch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useProductSearch.useCallback[performSearch]": async (query, excludeList = [], mustContainList = [])=>{
            setLoading(true);
            try {
                let rawProducts = [];
                // A. FETCHING (Igual que abans)
                if (Array.isArray(query)) {
                    const promises = query.map({
                        "useProductSearch.useCallback[performSearch].promises": (q)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$04d964__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["searchProductsAction"])(q)
                    }["useProductSearch.useCallback[performSearch].promises"]);
                    const responses = await Promise.all(promises);
                    rawProducts = responses.filter({
                        "useProductSearch.useCallback[performSearch]": (res)=>res.success && res.data
                    }["useProductSearch.useCallback[performSearch]"]).flatMap({
                        "useProductSearch.useCallback[performSearch]": (res)=>res.data || []
                    }["useProductSearch.useCallback[performSearch]"]);
                } else {
                    const res = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$04d964__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["searchProductsAction"])(query);
                    if (res.success && res.data) rawProducts = res.data;
                }
                // B. UNIQUE MAP (Igual que abans)
                const uniqueProducts = Array.from(new Map(rawProducts.map({
                    "useProductSearch.useCallback[performSearch].uniqueProducts": (item)=>[
                            item.id,
                            item
                        ]
                }["useProductSearch.useCallback[performSearch].uniqueProducts"])).values());
                // C. FILTRES MILLORATS (NORMALITZACIÓ)
                const filteredResults = uniqueProducts.filter({
                    "useProductSearch.useCallback[performSearch].filteredResults": (product)=>{
                        // ✅ MILLORA: Normalitzem el nom del producte (sense accents)
                        const normalizedName = normalizeText(product.name);
                        // 1. EXCLUDE FILTER
                        if (excludeList.length > 0) {
                            const hasBadWord = excludeList.some({
                                "useProductSearch.useCallback[performSearch].filteredResults.hasBadWord": (badWord)=>normalizedName.includes(normalizeText(badWord)) // ✅ Comparació neta
                            }["useProductSearch.useCallback[performSearch].filteredResults.hasBadWord"]);
                            if (hasBadWord) return false;
                        }
                        // 2. MUST CONTAIN FILTER
                        if (mustContainList) {
                            const requiredWords = Array.isArray(mustContainList) ? mustContainList : [
                                mustContainList
                            ];
                            if (requiredWords.length > 0) {
                                const hasRequiredWord = requiredWords.some({
                                    "useProductSearch.useCallback[performSearch].filteredResults.hasRequiredWord": (goodWord)=>normalizedName.includes(normalizeText(goodWord)) // ✅ Comparació neta
                                }["useProductSearch.useCallback[performSearch].filteredResults.hasRequiredWord"]);
                                // Si no té la paraula clau, fora
                                if (!hasRequiredWord) return false;
                            }
                        }
                        return true;
                    }
                }["useProductSearch.useCallback[performSearch].filteredResults"]);
                setResults(filteredResults);
            } catch (e) {
                console.error("Error searching products:", e);
                setResults([]);
            } finally{
                setLoading(false);
            }
        }
    }["useProductSearch.useCallback[performSearch]"], []);
    // --- 2. EFFECT ---
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useProductSearch.useEffect": ()=>{
            if (!activeSubQuery && !manualSearch) {
                setResults([]);
                return;
            }
            // Manual Search
            if (manualSearch) {
                if (manualSearch.length < 3) return;
                const timeout = setTimeout({
                    "useProductSearch.useEffect.timeout": ()=>{
                        performSearch(manualSearch);
                    }
                }["useProductSearch.useEffect.timeout"], 500);
                return ({
                    "useProductSearch.useEffect": ()=>clearTimeout(timeout)
                })["useProductSearch.useEffect"];
            }
            // Category Search
            if (activeSubQuery) {
                let excludeList = [];
                let mustContainList = []; // ✅ Init variable
                if (activeCategory) {
                    // Find the active subcategory object to get its rules
                    // We handle the case where activeSubQuery is an array by comparing JSON strings or checking inclusion
                    const subCat = activeCategory.subcategories.find({
                        "useProductSearch.useEffect.subCat": (s)=>Array.isArray(s.query) && Array.isArray(activeSubQuery) ? JSON.stringify(s.query) === JSON.stringify(activeSubQuery) : s.query === activeSubQuery
                    }["useProductSearch.useEffect.subCat"]);
                    if (subCat) {
                        if (subCat.exclude) excludeList = subCat.exclude;
                        if (subCat.mustContain) mustContainList = subCat.mustContain; // ✅ Extract rule
                    }
                }
                // ✅ Pass both lists to search function
                performSearch(activeSubQuery, excludeList, mustContainList);
            }
        }
    }["useProductSearch.useEffect"], [
        activeSubQuery,
        manualSearch,
        activeCategory,
        performSearch
    ]);
    // --- 3. ACTIONS ---
    const selectCategory = (cat)=>{
        setActiveCategory(cat);
        setManualSearch('');
        if (cat.subcategories.length > 0) {
            setActiveSubQuery(cat.subcategories[0].query);
        }
    };
    const resetSearch = ()=>{
        setActiveCategory(null);
        setActiveSubQuery('');
        setResults([]);
        setManualSearch('');
    };
    const handleManualInput = (text)=>{
        setManualSearch(text);
        if (text) setActiveCategory(null);
    };
    return {
        activeCategory,
        activeSubQuery,
        manualSearch,
        results,
        loading,
        selectCategory,
        setActiveSubQuery,
        handleManualInput,
        resetSearch
    };
}
_s(useProductSearch, "2rV7z7ogGAVEI9r9FDd6D1MRec8=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/fruit.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FRUIT_CATEGORY",
    ()=>FRUIT_CATEGORY
]);
const FRUIT_CATEGORY = {
    id: 'fruit',
    label: 'Fruita',
    emoji: '🍎',
    gradient: 'from-red-900/30 to-orange-900/30 border-red-800/40',
    subcategories: [
        // --- 🍌 BÀSICS DE FRUITERIA ---
        {
            id: 'banana',
            label: 'Plàtan',
            emoji: '🍌',
            query: 'Plàtan banana',
            exclude: [
                'iogurt',
                'batut',
                'postre',
                'gelat',
                'xips',
                'fregit',
                'sec',
                'deshidratat',
                'galeta',
                'pastís',
                'brioix',
                'CAN'
            ]
        },
        {
            id: 'apple',
            label: 'Pomes',
            emoji: '🍎',
            // Totes les varietats fresques
            query: [
                'Poma Golden',
                'Poma Fuji',
                'Poma Royal Gala',
                'Poma Granny Smith'
            ],
            exclude: [
                'suc',
                'compota',
                'pastís',
                'sidra',
                'vinagre',
                'iogurt',
                'bossa',
                'xips',
                'forn',
                'caramel'
            ]
        },
        {
            id: 'pear',
            label: 'Peres',
            emoji: '🍐',
            query: [
                'Pera Conferència',
                'Pera Blanquilla',
                'Pera Ercolini',
                'Pera Llimonera'
            ],
            exclude: [
                'suc',
                'iogurt',
                'almívar',
                'pot',
                'conserva',
                'LA COLLITA',
                'Tomàquet'
            ]
        },
        // --- 🍊 CÍTRICS ---
        {
            id: 'orange',
            label: 'Taronges',
            emoji: '🍊',
            query: 'Taronja Premium',
            exclude: [
                'suc',
                'fanta',
                'kas',
                'refresc',
                'melmelada',
                'gelat',
                'iogurt',
                'galeta',
                'xocolata',
                'ambientador',
                'sabó',
                'detergent',
                'GRANINI' // "Taronja" surt molt a neteja
            ]
        },
        {
            id: 'mandarin',
            label: 'Mandarina',
            emoji: '🍊',
            query: [
                'Mans Mandarina'
            ],
            exclude: [
                'suc',
                'iogurt',
                'sorbet'
            ]
        },
        {
            id: 'lemon',
            label: 'Llimona/Llima',
            emoji: '🍋',
            query: [
                'LA COLLITA Llimona',
                'Llima'
            ],
            exclude: [
                'suc',
                'refresc',
                'fanta',
                'schweppes',
                'cervesa',
                'galeta',
                'iogurt',
                'postre',
                'neteja',
                'rentavaixelles',
                'lleixiu' // Molt important excloure neteja
            ]
        },
        // --- 🍓 VERMELLS I BOSC ---
        {
            id: 'strawberry',
            label: 'Maduixes',
            emoji: '🍓',
            query: [
                'Maduixa en caixa'
            ],
            exclude: [
                'iogurt',
                'batut',
                'melmelada',
                'gelat',
                'nata',
                'galeta',
                'caramel',
                'xiclet',
                'suc'
            ]
        },
        {
            id: 'cherry',
            label: 'Cireres/Picotes',
            emoji: '🍒',
            query: [
                'Cireres'
            ],
            exclude: [
                'iogurt',
                'melmelada',
                'bombó',
                'licor',
                'confitada',
                'pot'
            ]
        },
        {
            id: 'berries',
            label: 'Fruits del Bosc',
            emoji: '🫐',
            query: [
                'Nabius',
                'Gerds',
                'Mores',
                'Grosella'
            ],
            exclude: [
                'iogurt',
                'melmelada',
                'congelat',
                'sec',
                'deshidratat',
                'BICENTURY',
                'Coquetes',
                'moro'
            ]
        },
        // --- 🥝 TROPICAL ---
        {
            id: 'avocado',
            label: 'Alvocat',
            emoji: '🥑',
            query: [
                'Alvocat',
                'Alvocat hass'
            ],
            exclude: [
                'guacamole',
                'salsa',
                'oli',
                'crema'
            ] // Evitem el guacamole preparat
        },
        {
            id: 'kiwi',
            label: 'Kiwi',
            emoji: '🥝',
            query: [
                'Kiwi verd',
                'Kiwi groc',
                'Kiwi gold'
            ],
            exclude: [
                'iogurt',
                'suc',
                'gelat'
            ]
        },
        {
            id: 'mango',
            label: 'Mango',
            emoji: '🥭',
            query: [
                'Mango fresc'
            ],
            exclude: [
                'suc',
                'iogurt',
                'deshidratat',
                'tires',
                'chutney',
                'salsa'
            ]
        },
        {
            id: 'pineapple',
            label: 'Pinya',
            emoji: '🍍',
            query: [
                'Pinya'
            ],
            // Molta cura amb la pinya en llauna (almívar/suc)
            exclude: [
                'suc',
                'almívar',
                'llauna',
                'pot',
                'rodanxes',
                'trossos',
                'pizza',
                'iogurt'
            ]
        },
        {
            id: 'papaya',
            label: 'Papaia',
            emoji: '🥭',
            query: 'Papaies',
            exclude: [
                'deshidratada',
                'suc'
            ]
        },
        // --- 🍇 ESTACIONALS ---
        {
            id: 'melon',
            label: 'Meló',
            emoji: '🍈',
            query: [
                'Meló',
                'Melons'
            ],
            exclude: [
                'pernil',
                'xiclet',
                'iogurt',
                'tallejat',
                'PUERTO'
            ]
        },
        {
            id: 'watermelon',
            label: 'Síndria',
            emoji: '🍉',
            query: [
                'Síndries tmpoc hi an'
            ],
            exclude: [
                'xiclet',
                'caramel',
                'gaspatxo',
                'tallejada'
            ]
        },
        {
            id: 'peach',
            label: 'Préssec/Nectarina',
            emoji: '🍑',
            query: [
                'Préssecs no i han '
            ],
            exclude: [
                'suc',
                'iogurt',
                'almívar',
                'pot',
                'melmelada',
                'sec',
                'orellana'
            ]
        },
        {
            id: 'grape',
            label: 'Raïm',
            emoji: '🍇',
            query: [
                'Raïm blanc',
                'Raïm negre',
                'Raïm sense llavors'
            ],
            exclude: [
                'suc',
                'most',
                'panses',
                'vi',
                'cava'
            ] // "Panses" i "Vi" són els enemics aquí
        },
        {
            id: 'pomegranate',
            label: 'Magrana',
            emoji: '🍎',
            query: 'Punica granatum',
            exclude: [
                'suc',
                'iogurt'
            ]
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/vegetables.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VEGETABLES_CATEGORY",
    ()=>VEGETABLES_CATEGORY
]);
const VEGETABLES_CATEGORY = {
    id: 'vegetables',
    label: 'Verdura',
    emoji: '🥦',
    gradient: 'from-green-900/30 to-emerald-900/30 border-green-800/40',
    subcategories: [
        // --- BÀSICS CUINA ---
        {
            id: 'potato',
            label: 'Patates',
            emoji: '🥔',
            query: [
                'Patates',
                'Patata',
                'Patates mini en bossa'
            ],
            // Exclusions MOLT importants per netejar la llista
            exclude: [
                'xips',
                'fregides',
                'bravas',
                'congelades',
                'truita',
                'gnocchi',
                'snack',
                'pelades',
                'tonyina',
                'farcellets',
                'preparada',
                'microones',
                'deluxe',
                'puré',
                'lay\'s',
                'pringles',
                'ruffles',
                'doritos',
                'cheetos',
                'Ceba',
                'SANTA ANA',
                'fregir',
                'TERRA I TAST',
                'TERESA'
            ]
        },
        {
            id: 'onion',
            label: 'Cebes',
            emoji: '🧅',
            query: [
                'Ceba seca',
                'Ceba figueres',
                'Ceba morada',
                'Ceba dolça'
            ],
            exclude: [
                'fregida',
                'cruixent',
                'congelada',
                'caramel',
                'pot',
                'en pols',
                'LENOR',
                'PIERNAS GRANADA'
            ]
        },
        {
            id: 'garlic',
            label: 'Alls',
            emoji: '🧄',
            query: 'Alls secs',
            exclude: [
                'talls',
                'picada',
                'salsa',
                'oli'
            ]
        },
        {
            id: 'carrot',
            label: 'Pastanaga',
            emoji: '🥕',
            query: [
                'Pastanaga',
                'Pastanages',
                'fresca'
            ],
            exclude: [
                'ratllada',
                'brot',
                'pastís',
                'suc',
                'Burger',
                'Barreja',
                'PAGO',
                'HIPP'
            ] // Evitem pastanaga ratllada o sucs
        },
        // --- AMANIDA ---
        {
            id: 'lettuce',
            label: 'Enciam',
            emoji: '🥬',
            query: 'Enciam fresc',
            exclude: [
                'bossa'
            ] // Si vols evitar les bosses preparades, sinó treu-ho
        },
        {
            id: 'tomato',
            label: 'Tomàquet',
            emoji: '🍅',
            query: 'Tomàquet amanida',
            exclude: [
                'fregit',
                'triturat',
                'salsa',
                'sec'
            ]
        },
        {
            id: 'tomato_cherry',
            label: 'Cherry',
            emoji: '🍅',
            query: 'Tomàquet cherry',
            exclude: [
                'confitat'
            ]
        },
        {
            id: 'cucumber',
            label: 'Cogombre',
            emoji: '🥒',
            query: 'Cogombre',
            exclude: [
                'in vinagre',
                'adobats'
            ] // Evitem els de pot
        },
        // --- CUINAR ---
        {
            id: 'zucchini',
            label: 'Carbassó',
            emoji: '🥒',
            query: 'Carbassó',
            exclude: [
                'crema',
                'puré',
                'fregit'
            ]
        },
        {
            id: 'eggplant',
            label: 'Albergínia',
            emoji: '🍆',
            query: 'Albergínia',
            exclude: [
                'farcida',
                'arrebossada',
                'crema'
            ]
        },
        // --- 🌶️ PEBROTS MILLORATS ---
        {
            id: 'pepper_red',
            label: 'Pebrot Vermell',
            emoji: '🌶️',
            // ESTRATÈGIA: 
            // 1. "Pebrot vermell": El clàssic.
            // 2. "Pebrot tricolor": Molt important, sovint és l'única manera de comprar-ne.
            // 3. "Pebrot California": És la varietat tècnica del vermell gruixut.
            query: [
                'Pebrot vermell',
                'Pebrot tricolor',
                'Pebrot groc'
            ],
            // EXCLUSIONS:
            // "Piquillo" i "Nyora" solen sortir com a vermells però són conserves o secs.
            // "Escalivat" és el gran enemic aquí.
            exclude: [
                'escalivat',
                'farcit',
                'conserva',
                'melmelada',
                'bitxo',
                'pot',
                'llauna',
                'tires',
                'piquillo',
                'nyora',
                'fregit',
                'cuit',
                'verd',
                'Pebre'
            ]
        },
        {
            id: 'pepper_green',
            label: 'Pebrot Verd/Italià',
            emoji: '🫑',
            // ESTRATÈGIA:
            // 1. "Pebrot verd": El de carn gruixuda.
            // 2. "Pebrot italià": El llarg i prim (el més venut).
            // 3. "Pebrot Padrón": Els petits per fregir.
            query: [
                'Pebrot verd',
                'Pebrot italià',
                'Pebrot Padrón'
            ],
            exclude: [
                'fregit',
                'conserva',
                'vinagre',
                'bitxo',
                'guindilla',
                'IFA'
            ]
        },
        {
            id: 'mushrooms',
            label: 'Bolets',
            emoji: '🍄',
            // ESTRATÈGIA: Busquem les espècies concretes, no la paraula genèrica "Bolet"
            query: [
                'Xampinyó',
                'Portobello',
                'Gírgola',
                'Shiitake',
                'Bolets variats',
                'Mochardon' // Moixernó (a vegades fresc, a vegades sec, l'exclude farà la feina)
            ],
            // FILTRE ANTI-REBOST:
            exclude: [
                'conserva',
                'pot',
                'llauna',
                'sec',
                'deshidratat',
                'crema',
                'brou',
                'congelat',
                'risotto',
                'arròs',
                'fideus',
                'confitat',
                'saltat',
                'Burger' // Sol ser congelat
            ]
        },
        {
            id: 'spinach',
            label: 'Espinacs',
            emoji: '🍃',
            query: 'Espinacs frescos',
            exclude: [
                'congelat',
                'crema',
                'bossa',
                'TERRA I TAST',
                'Raviolis',
                'PETRAS'
            ]
        },
        {
            id: 'pumpkin',
            label: 'Carbassa',
            emoji: '🎃',
            query: 'Carbassa',
            exclude: [
                'crema',
                'cabell',
                'pipes'
            ] // Evitem crema de carbassa o cabell d'àngel
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/meat.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MEAT_CATEGORY",
    ()=>MEAT_CATEGORY
]);
const MEAT_CATEGORY = {
    id: 'meat',
    label: 'Carnisseria',
    emoji: '🥩',
    gradient: 'from-red-900/20 to-rose-900/20 border-red-800/30',
    subcategories: [
        // --- 🐔 POLLASTRE I AUS ---
        {
            id: 'chicken_breast',
            label: 'Pit de Pollastre',
            emoji: '🍗',
            query: [
                'Pit pollastre',
                'Filet de pollastre',
                'Pit de gall d\'indi'
            ],
            mustContain: [
                'pit',
                'filet'
            ],
            exclude: [
                'embotit',
                'cuit',
                'brasa',
                'fiambre',
                'llesques',
                'arrebossat',
                'croquetes',
                'canelons',
                'brou',
                'sopa',
                'gat',
                'gos',
                'piz'
            ]
        },
        {
            id: 'chicken_thigh',
            label: 'Cuixes',
            emoji: '🍗',
            query: [
                'Cuixa pollastre',
                'Pernilets pollastre',
                'Contra cuixa'
            ],
            mustContain: [
                'cuixa',
                'pernilet'
            ],
            exclude: [
                'farcit',
                'congelat',
                'preparat',
                'canelons',
                'brou'
            ]
        },
        {
            id: 'chicken_wings',
            label: 'Aletes',
            emoji: '🍗',
            query: 'Aletes pollastre',
            mustContain: 'Ales',
            exclude: [
                'barbacoa',
                'cuites',
                'congelat',
                'adobades'
            ]
        },
        {
            id: 'chicken_whole',
            label: 'Pollastre Sencer',
            emoji: '🐓',
            query: [
                'Pollastre sencer',
                'Pollastre net'
            ],
            mustContain: 'pollastre',
            exclude: [
                'a l\'ast',
                'cuit',
                'farcit',
                'brou',
                'croquetes'
            ]
        },
        {
            id: 'breaded',
            label: 'Arrebossats/Nuggets',
            emoji: '🍘',
            query: [
                'Pollastre arrebossat',
                'Nuggets'
            ],
            exclude: [
                'congelat',
                'vegetal'
            ]
        },
        // --- 🥩 VEDELLA ---
        {
            id: 'beef_steak',
            label: 'Bistec/Entrecot',
            emoji: '🥩',
            query: [
                'Bistec vedella',
                'Entrecot vedella',
                'Filet vedella'
            ],
            mustContain: [
                'bistec',
                'entrecot',
                'filet'
            ],
            exclude: [
                'hamburguesa',
                'carpaccio',
                'congelat',
                'brou',
                'pastilla'
            ]
        },
        {
            id: 'beef_stew',
            label: 'Vedella Estofar',
            emoji: '🥘',
            query: [
                'Estofat de vedella'
            ],
            exclude: [
                'cuinat',
                'brou',
                'conserva'
            ]
        },
        // --- 🐖 PORC ---
        {
            id: 'pork_loin',
            label: 'Llom',
            emoji: '🐖',
            query: [
                'Llom porc',
                'Cinta de llom'
            ],
            mustContain: 'llom',
            exclude: [
                'embotit',
                'curat',
                'cuit',
                'cap de llom',
                'adobat',
                'fumat',
                'llesques'
            ]
        },
        {
            id: 'pork_ribs',
            label: 'Costelles',
            emoji: '🍖',
            query: [
                'Costella porc',
                'Costelló'
            ],
            mustContain: [
                'costella',
                'costelló'
            ],
            exclude: [
                'barbacoa',
                'adobat',
                'cuit'
            ]
        },
        {
            id: 'sausages',
            label: 'Botifarres/Salsitxes',
            emoji: '🌭',
            query: [
                'Botifarra crua',
                'Salsitxes porc',
                'Salsitxes pollastre',
                'Llonganissa fresca'
            ],
            exclude: [
                'frankfurt',
                'cuit',
                'curada',
                'sec',
                'fuet',
                'vegana'
            ]
        },
        // --- 🍔 PREPARATS I PICADA ---
        {
            id: 'minced_meat',
            label: 'Carn Picada',
            emoji: '🍝',
            query: [
                'Carn picada',
                'Picada mixta',
                'Picada vedella',
                'Picada pollastre'
            ],
            mustContain: 'picada',
            exclude: [
                'congelada',
                'bolognesa',
                'salsa'
            ]
        },
        {
            id: 'burgers',
            label: 'Hamburgueses',
            emoji: '🍔',
            query: [
                'Burger meat',
                'Hamburguesa vedella',
                'Hamburguesa pollastre'
            ],
            mustContain: [
                'burger',
                'hamburguesa'
            ],
            exclude: [
                'pa',
                'vegetal',
                'vegana',
                'congelada',
                'mc',
                'ketchup'
            ]
        },
        // --- 🐑 TRADICIONAL ---
        {
            id: 'lamb',
            label: 'Xai',
            emoji: '🐑',
            query: [
                'Costelles xai',
                'Cuixa xai',
                'Espatlla xai'
            ],
            mustContain: 'xai',
            exclude: [
                'congelat'
            ]
        },
        {
            id: 'rabbit',
            label: 'Conill',
            emoji: '🐇',
            query: [
                'Conill sencer',
                'Conill trossejat',
                'Espatlla conill'
            ],
            mustContain: 'conill',
            exclude: [
                'menjar',
                'gat',
                'gos'
            ]
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/fish.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FISH_CATEGORY",
    ()=>FISH_CATEGORY
]);
const FISH_CATEGORY = {
    id: 'fish',
    label: 'Peixateria',
    emoji: '🐟',
    gradient: 'from-blue-900/20 to-cyan-900/20 border-blue-800/30',
    subcategories: [
        {
            id: 'salmon',
            label: 'Salmó',
            emoji: '🍣',
            query: 'Salmó fresc'
        },
        {
            id: 'hake',
            label: 'Lluç',
            emoji: '🐟',
            query: 'Lluç fresc'
        },
        {
            id: 'cod',
            label: 'Bacallà',
            emoji: '🐟',
            query: 'Bacallà'
        },
        {
            id: 'tuna',
            label: 'Tonyina',
            emoji: '🦈',
            query: 'Tonyina fresca'
        },
        {
            id: 'prawns',
            label: 'Gambes',
            emoji: '🦐',
            query: 'Gamba'
        },
        {
            id: 'mussels',
            label: 'Musclos',
            emoji: '🦪',
            query: 'Musclos'
        },
        {
            id: 'squid',
            label: 'Sípia/Calamar',
            emoji: '🦑',
            query: 'Sípia bruta'
        },
        {
            id: 'sushi',
            label: 'Sushi',
            emoji: '🍱',
            query: 'Sushi'
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/dairy.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DAIRY_CATEGORY",
    ()=>DAIRY_CATEGORY
]);
const DAIRY_CATEGORY = {
    id: 'dairy',
    label: 'Làctics i Ous',
    emoji: '🧀',
    gradient: 'from-amber-100/10 to-orange-100/10 border-orange-200/20',
    subcategories: [
        // Llet
        {
            id: 'milk_whole',
            label: 'Llet Sencera',
            emoji: '🥛',
            query: 'Llet sencera'
        },
        {
            id: 'milk_semi',
            label: 'Llet Semi',
            emoji: '🥛',
            query: 'Llet semidesnatada'
        },
        {
            id: 'milk_veg',
            label: 'Beguda Vegetal',
            emoji: '🌱',
            query: 'Beguda civada'
        },
        // Iogurts
        {
            id: 'yogurt',
            label: 'Iogurt Natural',
            emoji: '🥣',
            query: 'Iogurt natural'
        },
        {
            id: 'yogurt_flav',
            label: 'Iogurt Sabors',
            emoji: '🍓',
            query: 'Iogurt maduixa'
        },
        {
            id: 'dessert',
            label: 'Postres',
            emoji: '🍮',
            query: 'Natilles'
        },
        // Formatges
        {
            id: 'cheese_fresh',
            label: 'Formatge Fresc',
            emoji: '🧀',
            query: 'Formatge fresc'
        },
        {
            id: 'cheese_sliced',
            label: 'Formatge Talls',
            emoji: '🥪',
            query: 'Formatge talls'
        },
        {
            id: 'cheese_cured',
            label: 'Formatge Curat',
            emoji: '🧀',
            query: 'Formatge curat'
        },
        {
            id: 'cheese_grated',
            label: 'Formatge Ratllat',
            emoji: '🍝',
            query: 'Formatge ratllat'
        },
        // Altres
        {
            id: 'eggs',
            label: 'Ous',
            emoji: '🥚',
            query: 'Ous'
        },
        {
            id: 'butter',
            label: 'Mantega',
            emoji: '🧈',
            query: 'Mantega'
        },
        {
            id: 'cream',
            label: 'Nata Cuina',
            emoji: '🥘',
            query: 'Nata cuinar'
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/charcuterie.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CHARCUTERIE_CATEGORY",
    ()=>CHARCUTERIE_CATEGORY
]);
const CHARCUTERIE_CATEGORY = {
    id: 'charcuterie',
    label: 'Xarcuteria',
    emoji: '🥓',
    gradient: 'from-pink-900/20 to-rose-800/20 border-pink-800/30',
    subcategories: [
        {
            id: 'ham_sweet',
            label: 'Pernil Dolç',
            emoji: '🥪',
            query: 'Pernil cuit'
        },
        {
            id: 'turkey_breast',
            label: 'Pit Gall D\'indi',
            emoji: '🦃',
            query: 'Pit gall indi llesques'
        },
        {
            id: 'serrano',
            label: 'Pernil Salat',
            emoji: '🍖',
            query: 'Pernil serrano'
        },
        {
            id: 'fuet',
            label: 'Fuet/Llonganissa',
            emoji: '🥖',
            query: 'Fuet'
        },
        {
            id: 'chorizo',
            label: 'Xoriço',
            emoji: '🌭',
            query: 'Xoriço'
        },
        {
            id: 'frankfurt',
            label: 'Frankfurt',
            emoji: '🌭',
            query: 'Frankfurt'
        },
        {
            id: 'pate',
            label: 'Paté',
            emoji: '🍞',
            query: 'Paté'
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/pantry.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PANTRY_CATEGORY",
    ()=>PANTRY_CATEGORY
]);
const PANTRY_CATEGORY = {
    id: 'pantry',
    label: 'Rebost',
    emoji: '🥫',
    gradient: 'from-amber-900/20 to-yellow-900/20 border-amber-800/30',
    subcategories: [
        // Bàsics
        {
            id: 'oil',
            label: 'Oli Oliva',
            emoji: '🫒',
            query: 'Oli oliva verge'
        },
        {
            id: 'sunflower',
            label: 'Oli Gira-sol',
            emoji: '🌻',
            query: 'Oli gira-sol'
        },
        {
            id: 'pasta',
            label: 'Pasta',
            emoji: '🍝',
            query: 'Pasta'
        },
        {
            id: 'rice',
            label: 'Arròs',
            emoji: '🍚',
            query: 'Arròs'
        },
        {
            id: 'legumes',
            label: 'Llegums',
            emoji: '🫘',
            query: 'Cigrons cuits'
        },
        {
            id: 'sauce',
            label: 'Tomàquet/Salses',
            emoji: '🥫',
            query: 'Tomàquet fregit'
        },
        // Pa i Esmorzar
        {
            id: 'bread',
            label: 'Pa',
            emoji: '🥖',
            query: 'Pa barra'
        },
        {
            id: 'sliced_bread',
            label: 'Pa Motlle',
            emoji: '🍞',
            query: 'Pa motlle'
        },
        {
            id: 'cookies',
            label: 'Galetes',
            emoji: '🍪',
            query: 'Galetes'
        },
        {
            id: 'cereals',
            label: 'Cereals',
            emoji: '🥣',
            query: 'Cereals esmorzar'
        },
        {
            id: 'coffee',
            label: 'Cafè',
            emoji: '☕',
            query: 'Cafè molt'
        },
        {
            id: 'cocoa',
            label: 'Cacau',
            emoji: '🍫',
            query: 'Cacau pols'
        },
        // Conserves
        {
            id: 'tuna_can',
            label: 'Tonyina',
            emoji: '🐟',
            query: 'Tonyina oli'
        },
        {
            id: 'olives',
            label: 'Olives',
            emoji: '🫒',
            query: 'Olives'
        },
        {
            id: 'soup',
            label: 'Brou/Sopes',
            emoji: '🍲',
            query: 'Brou pollastre'
        },
        // Condiments
        {
            id: 'salt',
            label: 'Sal/Espècies',
            emoji: '🧂',
            query: 'Sal cuina'
        },
        {
            id: 'sugar',
            label: 'Sucre',
            emoji: '🍬',
            query: 'Sucre'
        },
        {
            id: 'sauces',
            label: 'Maionesa/Kètxup',
            emoji: '🌭',
            query: 'Maionesa'
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/frozen.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FROZEN_CATEGORY",
    ()=>FROZEN_CATEGORY
]);
const FROZEN_CATEGORY = {
    id: 'frozen',
    label: 'Congelats',
    emoji: '❄️',
    gradient: 'from-cyan-900/20 to-sky-900/20 border-cyan-800/30',
    subcategories: [
        {
            id: 'pizza',
            label: 'Pizza',
            emoji: '🍕',
            query: 'Pizza'
        },
        {
            id: 'veggies',
            label: 'Verdura',
            emoji: '🥦',
            query: 'Verdura congelada'
        },
        {
            id: 'chips',
            label: 'Patates Fregir',
            emoji: '🍟',
            query: 'Patates pre-fregides'
        },
        {
            id: 'fish',
            label: 'Peix/Marisc',
            emoji: '🐟',
            query: 'Peix congelat'
        },
        {
            id: 'croquettes',
            label: 'Croquetes',
            emoji: '🥟',
            query: 'Croquetes'
        },
        {
            id: 'icecream',
            label: 'Gelats',
            emoji: '🍦',
            query: 'Gelat'
        },
        {
            id: 'meals',
            label: 'Plats Preparats',
            emoji: '🥘',
            query: 'Lassanya congelada'
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/drinks.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DRINKS_CATEGORY",
    ()=>DRINKS_CATEGORY
]);
const DRINKS_CATEGORY = {
    id: 'drinks',
    label: 'Begudes',
    emoji: '🧃',
    gradient: 'from-purple-900/20 to-indigo-900/20 border-purple-800/30',
    subcategories: [
        {
            id: 'water',
            label: 'Aigua',
            emoji: '💧',
            query: 'Aigua mineral'
        },
        {
            id: 'soda',
            label: 'Refrescos',
            emoji: '🥤',
            query: 'Refresc'
        },
        {
            id: 'cola',
            label: 'Cola',
            emoji: '🥤',
            query: 'Refresc cola'
        },
        {
            id: 'beer',
            label: 'Cervesa',
            emoji: '🍺',
            query: 'Cervesa'
        },
        {
            id: 'wine',
            label: 'Vi',
            emoji: '🍷',
            query: 'Vi negre'
        },
        {
            id: 'juice',
            label: 'Sucs',
            emoji: '🍊',
            query: 'Suc'
        },
        {
            id: 'alcohol',
            label: 'Licors',
            emoji: '🥃',
            query: 'Ginebra'
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/dietary.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DIETARY_CATEGORY",
    ()=>DIETARY_CATEGORY
]);
const DIETARY_CATEGORY = {
    id: 'dietary',
    label: 'Dietes i Bio',
    emoji: '🌿',
    gradient: 'from-teal-900/30 to-green-800/30 border-teal-500/40',
    subcategories: [
        {
            id: 'eco',
            label: 'Ecològic',
            emoji: '🌱',
            query: 'Ecològic'
        },
        {
            id: 'gluten_free',
            label: 'Sense Gluten',
            emoji: '🌾',
            query: 'Sense gluten'
        },
        {
            id: 'lactose_free',
            label: 'Sense Lactosa',
            emoji: '🥛',
            query: 'Sense lactosa'
        },
        {
            id: 'vegan',
            label: 'Vegà',
            emoji: '🥬',
            query: 'Vegetal'
        },
        {
            id: 'protein',
            label: 'Proteïna +',
            emoji: '💪',
            query: 'Proteïna'
        },
        {
            id: 'diet',
            label: 'Dietètic',
            emoji: '📉',
            query: 'Integral'
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/household.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HOUSEHOLD_CATEGORY",
    ()=>HOUSEHOLD_CATEGORY
]);
const HOUSEHOLD_CATEGORY = {
    id: 'household',
    label: 'Llar i Higiene',
    emoji: '🧹',
    gradient: 'from-gray-800 to-slate-800 border-slate-600',
    subcategories: [
        // Neteja Llar
        {
            id: 'detergent',
            label: 'Detergent Roba',
            emoji: '👕',
            query: 'Detergent roba'
        },
        {
            id: 'softener',
            label: 'Suavitzant',
            emoji: '🌸',
            query: 'Suavitzant'
        },
        {
            id: 'dishwasher',
            label: 'Rentavaixelles',
            emoji: '🍽️',
            query: 'Rentavaixelles'
        },
        {
            id: 'cleaning',
            label: 'Netejadors',
            emoji: '🧼',
            query: 'Netejador llar'
        },
        {
            id: 'paper',
            label: 'Paper WC/Cuina',
            emoji: '🧻',
            query: 'Paper higiènic'
        },
        // Higiene Personal
        {
            id: 'shower',
            label: 'Gel/Xampú',
            emoji: '🚿',
            query: 'Gel bany'
        },
        {
            id: 'dental',
            label: 'Dental',
            emoji: '🦷',
            query: 'Pasta dents'
        },
        {
            id: 'deo',
            label: 'Desodorant',
            emoji: '🧴',
            query: 'Desodorant'
        },
        // Nadons
        {
            id: 'baby_food',
            label: 'Menjar Nadó',
            emoji: '👶',
            query: 'Potet'
        },
        {
            id: 'diapers',
            label: 'Bolquers',
            emoji: '👶',
            query: 'Bolquers'
        },
        // Mascotes
        {
            id: 'cat',
            label: 'Gats',
            emoji: '🐱',
            query: 'Menjar gat'
        },
        {
            id: 'dog',
            label: 'Gossos',
            emoji: '🐶',
            query: 'Menjar gos'
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/types.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/lib/taxonomy/types.ts
__turbopack_context__.s([]);
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FOOD_TAXONOMY",
    ()=>FOOD_TAXONOMY
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$fruit$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/fruit.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$vegetables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/vegetables.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$meat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/meat.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$fish$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/fish.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$dairy$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/dairy.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$charcuterie$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/charcuterie.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$pantry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/pantry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$frozen$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/frozen.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$drinks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/drinks.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$dietary$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/dietary.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$household$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/household.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/types.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
const FOOD_TAXONOMY = [
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$fruit$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FRUIT_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$vegetables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VEGETABLES_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$meat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MEAT_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$fish$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FISH_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$dairy$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAIRY_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$charcuterie$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CHARCUTERIE_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$pantry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PANTRY_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$frozen$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FROZEN_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$drinks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DRINKS_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$dietary$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DIETARY_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$household$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HOUSEHOLD_CATEGORY"]
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/inventory/products/components/CategoryGrid.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CategoryGrid",
    ()=>CategoryGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// ✅ FIX: Corregit 'taxonamy' -> 'taxonomy'
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/taxonamy/index.ts [app-client] (ecmascript) <locals>");
'use client';
;
;
function CategoryGrid({ onSelect }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "p-2 pb-32",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-6 text-center animate-in slide-in-from-top-4 fade-in duration-700",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-3xl font-black text-white mb-1",
                        children: "Què afegim? 😋"
                    }, void 0, false, {
                        fileName: "[project]/features/inventory/products/components/CategoryGrid.tsx",
                        lineNumber: 15,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-slate-400 text-sm",
                        children: "Tria una secció per començar"
                    }, void 0, false, {
                        fileName: "[project]/features/inventory/products/components/CategoryGrid.tsx",
                        lineNumber: 16,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/inventory/products/components/CategoryGrid.tsx",
                lineNumber: 14,
                columnNumber: 8
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3",
                children: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["FOOD_TAXONOMY"].map((cat, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>onSelect(cat),
                        // Animació escalonada (staggered) usant 'style' per l'index
                        style: {
                            animationDelay: `${index * 50}ms`
                        },
                        className: `
                   relative h-32 md:h-40 rounded-3xl overflow-hidden border border-white/5 
                   flex flex-col items-center justify-center gap-2
                   
                   // ✅ FIX: 'bg-gradient-to-br' és la classe estàndard de Tailwind
                   bg-gradient-to-br ${cat.gradient}
                   
                   hover:scale-[1.02] active:scale-95 transition-all duration-300
                   shadow-lg hover:shadow-xl group
                   animate-in zoom-in-50 fill-mode-backwards
                `,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute top-0 left-0 w-full h-full bg-white/0 group-hover:bg-white/10 transition-colors"
                            }, void 0, false, {
                                fileName: "[project]/features/inventory/products/components/CategoryGrid.tsx",
                                lineNumber: 40,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-5xl md:text-6xl filter drop-shadow-lg transform group-hover:-rotate-12 transition-transform duration-300",
                                children: cat.emoji
                            }, void 0, false, {
                                fileName: "[project]/features/inventory/products/components/CategoryGrid.tsx",
                                lineNumber: 43,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-bold text-white text-sm tracking-wide drop-shadow-md relative z-10",
                                children: cat.label
                            }, void 0, false, {
                                fileName: "[project]/features/inventory/products/components/CategoryGrid.tsx",
                                lineNumber: 48,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute -bottom-4 -right-4 w-20 h-20 bg-white/10 rounded-full blur-xl"
                            }, void 0, false, {
                                fileName: "[project]/features/inventory/products/components/CategoryGrid.tsx",
                                lineNumber: 53,
                                columnNumber: 17
                            }, this)
                        ]
                    }, cat.id, true, {
                        fileName: "[project]/features/inventory/products/components/CategoryGrid.tsx",
                        lineNumber: 22,
                        columnNumber: 14
                    }, this))
            }, void 0, false, {
                fileName: "[project]/features/inventory/products/components/CategoryGrid.tsx",
                lineNumber: 20,
                columnNumber: 8
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-24"
            }, void 0, false, {
                fileName: "[project]/features/inventory/products/components/CategoryGrid.tsx",
                lineNumber: 59,
                columnNumber: 8
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/inventory/products/components/CategoryGrid.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, this);
}
_c = CategoryGrid;
var _c;
__turbopack_context__.k.register(_c, "CategoryGrid");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/inventory/products/components/SubcategoryChips.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SubcategoryChips",
    ()=>SubcategoryChips
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
function SubcategoryChips({ category, activeQuery, onSelect }) {
    _s();
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Auto-scroll to selected chip
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SubcategoryChips.useEffect": ()=>{
            const activeEl = containerRef.current?.querySelector('[data-active="true"]');
            if (activeEl) {
                activeEl.scrollIntoView({
                    behavior: 'smooth',
                    block: 'nearest',
                    inline: 'center'
                });
            }
        }
    }["SubcategoryChips.useEffect"], [
        activeQuery
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: containerRef,
        className: "flex gap-2",
        children: category.subcategories.map((sub)=>{
            // ✅ Comparison logic for complex types (string vs array)
            // Since we are setting activeQuery directly from sub.query on click,
            // strict reference equality (===) might work if reference is preserved,
            // but robust comparison is safer for arrays.
            let isActive = false;
            if (Array.isArray(sub.query) && Array.isArray(activeQuery)) {
                // If both are arrays, simple JSON stringify comparison is usually enough for this use case
                // or checking if length and first element match.
                isActive = JSON.stringify(sub.query) === JSON.stringify(activeQuery);
            } else {
                // String comparison
                isActive = sub.query === activeQuery;
            }
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                "data-active": isActive,
                onClick: ()=>onSelect(sub.query),
                className: `
              flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold border transition-all duration-300 shrink-0
              ${isActive ? 'bg-white text-black border-white shadow-[0_0_15px_rgba(255,255,255,0.4)] scale-105 z-10' : 'bg-slate-800/50 text-slate-400 border-slate-700/50 hover:bg-slate-800 hover:text-slate-200'}
            `,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-base",
                        children: sub.emoji
                    }, void 0, false, {
                        fileName: "[project]/features/inventory/products/components/SubcategoryChips.tsx",
                        lineNumber: 53,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "uppercase tracking-wide",
                        children: sub.label
                    }, void 0, false, {
                        fileName: "[project]/features/inventory/products/components/SubcategoryChips.tsx",
                        lineNumber: 54,
                        columnNumber: 13
                    }, this)
                ]
            }, sub.id, true, {
                fileName: "[project]/features/inventory/products/components/SubcategoryChips.tsx",
                lineNumber: 41,
                columnNumber: 11
            }, this);
        })
    }, void 0, false, {
        fileName: "[project]/features/inventory/products/components/SubcategoryChips.tsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
}
_s(SubcategoryChips, "8puyVO4ts1RhCfXUmci3vLI3Njw=");
_c = SubcategoryChips;
var _c;
__turbopack_context__.k.register(_c, "SubcategoryChips");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/imageUtils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// =================== FILE: src/lib/imageUtils.ts ===================
__turbopack_context__.s([
    "getSafeImageUrl",
    ()=>getSafeImageUrl
]);
function getSafeImageUrl(url) {
    if (!url) return undefined;
    // Si és Bonpreu, el passem pel proxy que neteja el rastre i afegeix CORS
    if (url.includes('bonpreuesclat.cat')) {
        return `https://wsrv.nl/?url=${encodeURIComponent(url)}&w=600&output=webp`;
    }
    return url;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/inventory/products/components/ProductCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductCard",
    ()=>ProductCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$imageUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/imageUtils.ts [app-client] (ecmascript)");
;
;
function ProductCard({ product, quantity, onSelect }) {
    // ✅ 1. LÒGICA DE NETEJA: Treiem la marca "Bonpreu" per guanyar espai
    // Això elimina "BONPREU ", "BON PREU ", "Bonpreu " del principi.
    const cleanName = product.name.replace(/^(BON\s?PREU)\s+/i, '');
    const safeImageSrc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$imageUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSafeImageUrl"])(product.image);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        onClick: ()=>onSelect(product),
        "data-testid": `product-card-${product.id}`,
        className: `
        relative flex flex-col w-full h-full
        bg-slate-900 border rounded-xl overflow-hidden transition-all text-left shadow-md active:scale-95
        ${quantity > 0 ? 'border-emerald-500 ring-1 ring-emerald-500' : 'border-slate-800 hover:border-slate-600'}
      `,
        children: [
            quantity > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute top-1 right-1 z-20 bg-emerald-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center shadow-lg animate-in zoom-in",
                children: quantity
            }, void 0, false, {
                fileName: "[project]/features/inventory/products/components/ProductCard.tsx",
                lineNumber: 29,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "aspect-square w-full bg-white p-2 flex items-center justify-center relative overflow-hidden",
                children: [
                    product.image ? /* eslint-disable-next-line @next/next/no-img-element */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                        src: safeImageSrc,
                        alt: "",
                        className: "w-full h-full object-contain",
                        loading: "lazy"
                    }, void 0, false, {
                        fileName: "[project]/features/inventory/products/components/ProductCard.tsx",
                        lineNumber: 38,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-4xl",
                        children: product.emoji
                    }, void 0, false, {
                        fileName: "[project]/features/inventory/products/components/ProductCard.tsx",
                        lineNumber: 45,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute bottom-1 left-1 px-1 bg-slate-100 text-[8px] text-slate-500 rounded border border-slate-200",
                        children: product.source === 'BONPREU' ? 'BP' : 'DB'
                    }, void 0, false, {
                        fileName: "[project]/features/inventory/products/components/ProductCard.tsx",
                        lineNumber: 49,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/inventory/products/components/ProductCard.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 w-full p-2 flex flex-col justify-between bg-slate-900 gap-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                        className: "text-[11px] leading-tight line-clamp-3 md:text-sm md:leading-snug font-medium text-slate-300",
                        children: cleanName
                    }, void 0, false, {
                        fileName: "[project]/features/inventory/products/components/ProductCard.tsx",
                        lineNumber: 61,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between mt-auto pt-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xs md:text-sm font-bold text-emerald-400",
                                children: [
                                    product.price,
                                    "€"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/inventory/products/components/ProductCard.tsx",
                                lineNumber: 68,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-5 h-5 rounded bg-slate-800 flex items-center justify-center text-xs text-slate-400 md:w-6 md:h-6 md:text-sm",
                                children: "+"
                            }, void 0, false, {
                                fileName: "[project]/features/inventory/products/components/ProductCard.tsx",
                                lineNumber: 73,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/inventory/products/components/ProductCard.tsx",
                        lineNumber: 66,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/inventory/products/components/ProductCard.tsx",
                lineNumber: 55,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/inventory/products/components/ProductCard.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
}
_c = ProductCard;
var _c;
__turbopack_context__.k.register(_c, "ProductCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/inventory/products/components/ProductGrid.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductGrid",
    ()=>ProductGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$inventory$2f$products$2f$components$2f$ProductCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/inventory/products/components/ProductCard.tsx [app-client] (ecmascript)");
;
;
function ProductGrid({ loading, results, quantities, onSelect }) {
    // 1. LOADING STATE
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 animate-pulse",
            children: [
                1,
                2,
                3,
                4,
                5,
                6
            ].map((i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-56 bg-slate-800/50 rounded-xl border border-slate-800"
                }, i, false, {
                    fileName: "[project]/features/inventory/products/components/ProductGrid.tsx",
                    lineNumber: 17,
                    columnNumber: 11
                }, this))
        }, void 0, false, {
            fileName: "[project]/features/inventory/products/components/ProductGrid.tsx",
            lineNumber: 15,
            columnNumber: 7
        }, this);
    }
    // 2. EMPTY STATE
    if (results.length === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "col-span-full py-12 flex flex-col items-center justify-center text-slate-500 opacity-60",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-6xl mb-4 grayscale opacity-50",
                    children: "🧺"
                }, void 0, false, {
                    fileName: "[project]/features/inventory/products/components/ProductGrid.tsx",
                    lineNumber: 27,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-base font-medium",
                    children: "No s'han trobat productes."
                }, void 0, false, {
                    fileName: "[project]/features/inventory/products/components/ProductGrid.tsx",
                    lineNumber: 28,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-xs mt-1",
                    children: "Prova de buscar manualment."
                }, void 0, false, {
                    fileName: "[project]/features/inventory/products/components/ProductGrid.tsx",
                    lineNumber: 29,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/features/inventory/products/components/ProductGrid.tsx",
            lineNumber: 26,
            columnNumber: 7
        }, this);
    }
    // 3. RESULTS GRID
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-2 pb-32",
        children: results.map((product)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$inventory$2f$products$2f$components$2f$ProductCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProductCard"], {
                product: product,
                quantity: quantities[product.id] || 0,
                onSelect: onSelect
            }, product.id, false, {
                fileName: "[project]/features/inventory/products/components/ProductGrid.tsx",
                lineNumber: 38,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/features/inventory/products/components/ProductGrid.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
_c = ProductGrid;
var _c;
__turbopack_context__.k.register(_c, "ProductGrid");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/inventory/products/ProductExplorer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductExplorer",
    ()=>ProductExplorer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$inventory$2f$products$2f$useProductSearch$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/inventory/products/useProductSearch.ts [app-client] (ecmascript)");
// Components
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$inventory$2f$products$2f$components$2f$CategoryGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/inventory/products/components/CategoryGrid.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$inventory$2f$products$2f$components$2f$SubcategoryChips$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/inventory/products/components/SubcategoryChips.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$inventory$2f$products$2f$components$2f$ProductGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/inventory/products/components/ProductGrid.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function ProductExplorer({ onSelect, quantities, onClose }) {
    _s();
    const { activeCategory, activeSubQuery, manualSearch, results, loading, selectCategory, setActiveSubQuery, handleManualInput, resetSearch } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$inventory$2f$products$2f$useProductSearch$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProductSearch"])();
    // Estem dins d'una categoria o buscant manualment?
    const isBrowsing = !!activeCategory || !!manualSearch;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col h-full w-full bg-slate-950",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "shrink-0 bg-slate-950 z-20 border-b border-slate-800/50 relative shadow-md",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3 p-3",
                        children: [
                            !activeCategory ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 relative animate-in fade-in slide-in-from-left-2 duration-300",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        value: manualSearch,
                                        onChange: (e)=>handleManualInput(e.target.value),
                                        placeholder: "🔎 Què afegim avui?",
                                        "data-testid": "product-search-input",
                                        className: "w-full h-12 pl-12 pr-4 rounded-2xl bg-slate-900 border border-slate-800 text-white placeholder-slate-400 focus:ring-2 focus:ring-emerald-500/50 outline-none transition-all text-base font-medium shadow-inner",
                                        autoFocus: false
                                    }, void 0, false, {
                                        fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
                                        lineNumber: 46,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "absolute left-4 top-3 text-xl animate-pulse-slow",
                                        children: "⚡️"
                                    }, void 0, false, {
                                        fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
                                        lineNumber: 55,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
                                lineNumber: 45,
                                columnNumber: 16
                            }, this) : /* ESTAT B: NAVEGANT (Botó Enrere + Títol) */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 flex items-center gap-3 animate-in fade-in slide-in-from-right-2 duration-300 overflow-hidden",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: resetSearch,
                                        className: "h-12 w-12 shrink-0 flex items-center justify-center rounded-2xl bg-slate-800 border border-slate-700 hover:bg-slate-700 text-white transition-all active:scale-95",
                                        children: "↩"
                                    }, void 0, false, {
                                        fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
                                        lineNumber: 60,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 overflow-hidden",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-3xl filter drop-shadow-md",
                                                children: activeCategory.emoji
                                            }, void 0, false, {
                                                fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
                                                lineNumber: 68,
                                                columnNumber: 22
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "text-lg font-black text-white truncate uppercase tracking-tight",
                                                children: activeCategory.label
                                            }, void 0, false, {
                                                fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
                                                lineNumber: 69,
                                                columnNumber: 22
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
                                        lineNumber: 67,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
                                lineNumber: 59,
                                columnNumber: 16
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onClose,
                                "data-testid": "product-search-close",
                                className: "h-12 w-12 shrink-0 rounded-full bg-slate-900/50 text-slate-400 hover:text-white hover:bg-red-500/10 hover:border-red-500/50 border border-transparent flex items-center justify-center transition-all active:scale-90",
                                children: "✕"
                            }, void 0, false, {
                                fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
                                lineNumber: 77,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
                        lineNumber: 41,
                        columnNumber: 10
                    }, this),
                    activeCategory && !manualSearch && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-3 pb-3 overflow-x-auto scrollbar-hide animate-in slide-in-from-top-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$inventory$2f$products$2f$components$2f$SubcategoryChips$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SubcategoryChips"], {
                            category: activeCategory,
                            activeQuery: activeSubQuery,
                            onSelect: setActiveSubQuery
                        }, void 0, false, {
                            fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
                            lineNumber: 90,
                            columnNumber: 16
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
                        lineNumber: 89,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 overflow-y-auto overflow-x-hidden p-4 scroll-smooth",
                children: [
                    !isBrowsing && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "animate-in zoom-in-95 duration-300 pb-20",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$inventory$2f$products$2f$components$2f$CategoryGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CategoryGrid"], {
                            onSelect: selectCategory
                        }, void 0, false, {
                            fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
                            lineNumber: 105,
                            columnNumber: 14
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
                        lineNumber: 104,
                        columnNumber: 11
                    }, this),
                    isBrowsing && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "pb-32 animate-in slide-in-from-bottom-8 duration-500",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$inventory$2f$products$2f$components$2f$ProductGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProductGrid"], {
                            loading: loading,
                            results: results,
                            quantities: quantities,
                            onSelect: onSelect
                        }, void 0, false, {
                            fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
                            lineNumber: 112,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
                        lineNumber: 111,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
                lineNumber: 100,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/inventory/products/ProductExplorer.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}
_s(ProductExplorer, "4qS9IrYY42OTzLJwriF+SOcJWws=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$inventory$2f$products$2f$useProductSearch$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProductSearch"]
    ];
});
_c = ProductExplorer;
var _c;
__turbopack_context__.k.register(_c, "ProductExplorer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/inventory/products/CartDock.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CartDock",
    ()=>CartDock
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
function CartDock({ items, onRemove, onSave, isSaving }) {
    _s();
    const [isExpanded, setIsExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    if (items.length === 0) return null;
    const totalItems = items.reduce((acc, item)=>acc + item.quantity, 0);
    const totalPrice = items.reduce((acc, item)=>acc + item.product.price * item.quantity, 0);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            isExpanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                onClick: ()=>setIsExpanded(false),
                className: "fixed inset-0 bg-black/60 backdrop-blur-sm z-40 animate-in fade-in"
            }, void 0, false, {
                fileName: "[project]/features/inventory/products/CartDock.tsx",
                lineNumber: 30,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `
           fixed bottom-0 left-0 right-0 z-50 
           bg-slate-900 border-t border-slate-800 rounded-t-3xl shadow-[0_-10px_40px_rgba(0,0,0,0.5)]
           transition-all duration-500 cubic-bezier(0.32, 0.72, 0, 1)
           ${isExpanded ? 'translate-y-0' : 'translate-y-0'} 
        `,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        onClick: ()=>setIsExpanded(!isExpanded),
                        className: "w-full h-5 flex items-center justify-center cursor-pointer active:opacity-50 pt-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-12 h-1 bg-slate-700 rounded-full"
                        }, void 0, false, {
                            fileName: "[project]/features/inventory/products/CartDock.tsx",
                            lineNumber: 51,
                            columnNumber: 12
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/inventory/products/CartDock.tsx",
                        lineNumber: 47,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-4 pb-6 pt-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between mb-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setIsExpanded(!isExpanded),
                                        className: "flex items-center gap-3 text-left group",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "relative transition-transform group-active:scale-95",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-4xl filter drop-shadow-md",
                                                        children: "🛒"
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/inventory/products/CartDock.tsx",
                                                        lineNumber: 63,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "absolute -top-1 -right-2 bg-red-500 text-white text-[11px] font-bold h-5 w-5 flex items-center justify-center rounded-full border-2 border-slate-900 shadow-sm",
                                                        children: totalItems
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/inventory/products/CartDock.tsx",
                                                        lineNumber: 64,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/features/inventory/products/CartDock.tsx",
                                                lineNumber: 62,
                                                columnNumber: 18
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-col",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-[10px] text-slate-400 font-bold uppercase tracking-wider",
                                                        children: "Total estimat"
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/inventory/products/CartDock.tsx",
                                                        lineNumber: 69,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-xl font-black text-white leading-none",
                                                        children: [
                                                            totalPrice.toFixed(2),
                                                            "€"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/features/inventory/products/CartDock.tsx",
                                                        lineNumber: 70,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/features/inventory/products/CartDock.tsx",
                                                lineNumber: 68,
                                                columnNumber: 18
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/inventory/products/CartDock.tsx",
                                        lineNumber: 58,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: onSave,
                                        disabled: isSaving,
                                        className: "bg-emerald-500 hover:bg-emerald-400 text-white font-bold py-3 px-6 rounded-2xl shadow-lg shadow-emerald-900/20 active:scale-95 transition-all flex items-center gap-2",
                                        children: isSaving ? '...' : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: "Afegir"
                                                }, void 0, false, {
                                                    fileName: "[project]/features/inventory/products/CartDock.tsx",
                                                    lineNumber: 82,
                                                    columnNumber: 22
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "bg-black/10 px-1.5 py-0.5 rounded text-xs",
                                                    children: "↵"
                                                }, void 0, false, {
                                                    fileName: "[project]/features/inventory/products/CartDock.tsx",
                                                    lineNumber: 83,
                                                    columnNumber: 22
                                                }, this)
                                            ]
                                        }, void 0, true)
                                    }, void 0, false, {
                                        fileName: "[project]/features/inventory/products/CartDock.tsx",
                                        lineNumber: 75,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/inventory/products/CartDock.tsx",
                                lineNumber: 57,
                                columnNumber: 12
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `
              overflow-hidden transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)]
              ${isExpanded ? 'max-h-64 opacity-100 mt-4' : 'max-h-0 opacity-0'}
           `,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-[1px] w-full bg-slate-800 mb-4"
                                    }, void 0, false, {
                                        fileName: "[project]/features/inventory/products/CartDock.tsx",
                                        lineNumber: 94,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex gap-4 overflow-x-auto pb-4 pt-3 scrollbar-hide snap-x px-1",
                                        children: [
                                            items.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "relative flex-none w-20 group snap-start",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "absolute -top-2 -right-2 z-20 bg-slate-100 text-slate-900 text-[10px] font-black w-6 h-6 rounded-full flex items-center justify-center border-2 border-slate-900 shadow-md",
                                                            children: item.quantity
                                                        }, void 0, false, {
                                                            fileName: "[project]/features/inventory/products/CartDock.tsx",
                                                            lineNumber: 102,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "w-20 h-20 bg-white rounded-2xl flex items-center justify-center p-2 overflow-hidden border border-slate-700 relative shadow-sm",
                                                            children: [
                                                                item.product.image ? /* eslint-disable-next-line @next/next/no-img-element */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                                    src: item.product.image,
                                                                    className: "w-full h-full object-contain",
                                                                    alt: ""
                                                                }, void 0, false, {
                                                                    fileName: "[project]/features/inventory/products/CartDock.tsx",
                                                                    lineNumber: 110,
                                                                    columnNumber: 26
                                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-3xl",
                                                                    children: item.product.emoji
                                                                }, void 0, false, {
                                                                    fileName: "[project]/features/inventory/products/CartDock.tsx",
                                                                    lineNumber: 112,
                                                                    columnNumber: 26
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    onClick: ()=>onRemove(item.product.id),
                                                                    className: "absolute inset-0 bg-red-500/90 text-white opacity-0 group-hover:opacity-100 flex items-center justify-center font-bold text-2xl transition-all z-10 backdrop-blur-[2px]",
                                                                    children: "✕"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/features/inventory/products/CartDock.tsx",
                                                                    lineNumber: 116,
                                                                    columnNumber: 24
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/features/inventory/products/CartDock.tsx",
                                                            lineNumber: 107,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-[10px] text-slate-400 text-center mt-2 leading-tight line-clamp-2 w-full px-1 font-medium",
                                                            children: item.product.name
                                                        }, void 0, false, {
                                                            fileName: "[project]/features/inventory/products/CartDock.tsx",
                                                            lineNumber: 125,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, item.product.id, true, {
                                                    fileName: "[project]/features/inventory/products/CartDock.tsx",
                                                    lineNumber: 99,
                                                    columnNumber: 19
                                                }, this)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "w-2"
                                            }, void 0, false, {
                                                fileName: "[project]/features/inventory/products/CartDock.tsx",
                                                lineNumber: 132,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/inventory/products/CartDock.tsx",
                                        lineNumber: 97,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/inventory/products/CartDock.tsx",
                                lineNumber: 90,
                                columnNumber: 12
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/inventory/products/CartDock.tsx",
                        lineNumber: 54,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/inventory/products/CartDock.tsx",
                lineNumber: 37,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(CartDock, "FPNvbbHVlWWR4LKxxNntSxiIS38=");
_c = CartDock;
var _c;
__turbopack_context__.k.register(_c, "CartDock");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:03560d [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addBatchToShoppingListAction",
    ()=>$$RSC_SERVER_ACTION_3
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"60e15d4a3a617c223aea9279cc3932318d82d2f4d5":"addBatchToShoppingListAction"},"app/actions/shopping-list-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("60e15d4a3a617c223aea9279cc3932318d82d2f4d5", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "addBatchToShoppingListAction");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vc2hvcHBpbmctbGlzdC1hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc2VydmVyJztcclxuXHJcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2Uvc2VydmVyJztcclxuaW1wb3J0IHsgY29udGFpbmVyIH0gZnJvbSAnQC9zZXJ2aWNlcy9jb250YWluZXInO1xyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gJ25leHQvY2FjaGUnO1xyXG5pbXBvcnQgeyBkZWJ1ZywgZXJyb3IgYXMgbG9nRXJyb3IgfSBmcm9tICdAL2xpYi9sb2dnZXInO1xyXG5pbXBvcnQgeyB6IH0gZnJvbSAnem9kJztcclxuXHJcbmNvbnN0IEFkZEl0ZW1TY2hlbWEgPSB6Lm9iamVjdCh7XHJcbiAgbmFtZTogei5zdHJpbmcoKS5taW4oMSksXHJcbiAgcXVhbnRpdHk6IHoubnVtYmVyKCkucG9zaXRpdmUoKSxcclxuICB1bml0OiB6LnN0cmluZygpLFxyXG4gIGVtb2ppOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgcHJvZHVjdElkOiB6LnN0cmluZygpLm9wdGlvbmFsKCkubnVsbGFibGUoKSxcclxuICBwcm9kdWN0SW1hZ2U6IHouc3RyaW5nKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpLFxyXG4gIGVzdGltYXRlZENvc3Q6IHoubnVtYmVyKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpLFxyXG4gIHJvb21JZDogei5zdHJpbmcoKS51dWlkKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpXHJcbn0pO1xyXG4vLyDinIUgU2NoZW1hIHBlciB2YWxpZGFjacOzIG1hc3NpdmFcclxuY29uc3QgQmF0Y2hJdGVtU2NoZW1hID0gei5vYmplY3Qoe1xyXG4gIGl0ZW1zOiB6LmFycmF5KEFkZEl0ZW1TY2hlbWEpLFxyXG4gIHJvb21JZDogei5zdHJpbmcoKS51dWlkKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpXHJcbn0pO1xyXG5jb25zdCBUb2dnbGVJdGVtU2NoZW1hID0gei5vYmplY3Qoe1xyXG4gIGl0ZW1JZDogei5zdHJpbmcoKS51dWlkKCksXHJcbiAgaXNDaGVja2VkOiB6LmJvb2xlYW4oKVxyXG59KTtcclxuY29uc3QgUm9vbUlkU2NoZW1hID0gei5zdHJpbmcoKS51dWlkKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpO1xyXG4vLyAxLiBBREQgSVRFTVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYWRkVG9TaG9wcGluZ0xpc3RBY3Rpb24oXHJcbiAgICBuYW1lOiBzdHJpbmcsIFxyXG4gICAgcXVhbnRpdHk6IG51bWJlciwgXHJcbiAgICB1bml0OiBzdHJpbmcsIFxyXG4gICAgZW1vamk/OiBzdHJpbmcsIFxyXG4gICAgcHJvZHVjdElkPzogc3RyaW5nLFxyXG4gICAgcHJvZHVjdEltYWdlPzogc3RyaW5nLFxyXG4gICAgZXN0aW1hdGVkQ29zdD86IG51bWJlcixcclxuICAgIHJvb21JZD86IHN0cmluZyB8IG51bGxcclxuKSB7XHJcbiAgdHJ5IHtcclxuICAgIGRlYnVnKCdbQUNUSU9OXSBhZGRUb1Nob3BwaW5nTGlzdCBzdGFydCcpO1xyXG5cclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICAgIGlmICghdXNlcikgdGhyb3cgbmV3IEVycm9yKFwiVW5hdXRob3JpemVkXCIpO1xyXG5cclxuICAgIGNvbnN0IHZhbGlkYXRpb24gPSBBZGRJdGVtU2NoZW1hLnNhZmVQYXJzZSh7IFxyXG4gICAgICAgIG5hbWUsIHF1YW50aXR5LCB1bml0LCBlbW9qaSwgcHJvZHVjdElkLCBwcm9kdWN0SW1hZ2UsIGVzdGltYXRlZENvc3QsIHJvb21JZFxyXG4gICAgfSk7XHJcbiAgICBcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSB7XHJcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkRhZGVzIGludsOgbGlkZXNcIiB9O1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHVzZUNhc2UgPSBjb250YWluZXIuZ2V0QWRkVG9TaG9wcGluZ0xpc3Qoc3VwYWJhc2UpO1xyXG4gICAgXHJcbiAgICBhd2FpdCB1c2VDYXNlLmV4ZWN1dGUoXHJcbiAgICAgICAgdXNlci5pZCwgXHJcbiAgICAgICAgdmFsaWRhdGlvbi5kYXRhLm5hbWUsIFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5xdWFudGl0eSwgXHJcbiAgICAgICAgdmFsaWRhdGlvbi5kYXRhLnVuaXQsXHJcbiAgICAgICAgdmFsaWRhdGlvbi5kYXRhLmVtb2ppLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5wcm9kdWN0SWQgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5wcm9kdWN0SW1hZ2UgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5lc3RpbWF0ZWRDb3N0IHx8IHVuZGVmaW5lZCxcclxuICAgICAgICB2YWxpZGF0aW9uLmRhdGEucm9vbUlkIHx8IHVuZGVmaW5lZFxyXG4gICAgKTtcclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL3Nob3BwaW5nLWxpc3QnKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxuXHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGxvZ0Vycm9yKCdhZGRUb1Nob3BwaW5nTGlzdCBmYWlsZWQnLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiTm8gcydoYSBwb2d1dCBhZmVnaXIgYSBsYSBsbGlzdGEuXCIgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIDIuIFRPR0dMRSBJVEVNXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB0b2dnbGVTaG9wcGluZ0l0ZW1BY3Rpb24oaXRlbUlkOiBzdHJpbmcsIGlzQ2hlY2tlZDogYm9vbGVhbikge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB2YWxpZGF0aW9uID0gVG9nZ2xlSXRlbVNjaGVtYS5zYWZlUGFyc2UoeyBpdGVtSWQsIGlzQ2hlY2tlZCB9KTtcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRGFkZXMgaW52w6BsaWRlc1wiIH07XHJcblxyXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICAgIGNvbnN0IHJlcG8gPSBjb250YWluZXIuZ2V0U2hvcHBpbmdMaXN0UmVwbyhzdXBhYmFzZSk7IFxyXG4gICAgYXdhaXQgcmVwby50b2dnbGVDaGVjayh2YWxpZGF0aW9uLmRhdGEuaXRlbUlkLCB2YWxpZGF0aW9uLmRhdGEuaXNDaGVja2VkKTtcclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL3Nob3BwaW5nLWxpc3QnKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ3RvZ2dsZVNob3BwaW5nSXRlbSBmYWlsZWQnLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRXJyb3IgYWN0dWFsaXR6YW50XCIgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIDMuIENPTVBMRVRFIFNFU1NJT05cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNvbXBsZXRlU2hvcHBpbmdTZXNzaW9uQWN0aW9uKHJvb21JZD86IHN0cmluZyB8IG51bGwpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgdmFsaWRhdGlvbiA9IFJvb21JZFNjaGVtYS5zYWZlUGFyc2Uocm9vbUlkKTtcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRGFkZXMgaW52w6BsaWRlc1wiIH07XHJcblxyXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICAgIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0gfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpO1xyXG4gICAgaWYgKCF1c2VyKSB0aHJvdyBuZXcgRXJyb3IoJ1VuYXV0aG9yaXplZCcpO1xyXG5cclxuICAgIGNvbnN0IHVzZUNhc2UgPSBjb250YWluZXIuZ2V0Q29tcGxldGVTaG9wcGluZ1Nlc3Npb24oc3VwYWJhc2UpO1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdXNlQ2FzZS5leGVjdXRlKHVzZXIuaWQsIHZhbGlkYXRpb24uZGF0YSB8fCB1bmRlZmluZWQpO1xyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvc2hvcHBpbmctbGlzdCcpO1xyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9pbnZlbnRvcnknKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGNvdW50OiByZXN1bHQuYWRkZWQgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoXCJFcnJvciBjb21wbGV0aW5nIHNob3BwaW5nIHNlc3Npb246XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciBmaW5hbGl0emFudCBsYSBjb21wcmFcIiB9O1xyXG4gIH1cclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYWRkQmF0Y2hUb1Nob3BwaW5nTGlzdEFjdGlvbihpdGVtczogei5pbmZlcjx0eXBlb2YgQWRkSXRlbVNjaGVtYT5bXSwgcm9vbUlkPzogc3RyaW5nIHwgbnVsbCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgICBpZiAoIXVzZXIpIHRocm93IG5ldyBFcnJvcihcIlVuYXV0aG9yaXplZFwiKTtcclxuXHJcbiAgICAvLyBWYWxpZGFyIGRhZGVzXHJcbiAgICBjb25zdCB2YWxpZGF0aW9uID0gQmF0Y2hJdGVtU2NoZW1hLnNhZmVQYXJzZSh7IGl0ZW1zLCByb29tSWQgfSk7XHJcbiAgICBpZiAoIXZhbGlkYXRpb24uc3VjY2VzcykgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkRhZGVzIGludsOgbGlkZXNcIiB9O1xyXG5cclxuICAgIGNvbnN0IHVzZUNhc2UgPSBjb250YWluZXIuZ2V0QWRkVG9TaG9wcGluZ0xpc3Qoc3VwYWJhc2UpO1xyXG5cclxuICAgIC8vIEV4ZWN1dGFyIGVuIHBhcmFswrdsZWwgKG8gcG9kcmllcyBmZXIgdW4gbG9vcCBzZXF1ZW5jaWFsIHNpIHZvbHMgZ2FyYW50aXIgb3JkcmUpXHJcbiAgICBhd2FpdCBQcm9taXNlLmFsbChpdGVtcy5tYXAoaXRlbSA9PiBcclxuICAgICAgdXNlQ2FzZS5leGVjdXRlKFxyXG4gICAgICAgIHVzZXIuaWQsXHJcbiAgICAgICAgaXRlbS5uYW1lLFxyXG4gICAgICAgIGl0ZW0ucXVhbnRpdHksXHJcbiAgICAgICAgaXRlbS51bml0LFxyXG4gICAgICAgIGl0ZW0uZW1vamksXHJcbiAgICAgICAgaXRlbS5wcm9kdWN0SWQgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIGl0ZW0ucHJvZHVjdEltYWdlIHx8IHVuZGVmaW5lZCxcclxuICAgICAgICBpdGVtLmVzdGltYXRlZENvc3QgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5yb29tSWQgfHwgdW5kZWZpbmVkXHJcbiAgICAgIClcclxuICAgICkpO1xyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvc2hvcHBpbmctbGlzdCcpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG5cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoXCJFcnJvciBhZGRpbmcgYmF0Y2g6XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciBndWFyZGFudCBwcm9kdWN0ZXNcIiB9O1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNob3BwaW5nTGlzdERhdGFBY3Rpb24ocm9vbUlkPzogc3RyaW5nIHwgbnVsbCkge1xyXG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgaWYgKCF1c2VyKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGlvbiA9IFJvb21JZFNjaGVtYS5zYWZlUGFyc2Uocm9vbUlkKTtcclxuICBpZiAoIXZhbGlkYXRpb24uc3VjY2VzcykgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkRhZGVzIGludsOgbGlkZXNcIiB9O1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgZ2V0U2hvcHBpbmdMaXN0ID0gY29udGFpbmVyLmdldEdldFNob3BwaW5nTGlzdChzdXBhYmFzZSk7XHJcbiAgICBjb25zdCBnZXRIaXN0b3J5ID0gY29udGFpbmVyLmdldEdldFNob3BwaW5nSGlzdG9yeShzdXBhYmFzZSk7XHJcblxyXG4gICAgY29uc3QgW2l0ZW1zLCBoaXN0b3J5XSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgZ2V0U2hvcHBpbmdMaXN0LmV4ZWN1dGUodXNlci5pZCwgdmFsaWRhdGlvbi5kYXRhIHx8IHVuZGVmaW5lZCksXHJcbiAgICAgIGdldEhpc3RvcnkuZXhlY3V0ZSh1c2VyLmlkLCB2YWxpZGF0aW9uLmRhdGEgfHwgdW5kZWZpbmVkKSxcclxuICAgIF0pO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IHRydWUsXHJcbiAgICAgIGRhdGE6IHtcclxuICAgICAgICBpdGVtczogbWFwSXRlbXNUb1ZpZXdNb2RlbChpdGVtcyksXHJcbiAgICAgICAgaGlzdG9yeTogbWFwSGlzdG9yeVRvVmlld01vZGVsKGhpc3RvcnkpLFxyXG4gICAgICB9LFxyXG4gICAgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ2dldFNob3BwaW5nTGlzdERhdGFBY3Rpb24gZmFpbGVkJywgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIk5vIHMnaGEgcG9ndXQgY2FycmVnYXIgbGEgbGxpc3RhLlwiIH07XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBtYXBJdGVtc1RvVmlld01vZGVsKGl0ZW1zOiBpbXBvcnQoJ0AvY29yZS9kb21haW4vZW50aXRpZXMvU2hvcHBpbmdMaXN0SXRlbScpLlNob3BwaW5nTGlzdEl0ZW1bXSkge1xyXG4gIHJldHVybiBpdGVtcy5tYXAoKGkpID0+ICh7XHJcbiAgICBpZDogaS5wcm9wcy5pZCxcclxuICAgIG5hbWU6IGkucHJvcHMubmFtZSxcclxuICAgIHF1YW50aXR5OiBpLnByb3BzLnF1YW50aXR5LFxyXG4gICAgdW5pdDogaS5wcm9wcy51bml0LFxyXG4gICAgaXNDaGVja2VkOiBpLnByb3BzLmlzQ2hlY2tlZCxcclxuICAgIGVtb2ppOiBpLnByb3BzLmVtb2ppLFxyXG4gICAgcHJvZHVjdElkOiBpLnByb3BzLnByb2R1Y3RJZCA/PyB1bmRlZmluZWQsXHJcbiAgICBwcm9kdWN0SW1hZ2U6IGkucHJvcHMucHJvZHVjdEltYWdlID8/IHVuZGVmaW5lZCxcclxuICAgIGVzdGltYXRlZENvc3Q6IGkucHJvcHMuZXN0aW1hdGVkQ29zdCA/PyB1bmRlZmluZWRcclxuICB9KSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIG1hcEhpc3RvcnlUb1ZpZXdNb2RlbChoaXN0b3J5OiBpbXBvcnQoJ0AvY29yZS9kb21haW4vZW50aXRpZXMvU2hvcHBpbmdTZXNzaW9uJykuU2hvcHBpbmdTZXNzaW9uW10pIHtcclxuICByZXR1cm4gaGlzdG9yeS5tYXAoKGgpID0+ICh7XHJcbiAgICBpZDogaC5wcm9wcy5pZCxcclxuICAgIGNyZWF0ZWRBdDogaC5wcm9wcy5jcmVhdGVkQXQsXHJcbiAgICB0b3RhbENvc3Q6IGgucHJvcHMudG90YWxDb3N0LFxyXG4gICAgaXRlbUNvdW50OiBoLnByb3BzLml0ZW1Db3VudCxcclxuICAgIGl0ZW1zU25hcHNob3Q6IGgucHJvcHMuaXRlbXNTbmFwc2hvdFxyXG4gIH0pKTtcclxufVxyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6InFUQW9Ic0IseU1BQUEifQ==
}),
"[project]/features/shoppingList/components/BulkAddShoppingItemForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BulkAddShoppingItemForm",
    ()=>BulkAddShoppingItemForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$inventory$2f$products$2f$ProductExplorer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/inventory/products/ProductExplorer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$inventory$2f$products$2f$CartDock$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/inventory/products/CartDock.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$03560d__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:03560d [app-client] (ecmascript) <text/javascript>");
;
var _s = __turbopack_context__.k.signature();
// ARXIU: src/features/shoppingList/components/BulkAddShoppingItemForm.tsx
'use client';
;
;
;
;
function BulkAddShoppingItemForm({ onClose, activeRoomId }) {
    _s();
    const [cart, setCart] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isSaving, setIsSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Mapeig per saber quants en tenim seleccionats al explorador
    const quantitiesMap = cart.reduce((acc, item)=>{
        acc[item.product.id] = item.quantity;
        return acc;
    }, {});
    const handleSelect = (product)=>{
        setCart((prev)=>{
            const existing = prev.find((p)=>p.product.id === product.id);
            if (existing) {
                return prev.map((p)=>p.product.id === product.id ? {
                        ...p,
                        quantity: p.quantity + 1
                    } : p);
            }
            return [
                {
                    product,
                    quantity: 1
                },
                ...prev
            ];
        });
    };
    const handleRemove = (id)=>setCart((prev)=>prev.filter((p)=>p.product.id !== id));
    const handleSaveAll = async ()=>{
        if (cart.length === 0) return;
        setIsSaving(true);
        try {
            // Mapegem el carret al format que espera l'acció de la llista de la compra
            const itemsPayload = cart.map((item)=>({
                    name: item.product.name,
                    quantity: item.quantity,
                    unit: 'ut',
                    emoji: item.product.emoji,
                    productId: item.product.id,
                    productImage: item.product.image,
                    estimatedCost: item.product.price // ✅ Important: Passem el preu!
                }));
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$03560d__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["addBatchToShoppingListAction"])(itemsPayload, activeRoomId);
            if (result.success) {
                onClose();
            } else {
                alert("Error guardant: " + result.error);
            }
        } catch (e) {
            console.error(e);
        } finally{
            setIsSaving(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-50 flex flex-col bg-slate-950 animate-in fade-in slide-in-from-bottom-10 duration-200",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 overflow-hidden relative",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$inventory$2f$products$2f$ProductExplorer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProductExplorer"], {
                    onSelect: handleSelect,
                    quantities: quantitiesMap,
                    onClose: onClose
                }, void 0, false, {
                    fileName: "[project]/features/shoppingList/components/BulkAddShoppingItemForm.tsx",
                    lineNumber: 78,
                    columnNumber: 10
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/shoppingList/components/BulkAddShoppingItemForm.tsx",
                lineNumber: 77,
                columnNumber: 8
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$inventory$2f$products$2f$CartDock$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CartDock"], {
                items: cart,
                onRemove: handleRemove,
                onSave: handleSaveAll,
                isSaving: isSaving
            }, void 0, false, {
                fileName: "[project]/features/shoppingList/components/BulkAddShoppingItemForm.tsx",
                lineNumber: 87,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/shoppingList/components/BulkAddShoppingItemForm.tsx",
        lineNumber: 73,
        columnNumber: 5
    }, this);
}
_s(BulkAddShoppingItemForm, "10K1bhOuKKmYNoo9pyNtq1UmMHo=");
_c = BulkAddShoppingItemForm;
var _c;
__turbopack_context__.k.register(_c, "BulkAddShoppingItemForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/shoppingList/components/ShoppingHeader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ShoppingHeader",
    ()=>ShoppingHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// ARXIU: src/features/shoppingList/components/ShoppingHeader.tsx
'use client';
;
function ShoppingHeader({ activeTab, onTabChange, onSearchClick, tourId, contextSelector }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-2 sticky top-2 z-30",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: tourId,
                className: "flex-1 flex p-1 bg-slate-900 rounded-xl border border-slate-800 shadow-xl shadow-black/20",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>onTabChange('active'),
                        className: `flex-1 py-2 text-sm font-bold rounded-lg transition-all ${activeTab === 'active' ? 'bg-slate-800 text-white shadow ring-1 ring-slate-700' : 'text-slate-500 hover:text-slate-300'}`,
                        children: "🛒 Llista"
                    }, void 0, false, {
                        fileName: "[project]/features/shoppingList/components/ShoppingHeader.tsx",
                        lineNumber: 17,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>onTabChange('history'),
                        className: `flex-1 py-2 text-sm font-bold rounded-lg transition-all ${activeTab === 'history' ? 'bg-slate-800 text-white shadow ring-1 ring-slate-700' : 'text-slate-500 hover:text-slate-300'}`,
                        children: "📜 Historial"
                    }, void 0, false, {
                        fileName: "[project]/features/shoppingList/components/ShoppingHeader.tsx",
                        lineNumber: 23,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/shoppingList/components/ShoppingHeader.tsx",
                lineNumber: 16,
                columnNumber: 13
            }, this),
            contextSelector,
            activeTab === 'active' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                id: "tour-shopping-add-btn",
                onClick: onSearchClick,
                "data-testid": "shopping-add-button",
                className: "h-11.5 w-11.5 flex items-center justify-center bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl shadow-lg shadow-emerald-900/20 active:scale-95 transition-all border border-emerald-500/50",
                "aria-label": "Buscar productes",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-xl",
                    children: "🔎"
                }, void 0, false, {
                    fileName: "[project]/features/shoppingList/components/ShoppingHeader.tsx",
                    lineNumber: 42,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/shoppingList/components/ShoppingHeader.tsx",
                lineNumber: 35,
                columnNumber: 17
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/shoppingList/components/ShoppingHeader.tsx",
        lineNumber: 14,
        columnNumber: 9
    }, this);
}
_c = ShoppingHeader;
var _c;
__turbopack_context__.k.register(_c, "ShoppingHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/shoppingList/components/ShoppingStats.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ARXIU: src/features/shoppingList/components/ShoppingStats.tsx
__turbopack_context__.s([
    "ShoppingStats",
    ()=>ShoppingStats
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function ShoppingStats({ grandTotal, cartTotal }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-2 gap-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StatCard, {
                label: "Total Llista",
                amount: grandTotal
            }, void 0, false, {
                fileName: "[project]/features/shoppingList/components/ShoppingStats.tsx",
                lineNumber: 10,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StatCard, {
                label: "Al Carret",
                amount: cartTotal,
                isHighlight: true
            }, void 0, false, {
                fileName: "[project]/features/shoppingList/components/ShoppingStats.tsx",
                lineNumber: 11,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/shoppingList/components/ShoppingStats.tsx",
        lineNumber: 9,
        columnNumber: 9
    }, this);
}
_c = ShoppingStats;
function StatCard({ label, amount, isHighlight = false }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `
            p-4 rounded-2xl border flex flex-col items-center relative overflow-hidden
            ${isHighlight ? 'bg-emerald-950/30 border-emerald-900/50' : 'bg-slate-900/50 border-slate-800'}
        `,
        children: [
            isHighlight && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 bg-emerald-500/5 blur-xl"
            }, void 0, false, {
                fileName: "[project]/features/shoppingList/components/ShoppingStats.tsx",
                lineNumber: 22,
                columnNumber: 29
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: `text-[10px] uppercase tracking-wider font-bold relative z-10 ${isHighlight ? 'text-emerald-400' : 'text-slate-500'}`,
                children: label
            }, void 0, false, {
                fileName: "[project]/features/shoppingList/components/ShoppingStats.tsx",
                lineNumber: 23,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: `text-2xl font-black relative z-10 ${isHighlight ? 'text-emerald-400' : 'text-white'}`,
                children: [
                    amount.toFixed(2),
                    "€"
                ]
            }, void 0, true, {
                fileName: "[project]/features/shoppingList/components/ShoppingStats.tsx",
                lineNumber: 26,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/shoppingList/components/ShoppingStats.tsx",
        lineNumber: 18,
        columnNumber: 9
    }, this);
}
_c1 = StatCard;
var _c, _c1;
__turbopack_context__.k.register(_c, "ShoppingStats");
__turbopack_context__.k.register(_c1, "StatCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/shoppingList/components/ShoppingListContextSelector.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ShoppingListContextSelector",
    ()=>ShoppingListContextSelector
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/users.js [app-client] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/user.js [app-client] (ecmascript) <export default as User>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
;
;
function ShoppingListContextSelector({ scope, setScope, rooms }) {
    if (rooms.length === 0) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative group shrink-0",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute left-3 top-1/2 -translate-y-1/2 text-amber-300 pointer-events-none",
                children: scope === 'PERSONAL' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__["User"], {
                    size: 14
                }, void 0, false, {
                    fileName: "[project]/features/shoppingList/components/ShoppingListContextSelector.tsx",
                    lineNumber: 15,
                    columnNumber: 33
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                    size: 14
                }, void 0, false, {
                    fileName: "[project]/features/shoppingList/components/ShoppingListContextSelector.tsx",
                    lineNumber: 15,
                    columnNumber: 54
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/shoppingList/components/ShoppingListContextSelector.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                value: scope,
                onChange: (e)=>setScope(e.target.value),
                "data-testid": "shopping-scope-select",
                className: "appearance-none bg-slate-950/70 hover:bg-slate-900 text-slate-100 text-xs font-semibold py-2 pl-9 pr-8 rounded-full border border-amber-400/20 hover:border-amber-400/60 shadow-[0_0_0_1px_rgba(251,191,36,0.08)] transition-all cursor-pointer focus:outline-none focus:ring-2 focus:ring-amber-400/30",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                        value: "PERSONAL",
                        children: "Compra Personal"
                    }, void 0, false, {
                        fileName: "[project]/features/shoppingList/components/ShoppingListContextSelector.tsx",
                        lineNumber: 23,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("optgroup", {
                        label: "Sales Compartides",
                        children: rooms.map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: r.id,
                                children: r.name
                            }, r.id, false, {
                                fileName: "[project]/features/shoppingList/components/ShoppingListContextSelector.tsx",
                                lineNumber: 25,
                                columnNumber: 27
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/features/shoppingList/components/ShoppingListContextSelector.tsx",
                        lineNumber: 24,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/shoppingList/components/ShoppingListContextSelector.tsx",
                lineNumber: 17,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute right-3 top-1/2 -translate-y-1/2 text-amber-300/70 pointer-events-none",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                    size: 12
                }, void 0, false, {
                    fileName: "[project]/features/shoppingList/components/ShoppingListContextSelector.tsx",
                    lineNumber: 29,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/shoppingList/components/ShoppingListContextSelector.tsx",
                lineNumber: 28,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/shoppingList/components/ShoppingListContextSelector.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = ShoppingListContextSelector;
var _c;
__turbopack_context__.k.register(_c, "ShoppingListContextSelector");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:5b8b64 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getMyShoppingRoomsAction",
    ()=>$$RSC_SERVER_ACTION_6
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"000df75d1e51fd9c6784913db42cd897ac13c855d3":"getMyShoppingRoomsAction"},"app/actions/room-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("000df75d1e51fd9c6784913db42cd897ac13c855d3", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getMyShoppingRoomsAction");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vcm9vbS1hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc2VydmVyJ1xyXG5cclxuaW1wb3J0IHsgeiB9IGZyb20gJ3pvZCc7XHJcbmltcG9ydCB7IHJldmFsaWRhdGVQYXRoIH0gZnJvbSAnbmV4dC9jYWNoZSc7XHJcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2Uvc2VydmVyJztcclxuaW1wb3J0IHsgY29udGFpbmVyIH0gZnJvbSAnQC9zZXJ2aWNlcy9jb250YWluZXInO1xyXG5pbXBvcnQgeyBTdXBhYmFzZVJhdGVMaW1pdGVyIH0gZnJvbSAnQC9hZGFwdGVycy9zdXBhYmFzZS9TdXBhYmFzZVJhdGVMaW1pdGVyJztcclxuaW1wb3J0IHsgU3VwYWJhc2VTZWN1cml0eUxvZ2dlciB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2UvU3VwYWJhc2VTZWN1cml0eUxvZ2dlcic7XHJcbmltcG9ydCB7IGRlYnVnLCBlcnJvciBhcyBsb2dFcnJvciB9IGZyb20gJ0AvbGliL2xvZ2dlcic7XHJcbmltcG9ydCB7IFN1cGFiYXNlQ2FuZGlkYXRlUmVwb3NpdG9yeSB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2UvU3VwYWJhc2VDYW5kaWRhdGVSZXBvc2l0b3J5JztcclxuaW1wb3J0IHsgRGljdGlvbmFyeSB9IGZyb20gJ0AvbGliL2kxOG4vZGljdGlvbmFyaWVzJztcclxuaW1wb3J0IHsgY2hlY2tSb29tRGFpbHlMaW1pdCB9IGZyb20gJ0AvbGliL3NlY3VyaXR5L2RlY2lzaW9uLWxpbWl0JztcclxuXHJcbmltcG9ydCB7IENyZWF0ZVJvb21TY2hlbWEsIFBhcnRpY2lwYW50QWN0aW9uU2NoZW1hIH0gZnJvbSAnQC9jb3JlL2FwcGxpY2F0aW9uL3NjaGVtYXMvaW5wdXRTY2hlbWFzJztcclxuaW1wb3J0IHsgRGlldGFyeVJlc3RyaWN0aW9uIH0gZnJvbSAnQC9jb3JlL2RvbWFpbi92YWx1ZS1vYmplY3RzL0RpZXRhcnlSZXN0cmljdGlvbic7XHJcbi8vIC0tLSBHRVNUScOTIEQnSURJT01BIC0tLVxyXG5pbXBvcnQgeyBjYSB9IGZyb20gJ0AvbGliL2kxOG4vbG9jYWxlcy9jYSc7XHJcbmltcG9ydCB7IGVzIH0gZnJvbSAnQC9saWIvaTE4bi9sb2NhbGVzL2VzJztcclxuaW1wb3J0IHsgZW4gfSBmcm9tICdAL2xpYi9pMThuL2xvY2FsZXMvZW4nO1xyXG5pbXBvcnQgeyBSZWNpcGVFbnJpY2hlclNlcnZpY2UgfSBmcm9tICdAL2NvcmUvYXBwbGljYXRpb24vc2VydmljZXMvUmVjaXBlRW5yaWNoZXJTZXJ2aWNlJztcclxuXHJcblxyXG5cclxuLy8gLS0tIFRJUFVTIERFIFJFVE9STiBJIERCIC0tLVxyXG5leHBvcnQgdHlwZSBBY3Rpb25TdGF0ZSA9IHtcclxuICBzdWNjZXNzPzogYm9vbGVhbjtcclxuICBlcnJvcj86IHN0cmluZztcclxuICByb29tSWQ/OiBzdHJpbmc7XHJcbiAgb3V0Y29tZT86IHtcclxuICAgIGNob2ljZTogc3RyaW5nO1xyXG4gICAgcmVhc29uOiBzdHJpbmc7XHJcbiAgfTtcclxufTtcclxuXHJcbnR5cGUgQ3JlYXRlUm9vbVJlc3VsdCA9IHtcclxuICBzdWNjZXNzOiBib29sZWFuO1xyXG4gIHJvb21JZD86IHN0cmluZztcclxuICBlcnJvcj86IHN0cmluZztcclxufTtcclxuXHJcbi8vIERlZmluaW0gZWwgdGlwdXMgZXhhY3RlIGRlbCBxdWUgZW5zIHJldG9ybmEgU3VwYWJhc2VcclxuaW50ZXJmYWNlIFJvb21QYXJ0aWNpcGFudFJvdyB7XHJcbiAgcm9vbToge1xyXG4gICAgaWQ6IHN0cmluZztcclxuICAgIG5hbWU6IHN0cmluZztcclxuICAgIGVuYWJsZV9pbnZlbnRvcnk6IGJvb2xlYW47XHJcbiAgICBlbmFibGVfc2hvcHBpbmdfbGlzdDogYm9vbGVhbjtcclxuICB9IHwgbnVsbDtcclxufVxyXG5cclxuLy8g4pyFIFRJUEFUR0UgU0VHVVI6IERlZmluaW0gZWwgdGlwdXMgZGVsIGRpY2Npb25hcmkgcGVyIGV2aXRhciAnYW55J1xyXG5jb25zdCBESUNUSU9OQVJJRVM6IFJlY29yZDxzdHJpbmcsIERpY3Rpb25hcnk+ID0geyBjYSwgZXMsIGVuIH07XHJcblxyXG4vLyDinIUgSU5URVJGw41DSUVTIE5PVkVTIFBFUiBFVklUQVIgJ0FOWSdcclxuaW50ZXJmYWNlIERiUHJvZmlsZSB7XHJcbiAgdXNlcl9pZDogc3RyaW5nO1xyXG4gIGV4Y2x1c2lvbnM6IHN0cmluZ1tdIHwgbnVsbDtcclxuICBmb29kX3ByZWZlcmVuY2VzOiBzdHJpbmdbXSB8IG51bGw7XHJcbn1cclxuXHJcbmludGVyZmFjZSBEZWNpc2lvbk1ldGEge1xyXG4gIGlzQWlHZW5lcmF0ZWQ/OiBib29sZWFuO1xyXG4gIGlzTWFudWFsPzogYm9vbGVhbjtcclxuICB2aWJlPzogc3RyaW5nO1xyXG4gIHRhZ3M/OiBzdHJpbmdbXTtcclxuICBmdWxsUmVjaXBlPzogdW5rbm93bjsgLy8gTyBlbCB0aXB1cyBSZWNpcGVQcm9wcyBzaSBlbCB0ZW5zIGltcG9ydGF0XHJcbiAgdG90YWxPcHRpb25zPzogbnVtYmVyO1xyXG4gIG1hdGNoQ291bnQ/OiBudW1iZXI7XHJcbiAgW2tleTogc3RyaW5nXTogdW5rbm93bjsgLy8gUGVybWV0IGV4dGVuc2liaWxpdGF0IHNlbnNlIHVzYXIgJ2FueScgZGVzY29udHJvbGF0XHJcbn1cclxuLy8gSGVscGVyIHBlciBlcnJvcnMgWm9kXHJcbmZ1bmN0aW9uIGdldFpvZEVycm9yKGVycm9yOiB6LlpvZEVycm9yPHVua25vd24+KTogc3RyaW5nIHtcclxuICByZXR1cm4gZXJyb3IuaXNzdWVzWzBdPy5tZXNzYWdlIHx8IFwiRGFkZXMgaW52w6BsaWRlc1wiO1xyXG59XHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gMS4gQ1JFQVRFIFJPT01cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVSb29tQWN0aW9uKHVzZXJJZDogc3RyaW5nLCByb29tTmFtZTogc3RyaW5nKTogUHJvbWlzZTxDcmVhdGVSb29tUmVzdWx0PiB7XHJcbiAgY29uc3QgdmFsaWRhdGlvbiA9IENyZWF0ZVJvb21TY2hlbWEuc2FmZVBhcnNlKHsgaG9zdFVzZXJJZDogdXNlcklkLCBuYW1lOiByb29tTmFtZSB9KTtcclxuICBpZiAoIXZhbGlkYXRpb24uc3VjY2VzcykgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBnZXRab2RFcnJvcih2YWxpZGF0aW9uLmVycm9yKSB9O1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBjcmVhdGVSb29tVXNlQ2FzZSA9IGNvbnRhaW5lci5nZXRDcmVhdGVEZWNpc2lvblJvb20oKTtcclxuICAgIGNvbnN0IG5ld1Jvb21JZCA9IGF3YWl0IGNyZWF0ZVJvb21Vc2VDYXNlLmV4ZWN1dGUoeyBob3N0VXNlcklkOiB2YWxpZGF0aW9uLmRhdGEuaG9zdFVzZXJJZCwgbmFtZTogdmFsaWRhdGlvbi5kYXRhLm5hbWUgfSk7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCByb29tSWQ6IG5ld1Jvb21JZCB9O1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBsb2dFcnJvcignY3JlYXRlUm9vbUFjdGlvbiBmYWlsZWQnLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiTm8gcydoYSBwb2d1dCBjcmVhciBsYSBzYWxhLlwiIH07XHJcbiAgfVxyXG59XHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gMi4gSk9JTiBST09NXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gam9pblJvb21BY3Rpb24ocm9vbUlkOiBzdHJpbmcsIHVzZXJJZDogc3RyaW5nKTogUHJvbWlzZTxBY3Rpb25TdGF0ZT4ge1xyXG4gIGNvbnN0IHZhbGlkYXRpb24gPSBQYXJ0aWNpcGFudEFjdGlvblNjaGVtYS5zYWZlUGFyc2UoeyByb29tSWQsIHVzZXJJZCB9KTtcclxuICBpZiAoIXZhbGlkYXRpb24uc3VjY2VzcykgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBnZXRab2RFcnJvcih2YWxpZGF0aW9uLmVycm9yKSB9O1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB1c2VDYXNlID0gY29udGFpbmVyLmdldEpvaW5EZWNpc2lvblJvb20oKTtcclxuICAgIGF3YWl0IHVzZUNhc2UuZXhlY3V0ZSh2YWxpZGF0aW9uLmRhdGEpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogU3RyaW5nKGVycm9yKSB9O1xyXG4gIH1cclxufVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIDMuIEtJQ0sgUEFSVElDSVBBTlRcclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBraWNrUGFydGljaXBhbnRBY3Rpb24ocm9vbUlkOiBzdHJpbmcsIHBhcnRpY2lwYW50SWQ6IHN0cmluZykge1xyXG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgaWYgKCF1c2VyKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfTtcclxuXHJcbiAgY29uc3QgS2lja1NjaGVtYSA9IHoub2JqZWN0KHsgcm9vbUlkOiB6LnN0cmluZygpLnV1aWQoKSwgcGFydGljaXBhbnRJZDogei5zdHJpbmcoKS51dWlkKCksIGhvc3RJZDogei5zdHJpbmcoKS51dWlkKCkgfSk7XHJcbiAgY29uc3QgdmFsaWRhdGlvbiA9IEtpY2tTY2hlbWEuc2FmZVBhcnNlKHsgcm9vbUlkLCBwYXJ0aWNpcGFudElkLCBob3N0SWQ6IHVzZXIuaWQgfSk7XHJcblxyXG4gIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldFpvZEVycm9yKHZhbGlkYXRpb24uZXJyb3IpIH07XHJcblxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB1c2VDYXNlID0gY29udGFpbmVyLmdldFJlbW92ZVBhcnRpY2lwYW50KCk7XHJcbiAgICBhd2FpdCB1c2VDYXNlLmV4ZWN1dGUodXNlci5pZCwgcm9vbUlkLCBwYXJ0aWNpcGFudElkKTtcclxuICAgIHJldmFsaWRhdGVQYXRoKGAvcm9vbXMvJHtyb29tSWR9YCk7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIkVycm9yIGRlc2NvbmVndXRcIiB9O1xyXG4gIH1cclxufVxyXG5cclxuXHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gNS4gQUREIENBTkRJREFURVxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuY29uc3QgQWRkQ2FuZGlkYXRlU2NoZW1hID0gei5vYmplY3Qoe1xyXG4gIHJvb21JZDogei5zdHJpbmcoKS51dWlkKCksXHJcbiAgY2FuZGlkYXRlTmFtZTogei5zdHJpbmcoKVxyXG4gICAgLm1pbigxKVxyXG4gICAgLm1heCg1MClcclxuICAgIC5yZWdleCgvXlthLXpBLVowLTlcXHPDgC3Dv1xcdTAwZjFcXHUwMGQxXSskLywgJ05vIGVzIHBlcm1ldGVuIGVscyBjYXLDoGN0ZXJzIGVzcGVjaWFscycpLFxyXG59KTtcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhZGRDYW5kaWRhdGVBY3Rpb24ocm9vbUlkOiBzdHJpbmcsIGNhbmRpZGF0ZU5hbWU6IHN0cmluZykge1xyXG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgY29uc3QgdXNlcklkID0gdXNlcj8uaWQgfHwgJ2Fub255bW91cyc7XHJcblxyXG4gIC8vIDEuIFZhbGlkYWNpw7NcclxuICBjb25zdCB2YWxpZGF0aW9uID0gQWRkQ2FuZGlkYXRlU2NoZW1hLnNhZmVQYXJzZSh7IHJvb21JZCwgY2FuZGlkYXRlTmFtZSB9KTtcclxuICBpZiAoIXZhbGlkYXRpb24uc3VjY2Vzcykge1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiB2YWxpZGF0aW9uLmVycm9yLmlzc3Vlc1swXS5tZXNzYWdlIH07XHJcbiAgfVxyXG5cclxuICAvLyAyLiBSYXRlIExpbWl0aW5nXHJcbiAgY29uc3QgcmF0ZUxpbWl0ZXIgPSBuZXcgU3VwYWJhc2VSYXRlTGltaXRlcigpO1xyXG4gIGNvbnN0IGxvZ2dlciA9IG5ldyBTdXBhYmFzZVNlY3VyaXR5TG9nZ2VyKCk7XHJcbiAgY29uc3QgaXNBbGxvd2VkID0gYXdhaXQgcmF0ZUxpbWl0ZXIuY2hlY2soYCR7dXNlcklkfTphZGRfY2FuZGlkYXRlYCwgMTAsIDYwKTtcclxuXHJcbiAgaWYgKCFpc0FsbG93ZWQpIHtcclxuICAgIGF3YWl0IGxvZ2dlci5sb2coJ1dBUk4nLCAnUkFURV9MSU1JVF9CUkVBQ0gnLCB1c2VySWQsIHsgcm9vbUlkIH0pO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnVmFzIG1hc3NhIHLDoHBpZC4gRXNwZXJhIHVucyBzZWdvbnMuJyB9O1xyXG4gIH1cclxuXHJcbiAgLy8gMy4gRXhlY3VjacOzXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlcG8gPSBuZXcgU3VwYWJhc2VDYW5kaWRhdGVSZXBvc2l0b3J5KCk7XHJcbiAgICBhd2FpdCByZXBvLmFkZChyb29tSWQsIHVzZXJJZCwgY2FuZGlkYXRlTmFtZSk7XHJcbiAgICByZXZhbGlkYXRlUGF0aChgL3Jvb21zLyR7cm9vbUlkfWApO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBsb2dFcnJvcignYWRkQ2FuZGlkYXRlQWN0aW9uIGZhaWxlZCcsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ0Vycm9yIGludGVybiBhbCBndWFyZGFyLicgfTtcclxuICB9XHJcbn1cclxuXHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbWFrZUdyb3VwRGVjaXNpb25BY3Rpb24oXHJcbiAgcm9vbUlkOiBzdHJpbmcsXHJcbiAgbW9kZTogJ21hZ2ljJyB8ICdtYW51YWwnLFxyXG4gIGxvY2FsZTogc3RyaW5nID0gJ2NhJ1xyXG4pIHtcclxuICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0gfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpO1xyXG5cclxuICBpZiAoIXVzZXIpIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9O1xyXG5cclxuICBjb25zdCBub3JtYWxpemVkTG9jYWxlID0gbG9jYWxlLnN1YnN0cmluZygwLCAyKS50b0xvd2VyQ2FzZSgpO1xyXG4gIGNvbnN0IHQ6IERpY3Rpb25hcnkgPSBESUNUSU9OQVJJRVNbbm9ybWFsaXplZExvY2FsZV0gfHwgRElDVElPTkFSSUVTWydjYSddO1xyXG5cclxuICAvLyAxLiBWYWxpZGFjacOzIEzDrW1pdHNcclxuICBjb25zdCBsaW1pdENoZWNrID0gYXdhaXQgY2hlY2tSb29tRGFpbHlMaW1pdChzdXBhYmFzZSwgcm9vbUlkKTtcclxuICBpZiAoIWxpbWl0Q2hlY2suYWxsb3dlZCkgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBsaW1pdENoZWNrLmVycm9yIH07XHJcblxyXG4gIHRyeSB7XHJcbiAgICBsZXQgb3V0Y29tZUNob2ljZTogc3RyaW5nO1xyXG4gICAgbGV0IG91dGNvbWVSZWFzb246IHN0cmluZztcclxuICAgIGxldCBvdXRjb21lTWV0YTogRGVjaXNpb25NZXRhID0ge307XHJcbiAgICBsZXQgY2FuZGlkYXRlc1RpdGxlczogc3RyaW5nW10gPSBbXTtcclxuXHJcbiAgICAvLyAtLS0gTU9ERSBNw4BHSUMgKElBIEdFTkVSQVRJVkEpIC0tLVxyXG4gICAgaWYgKG1vZGUgPT09ICdtYWdpYycpIHtcclxuICAgICAgY29uc3QgeyBkYXRhOiBwYXJ0aWNpcGFudHMgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3Jvb21fcGFydGljaXBhbnRzJykuc2VsZWN0KCd1c2VyX2lkJykuZXEoJ3Jvb21faWQnLCByb29tSWQpO1xyXG4gICAgICBpZiAoIXBhcnRpY2lwYW50cz8ubGVuZ3RoKSB0aHJvdyBuZXcgRXJyb3IoXCJSb29tIGlzIGVtcHR5XCIpO1xyXG5cclxuICAgICAgY29uc3QgdXNlcklkcyA9IHBhcnRpY2lwYW50cy5tYXAocCA9PiBwLnVzZXJfaWQpO1xyXG5cclxuICAgICAgLy8gUmVjdXBlcmFyIHBlcmZpbHNcclxuICAgICAgY29uc3QgeyBkYXRhOiByYXdQcm9maWxlcyB9ID0gYXdhaXQgc3VwYWJhc2VcclxuICAgICAgICAuZnJvbSgncHJlZmVyZW5jZV9wcm9maWxlcycpXHJcbiAgICAgICAgLnNlbGVjdCgndXNlcl9pZCwgZXhjbHVzaW9ucywgZm9vZF9wcmVmZXJlbmNlcycpXHJcbiAgICAgICAgLmluKCd1c2VyX2lkJywgdXNlcklkcyk7XHJcblxyXG4gICAgICBjb25zdCBwcm9maWxlcyA9IChyYXdQcm9maWxlcyB8fCBbXSkgYXMgdW5rbm93biBhcyBEYlByb2ZpbGVbXTtcclxuXHJcbiAgICAgIC8vIEZ1c2nDsyBkZSBEYWRlc1xyXG4gICAgICBjb25zdCBncm91cFJlc3RyaWN0aW9ucyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xyXG4gICAgICBjb25zdCBncm91cFByZWZlcmVuY2VzOiBzdHJpbmdbXSA9IFtdO1xyXG5cclxuICAgICAgcHJvZmlsZXMuZm9yRWFjaCgocCkgPT4ge1xyXG4gICAgICAgIGlmIChwLmV4Y2x1c2lvbnMpIHAuZXhjbHVzaW9ucy5mb3JFYWNoKChlKSA9PiBncm91cFJlc3RyaWN0aW9ucy5hZGQoZSkpO1xyXG4gICAgICAgIGlmIChwLmZvb2RfcHJlZmVyZW5jZXMpIHAuZm9vZF9wcmVmZXJlbmNlcy5mb3JFYWNoKChwcmVmKSA9PiBncm91cFByZWZlcmVuY2VzLnB1c2gocHJlZikpO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IGZpbmFsUmVzdHJpY3Rpb25zID0gQXJyYXkuZnJvbShncm91cFJlc3RyaWN0aW9ucykgYXMgRGlldGFyeVJlc3RyaWN0aW9uW107XHJcblxyXG4gICAgICAvLyBUcmlhciBWaWJlXHJcbiAgICAgIGxldCB2aWJlID0gXCJTb3JwcmVzYSBjcmVhdGl2YSBwZXIgYSBncnVwc1wiO1xyXG4gICAgICBpZiAoZ3JvdXBQcmVmZXJlbmNlcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgY29uc3QgcmFuZG9tUHJlZiA9IGdyb3VwUHJlZmVyZW5jZXNbTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogZ3JvdXBQcmVmZXJlbmNlcy5sZW5ndGgpXTtcclxuICAgICAgICB2aWJlID0gYEVzdGlsICR7cmFuZG9tUHJlZn0gKENvbnNlbnMgR3J1cGFsKWA7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGRlYnVnKCdbQUNUSU9OXSBncm91cCBBSSBnZW5lcmF0ZScpO1xyXG5cclxuXHJcblxyXG4gICAgICAvLyBHZW5lcmFyIFJlY2VwdGVzXHJcbiAgICAgIGNvbnN0IGdlbmVyYXRvciA9IGNvbnRhaW5lci5nZXRSZWNpcGVHZW5lcmF0b3IoKTtcclxuXHJcbiAgICAgIGNvbnN0IGNvbnRleHQgPSB7XHJcbiAgICAgICAgbW9kZTogJ0ZBVEUnIGFzIGNvbnN0LFxyXG4gICAgICAgIGNvdW50OiA0LFxyXG4gICAgICAgIGxhbmd1YWdlOiBsb2NhbGUsXHJcbiAgICAgICAgaW52ZW50b3J5OiBbXSxcclxuICAgICAgICByZXN0cmljdGlvbnM6IGZpbmFsUmVzdHJpY3Rpb25zLFxyXG4gICAgICAgIGRpc2xpa2VzOiBbXSxcclxuICAgICAgICBlbmVyZ3lMZXZlbDogJ01FRElVTScgYXMgY29uc3QsXHJcbiAgICAgICAgdGltZUF2YWlsYWJsZU1pbnV0ZXM6IDQ1LFxyXG4gICAgICAgIGZvY3VzRGlzaDogdW5kZWZpbmVkLFxyXG4gICAgICAgIHZpYmU6IHZpYmVcclxuICAgICAgfTtcclxuXHJcbiAgICAgIGNvbnN0IGFpUmVjaXBlcyA9IGF3YWl0IGdlbmVyYXRvci5nZW5lcmF0ZShjb250ZXh0KTtcclxuXHJcbiAgICAgIGlmICghYWlSZWNpcGVzIHx8IGFpUmVjaXBlcy5sZW5ndGggPT09IDApIHRocm93IG5ldyBFcnJvcihcIkxhIElBIG5vIGhhIGdlbmVyYXQgcmVzLlwiKTtcclxuXHJcbiAgICAgIC8vIFNlbGVjY2lvbmFyIEd1YW55YWRvcmFcclxuICAgICAgbGV0IHdpbm5lclJlY2lwZSA9IGFpUmVjaXBlc1tNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBhaVJlY2lwZXMubGVuZ3RoKV07XHJcblxyXG4gICAgICAvLyDwn5SlIEVOUklRVUlNRU5UIE3DgEdJQyAoQnVzY2FyIGZvdG9zIGkgcHJldXMpXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgZGVidWcoJ1tBQ1RJT05dIGVucmljaCB3aW5uZXIgcmVjaXBlJyk7XHJcbiAgICAgICAgY29uc3QgZW5yaWNoZXIgPSBuZXcgUmVjaXBlRW5yaWNoZXJTZXJ2aWNlKGNvbnRhaW5lci5nZXRQcm9kdWN0Q2F0YWxvZ1JlcG8oc3VwYWJhc2UpKTtcclxuICAgICAgICB3aW5uZXJSZWNpcGUgPSBhd2FpdCBlbnJpY2hlci5lbnJpY2hSZWNpcGUod2lubmVyUmVjaXBlKTtcclxuXHJcbiAgICAgICAgY29uc3QgZmluYWxDb3N0ID0gd2lubmVyUmVjaXBlLmVzdGltYXRlZENvc3QgfHwgMDtcclxuXHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGxvZ0Vycm9yKFwi4pqg77iPIEVycm9yIGVucmlxdWludCByZWNlcHRhOlwiLCBlcnIpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBvdXRjb21lQ2hvaWNlID0gd2lubmVyUmVjaXBlLm5hbWU7XHJcbiAgICAgIG91dGNvbWVSZWFzb24gPSBgUHJvcG9zdGEgYmFzYWRhIGVuIGwnZXN0aWwgXCIke3ZpYmV9XCIgaSBzZWd1cmEgcGVyIGEgdG90cyBlbHMgcGFydGljaXBhbnRzLmA7XHJcblxyXG4gICAgICBvdXRjb21lTWV0YSA9IHtcclxuICAgICAgICBpc0FpR2VuZXJhdGVkOiB0cnVlLFxyXG4gICAgICAgIHZpYmUsXHJcbiAgICAgICAgdGFnczogd2lubmVyUmVjaXBlLnRhZ3MsXHJcbiAgICAgICAgLy8gQXJhIGZ1bGxSZWNpcGUgdGluZHLDoCBsaW5rZWRQcm9kdWN0SW1hZ2UgaSBlc3RpbWF0ZWRDb3N0IHBsZW5zIVxyXG4gICAgICAgIGZ1bGxSZWNpcGU6IHdpbm5lclJlY2lwZS50b1ByaW1pdGl2ZXMoKVxyXG4gICAgICB9O1xyXG5cclxuICAgICAgY2FuZGlkYXRlc1RpdGxlcyA9IGFpUmVjaXBlcy5tYXAociA9PiByLm5hbWUpO1xyXG5cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIC8vIC0tLSBNT0RFIE1BTlVBTCAtLS1cclxuICAgICAgY29uc3QgeyBkYXRhOiBtYW51YWxDYW5kaWRhdGVzIH0gPSBhd2FpdCBzdXBhYmFzZS5mcm9tKCdyb29tX2NhbmRpZGF0ZXMnKS5zZWxlY3QoJ2NvbnRlbnQnKS5lcSgncm9vbV9pZCcsIHJvb21JZCk7XHJcbiAgICAgIGlmICghbWFudWFsQ2FuZGlkYXRlcz8ubGVuZ3RoKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiTm8gaGkgaGEgb3BjaW9ucyFcIiB9O1xyXG5cclxuICAgICAgY29uc3Qgd2lubmVyID0gbWFudWFsQ2FuZGlkYXRlc1tNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBtYW51YWxDYW5kaWRhdGVzLmxlbmd0aCldO1xyXG4gICAgICBvdXRjb21lQ2hvaWNlID0gd2lubmVyLmNvbnRlbnQ7XHJcbiAgICAgIG91dGNvbWVSZWFzb24gPSB0LnJvb20uaGlzdG9yeS5tYW51YWxfcmVhc29uO1xyXG4gICAgICBvdXRjb21lTWV0YSA9IHsgaXNNYW51YWw6IHRydWUsIHRvdGFsT3B0aW9uczogbWFudWFsQ2FuZGlkYXRlcy5sZW5ndGggfTtcclxuICAgICAgY2FuZGlkYXRlc1RpdGxlcyA9IG1hbnVhbENhbmRpZGF0ZXMubWFwKGMgPT4gYy5jb250ZW50KTtcclxuICAgIH1cclxuXHJcbiAgICAvLyAyLiBQZXJzaXN0w6huY2lhIChJTlNFUlRBUiBMQSBOT1ZBIERFQ0lTScOTKVxyXG4gICAgYXdhaXQgc3VwYWJhc2UuZnJvbSgnZ3JvdXBfZGVjaXNpb25zJykuaW5zZXJ0KHtcclxuICAgICAgcm9vbV9pZDogcm9vbUlkLFxyXG4gICAgICBjaG9pY2U6IG91dGNvbWVDaG9pY2UsXHJcbiAgICAgIHJlYXNvbjogb3V0Y29tZVJlYXNvbixcclxuICAgICAgbWV0YWRhdGE6IG91dGNvbWVNZXRhLFxyXG4gICAgICBjYW5kaWRhdGVzX3Byb3Bvc2VkOiBjYW5kaWRhdGVzVGl0bGVzXHJcbiAgICB9KTtcclxuXHJcbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCdkZWNpc2lvbl9yb29tcycpLnVwZGF0ZSh7IGxhc3RfZGVjaXNpb25fYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSB9KS5lcSgnaWQnLCByb29tSWQpO1xyXG5cclxuICAgIC8vIPCflKUgMy4gUk9UQUNJw5MgQVVUT03DgFRJQ0EgKE1hbnRlbmlyIG3DoHhpbSAxMCkg8J+UpVxyXG4gICAgY29uc3QgeyBkYXRhOiBhbGxIaXN0b3J5IH0gPSBhd2FpdCBzdXBhYmFzZVxyXG4gICAgICAuZnJvbSgnZ3JvdXBfZGVjaXNpb25zJylcclxuICAgICAgLnNlbGVjdCgnaWQnKVxyXG4gICAgICAuZXEoJ3Jvb21faWQnLCByb29tSWQpXHJcbiAgICAgIC5vcmRlcignY3JlYXRlZF9hdCcsIHsgYXNjZW5kaW5nOiBmYWxzZSB9KTsgLy8gTcOpcyByZWNlbnRzIHByaW1lclxyXG5cclxuICAgIGlmIChhbGxIaXN0b3J5ICYmIGFsbEhpc3RvcnkubGVuZ3RoID4gMTApIHtcclxuICAgICAgLy8gQWdhZmVtIGVscyBJRHMgYSBwYXJ0aXIgZGUgbGEgcG9zaWNpw7MgMTAgKGVscyBtw6lzIHZlbGxzKVxyXG4gICAgICBjb25zdCBpZHNUb0RlbGV0ZSA9IGFsbEhpc3Rvcnkuc2xpY2UoMTApLm1hcChkID0+IGQuaWQpO1xyXG5cclxuICAgICAgaWYgKGlkc1RvRGVsZXRlLmxlbmd0aCA+IDApIHtcclxuICAgICAgICBkZWJ1ZygnW0FDVElPTl0gY2xlYW51cCBvbGQgZGVjaXNpb25zJyk7XHJcbiAgICAgICAgYXdhaXQgc3VwYWJhc2VcclxuICAgICAgICAgIC5mcm9tKCdncm91cF9kZWNpc2lvbnMnKVxyXG4gICAgICAgICAgLmRlbGV0ZSgpXHJcbiAgICAgICAgICAuaW4oJ2lkJywgaWRzVG9EZWxldGUpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoYC9yb29tcy8ke3Jvb21JZH1gKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIG91dGNvbWU6IHsgY2hvaWNlOiBvdXRjb21lQ2hvaWNlLCByZWFzb246IG91dGNvbWVSZWFzb24gfSB9O1xyXG5cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoXCLinYwgUm9vbSBBY3Rpb24gRXJyb3I6XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciBlbiBsYSBkZWNpc2nDsyBncnVwYWxcIiB9O1xyXG4gIH1cclxuXHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE15SW52ZW50b3J5Um9vbXNBY3Rpb24oKSB7XHJcbiAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuXHJcbiAgaWYgKCF1c2VyKSByZXR1cm4gW107XHJcblxyXG4gIC8vIFRpcGVtIGxhIHJlc3Bvc3RhIGNvbSBhIGFycmF5IGRlIFJvb21QYXJ0aWNpcGFudFJvd1xyXG4gIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXHJcbiAgICAuZnJvbSgncm9vbV9wYXJ0aWNpcGFudHMnKVxyXG4gICAgLnNlbGVjdChgXHJcbiAgICAgIHJvb206ZGVjaXNpb25fcm9vbXMgKFxyXG4gICAgICAgIGlkLFxyXG4gICAgICAgIG5hbWUsXHJcbiAgICAgICAgZW5hYmxlX2ludmVudG9yeSBcclxuICAgICAgKVxyXG4gICAgYClcclxuICAgIC5lcSgndXNlcl9pZCcsIHVzZXIuaWQpXHJcbiAgICAucmV0dXJuczxSb29tUGFydGljaXBhbnRSb3dbXT4oKTsgLy8gPC0tLSBUaXBhdGdlIGZvcnRcclxuXHJcbiAgaWYgKGVycm9yKSB7XHJcbiAgICBsb2dFcnJvcihcIkVycm9yIGZldGNoaW5nIHJvb21zOlwiLCBlcnJvcik7XHJcbiAgICByZXR1cm4gW107XHJcbiAgfVxyXG5cclxuICBpZiAoIWRhdGEpIHJldHVybiBbXTtcclxuICBjb25zdCBhdmFpbGFibGVSb29tcyA9IGRhdGFcclxuICAgIC5tYXAoKHJvdykgPT4gcm93LnJvb20pXHJcbiAgICAvLyDinIUgQ09SUkVDQ0nDkzogRmVtIHNlcnZpciAncm9vbScgKGwnYXJndW1lbnQpLCBubyAncm93J1xyXG4gICAgLmZpbHRlcigocm9vbSk6IHJvb20gaXMgTm9uTnVsbGFibGU8dHlwZW9mIHJvb20+ID0+XHJcbiAgICAgIHJvb20gIT09IG51bGwgJiYgcm9vbS5lbmFibGVfaW52ZW50b3J5ID09PSB0cnVlXHJcbiAgICApXHJcbiAgICAubWFwKChyb29tKSA9PiAoe1xyXG4gICAgICBpZDogcm9vbS5pZCxcclxuICAgICAgbmFtZTogcm9vbS5uYW1lXHJcbiAgICB9KSk7XHJcblxyXG5cclxuXHJcbiAgcmV0dXJuIGF2YWlsYWJsZVJvb21zO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TXlTaG9wcGluZ1Jvb21zQWN0aW9uKCkge1xyXG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcblxyXG4gIGlmICghdXNlcikgcmV0dXJuIFtdO1xyXG5cclxuICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxyXG4gICAgLmZyb20oJ3Jvb21fcGFydGljaXBhbnRzJylcclxuICAgIC5zZWxlY3QoYFxyXG4gICAgICByb29tOmRlY2lzaW9uX3Jvb21zIChcclxuICAgICAgICBpZCxcclxuICAgICAgICBuYW1lLFxyXG4gICAgICAgIGVuYWJsZV9pbnZlbnRvcnksXHJcbiAgICAgICAgZW5hYmxlX3Nob3BwaW5nX2xpc3RcclxuICAgICAgKVxyXG4gICAgYClcclxuICAgIC5lcSgndXNlcl9pZCcsIHVzZXIuaWQpXHJcbiAgICAucmV0dXJuczxSb29tUGFydGljaXBhbnRSb3dbXT4oKTtcclxuXHJcbiAgaWYgKGVycm9yKSB7XHJcbiAgICBsb2dFcnJvcihcIkVycm9yIGZldGNoaW5nIHNob3BwaW5nIHJvb21zOlwiLCBlcnJvcik7XHJcbiAgICByZXR1cm4gW107XHJcbiAgfVxyXG5cclxuICBpZiAoIWRhdGEpIHJldHVybiBbXTtcclxuICByZXR1cm4gZGF0YVxyXG4gICAgLm1hcCgocm93KSA9PiByb3cucm9vbSlcclxuICAgIC5maWx0ZXIoKHJvb20pOiByb29tIGlzIE5vbk51bGxhYmxlPHR5cGVvZiByb29tPiA9PlxyXG4gICAgICByb29tICE9PSBudWxsICYmIHJvb20uZW5hYmxlX3Nob3BwaW5nX2xpc3QgPT09IHRydWVcclxuICAgIClcclxuICAgIC5tYXAoKHJvb20pID0+ICh7XHJcbiAgICAgIGlkOiByb29tLmlkLFxyXG4gICAgICBuYW1lOiByb29tLm5hbWVcclxuICAgIH0pKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHRvZ2dsZVJvb21GZWF0dXJlQWN0aW9uKHJvb21JZDogc3RyaW5nLCBmZWF0dXJlOiAnSU5WRU5UT1JZJyB8ICdTSE9QUElORycsIGlzRW5hYmxlZDogYm9vbGVhbikge1xyXG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcblxyXG4gIGlmICghdXNlcikgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIlVuYXV0aG9yaXplZFwiIH07XHJcblxyXG4gIC8vIDEuIFZlcmlmaXF1ZW0gcXVlIGwndXN1YXJpIMOpcyBlbCBIT1NUIGRlIGxhIHNhbGEgKFNlZ3VyZXRhdClcclxuICBjb25zdCB7IGRhdGE6IHJvb20gfSA9IGF3YWl0IHN1cGFiYXNlXHJcbiAgICAuZnJvbSgnZGVjaXNpb25fcm9vbXMnKVxyXG4gICAgLnNlbGVjdCgnaG9zdF91c2VyX2lkJylcclxuICAgIC5lcSgnaWQnLCByb29tSWQpXHJcbiAgICAuc2luZ2xlKCk7XHJcblxyXG4gIGlmICghcm9vbSB8fCByb29tLmhvc3RfdXNlcl9pZCAhPT0gdXNlci5pZCkge1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIk5vbcOpcyBsJ2FkbWluaXN0cmFkb3IgcG90IGNhbnZpYXIgYWl4w7IuXCIgfTtcclxuICB9XHJcblxyXG4gIC8vIDIuIE1hcGVnZW0gbGEgZmVhdHVyZSBhIGxhIGNvbHVtbmEgZGUgbGEgQkRcclxuICBjb25zdCBjb2x1bW4gPSBmZWF0dXJlID09PSAnSU5WRU5UT1JZJyA/ICdlbmFibGVfaW52ZW50b3J5JyA6ICdlbmFibGVfc2hvcHBpbmdfbGlzdCc7IC8vIChTaSB0ZW5zIGxsaXN0YSBjb21wcmEpXHJcblxyXG4gIC8vIDMuIEFjdHVhbGl0emVtXHJcbiAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcclxuICAgIC5mcm9tKCdkZWNpc2lvbl9yb29tcycpXHJcbiAgICAudXBkYXRlKHsgW2NvbHVtbl06IGlzRW5hYmxlZCB9KVxyXG4gICAgLmVxKCdpZCcsIHJvb21JZCk7XHJcblxyXG4gIGlmIChlcnJvcikgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBlcnJvci5tZXNzYWdlIH07XHJcblxyXG4gIHJldmFsaWRhdGVQYXRoKGAvcm9vbXMvJHtyb29tSWR9YCk7XHJcbiAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG59XHJcblxyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IndTQTRYc0IscU1BQUEifQ==
}),
"[project]/app/actions/data:9244b4 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getShoppingListDataAction",
    ()=>$$RSC_SERVER_ACTION_4
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"406097e45faf56b66ed42909d29d58d44492b4e1e9":"getShoppingListDataAction"},"app/actions/shopping-list-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("406097e45faf56b66ed42909d29d58d44492b4e1e9", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getShoppingListDataAction");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vc2hvcHBpbmctbGlzdC1hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc2VydmVyJztcclxuXHJcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2Uvc2VydmVyJztcclxuaW1wb3J0IHsgY29udGFpbmVyIH0gZnJvbSAnQC9zZXJ2aWNlcy9jb250YWluZXInO1xyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gJ25leHQvY2FjaGUnO1xyXG5pbXBvcnQgeyBkZWJ1ZywgZXJyb3IgYXMgbG9nRXJyb3IgfSBmcm9tICdAL2xpYi9sb2dnZXInO1xyXG5pbXBvcnQgeyB6IH0gZnJvbSAnem9kJztcclxuXHJcbmNvbnN0IEFkZEl0ZW1TY2hlbWEgPSB6Lm9iamVjdCh7XHJcbiAgbmFtZTogei5zdHJpbmcoKS5taW4oMSksXHJcbiAgcXVhbnRpdHk6IHoubnVtYmVyKCkucG9zaXRpdmUoKSxcclxuICB1bml0OiB6LnN0cmluZygpLFxyXG4gIGVtb2ppOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgcHJvZHVjdElkOiB6LnN0cmluZygpLm9wdGlvbmFsKCkubnVsbGFibGUoKSxcclxuICBwcm9kdWN0SW1hZ2U6IHouc3RyaW5nKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpLFxyXG4gIGVzdGltYXRlZENvc3Q6IHoubnVtYmVyKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpLFxyXG4gIHJvb21JZDogei5zdHJpbmcoKS51dWlkKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpXHJcbn0pO1xyXG4vLyDinIUgU2NoZW1hIHBlciB2YWxpZGFjacOzIG1hc3NpdmFcclxuY29uc3QgQmF0Y2hJdGVtU2NoZW1hID0gei5vYmplY3Qoe1xyXG4gIGl0ZW1zOiB6LmFycmF5KEFkZEl0ZW1TY2hlbWEpLFxyXG4gIHJvb21JZDogei5zdHJpbmcoKS51dWlkKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpXHJcbn0pO1xyXG5jb25zdCBUb2dnbGVJdGVtU2NoZW1hID0gei5vYmplY3Qoe1xyXG4gIGl0ZW1JZDogei5zdHJpbmcoKS51dWlkKCksXHJcbiAgaXNDaGVja2VkOiB6LmJvb2xlYW4oKVxyXG59KTtcclxuY29uc3QgUm9vbUlkU2NoZW1hID0gei5zdHJpbmcoKS51dWlkKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpO1xyXG4vLyAxLiBBREQgSVRFTVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYWRkVG9TaG9wcGluZ0xpc3RBY3Rpb24oXHJcbiAgICBuYW1lOiBzdHJpbmcsIFxyXG4gICAgcXVhbnRpdHk6IG51bWJlciwgXHJcbiAgICB1bml0OiBzdHJpbmcsIFxyXG4gICAgZW1vamk/OiBzdHJpbmcsIFxyXG4gICAgcHJvZHVjdElkPzogc3RyaW5nLFxyXG4gICAgcHJvZHVjdEltYWdlPzogc3RyaW5nLFxyXG4gICAgZXN0aW1hdGVkQ29zdD86IG51bWJlcixcclxuICAgIHJvb21JZD86IHN0cmluZyB8IG51bGxcclxuKSB7XHJcbiAgdHJ5IHtcclxuICAgIGRlYnVnKCdbQUNUSU9OXSBhZGRUb1Nob3BwaW5nTGlzdCBzdGFydCcpO1xyXG5cclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICAgIGlmICghdXNlcikgdGhyb3cgbmV3IEVycm9yKFwiVW5hdXRob3JpemVkXCIpO1xyXG5cclxuICAgIGNvbnN0IHZhbGlkYXRpb24gPSBBZGRJdGVtU2NoZW1hLnNhZmVQYXJzZSh7IFxyXG4gICAgICAgIG5hbWUsIHF1YW50aXR5LCB1bml0LCBlbW9qaSwgcHJvZHVjdElkLCBwcm9kdWN0SW1hZ2UsIGVzdGltYXRlZENvc3QsIHJvb21JZFxyXG4gICAgfSk7XHJcbiAgICBcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSB7XHJcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkRhZGVzIGludsOgbGlkZXNcIiB9O1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHVzZUNhc2UgPSBjb250YWluZXIuZ2V0QWRkVG9TaG9wcGluZ0xpc3Qoc3VwYWJhc2UpO1xyXG4gICAgXHJcbiAgICBhd2FpdCB1c2VDYXNlLmV4ZWN1dGUoXHJcbiAgICAgICAgdXNlci5pZCwgXHJcbiAgICAgICAgdmFsaWRhdGlvbi5kYXRhLm5hbWUsIFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5xdWFudGl0eSwgXHJcbiAgICAgICAgdmFsaWRhdGlvbi5kYXRhLnVuaXQsXHJcbiAgICAgICAgdmFsaWRhdGlvbi5kYXRhLmVtb2ppLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5wcm9kdWN0SWQgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5wcm9kdWN0SW1hZ2UgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5lc3RpbWF0ZWRDb3N0IHx8IHVuZGVmaW5lZCxcclxuICAgICAgICB2YWxpZGF0aW9uLmRhdGEucm9vbUlkIHx8IHVuZGVmaW5lZFxyXG4gICAgKTtcclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL3Nob3BwaW5nLWxpc3QnKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxuXHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGxvZ0Vycm9yKCdhZGRUb1Nob3BwaW5nTGlzdCBmYWlsZWQnLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiTm8gcydoYSBwb2d1dCBhZmVnaXIgYSBsYSBsbGlzdGEuXCIgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIDIuIFRPR0dMRSBJVEVNXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB0b2dnbGVTaG9wcGluZ0l0ZW1BY3Rpb24oaXRlbUlkOiBzdHJpbmcsIGlzQ2hlY2tlZDogYm9vbGVhbikge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB2YWxpZGF0aW9uID0gVG9nZ2xlSXRlbVNjaGVtYS5zYWZlUGFyc2UoeyBpdGVtSWQsIGlzQ2hlY2tlZCB9KTtcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRGFkZXMgaW52w6BsaWRlc1wiIH07XHJcblxyXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICAgIGNvbnN0IHJlcG8gPSBjb250YWluZXIuZ2V0U2hvcHBpbmdMaXN0UmVwbyhzdXBhYmFzZSk7IFxyXG4gICAgYXdhaXQgcmVwby50b2dnbGVDaGVjayh2YWxpZGF0aW9uLmRhdGEuaXRlbUlkLCB2YWxpZGF0aW9uLmRhdGEuaXNDaGVja2VkKTtcclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL3Nob3BwaW5nLWxpc3QnKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ3RvZ2dsZVNob3BwaW5nSXRlbSBmYWlsZWQnLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRXJyb3IgYWN0dWFsaXR6YW50XCIgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIDMuIENPTVBMRVRFIFNFU1NJT05cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNvbXBsZXRlU2hvcHBpbmdTZXNzaW9uQWN0aW9uKHJvb21JZD86IHN0cmluZyB8IG51bGwpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgdmFsaWRhdGlvbiA9IFJvb21JZFNjaGVtYS5zYWZlUGFyc2Uocm9vbUlkKTtcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRGFkZXMgaW52w6BsaWRlc1wiIH07XHJcblxyXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICAgIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0gfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpO1xyXG4gICAgaWYgKCF1c2VyKSB0aHJvdyBuZXcgRXJyb3IoJ1VuYXV0aG9yaXplZCcpO1xyXG5cclxuICAgIGNvbnN0IHVzZUNhc2UgPSBjb250YWluZXIuZ2V0Q29tcGxldGVTaG9wcGluZ1Nlc3Npb24oc3VwYWJhc2UpO1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdXNlQ2FzZS5leGVjdXRlKHVzZXIuaWQsIHZhbGlkYXRpb24uZGF0YSB8fCB1bmRlZmluZWQpO1xyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvc2hvcHBpbmctbGlzdCcpO1xyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9pbnZlbnRvcnknKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGNvdW50OiByZXN1bHQuYWRkZWQgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoXCJFcnJvciBjb21wbGV0aW5nIHNob3BwaW5nIHNlc3Npb246XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciBmaW5hbGl0emFudCBsYSBjb21wcmFcIiB9O1xyXG4gIH1cclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYWRkQmF0Y2hUb1Nob3BwaW5nTGlzdEFjdGlvbihpdGVtczogei5pbmZlcjx0eXBlb2YgQWRkSXRlbVNjaGVtYT5bXSwgcm9vbUlkPzogc3RyaW5nIHwgbnVsbCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgICBpZiAoIXVzZXIpIHRocm93IG5ldyBFcnJvcihcIlVuYXV0aG9yaXplZFwiKTtcclxuXHJcbiAgICAvLyBWYWxpZGFyIGRhZGVzXHJcbiAgICBjb25zdCB2YWxpZGF0aW9uID0gQmF0Y2hJdGVtU2NoZW1hLnNhZmVQYXJzZSh7IGl0ZW1zLCByb29tSWQgfSk7XHJcbiAgICBpZiAoIXZhbGlkYXRpb24uc3VjY2VzcykgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkRhZGVzIGludsOgbGlkZXNcIiB9O1xyXG5cclxuICAgIGNvbnN0IHVzZUNhc2UgPSBjb250YWluZXIuZ2V0QWRkVG9TaG9wcGluZ0xpc3Qoc3VwYWJhc2UpO1xyXG5cclxuICAgIC8vIEV4ZWN1dGFyIGVuIHBhcmFswrdsZWwgKG8gcG9kcmllcyBmZXIgdW4gbG9vcCBzZXF1ZW5jaWFsIHNpIHZvbHMgZ2FyYW50aXIgb3JkcmUpXHJcbiAgICBhd2FpdCBQcm9taXNlLmFsbChpdGVtcy5tYXAoaXRlbSA9PiBcclxuICAgICAgdXNlQ2FzZS5leGVjdXRlKFxyXG4gICAgICAgIHVzZXIuaWQsXHJcbiAgICAgICAgaXRlbS5uYW1lLFxyXG4gICAgICAgIGl0ZW0ucXVhbnRpdHksXHJcbiAgICAgICAgaXRlbS51bml0LFxyXG4gICAgICAgIGl0ZW0uZW1vamksXHJcbiAgICAgICAgaXRlbS5wcm9kdWN0SWQgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIGl0ZW0ucHJvZHVjdEltYWdlIHx8IHVuZGVmaW5lZCxcclxuICAgICAgICBpdGVtLmVzdGltYXRlZENvc3QgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5yb29tSWQgfHwgdW5kZWZpbmVkXHJcbiAgICAgIClcclxuICAgICkpO1xyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvc2hvcHBpbmctbGlzdCcpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG5cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoXCJFcnJvciBhZGRpbmcgYmF0Y2g6XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciBndWFyZGFudCBwcm9kdWN0ZXNcIiB9O1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNob3BwaW5nTGlzdERhdGFBY3Rpb24ocm9vbUlkPzogc3RyaW5nIHwgbnVsbCkge1xyXG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgaWYgKCF1c2VyKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGlvbiA9IFJvb21JZFNjaGVtYS5zYWZlUGFyc2Uocm9vbUlkKTtcclxuICBpZiAoIXZhbGlkYXRpb24uc3VjY2VzcykgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkRhZGVzIGludsOgbGlkZXNcIiB9O1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgZ2V0U2hvcHBpbmdMaXN0ID0gY29udGFpbmVyLmdldEdldFNob3BwaW5nTGlzdChzdXBhYmFzZSk7XHJcbiAgICBjb25zdCBnZXRIaXN0b3J5ID0gY29udGFpbmVyLmdldEdldFNob3BwaW5nSGlzdG9yeShzdXBhYmFzZSk7XHJcblxyXG4gICAgY29uc3QgW2l0ZW1zLCBoaXN0b3J5XSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgZ2V0U2hvcHBpbmdMaXN0LmV4ZWN1dGUodXNlci5pZCwgdmFsaWRhdGlvbi5kYXRhIHx8IHVuZGVmaW5lZCksXHJcbiAgICAgIGdldEhpc3RvcnkuZXhlY3V0ZSh1c2VyLmlkLCB2YWxpZGF0aW9uLmRhdGEgfHwgdW5kZWZpbmVkKSxcclxuICAgIF0pO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IHRydWUsXHJcbiAgICAgIGRhdGE6IHtcclxuICAgICAgICBpdGVtczogbWFwSXRlbXNUb1ZpZXdNb2RlbChpdGVtcyksXHJcbiAgICAgICAgaGlzdG9yeTogbWFwSGlzdG9yeVRvVmlld01vZGVsKGhpc3RvcnkpLFxyXG4gICAgICB9LFxyXG4gICAgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ2dldFNob3BwaW5nTGlzdERhdGFBY3Rpb24gZmFpbGVkJywgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIk5vIHMnaGEgcG9ndXQgY2FycmVnYXIgbGEgbGxpc3RhLlwiIH07XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBtYXBJdGVtc1RvVmlld01vZGVsKGl0ZW1zOiBpbXBvcnQoJ0AvY29yZS9kb21haW4vZW50aXRpZXMvU2hvcHBpbmdMaXN0SXRlbScpLlNob3BwaW5nTGlzdEl0ZW1bXSkge1xyXG4gIHJldHVybiBpdGVtcy5tYXAoKGkpID0+ICh7XHJcbiAgICBpZDogaS5wcm9wcy5pZCxcclxuICAgIG5hbWU6IGkucHJvcHMubmFtZSxcclxuICAgIHF1YW50aXR5OiBpLnByb3BzLnF1YW50aXR5LFxyXG4gICAgdW5pdDogaS5wcm9wcy51bml0LFxyXG4gICAgaXNDaGVja2VkOiBpLnByb3BzLmlzQ2hlY2tlZCxcclxuICAgIGVtb2ppOiBpLnByb3BzLmVtb2ppLFxyXG4gICAgcHJvZHVjdElkOiBpLnByb3BzLnByb2R1Y3RJZCA/PyB1bmRlZmluZWQsXHJcbiAgICBwcm9kdWN0SW1hZ2U6IGkucHJvcHMucHJvZHVjdEltYWdlID8/IHVuZGVmaW5lZCxcclxuICAgIGVzdGltYXRlZENvc3Q6IGkucHJvcHMuZXN0aW1hdGVkQ29zdCA/PyB1bmRlZmluZWRcclxuICB9KSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIG1hcEhpc3RvcnlUb1ZpZXdNb2RlbChoaXN0b3J5OiBpbXBvcnQoJ0AvY29yZS9kb21haW4vZW50aXRpZXMvU2hvcHBpbmdTZXNzaW9uJykuU2hvcHBpbmdTZXNzaW9uW10pIHtcclxuICByZXR1cm4gaGlzdG9yeS5tYXAoKGgpID0+ICh7XHJcbiAgICBpZDogaC5wcm9wcy5pZCxcclxuICAgIGNyZWF0ZWRBdDogaC5wcm9wcy5jcmVhdGVkQXQsXHJcbiAgICB0b3RhbENvc3Q6IGgucHJvcHMudG90YWxDb3N0LFxyXG4gICAgaXRlbUNvdW50OiBoLnByb3BzLml0ZW1Db3VudCxcclxuICAgIGl0ZW1zU25hcHNob3Q6IGgucHJvcHMuaXRlbXNTbmFwc2hvdFxyXG4gIH0pKTtcclxufVxyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6ImtUQXdKc0Isc01BQUEifQ==
}),
"[project]/features/shoppingList/hooks/useShoppingListData.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useShoppingListData",
    ()=>useShoppingListData
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/sonner@2.0.7_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$5b8b64__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:5b8b64 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$9244b4__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:9244b4 [app-client] (ecmascript) <text/javascript>");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function normalizeHistory(sessions) {
    return sessions.map((session)=>({
            ...session,
            createdAt: session.createdAt instanceof Date ? session.createdAt : new Date(session.createdAt)
        }));
}
function useShoppingListData(initialItems, initialHistory, initialScope) {
    _s();
    const [scope, setScope] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialScope ?? 'PERSONAL');
    const [items, setItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialItems);
    const [history, setHistory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "useShoppingListData.useState": ()=>normalizeHistory(initialHistory)
    }["useShoppingListData.useState"]);
    const [rooms, setRooms] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useShoppingListData.useEffect": ()=>{
            setItems(initialItems);
            setHistory(normalizeHistory(initialHistory));
        }
    }["useShoppingListData.useEffect"], [
        initialItems,
        initialHistory
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useShoppingListData.useEffect": ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$5b8b64__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getMyShoppingRoomsAction"])().then(setRooms).catch({
                "useShoppingListData.useEffect": (error)=>{
                    console.error('Error loading shopping rooms', error);
                }
            }["useShoppingListData.useEffect"]);
        }
    }["useShoppingListData.useEffect"], []);
    const refreshData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useShoppingListData.useCallback[refreshData]": async ()=>{
            setIsLoading(true);
            try {
                const roomId = scope === 'PERSONAL' ? undefined : scope;
                const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$9244b4__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getShoppingListDataAction"])(roomId);
                if (response.success && response.data) {
                    setItems(response.data.items);
                    setHistory(normalizeHistory(response.data.history));
                } else {
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Error actualitzant la llista");
                }
            } catch (error) {
                console.error('Error fetching shopping list:', error);
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error('Error de connexio');
            } finally{
                setIsLoading(false);
            }
        }
    }["useShoppingListData.useCallback[refreshData]"], [
        scope
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useShoppingListData.useEffect": ()=>{
            if (scope === 'PERSONAL' && items === initialItems) return;
            refreshData();
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["useShoppingListData.useEffect"], [
        scope
    ]);
    return {
        scope,
        setScope,
        items,
        setItems,
        history,
        setHistory,
        rooms,
        isLoading,
        refreshData
    };
}
_s(useShoppingListData, "sXDMcIisP8xjYOI0m8yX8SVfmrA=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/adapters/supabase/browser.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createClient",
    ()=>createClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$supabase$2b$ssr$40$0$2e$8$2e$0_$40$supabase$2b$supabase$2d$js$40$2$2e$89$2e$0$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@supabase+ssr@0.8.0_@supabase+supabase-js@2.89.0/node_modules/@supabase/ssr/dist/module/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$supabase$2b$ssr$40$0$2e$8$2e$0_$40$supabase$2b$supabase$2d$js$40$2$2e$89$2e$0$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@supabase+ssr@0.8.0_@supabase+supabase-js@2.89.0/node_modules/@supabase/ssr/dist/module/createBrowserClient.js [app-client] (ecmascript)");
;
function createClient() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$supabase$2b$ssr$40$0$2e$8$2e$0_$40$supabase$2b$supabase$2d$js$40$2$2e$89$2e$0$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBrowserClient"])(("TURBOPACK compile-time value", "https://bewsqdfbspvwkaojncjs.supabase.co"), ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJld3NxZGZic3B2d2thb2puY2pzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjY3ODI2MzcsImV4cCI6MjA4MjM1ODYzN30.0aiiaskagTAUIp3Vnj9qCJ_ub0Fu8N6lZz1xR2tff3M"));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/shoppingList/hooks/useRealtimeShoppingList.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useRealtimeShoppingList",
    ()=>useRealtimeShoppingList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$adapters$2f$supabase$2f$browser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/adapters/supabase/browser.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function useRealtimeShoppingList(scope, userId, onRefresh) {
    _s();
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useRealtimeShoppingList.useMemo[supabase]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$adapters$2f$supabase$2f$browser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])()
    }["useRealtimeShoppingList.useMemo[supabase]"], []);
    const onRefreshRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(onRefresh);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useRealtimeShoppingList.useEffect": ()=>{
            onRefreshRef.current = onRefresh;
        }
    }["useRealtimeShoppingList.useEffect"], [
        onRefresh
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useRealtimeShoppingList.useEffect": ()=>{
            const filterString = scope === 'PERSONAL' ? `and=(room_id.is.null,user_id.eq.${userId})` : `room_id=eq.${scope}`;
            console.log(`🔌 [REALTIME] ShoppingList connectant... (${scope})`);
            console.log(`🔎 [REALTIME] Filter: ${filterString}`);
            const itemsChannel = supabase.channel(`shopping-list-items-${scope}`).on('postgres_changes', {
                event: '*',
                schema: 'public',
                table: 'shopping_list_items',
                filter: filterString
            }, {
                "useRealtimeShoppingList.useEffect.itemsChannel": ()=>{
                    console.log('✅ [REALTIME] Event shopping_list_items');
                    if (onRefreshRef.current) onRefreshRef.current();
                }
            }["useRealtimeShoppingList.useEffect.itemsChannel"]).subscribe({
                "useRealtimeShoppingList.useEffect.itemsChannel": (status)=>{
                    if (status === 'SUBSCRIBED') {
                        console.log(`✅ [REALTIME] Items subscrit (${scope})`);
                    }
                    if (status === 'CHANNEL_ERROR') {
                        console.error('❌ [REALTIME] Items error');
                    }
                }
            }["useRealtimeShoppingList.useEffect.itemsChannel"]);
            const sessionsChannel = supabase.channel(`shopping-list-sessions-${scope}`).on('postgres_changes', {
                event: '*',
                schema: 'public',
                table: 'shopping_sessions',
                filter: filterString
            }, {
                "useRealtimeShoppingList.useEffect.sessionsChannel": ()=>{
                    console.log('✅ [REALTIME] Event shopping_sessions');
                    if (onRefreshRef.current) onRefreshRef.current();
                }
            }["useRealtimeShoppingList.useEffect.sessionsChannel"]).subscribe({
                "useRealtimeShoppingList.useEffect.sessionsChannel": (status)=>{
                    if (status === 'SUBSCRIBED') {
                        console.log(`✅ [REALTIME] Sessions subscrit (${scope})`);
                    }
                    if (status === 'CHANNEL_ERROR') {
                        console.error('❌ [REALTIME] Sessions error');
                    }
                }
            }["useRealtimeShoppingList.useEffect.sessionsChannel"]);
            return ({
                "useRealtimeShoppingList.useEffect": ()=>{
                    console.log(`🔌 [REALTIME] Tancant shopping list (${scope})`);
                    supabase.removeChannel(itemsChannel);
                    supabase.removeChannel(sessionsChannel);
                }
            })["useRealtimeShoppingList.useEffect"];
        }
    }["useRealtimeShoppingList.useEffect"], [
        scope,
        userId
    ]);
}
_s(useRealtimeShoppingList, "DDIRBq4QuBpQxb7wEeaBd6GrGrU=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/shoppingList/components/ShoppingListManager.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ShoppingListManager",
    ()=>ShoppingListManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/sonner@2.0.7_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
// Accions
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$6ba89e__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:6ba89e [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$079bca__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:079bca [app-client] (ecmascript) <text/javascript>");
// Contextos
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/onboarding/OnboardingContext.tsx [app-client] (ecmascript)");
// Components
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$TourTrigger$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/onboarding/TourTrigger.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$components$2f$ShoppingListItem$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/shoppingList/components/ShoppingListItem.tsx [app-client] (ecmascript)"); // Assegura't de tenir aquest import correcte
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$components$2f$ShoppingHistory$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/shoppingList/components/ShoppingHistory.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$components$2f$BulkAddShoppingItemForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/shoppingList/components/BulkAddShoppingItemForm.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$components$2f$ShoppingHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/shoppingList/components/ShoppingHeader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$components$2f$ShoppingStats$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/shoppingList/components/ShoppingStats.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$components$2f$ShoppingListContextSelector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/shoppingList/components/ShoppingListContextSelector.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$hooks$2f$useShoppingListData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/shoppingList/hooks/useShoppingListData.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$hooks$2f$useRealtimeShoppingList$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/shoppingList/hooks/useRealtimeShoppingList.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// ARXIU: src/features/shoppingList/components/ShoppingListManager.tsx
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function ShoppingListManager({ initialItems, history: initialHistory, initialScope, userId }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const { startTour } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"])();
    const isE2E = ("TURBOPACK compile-time value", "true") === 'true';
    // --- ESTAT ---
    const [activeTab, setActiveTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('active');
    const { scope, setScope, items, setItems, history, rooms, isLoading, refreshData } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$hooks$2f$useShoppingListData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShoppingListData"])(initialItems, initialHistory, initialScope);
    const [isCompleting, setIsCompleting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isAddMode, setIsAddMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const activeRoomId = scope === 'PERSONAL' ? undefined : scope;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$hooks$2f$useRealtimeShoppingList$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRealtimeShoppingList"])(scope, userId, refreshData);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ShoppingListManager.useEffect": ()=>{
            if (scope === 'PERSONAL') {
                router.replace('/shopping-list', {
                    scroll: false
                });
            } else {
                router.replace(`/shopping-list?room=${scope}`, {
                    scroll: false
                });
            }
        }
    }["ShoppingListManager.useEffect"], [
        scope,
        router
    ]);
    // --- CÀLCULS ---
    const cartTotal = items.filter((i)=>i.isChecked).reduce((acc, i)=>acc + (i.estimatedCost || 0) * i.quantity, 0);
    const pendingTotal = items.filter((i)=>!i.isChecked).reduce((acc, i)=>acc + (i.estimatedCost || 0) * i.quantity, 0);
    const grandTotal = cartTotal + pendingTotal;
    const checkedCount = items.filter((i)=>i.isChecked).length;
    // --- TOUR ---
    const onboardingSteps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ShoppingListManager.useMemo[onboardingSteps]": ()=>[
                {
                    targetId: 'tour-shopping-header',
                    title: t.onboarding?.shopping?.step_welcome_title || "Benvingut",
                    description: t.onboarding?.shopping?.step_welcome_desc || "Descripció..."
                },
                {
                    targetId: 'tour-shopping-tabs',
                    title: t.onboarding?.shopping?.step_tabs_title,
                    description: t.onboarding?.shopping?.step_tabs_desc
                },
                {
                    targetId: 'tour-shopping-stats',
                    title: t.onboarding?.shopping?.step_stats_title,
                    description: t.onboarding?.shopping?.step_stats_desc
                },
                {
                    targetId: 'tour-shopping-add-btn',
                    title: t.onboarding?.shopping?.step_add_title,
                    description: t.onboarding?.shopping?.step_add_desc
                },
                {
                    targetId: 'tour-shopping-finish-btn',
                    title: t.onboarding?.shopping?.step_finish_title,
                    description: t.onboarding?.shopping?.step_finish_desc
                }
            ]
    }["ShoppingListManager.useMemo[onboardingSteps]"], [
        t
    ]);
    // Filtrar passos actius
    const activeSteps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ShoppingListManager.useMemo[activeSteps]": ()=>{
            return onboardingSteps.filter({
                "ShoppingListManager.useMemo[activeSteps]": (step)=>{
                    if (step.targetId === 'tour-shopping-finish-btn' && checkedCount === 0) return false;
                    return true;
                }
            }["ShoppingListManager.useMemo[activeSteps]"]);
        }
    }["ShoppingListManager.useMemo[activeSteps]"], [
        onboardingSteps,
        checkedCount
    ]);
    // Auto-start del tour
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ShoppingListManager.useEffect": ()=>{
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            return;
        }
    }["ShoppingListManager.useEffect"], [
        startTour,
        activeSteps,
        isE2E
    ]);
    // --- HANDLERS ---
    const handleToggle = async (id, currentStatus)=>{
        setItems((prev)=>prev.map((i)=>i.id === id ? {
                    ...i,
                    isChecked: !currentStatus
                } : i));
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$6ba89e__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["toggleShoppingItemAction"])(id, !currentStatus);
    };
    const handleFinish = async ()=>{
        if (checkedCount === 0) return;
        setIsCompleting(true);
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$079bca__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["completeShoppingSessionAction"])(activeRoomId);
        if (result.success) {
            await refreshData();
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success(`🎉 Compra finalitzada!`, {
                description: `Cost total: ${cartTotal.toFixed(2)}€`
            });
        } else {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Error al finalitzar", {
                description: result.error
            });
        }
        setIsCompleting(false);
    };
    const handleCloseModal = ()=>{
        setIsAddMode(false);
        refreshData();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                children: isAddMode && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$components$2f$BulkAddShoppingItemForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BulkAddShoppingItemForm"], {
                    onClose: handleCloseModal,
                    activeRoomId: activeRoomId
                }, void 0, false, {
                    fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                    lineNumber: 151,
                    columnNumber: 31
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                lineNumber: 150,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-6 pb-24",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        id: "tour-shopping-header",
                        className: "sticky top-0 z-40 bg-slate-950/80 backdrop-blur-md pt-4 pb-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$components$2f$ShoppingHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ShoppingHeader"], {
                                        activeTab: activeTab,
                                        onTabChange: setActiveTab,
                                        onSearchClick: ()=>setIsAddMode(true),
                                        tourId: "tour-shopping-tabs",
                                        contextSelector: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$components$2f$ShoppingListContextSelector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ShoppingListContextSelector"], {
                                            scope: scope,
                                            setScope: setScope,
                                            rooms: rooms
                                        }, void 0, false, {
                                            fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                                            lineNumber: 166,
                                            columnNumber: 37
                                        }, void 0)
                                    }, void 0, false, {
                                        fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                                        lineNumber: 160,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                                    lineNumber: 159,
                                    columnNumber: 25
                                }, this),
                                !isE2E && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$TourTrigger$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TourTrigger"], {
                                    tourId: "shopping-list-v1",
                                    steps: activeSteps,
                                    className: "bg-slate-900 border-slate-800 text-purple-400 hover:bg-slate-800 shrink-0"
                                }, void 0, false, {
                                    fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                                    lineNumber: 175,
                                    columnNumber: 29
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                            lineNumber: 158,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                        lineNumber: 157,
                        columnNumber: 17
                    }, this),
                    activeTab === 'active' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                        initial: {
                            opacity: 0,
                            x: -20
                        },
                        animate: {
                            opacity: 1,
                            x: 0
                        },
                        className: "space-y-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                id: "tour-shopping-stats",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$components$2f$ShoppingStats$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ShoppingStats"], {
                                    grandTotal: grandTotal,
                                    cartTotal: cartTotal
                                }, void 0, false, {
                                    fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                                    lineNumber: 191,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                                lineNumber: 190,
                                columnNumber: 25
                            }, this),
                            isLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-xs text-slate-500",
                                children: "Carregant llista..."
                            }, void 0, false, {
                                fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                                lineNumber: 195,
                                columnNumber: 29
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-2 pb-32",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                                        mode: "popLayout",
                                        children: items.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$components$2f$ShoppingListItem$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ShoppingListItem"], {
                                                item: item,
                                                onToggle: handleToggle
                                            }, item.id, false, {
                                                fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                                                lineNumber: 204,
                                                columnNumber: 37
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                                        lineNumber: 202,
                                        columnNumber: 29
                                    }, this),
                                    items.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-center py-10 text-slate-500 bg-slate-900/20 rounded-xl border border-slate-800/50 border-dashed",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-2xl mb-2",
                                                children: "🛒"
                                            }, void 0, false, {
                                                fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                                                lineNumber: 210,
                                                columnNumber: 37
                                            }, this),
                                            "Tot net! Afegeix coses per comprar."
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                                        lineNumber: 209,
                                        columnNumber: 33
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                                lineNumber: 201,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                                children: checkedCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                    id: "tour-shopping-finish-btn",
                                    initial: {
                                        y: 100
                                    },
                                    animate: {
                                        y: 0
                                    },
                                    exit: {
                                        y: 100
                                    },
                                    className: "fixed bottom-6 left-0 right-0 px-4 flex justify-center z-40",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: handleFinish,
                                        disabled: isCompleting,
                                        className: "bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 px-8 rounded-full shadow-2xl shadow-emerald-900/50 flex items-center gap-3 transition-all active:scale-95 border-t border-emerald-400/20",
                                        children: [
                                            isCompleting ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "animate-spin",
                                                children: "⏳"
                                            }, void 0, false, {
                                                fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                                                lineNumber: 229,
                                                columnNumber: 57
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "💳 Finalitzar Compra"
                                            }, void 0, false, {
                                                fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                                                lineNumber: 229,
                                                columnNumber: 99
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "bg-emerald-800 px-2 py-0.5 rounded-full text-xs font-mono border border-emerald-700",
                                                children: [
                                                    cartTotal.toFixed(2),
                                                    "€"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                                                lineNumber: 230,
                                                columnNumber: 41
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                                        lineNumber: 224,
                                        columnNumber: 37
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                                    lineNumber: 219,
                                    columnNumber: 33
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                                lineNumber: 217,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                        lineNumber: 185,
                        columnNumber: 21
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                        initial: {
                            opacity: 0,
                            x: 20
                        },
                        animate: {
                            opacity: 1,
                            x: 0
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$components$2f$ShoppingHistory$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ShoppingHistory"], {
                            sessions: history
                        }, void 0, false, {
                            fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                            lineNumber: 241,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                        lineNumber: 240,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/shoppingList/components/ShoppingListManager.tsx",
                lineNumber: 154,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true);
}
_s(ShoppingListManager, "tdG/KQSKsjDaeUBJfvk2F7QIjtA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"],
        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"],
        __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$hooks$2f$useShoppingListData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShoppingListData"],
        __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$shoppingList$2f$hooks$2f$useRealtimeShoppingList$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRealtimeShoppingList"]
    ];
});
_c = ShoppingListManager;
var _c;
__turbopack_context__.k.register(_c, "ShoppingListManager");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/onboarding/OnboardingOverlay.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OnboardingOverlay",
    ()=>OnboardingOverlay
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/onboarding/OnboardingContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function OnboardingOverlay() {
    _s();
    const { isActive, steps, currentStepIndex, nextStep, prevStep, skipTour } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"])();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [targetRect, setTargetRect] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [windowSize, setWindowSize] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        w: 0,
        h: 0
    });
    const currentStep = steps[currentStepIndex];
    // 1. Detectar posició i mida finestra
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OnboardingOverlay.useEffect": ()=>{
            if (!isActive || !currentStep) return;
            const updatePosition = {
                "OnboardingOverlay.useEffect.updatePosition": ()=>{
                    setWindowSize({
                        w: window.innerWidth,
                        h: window.innerHeight
                    });
                    const element = document.getElementById(currentStep.targetId);
                    if (element) {
                        // En mòbil preferim 'center' per tenir-lo a la vista, 
                        // la nostra nova lògica s'apartarà d'ell.
                        element.scrollIntoView({
                            behavior: 'smooth',
                            block: 'center'
                        });
                        setTimeout({
                            "OnboardingOverlay.useEffect.updatePosition": ()=>{
                                const rect = element.getBoundingClientRect();
                                setTargetRect(rect);
                            }
                        }["OnboardingOverlay.useEffect.updatePosition"], 150);
                    } else {
                        setTargetRect(null);
                    }
                }
            }["OnboardingOverlay.useEffect.updatePosition"];
            const timeout = setTimeout(updatePosition, 100);
            window.addEventListener('resize', updatePosition);
            window.addEventListener('scroll', updatePosition);
            return ({
                "OnboardingOverlay.useEffect": ()=>{
                    clearTimeout(timeout);
                    window.removeEventListener('resize', updatePosition);
                    window.removeEventListener('scroll', updatePosition);
                }
            })["OnboardingOverlay.useEffect"];
        }
    }["OnboardingOverlay.useEffect"], [
        isActive,
        currentStepIndex,
        currentStep
    ]);
    if (!isActive || !currentStep) return null;
    // --- LÒGICA DE POSICIONAMENT INTEL·LIGENT (MOBILE & DESKTOP) 🧠 ---
    const isMobile = windowSize.w > 0 && windowSize.w < 768;
    // 1. ESTAT BASE (Fallback segur: Fixat a baix)
    let cardStyles = {
        position: 'fixed',
        top: 'auto',
        bottom: 24,
        left: '50%',
        x: '-50%',
        y: 0,
        width: '90%',
        maxWidth: '400px'
    };
    if (targetRect && windowSize.h > 0) {
        // --- LÒGICA MÒBIL: HEMISFERI OPOSAT ---
        if (isMobile) {
            const elementCenterY = targetRect.top + targetRect.height / 2;
            const screenCenterY = windowSize.h / 2;
            // Si l'element està a la meitat INFERIOR de la pantalla (> centre)
            if (elementCenterY > screenCenterY) {
                // Posem la targeta a DALT
                cardStyles = {
                    position: 'fixed',
                    top: 24,
                    bottom: 'auto',
                    left: '50%',
                    x: '-50%',
                    y: 0,
                    width: '90%',
                    maxWidth: '400px'
                };
            } else {
                // Si l'element està a la meitat SUPERIOR (< centre)
                // Posem la targeta a BAIX (lògica per defecte, però explicita aquí)
                cardStyles = {
                    position: 'fixed',
                    top: 'auto',
                    bottom: 24,
                    left: '50%',
                    x: '-50%',
                    y: 0,
                    width: '90%',
                    maxWidth: '400px'
                };
            }
        } else {
            const spaceAbove = targetRect.top;
            const spaceBelow = windowSize.h - targetRect.bottom;
            const CARD_HEIGHT = 220;
            // Si tenim espai a SOTA -> Absolute a sota
            if (spaceBelow > CARD_HEIGHT) {
                cardStyles = {
                    position: 'absolute',
                    top: targetRect.bottom + 20,
                    bottom: 'auto',
                    left: Math.max(20, Math.min(targetRect.left, windowSize.w - 380)),
                    x: 0,
                    y: 0,
                    width: '380px',
                    maxWidth: '380px'
                };
            } else if (spaceAbove > CARD_HEIGHT) {
                cardStyles = {
                    position: 'absolute',
                    top: targetRect.top - 20,
                    bottom: 'auto',
                    left: Math.max(20, Math.min(targetRect.left, windowSize.w - 380)),
                    x: 0,
                    y: '-100%',
                    width: '380px',
                    maxWidth: '380px'
                };
            }
        // Si no hi cap enlloc (rar en desktop) -> Es queda fixed center o bottom (fallback)
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-9999 overflow-hidden pointer-events-none",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                className: "absolute rounded-xl pointer-events-none transition-all duration-500 ease-in-out box-content border-4 border-purple-500/50",
                initial: false,
                animate: {
                    top: targetRect ? targetRect.top - 4 : '50%',
                    left: targetRect ? targetRect.left - 4 : '50%',
                    width: targetRect ? targetRect.width + 8 : 0,
                    height: targetRect ? targetRect.height + 8 : 0,
                    opacity: targetRect ? 1 : 0,
                    boxShadow: `0 0 0 9999px rgba(2, 6, 23, 0.85)`
                }
            }, void 0, false, {
                fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                lineNumber: 157,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                mode: "wait",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "pointer-events-auto z-10000",
                    style: {
                        position: cardStyles.position,
                        width: cardStyles.width,
                        maxWidth: cardStyles.maxWidth,
                        // Apliquem top/bottom dinàmicament
                        top: cardStyles.top,
                        bottom: cardStyles.bottom,
                        left: cardStyles.left,
                        right: cardStyles.right
                    },
                    initial: {
                        opacity: 0,
                        scale: 0.9,
                        x: cardStyles.x,
                        y: cardStyles.y
                    },
                    animate: {
                        opacity: 1,
                        scale: 1,
                        // Necessitem passar explícitament top/bottom a l'animate per suavitzar canvis
                        top: cardStyles.top,
                        bottom: cardStyles.bottom,
                        left: cardStyles.left,
                        x: cardStyles.x,
                        y: cardStyles.y
                    },
                    exit: {
                        opacity: 0,
                        scale: 0.95
                    },
                    transition: {
                        duration: 0.4,
                        type: "spring",
                        damping: 25,
                        stiffness: 200
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-slate-900 border border-slate-700 text-white p-5 rounded-2xl shadow-2xl relative",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: skipTour,
                                className: "absolute top-3 right-3 text-slate-500 hover:text-white transition-colors",
                                title: t.onboarding.buttons.skip,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                    size: 16
                                }, void 0, false, {
                                    fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                    lineNumber: 209,
                                    columnNumber: 21
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                lineNumber: 204,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-6 pr-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-lg font-bold mb-2 flex items-center gap-2 text-purple-200",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "bg-purple-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs shadow-lg shadow-purple-500/30 shrink-0",
                                                children: currentStepIndex + 1
                                            }, void 0, false, {
                                                fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                                lineNumber: 215,
                                                columnNumber: 25
                                            }, this),
                                            currentStep.title
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                        lineNumber: 214,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-slate-300 text-sm leading-relaxed",
                                        children: currentStep.description
                                    }, void 0, false, {
                                        fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                        lineNumber: 220,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                lineNumber: 213,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex gap-1.5",
                                        children: steps.map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `w-1.5 h-1.5 rounded-full transition-colors ${i === currentStepIndex ? 'bg-purple-500 scale-125' : 'bg-slate-700'}`
                                            }, i, false, {
                                                fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                                lineNumber: 229,
                                                columnNumber: 29
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                        lineNumber: 227,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex gap-2",
                                        children: [
                                            currentStepIndex > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: prevStep,
                                                className: "px-3 py-2 rounded-lg text-sm font-bold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors",
                                                children: t.onboarding.buttons.back
                                            }, void 0, false, {
                                                fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                                lineNumber: 238,
                                                columnNumber: 29
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: nextStep,
                                                className: "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold bg-purple-600 hover:bg-purple-500 text-white shadow-lg shadow-purple-900/20 transition-all active:scale-95",
                                                children: currentStepIndex === steps.length - 1 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                    children: [
                                                        " ",
                                                        t.onboarding.buttons.finish,
                                                        " ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                                            size: 16
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                                            lineNumber: 251,
                                                            columnNumber: 66
                                                        }, this),
                                                        " "
                                                    ]
                                                }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                    children: [
                                                        " ",
                                                        t.onboarding.buttons.next,
                                                        " ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                                            size: 16
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                                            lineNumber: 253,
                                                            columnNumber: 64
                                                        }, this),
                                                        " "
                                                    ]
                                                }, void 0, true)
                                            }, void 0, false, {
                                                fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                                lineNumber: 246,
                                                columnNumber: 25
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                        lineNumber: 236,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                lineNumber: 226,
                                columnNumber: 17
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                        lineNumber: 201,
                        columnNumber: 13
                    }, this)
                }, currentStepIndex, false, {
                    fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                    lineNumber: 172,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                lineNumber: 171,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
        lineNumber: 154,
        columnNumber: 5
    }, this);
}
_s(OnboardingOverlay, "2zLw7UVeLwdBtmkHpjmSjIvvINg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = OnboardingOverlay;
var _c;
__turbopack_context__.k.register(_c, "OnboardingOverlay");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_4fb9f4dc._.js.map