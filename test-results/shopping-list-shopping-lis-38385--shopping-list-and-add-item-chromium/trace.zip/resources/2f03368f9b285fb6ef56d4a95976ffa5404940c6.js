(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_a46c7f26._.js",
  "static/chunks/node_modules__pnpm_991bcc5a._.js"
],
    source: "dynamic"
});
