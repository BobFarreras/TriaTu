(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/actions/data:f52072 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "signOutAction",
    ()=>$$RSC_SERVER_ACTION_2
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"00648a5c3020a7b5101155864afaab60217c174f2a":"signOutAction"},"app/actions/auth-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("00648a5c3020a7b5101155864afaab60217c174f2a", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "signOutAction");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYXV0aC1hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9hcHAvYWN0aW9ucy9hdXRoLWFjdGlvbnMudHNcclxuJ3VzZSBzZXJ2ZXInXHJcblxyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gJ25leHQvY2FjaGUnO1xyXG5pbXBvcnQgeyByZWRpcmVjdCB9IGZyb20gJ25leHQvbmF2aWdhdGlvbic7XHJcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2Uvc2VydmVyJztcclxuXHJcbi8vIOKchSBEZWZpbmltIGxhIGludGVyZsOtY2llIGRlIHJlc3Bvc3RhIChEb21haW4gTGF5ZXIpXHJcbi8vIEFpeMOyIMOpcyBDbGVhbiBDb2RlOiBkZWZpbmltIGVsIGNvbnRyYWN0ZSBkZWwgcXVlIHJldG9ybmEgbGEgbm9zdHJhIGFjY2nDs1xyXG5leHBvcnQgdHlwZSBBdXRoUmVzdWx0ID0geyBlcnJvcjogc3RyaW5nIH0gfCB2b2lkO1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGxvZ2luKGZvcm1EYXRhOiBGb3JtRGF0YSk6IFByb21pc2U8QXV0aFJlc3VsdD4ge1xyXG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcblxyXG4gIGNvbnN0IGVtYWlsID0gZm9ybURhdGEuZ2V0KCdlbWFpbCcpIGFzIHN0cmluZztcclxuICBjb25zdCBwYXNzd29yZCA9IGZvcm1EYXRhLmdldCgncGFzc3dvcmQnKSBhcyBzdHJpbmc7XHJcbiAgY29uc3QgbmV4dFJhdyA9IGZvcm1EYXRhLmdldCgnbmV4dCcpIGFzIHN0cmluZztcclxuICAvLyBTYW5pdGl6ZTogU2kgbmV4dCDDqXMgYnVpdCBvIG51bGwsIGZhbGxiYWNrIGEgZGFzaGJvYXJkXHJcbiAgY29uc3QgbmV4dCA9IG5leHRSYXcgfHwgJy9kYXNoYm9hcmQnO1xyXG5cclxuICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25JbldpdGhQYXNzd29yZCh7XHJcbiAgICBlbWFpbCxcclxuICAgIHBhc3N3b3JkLFxyXG4gIH0pO1xyXG5cclxuICBpZiAoZXJyb3IpIHtcclxuICAgIC8vIFJldG9ybmVtIGwnb2JqZWN0ZSBkJ2Vycm9yIChjb21wYXRpYmxlIGFtYiBBdXRoUmVzdWx0KVxyXG4gICAgcmV0dXJuIHsgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfTtcclxuICB9XHJcblxyXG4gIC8vIFByZXZlbmNpw7MgT3BlbiBSZWRpcmVjdFxyXG4gIGNvbnN0IGZpbmFsUmVkaXJlY3QgPSBuZXh0LnN0YXJ0c1dpdGgoJy8nKSA/IG5leHQgOiAnL2Rhc2hib2FyZCc7XHJcblxyXG4gIHJldmFsaWRhdGVQYXRoKCcvJywgJ2xheW91dCcpO1xyXG4gIC8vIFJlZGlyZWN0IGxsYW7Dp2EgdW5hIGV4Y2VwY2nDsyBpbnRlcm5hIChcIk5FWFRfUkVESVJFQ1RcIiksIHBlciB0YW50LCB0w6hjbmljYW1lbnQgcmV0b3JuYSBgdm9pZGAgYWJhbnMgZGUgc29ydGlyLlxyXG4gIHJlZGlyZWN0KGZpbmFsUmVkaXJlY3QpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2lnbnVwKGZvcm1EYXRhOiBGb3JtRGF0YSk6IFByb21pc2U8QXV0aFJlc3VsdD4ge1xyXG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcblxyXG4gIGNvbnN0IGVtYWlsID0gZm9ybURhdGEuZ2V0KCdlbWFpbCcpIGFzIHN0cmluZztcclxuICBjb25zdCBwYXNzd29yZCA9IGZvcm1EYXRhLmdldCgncGFzc3dvcmQnKSBhcyBzdHJpbmc7XHJcbiAgY29uc3QgbmV4dFJhdyA9IGZvcm1EYXRhLmdldCgnbmV4dCcpIGFzIHN0cmluZztcclxuICBjb25zdCBuZXh0ID0gbmV4dFJhdyB8fCAnL2Rhc2hib2FyZCc7XHJcblxyXG4gIGNvbnN0IHsgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguc2lnblVwKHtcclxuICAgIGVtYWlsLFxyXG4gICAgcGFzc3dvcmQsXHJcbiAgfSk7XHJcblxyXG4gIGlmIChlcnJvcikge1xyXG4gICAgcmV0dXJuIHsgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfTtcclxuICB9XHJcblxyXG4gIGNvbnN0IGZpbmFsUmVkaXJlY3QgPSBuZXh0LnN0YXJ0c1dpdGgoJy8nKSA/IG5leHQgOiAnL2Rhc2hib2FyZCc7XHJcblxyXG4gIHJldmFsaWRhdGVQYXRoKCcvJywgJ2xheW91dCcpO1xyXG4gIHJlZGlyZWN0KGZpbmFsUmVkaXJlY3QpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2lnbk91dEFjdGlvbigpIHtcclxuICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gIGF3YWl0IHN1cGFiYXNlLmF1dGguc2lnbk91dCgpO1xyXG4gIHJlZGlyZWN0KCcvJyk7XHJcbn0iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjZSQTZEc0IsMExBQUEifQ==
}),
"[project]/features/dashboard/components/DashboardHeader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DashboardHeader",
    ()=>DashboardHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$f52072__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:f52072 [app-client] (ecmascript) <text/javascript>");
;
var _s = __turbopack_context__.k.signature();
// src/components/dashboard/DashboardHeader.tsx
'use client';
;
;
;
function DashboardHeader({ userName }) {
    _s();
    // Obtenim l'objecte de traduccions 't' i el mètode per canviar idioma
    const { t, changeLanguage, locale } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [isLangOpen, setIsLangOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const dropdownRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const langs = [
        {
            code: 'ca',
            emoji: '🐲',
            label: 'CAT'
        },
        {
            code: 'es',
            emoji: '💃',
            label: 'ESP'
        },
        {
            code: 'en',
            emoji: '🍔',
            label: 'ENG'
        }
    ];
    const currentLang = langs.find((l)=>l.code === locale) || langs[0];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DashboardHeader.useEffect": ()=>{
            function handleClickOutside(event) {
                if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                    setIsLangOpen(false);
                }
            }
            document.addEventListener("mousedown", handleClickOutside);
            return ({
                "DashboardHeader.useEffect": ()=>document.removeEventListener("mousedown", handleClickOutside)
            })["DashboardHeader.useEffect"];
        }
    }["DashboardHeader.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: "relative z-50 w-full flex flex-nowrap items-center justify-between gap-2 mb-2 animate-in fade-in slide-in-from-top-4 duration-500 pt-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 min-w-0 overflow-hidden pr-2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col min-w-0",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-baseline gap-2 min-w-0",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "text-xl md:text-2xl font-black text-white tracking-tight leading-none truncate",
                                    children: [
                                        t.dashboard.greeting,
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-transparent bg-clip-text bg-linear-to-r from-purple-400 to-pink-400",
                                            children: userName
                                        }, void 0, false, {
                                            fileName: "[project]/features/dashboard/components/DashboardHeader.tsx",
                                            lineNumber: 45,
                                            columnNumber: 43
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/features/dashboard/components/DashboardHeader.tsx",
                                    lineNumber: 43,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-xl animate-wave origin-bottom-right",
                                    children: "👋"
                                }, void 0, false, {
                                    fileName: "[project]/features/dashboard/components/DashboardHeader.tsx",
                                    lineNumber: 47,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/features/dashboard/components/DashboardHeader.tsx",
                            lineNumber: 42,
                            columnNumber: 14
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex mt-0.5",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[9px] font-black text-emerald-400 bg-emerald-900/40 px-1.5 py-0.5 rounded border border-emerald-500/30 uppercase tracking-widest shadow-[0_0_8px_rgba(16,185,129,0.2)]",
                                children: t.dashboard.level || "LVL 1"
                            }, void 0, false, {
                                fileName: "[project]/features/dashboard/components/DashboardHeader.tsx",
                                lineNumber: 50,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/features/dashboard/components/DashboardHeader.tsx",
                            lineNumber: 49,
                            columnNumber: 14
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/features/dashboard/components/DashboardHeader.tsx",
                    lineNumber: 41,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/DashboardHeader.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-1.5 bg-black/40 backdrop-blur-md p-1 rounded-xl border border-white/10 shrink-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative",
                        ref: dropdownRef,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setIsLangOpen(!isLangOpen),
                                className: `w-9 h-9 flex items-center justify-center rounded-lg text-lg transition-all border border-transparent ${isLangOpen ? 'bg-zinc-700 border-zinc-500' : 'hover:bg-zinc-800'}`,
                                children: currentLang.emoji
                            }, void 0, false, {
                                fileName: "[project]/features/dashboard/components/DashboardHeader.tsx",
                                lineNumber: 63,
                                columnNumber: 13
                            }, this),
                            isLangOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute top-full right-0 mt-2 bg-zinc-900 border border-zinc-700 p-1.5 rounded-xl shadow-2xl flex flex-col gap-1 z-100 min-w-12.5 animate-in zoom-in-95 duration-200",
                                children: langs.map((l)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            changeLanguage(l.code);
                                            setIsLangOpen(false);
                                        },
                                        className: `w-full p-2 rounded-lg text-lg hover:bg-zinc-800 transition-colors flex justify-center ${locale === l.code ? 'bg-zinc-800 border border-zinc-600' : ''}`,
                                        children: l.emoji
                                    }, l.code, false, {
                                        fileName: "[project]/features/dashboard/components/DashboardHeader.tsx",
                                        lineNumber: 73,
                                        columnNumber: 25
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/features/dashboard/components/DashboardHeader.tsx",
                                lineNumber: 71,
                                columnNumber: 17
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/dashboard/components/DashboardHeader.tsx",
                        lineNumber: 62,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-px h-5 bg-white/10 mx-0.5"
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/DashboardHeader.tsx",
                        lineNumber: 85,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$f52072__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["signOutAction"])(),
                        "data-testid": "logout-button",
                        className: "w-9 h-9 bg-red-600 hover:bg-red-500 rounded-lg flex items-center justify-center border-b-[3px] border-red-900 active:border-b-0 active:translate-y-1 transition-all group",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-base group-hover:-translate-x-0.5 transition-transform text-white font-bold",
                            children: "🚪"
                        }, void 0, false, {
                            fileName: "[project]/features/dashboard/components/DashboardHeader.tsx",
                            lineNumber: 93,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/DashboardHeader.tsx",
                        lineNumber: 88,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/dashboard/components/DashboardHeader.tsx",
                lineNumber: 59,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/dashboard/components/DashboardHeader.tsx",
        lineNumber: 37,
        columnNumber: 5
    }, this);
}
_s(DashboardHeader, "UrQuMtpXKmEI/NtDvZxou7NzHpw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = DashboardHeader;
var _c;
__turbopack_context__.k.register(_c, "DashboardHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/pwa/hooks/usePWA.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "usePWA",
    ()=>usePWA
]);
// src/hooks/usePWA.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
function usePWA() {
    _s();
    const [isInstallable, setIsInstallable] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [platform, setPlatform] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isStandalone, setIsStandalone] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [deferredPrompt, setDeferredPrompt] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePWA.useEffect": ()=>{
            // 1. Detecció inicial (Asíncrona per evitar errors de React)
            const timer = setTimeout({
                "usePWA.useEffect.timer": ()=>{
                    const userAgent = window.navigator.userAgent.toLowerCase();
                    const isStandaloneMode = window.matchMedia("(display-mode: standalone)").matches;
                    setIsStandalone(isStandaloneMode);
                    // Detectem la plataforma visualment
                    if (/iphone|ipad|ipod/.test(userAgent)) {
                        setPlatform('ios');
                    } else if (/android/.test(userAgent)) {
                        setPlatform('android');
                    } else {
                        setPlatform('desktop');
                    }
                // ❌ ESBORRA TOT AQUEST BLOC:
                /*
      if (process.env.NODE_ENV === 'development') {
        console.log("🔧 DEV MODE: Forçant visibilitat del botó PWA");
        setIsInstallable(true);
        setPlatform('desktop'); 
      }
      */ }
            }["usePWA.useEffect.timer"], 0);
            // 2. Capturem l'event natiu (Android / Desktop Chrome / Edge)
            const handleBeforeInstallPrompt = {
                "usePWA.useEffect.handleBeforeInstallPrompt": (e)=>{
                    e.preventDefault();
                    setDeferredPrompt(e);
                    setIsInstallable(true);
                // Si salta aquest event, és que el navegador permet instal·lació directa
                // (Pot ser Android o Desktop, l'userAgent ja ho haurà definit a dalt)
                }
            }["usePWA.useEffect.handleBeforeInstallPrompt"];
            window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
            return ({
                "usePWA.useEffect": ()=>{
                    clearTimeout(timer);
                    window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
                }
            })["usePWA.useEffect"];
        }
    }["usePWA.useEffect"], []);
    const installApp = async ()=>{
        // A. Instal·lació Nativa (Android / Desktop)
        if (deferredPrompt) {
            await deferredPrompt.prompt();
            const { outcome } = await deferredPrompt.userChoice;
            if (outcome === 'accepted') {
                setDeferredPrompt(null);
                setIsInstallable(false);
            }
        } else if (platform === 'ios') {
            alert("📲 Per instal·lar a l'iPhone:\n1. Prem el botó 'Compartir' (quadrat amb fletxa)\n2. Baixa i selecciona 'Afegir a la pantalla d'inici'");
        }
    };
    return {
        isInstallable,
        platform,
        isStandalone,
        installApp
    };
}
_s(usePWA, "hHmct71PrvrY4NhBYRVugssmTUc=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/dashboard/components/NavigationPanel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NavigationPanel",
    ()=>NavigationPanel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$pwa$2f$hooks$2f$usePWA$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/pwa/hooks/usePWA.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// src/features/dashboard/components/NavigationPanel.tsx
'use client';
;
;
;
function NavigationPanel() {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const { isInstallable, platform, isStandalone, installApp } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$pwa$2f$hooks$2f$usePWA$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePWA"])();
    const cardBaseClass = "group relative flex-1 min-h-[60px] w-full rounded-2xl border-b-[6px] active:border-b-0 active:translate-y-1.5 active:mt-1.5 transition-all overflow-hidden shadow-xl flex items-center px-4 md:px-6 justify-between";
    const showInstallCard = !isStandalone && (isInstallable || platform === 'ios');
    // CONFIGURACIÓ DINÀMICA DEL BOTÓ
    const getInstallUI = (plat)=>{
        switch(plat){
            case 'ios':
                return {
                    text: "Instal·lar a iPhone",
                    emoji: "🍎",
                    badge: "iOS App",
                    style: "bg-zinc-800 hover:bg-zinc-700 border-zinc-950 shadow-black/30",
                    textStyle: "text-zinc-300 bg-zinc-950/50"
                };
            case 'android':
                return {
                    text: "Instal·lar App",
                    emoji: "🤖",
                    badge: "Android APK",
                    style: "bg-emerald-600 hover:bg-emerald-500 border-emerald-800 shadow-emerald-900/20",
                    textStyle: "text-emerald-100 bg-emerald-800/40"
                };
            case 'desktop':
            default:
                return {
                    text: "Instal·lar al PC",
                    emoji: "💻",
                    badge: "Desktop App",
                    style: "bg-blue-600 hover:bg-blue-500 border-blue-800 shadow-blue-900/20",
                    textStyle: "text-blue-100 bg-blue-800/40"
                };
        }
    };
    const ui = getInstallUI(platform);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        id: "tour-dash-nav",
        className: "flex flex-col gap-3 h-full animate-in slide-in-from-right-4 duration-700 delay-100 pb-1",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "tour-dash-create",
                href: "/rooms/create",
                className: `${cardBaseClass} bg-blue-600 hover:bg-blue-500 border-blue-800 shadow-blue-900/20`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "z-10 flex flex-col justify-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[9px] font-black text-blue-200 bg-blue-800/30 px-2 py-0.5 rounded w-fit mb-0.5",
                                children: t.dashboard.nav.multiplayer_badge
                            }, void 0, false, {
                                fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                                lineNumber: 54,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg md:text-xl font-black text-white leading-none tracking-tight",
                                children: t.dashboard.create_room
                            }, void 0, false, {
                                fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                                lineNumber: 55,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                        lineNumber: 53,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-3xl md:text-5xl filter drop-shadow-lg group-hover:scale-110 group-hover:rotate-6 transition-transform duration-300",
                        children: "🛋️"
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                        lineNumber: 57,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                lineNumber: 52,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "tour-dash-join",
                href: "/join",
                className: `${cardBaseClass} bg-orange-500 hover:bg-orange-400 border-orange-700 shadow-orange-900/20`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "z-10 flex flex-col justify-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[9px] font-black text-orange-100 bg-orange-700/30 px-2 py-0.5 rounded w-fit mb-0.5",
                                children: t.dashboard.nav.guest_badge
                            }, void 0, false, {
                                fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                                lineNumber: 63,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg md:text-xl font-black text-white leading-none tracking-tight",
                                children: t.dashboard.join_room
                            }, void 0, false, {
                                fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                                lineNumber: 64,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                        lineNumber: 62,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-3xl md:text-5xl filter drop-shadow-lg group-hover:scale-110 group-hover:-rotate-12 transition-transform duration-300",
                        children: "🎫"
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                        lineNumber: 66,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                lineNumber: 61,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "tour-dash-recipes",
                href: "/recipes",
                className: `${cardBaseClass} bg-pink-600 hover:bg-pink-500 border-pink-800 shadow-pink-900/20`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "z-10 flex flex-col justify-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-lg md:text-xl font-black text-white leading-none tracking-tight",
                            children: t.dashboard.nav.recipes
                        }, void 0, false, {
                            fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                            lineNumber: 72,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                        lineNumber: 71,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-3xl md:text-5xl filter drop-shadow-lg group-hover:scale-110 group-hover:rotate-3 transition-transform duration-300",
                        children: "🍲"
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                        lineNumber: 74,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                lineNumber: 70,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "tour-dash-ranking",
                href: "/ranking",
                className: `${cardBaseClass} bg-amber-500 hover:bg-amber-400 border-amber-700 shadow-amber-900/20`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg md:text-xl font-black text-white leading-none tracking-tight",
                        children: t.dashboard.nav.ranking
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                        lineNumber: 79,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-3xl md:text-5xl filter drop-shadow-lg group-hover:scale-110 group-hover:-rotate-6 transition-transform duration-300",
                        children: "🏆"
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                        lineNumber: 80,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                lineNumber: 78,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "tour-dash-rooms",
                href: "/rooms",
                className: `${cardBaseClass} bg-indigo-600 hover:bg-indigo-500 border-indigo-800 shadow-indigo-900/20`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg md:text-xl font-black text-white leading-none tracking-tight",
                        children: t.dashboard.nav.my_rooms
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                        lineNumber: 85,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-3xl md:text-5xl filter drop-shadow-lg group-hover:scale-110 group-hover:-rotate-6 transition-transform duration-300",
                        children: "🏘️"
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                        lineNumber: 86,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                lineNumber: 84,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "tour-dash-inventory",
                href: "/inventory",
                className: `${cardBaseClass} bg-emerald-600 hover:bg-emerald-500 border-emerald-800 shadow-emerald-900/20`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg md:text-xl font-black text-white leading-none tracking-tight",
                        children: t.dashboard.nav.inventory
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                        lineNumber: 91,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-3xl md:text-5xl filter drop-shadow-lg group-hover:scale-110 group-hover:translate-x-1 transition-transform duration-300",
                        children: "📦"
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                        lineNumber: 92,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                lineNumber: 90,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "tour-dash-shopping",
                href: "/shopping-list",
                className: `${cardBaseClass} bg-purple-600 hover:bg-purple-500 border-purple-800 shadow-purple-900/20`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "z-10 flex flex-col justify-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-lg md:text-xl font-black text-white leading-none tracking-tight",
                            children: "Llista Compra"
                        }, void 0, false, {
                            fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                            lineNumber: 100,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                        lineNumber: 97,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-3xl md:text-5xl filter drop-shadow-lg group-hover:scale-110 group-hover:-rotate-12 transition-transform duration-300",
                        children: "📝"
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                        lineNumber: 102,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                lineNumber: 96,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "tour-dash-profile",
                href: "/profile",
                className: `${cardBaseClass} bg-zinc-700 hover:bg-zinc-600 border-zinc-900 shadow-black/20`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg md:text-xl font-black text-white leading-none tracking-tight",
                        children: t.dashboard.nav.profile
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                        lineNumber: 107,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-3xl md:text-5xl filter drop-shadow-lg group-hover:scale-110 group-hover:rotate-12 transition-transform duration-300",
                        children: "⚙️"
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                        lineNumber: 108,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                lineNumber: 106,
                columnNumber: 7
            }, this),
            showInstallCard && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: installApp,
                className: `${cardBaseClass} ${ui.style}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "z-10 flex flex-col justify-center text-left",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `text-[9px] font-black px-2 py-0.5 rounded w-fit mb-0.5 tracking-wider uppercase ${ui.textStyle}`,
                                children: ui.badge
                            }, void 0, false, {
                                fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                                lineNumber: 120,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg md:text-xl font-black text-white leading-none tracking-tight",
                                children: ui.text
                            }, void 0, false, {
                                fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                                lineNumber: 123,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                        lineNumber: 119,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-3xl md:text-5xl filter drop-shadow-lg group-hover:scale-110 group-hover:-rotate-12 transition-transform duration-300",
                        children: ui.emoji
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                        lineNumber: 127,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
                lineNumber: 115,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/dashboard/components/NavigationPanel.tsx",
        lineNumber: 49,
        columnNumber: 5
    }, this);
}
_s(NavigationPanel, "Lrsvh/1K2DhppNFVdRLCjIlpwk8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"],
        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$pwa$2f$hooks$2f$usePWA$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePWA"]
    ];
});
_c = NavigationPanel;
var _c;
__turbopack_context__.k.register(_c, "NavigationPanel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/Button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// =================== FILE: components/ui/Button.tsx ===================
__turbopack_context__.s([
    "Button",
    ()=>Button
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function Button({ children, variant = 'primary', isLoading, className = '', disabled, ...props }) {
    const baseStyle = "px-6 py-3 rounded-2xl font-bold text-lg transition-all duration-150 active:scale-95 active:border-b-0 active:translate-y-1 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2";
    const variants = {
        // Verd Principal
        primary: "bg-emerald-500 text-white border-b-4 border-emerald-700 hover:bg-emerald-400 hover:border-emerald-600 shadow-lg shadow-emerald-900/20",
        // Blau Secundari
        secondary: "bg-blue-500 text-white border-b-4 border-blue-700 hover:bg-blue-400 hover:border-blue-600 shadow-lg shadow-blue-900/20",
        // Taronja Accent
        accent: "bg-orange-500 text-white border-b-4 border-orange-700 hover:bg-orange-400 hover:border-orange-600 shadow-lg shadow-orange-900/20",
        // Outline (CORREGIT: SEMPRE FOSC)
        // Abans era blanc. Ara és transparent amb vores grises fosques i text blanc.
        outline: "bg-transparent text-gray-300 border-2 border-zinc-700 border-b-4 hover:bg-zinc-800 hover:text-white hover:border-zinc-500"
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        className: `${baseStyle} ${variants[variant]} ${className}`,
        disabled: disabled || isLoading,
        ...props,
        children: isLoading ? "⏳..." : children
    }, void 0, false, {
        fileName: "[project]/components/ui/Button.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
_c = Button;
var _c;
__turbopack_context__.k.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/decision/components/views/FateView.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FateView",
    ()=>FateView
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// src/features/decision/components/views/FateView.tsx
'use client';
;
;
function FateView({ onDecide, isPending }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full animate-in fade-in duration-300 pt-2",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            id: "tour-dec-action",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                onClick: onDecide,
                isLoading: isPending,
                className: "w-full py-4 rounded-xl font-black text-base shadow-lg bg-emerald-600 hover:bg-emerald-500 text-white border-b-4 border-emerald-800 active:border-b-0 active:translate-y-1 transition-all",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "flex items-center justify-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: "🎲"
                        }, void 0, false, {
                            fileName: "[project]/features/decision/components/views/FateView.tsx",
                            lineNumber: 25,
                            columnNumber: 17
                        }, this),
                        " ",
                        t.decision.actions.surprise_me
                    ]
                }, void 0, true, {
                    fileName: "[project]/features/decision/components/views/FateView.tsx",
                    lineNumber: 24,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/decision/components/views/FateView.tsx",
                lineNumber: 19,
                columnNumber: 11
            }, this)
        }, void 0, false, {
            fileName: "[project]/features/decision/components/views/FateView.tsx",
            lineNumber: 18,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/features/decision/components/views/FateView.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
}
_s(FateView, "ot2YhC7pP10gRrIouBKIa40vomw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = FateView;
var _c;
__turbopack_context__.k.register(_c, "FateView");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/decision/components/EnergyTimeSliders.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EnergyTimeSliders",
    ()=>EnergyTimeSliders
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Minus$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/minus.js [app-client] (ecmascript) <export default as Minus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const getEnergyEmoji = (level)=>{
    if (level <= 3) return '😴';
    if (level <= 7) return '🙂';
    return '🔥';
};
function EnergyTimeSliders({ energy, time, onEnergyChange, onTimeChange }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const sliderPercentage = energy / 10 * 100;
    // Lògica per incrementar/decrementar temps (de 5 en 5 minuts)
    const handleTimeChange = (amount)=>{
        const newVal = time + amount;
        // Mínim 5 minuts, màxim el que vulguis (ex: 240 min)
        if (newVal >= 5) {
            onTimeChange(newVal);
        }
    };
    const getEnergyLabel = (level)=>{
        if (level <= 3) return t.decision.energy_levels.low;
        if (level <= 7) return t.decision.energy_levels.mid;
        return t.decision.energy_levels.high;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3 bg-black/20 p-4 rounded-2xl border-2 border-dashed border-zinc-700",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between items-end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "text-sm font-bold text-gray-500 uppercase tracking-wider",
                                children: t.decision.energy_label
                            }, void 0, false, {
                                fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                                lineNumber: 44,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-3xl filter drop-shadow-sm transition-all duration-300 transform hover:scale-125 cursor-help",
                                title: getEnergyLabel(energy),
                                children: getEnergyEmoji(energy)
                            }, void 0, false, {
                                fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                                lineNumber: 47,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                        lineNumber: 43,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative w-full h-8 flex items-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute w-full h-4 bg-zinc-800 rounded-full overflow-hidden border border-zinc-600",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "h-full bg-linear-to-r from-yellow-500 to-red-600 transition-all duration-150 ease-out",
                                    style: {
                                        width: `${sliderPercentage}%`
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                                    lineNumber: 54,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                                lineNumber: 53,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "range",
                                min: "0",
                                max: "10",
                                step: "1",
                                value: energy,
                                onChange: (e)=>onEnergyChange(Number(e.target.value)),
                                className: "absolute w-full h-8 opacity-0 cursor-pointer z-10"
                            }, void 0, false, {
                                fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                                lineNumber: 60,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute h-6 w-6 bg-zinc-900 border-2 border-white rounded-full shadow-md pointer-events-none transition-all duration-150 ease-out",
                                style: {
                                    left: `calc(${sliderPercentage}% - 12px)`
                                }
                            }, void 0, false, {
                                fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                                lineNumber: 68,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                        lineNumber: 52,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-center font-bold text-gray-400",
                        children: getEnergyLabel(energy)
                    }, void 0, false, {
                        fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                        lineNumber: 74,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                lineNumber: 42,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-black/20 p-4 rounded-2xl border-2 border-dashed border-zinc-700 flex flex-col items-center justify-center gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "text-sm font-bold text-gray-500 uppercase tracking-wider flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"], {
                                className: "w-4 h-4"
                            }, void 0, false, {
                                fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                                lineNumber: 83,
                                columnNumber: 12
                            }, this),
                            " ",
                            t.decision.time_label
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                        lineNumber: 82,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>handleTimeChange(-5),
                                className: "w-12 h-12 rounded-xl bg-zinc-800 border-2 border-zinc-600 flex items-center justify-center text-white hover:bg-zinc-700 hover:border-zinc-500 active:scale-95 transition-all shadow-lg",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Minus$3e$__["Minus"], {
                                    className: "w-6 h-6"
                                }, void 0, false, {
                                    fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                                    lineNumber: 93,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                                lineNumber: 89,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col items-center w-24",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-5xl font-black text-white leading-none tracking-tight",
                                        children: time
                                    }, void 0, false, {
                                        fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                                        lineNumber: 98,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs font-bold text-zinc-500 uppercase",
                                        children: "minuts"
                                    }, void 0, false, {
                                        fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                                        lineNumber: 101,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                                lineNumber: 97,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>handleTimeChange(5),
                                className: "w-12 h-12 rounded-xl bg-zinc-800 border-2 border-zinc-600 flex items-center justify-center text-white hover:bg-zinc-700 hover:border-zinc-500 active:scale-95 transition-all shadow-lg",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                    className: "w-6 h-6"
                                }, void 0, false, {
                                    fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                                    lineNumber: 109,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                                lineNumber: 105,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                        lineNumber: 86,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
                lineNumber: 80,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/decision/components/EnergyTimeSliders.tsx",
        lineNumber: 39,
        columnNumber: 5
    }, this);
}
_s(EnergyTimeSliders, "ot2YhC7pP10gRrIouBKIa40vomw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = EnergyTimeSliders;
var _c;
__turbopack_context__.k.register(_c, "EnergyTimeSliders");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/decision/components/views/ChefView.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ChefView",
    ()=>ChefView
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$decision$2f$components$2f$EnergyTimeSliders$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/decision/components/EnergyTimeSliders.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// src/features/decision/components/views/ChefView.tsx
'use client';
;
;
;
function ChefView({ onSuggest, isPending, energy, time, setEnergy, setTime }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full flex flex-col gap-2 animate-in fade-in duration-300",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: "tour-dec-inputs",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$decision$2f$components$2f$EnergyTimeSliders$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EnergyTimeSliders"], {
                    energy: energy,
                    time: time,
                    onEnergyChange: setEnergy,
                    onTimeChange: setTime
                }, void 0, false, {
                    fileName: "[project]/features/decision/components/views/ChefView.tsx",
                    lineNumber: 25,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/decision/components/views/ChefView.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: "tour-dec-action",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                    onClick: onSuggest,
                    isLoading: isPending,
                    className: "w-full py-3 rounded-xl font-black text-sm shadow-lg bg-purple-600 hover:bg-purple-500 text-white border-b-4 border-purple-800 active:border-b-0 active:translate-y-1 transition-all",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "flex items-center justify-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "🍳"
                            }, void 0, false, {
                                fileName: "[project]/features/decision/components/views/ChefView.tsx",
                                lineNumber: 41,
                                columnNumber: 17
                            }, this),
                            " ",
                            t.decision.actions.generate_menu
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/decision/components/views/ChefView.tsx",
                        lineNumber: 40,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/features/decision/components/views/ChefView.tsx",
                    lineNumber: 35,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/decision/components/views/ChefView.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/decision/components/views/ChefView.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
}
_s(ChefView, "ot2YhC7pP10gRrIouBKIa40vomw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = ChefView;
var _c;
__turbopack_context__.k.register(_c, "ChefView");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/decision/components/LoadingOverlay.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LoadingOverlay",
    ()=>LoadingOverlay
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// src/features/decision/components/LoadingOverlay.tsx
'use client';
;
;
function LoadingOverlay({ isVisible, mode }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    if (!isVisible) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "absolute inset-0 z-50 flex flex-col items-center justify-center bg-zinc-950/90 backdrop-blur-sm animate-in fade-in duration-300 rounded-4xl",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                animate: {
                    scale: [
                        1,
                        1.2,
                        1
                    ],
                    rotate: [
                        0,
                        10,
                        -10,
                        0
                    ]
                },
                transition: {
                    duration: 2,
                    repeat: Infinity
                },
                className: "text-6xl mb-4 filter drop-shadow-[0_0_20px_rgba(168,85,247,0.5)]",
                children: mode === 'FATE' ? '🎲' : '👨‍🍳'
            }, void 0, false, {
                fileName: "[project]/features/decision/components/LoadingOverlay.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].h3, {
                animate: {
                    opacity: [
                        0.5,
                        1,
                        0.5
                    ]
                },
                transition: {
                    duration: 1.5,
                    repeat: Infinity
                },
                className: "text-xl font-black text-white tracking-widest uppercase",
                children: mode === 'FATE' ? t.common.loading : t.decision.actions.generate_menu
            }, void 0, false, {
                fileName: "[project]/features/decision/components/LoadingOverlay.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-xs text-zinc-400 mt-2 font-mono",
                children: mode === 'FATE' ? 'Consultant els astres...' : 'Analitzant el rebost...'
            }, void 0, false, {
                fileName: "[project]/features/decision/components/LoadingOverlay.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-48 h-1 bg-zinc-800 rounded-full mt-6 overflow-hidden",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        x: '-100%'
                    },
                    animate: {
                        x: '100%'
                    },
                    transition: {
                        duration: 1.5,
                        repeat: Infinity,
                        ease: 'linear'
                    },
                    className: "w-full h-full bg-linear-to-r from-transparent via-purple-500 to-transparent opacity-70"
                }, void 0, false, {
                    fileName: "[project]/features/decision/components/LoadingOverlay.tsx",
                    lineNumber: 44,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/decision/components/LoadingOverlay.tsx",
                lineNumber: 43,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/decision/components/LoadingOverlay.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
_s(LoadingOverlay, "ot2YhC7pP10gRrIouBKIa40vomw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = LoadingOverlay;
var _c;
__turbopack_context__.k.register(_c, "LoadingOverlay");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/onboarding/OnboardingContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OnboardingProvider",
    ()=>OnboardingProvider,
    "useOnboarding",
    ()=>useOnboarding
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
const OnboardingContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function OnboardingProvider({ children }) {
    _s();
    const [isActive, setIsActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [currentStepIndex, setCurrentStepIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [steps, setSteps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // Guardem quin tour estem fent per poder marcar-lo com a vist
    const [currentTourId, setCurrentTourId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const startTour = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OnboardingProvider.useCallback[startTour]": (tourId, newSteps, options = {})=>{
            if ("TURBOPACK compile-time truthy", 1) return;
            //TURBOPACK unreachable
            ;
            // Generem una clau única per aquest tour (ex: triatu_tour_seen_profile-setup)
            const storageKey = undefined;
            const hasSeen = undefined;
        }
    }["OnboardingProvider.useCallback[startTour]"], []);
    // ✅ Aquesta funció tanca el tour i GUANDA LA PREFERÈNCIA
    const finishTour = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OnboardingProvider.useCallback[finishTour]": ()=>{
            setIsActive(false);
            if (currentTourId) {
                // Guardem al navegador que aquest tour ja s'ha fet (o tancat)
                localStorage.setItem(`triatu_tour_seen_${currentTourId}`, 'true');
                console.log(`✅ [Onboarding] Tour '${currentTourId}' marcat com a vist.`);
            }
            // Resetegem per netejar
            setCurrentTourId('');
            setSteps([]);
            setCurrentStepIndex(0);
        }
    }["OnboardingProvider.useCallback[finishTour]"], [
        currentTourId
    ]);
    const nextStep = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OnboardingProvider.useCallback[nextStep]": ()=>{
            setCurrentStepIndex({
                "OnboardingProvider.useCallback[nextStep]": (prev)=>{
                    if (prev < steps.length - 1) {
                        return prev + 1;
                    } else {
                        finishTour(); // Si és l'últim pas, acabem i guardem
                        return prev;
                    }
                }
            }["OnboardingProvider.useCallback[nextStep]"]);
        }
    }["OnboardingProvider.useCallback[nextStep]"], [
        steps.length,
        finishTour
    ]);
    const prevStep = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OnboardingProvider.useCallback[prevStep]": ()=>{
            setCurrentStepIndex({
                "OnboardingProvider.useCallback[prevStep]": (prev)=>prev > 0 ? prev - 1 : prev
            }["OnboardingProvider.useCallback[prevStep]"]);
        }
    }["OnboardingProvider.useCallback[prevStep]"], []);
    // ✅ QUAN FEM CLICK A LA 'X'
    const skipTour = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OnboardingProvider.useCallback[skipTour]": ()=>{
            // Cridem a finishTour(), així que TAMBÉ ES GUARDA al localStorage
            finishTour();
        }
    }["OnboardingProvider.useCallback[skipTour]"], [
        finishTour
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OnboardingContext.Provider, {
        value: {
            isActive,
            currentStepIndex,
            steps,
            startTour,
            nextStep,
            prevStep,
            skipTour,
            finishTour
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/components/onboarding/OnboardingContext.tsx",
        lineNumber: 87,
        columnNumber: 5
    }, this);
}
_s(OnboardingProvider, "LwYR2QbA25DdOIzx6bjCxxgWgng=");
_c = OnboardingProvider;
function useOnboarding() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(OnboardingContext);
    if (!context) {
        throw new Error('useOnboarding must be used within an OnboardingProvider');
    }
    return context;
}
_s1(useOnboarding, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "OnboardingProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/onboarding/TourTrigger.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TourTrigger",
    ()=>TourTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$question$2d$mark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__HelpCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/circle-question-mark.js [app-client] (ecmascript) <export default as HelpCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/onboarding/OnboardingContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function TourTrigger({ steps, className, tourId }) {
    _s();
    const { startTour } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
        whileHover: {
            scale: 1.1,
            rotate: 10
        },
        whileTap: {
            scale: 0.9
        },
        onClick: ()=>{
            // ✅ { force: true } ignora el localStorage i l'activa igualment
            startTour(tourId, steps, {
                force: true
            }); // ✅ Passem l'ID
        },
        className: `
        flex items-center justify-center w-10 h-10 rounded-full 
        bg-slate-800 border border-slate-700 text-slate-400 
        hover:text-purple-400 hover:border-purple-500/50 hover:bg-slate-800/80
        transition-all shadow-lg z-50
        ${className}
      `,
        title: "Repetir la Guia 🆘",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$question$2d$mark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__HelpCircle$3e$__["HelpCircle"], {
            size: 20
        }, void 0, false, {
            fileName: "[project]/components/onboarding/TourTrigger.tsx",
            lineNumber: 34,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/onboarding/TourTrigger.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
}
_s(TourTrigger, "UeKKQgLVCaRaRTAKbwquCHh9TY8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"]
    ];
});
_c = TourTrigger;
var _c;
__turbopack_context__.k.register(_c, "TourTrigger");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/decision/components/DecisionHeader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DecisionHeader",
    ()=>DecisionHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$TourTrigger$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/onboarding/TourTrigger.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// src/features/decision/components/DecisionHeader.tsx
'use client';
;
;
;
function DecisionHeader({ mode, setMode, error, isMobileExpanded, setIsMobileExpanded, tourSteps }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const isFate = mode === 'FATE';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        id: "tour-dec-header",
        className: "h-14 shrink-0 bg-zinc-950/40 border-b border-white/5 flex items-center justify-between px-3 md:px-4 z-20",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${error ? 'bg-red-900/50 text-red-200' : isFate ? 'bg-emerald-600 text-white' : 'bg-purple-600 text-white'}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-lg",
                            children: error ? '⚠️' : '⚡'
                        }, void 0, false, {
                            fileName: "[project]/features/decision/components/DecisionHeader.tsx",
                            lineNumber: 28,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/decision/components/DecisionHeader.tsx",
                        lineNumber: 27,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setIsMobileExpanded(!isMobileExpanded),
                        className: "lg:hidden flex items-center gap-2 group text-left outline-none",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-black text-white text-xs uppercase tracking-wide",
                                children: isMobileExpanded ? t.decision.mobile.fast_mode : t.decision.mobile.actions
                            }, void 0, false, {
                                fileName: "[project]/features/decision/components/DecisionHeader.tsx",
                                lineNumber: 34,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                size: 16,
                                className: `text-zinc-400 transition-transform duration-300 ${isMobileExpanded ? 'rotate-180' : ''} group-active:scale-90`
                            }, void 0, false, {
                                fileName: "[project]/features/decision/components/DecisionHeader.tsx",
                                lineNumber: 37,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/decision/components/DecisionHeader.tsx",
                        lineNumber: 30,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "hidden lg:block font-black text-white text-xs uppercase tracking-wide",
                        children: t.decision.mobile.fast_mode
                    }, void 0, false, {
                        fileName: "[project]/features/decision/components/DecisionHeader.tsx",
                        lineNumber: 39,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/decision/components/DecisionHeader.tsx",
                lineNumber: 26,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        id: "tour-dec-mode",
                        className: `flex bg-black/40 p-1 rounded-lg border border-white/10 transition-opacity duration-300 ${!isMobileExpanded ? 'opacity-0 pointer-events-none lg:opacity-100 lg:pointer-events-auto' : 'opacity-100'}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setMode('FATE'),
                                className: `px-3 py-1.5 rounded-md text-[10px] font-bold flex items-center gap-1.5 transition-all ${isFate ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-white'}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "🎲"
                                    }, void 0, false, {
                                        fileName: "[project]/features/decision/components/DecisionHeader.tsx",
                                        lineNumber: 50,
                                        columnNumber: 25
                                    }, this),
                                    " ",
                                    t.decision.selector.fate
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/decision/components/DecisionHeader.tsx",
                                lineNumber: 49,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setMode('CHEF'),
                                className: `px-3 py-1.5 rounded-md text-[10px] font-bold flex items-center gap-1.5 transition-all ${!isFate ? 'bg-purple-600 text-white shadow' : 'text-slate-400 hover:text-white'}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "👨‍🍳"
                                    }, void 0, false, {
                                        fileName: "[project]/features/decision/components/DecisionHeader.tsx",
                                        lineNumber: 53,
                                        columnNumber: 25
                                    }, this),
                                    " ",
                                    t.decision.selector.chef
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/decision/components/DecisionHeader.tsx",
                                lineNumber: 52,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/decision/components/DecisionHeader.tsx",
                        lineNumber: 48,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `${!isMobileExpanded ? 'opacity-0 pointer-events-none lg:opacity-100' : 'opacity-100'} transition-opacity`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$TourTrigger$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TourTrigger"], {
                            tourId: "decision-maker",
                            steps: tourSteps,
                            className: "w-8 h-8 bg-zinc-800 hover:bg-zinc-700 border-zinc-700"
                        }, void 0, false, {
                            fileName: "[project]/features/decision/components/DecisionHeader.tsx",
                            lineNumber: 59,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/decision/components/DecisionHeader.tsx",
                        lineNumber: 58,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/decision/components/DecisionHeader.tsx",
                lineNumber: 45,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/decision/components/DecisionHeader.tsx",
        lineNumber: 23,
        columnNumber: 9
    }, this);
}
_s(DecisionHeader, "ot2YhC7pP10gRrIouBKIa40vomw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = DecisionHeader;
var _c;
__turbopack_context__.k.register(_c, "DecisionHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:2d7a82 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "saveRecipeAction",
    ()=>$$RSC_SERVER_ACTION_0
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"40ffcc09c13a24ff1fda9dc93b16548415ffc7f4d3":"saveRecipeAction"},"app/actions/recipe-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40ffcc09c13a24ff1fda9dc93b16548415ffc7f4d3", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "saveRecipeAction");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vcmVjaXBlLWFjdGlvbnMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQVJYSVU6IGFwcC9hY3Rpb25zL3JlY2lwZS1hY3Rpb25zLnRzXHJcbid1c2Ugc2VydmVyJ1xyXG5cclxuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSAnQC9hZGFwdGVycy9zdXBhYmFzZS9zZXJ2ZXInO1xyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gJ25leHQvY2FjaGUnO1xyXG4vLyDinIUgRklYOiBJbXBvcnRlbSBlbCByZXBvc2l0b3JpIHF1ZSBmYWx0YXZhXHJcbmltcG9ydCB7IFN1cGFiYXNlUmVjaXBlUmVwb3NpdG9yeSB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2UvU3VwYWJhc2VSZWNpcGVSZXBvc2l0b3J5JztcclxuaW1wb3J0IHsgY29udGFpbmVyIH0gZnJvbSAnQC9zZXJ2aWNlcy9jb250YWluZXInO1xyXG5pbXBvcnQgeyBFbW9qaU1hdGNoZXJTZXJ2aWNlIH0gZnJvbSAnQC9jb3JlL2FwcGxpY2F0aW9uL3NlcnZpY2VzL0Vtb2ppTWF0Y2hlclNlcnZpY2UnOyAvLyDinIUgSW1wb3J0ZW0gZWwgTWF0Y2hlclxyXG5pbXBvcnQgeyBHZW5lcmF0ZVJlY2lwZVNjaGVtYSwgTWF0ZXJpYWxpemVSZWNpcGVTY2hlbWEgfSBmcm9tICdAL2NvcmUvYXBwbGljYXRpb24vc2NoZW1hcy9pbnB1dFNjaGVtYXMnO1xyXG5pbXBvcnQgeyBTdXBhYmFzZVJhdGVMaW1pdGVyIH0gZnJvbSAnQC9hZGFwdGVycy9zdXBhYmFzZS9TdXBhYmFzZVJhdGVMaW1pdGVyJztcclxuaW1wb3J0IHsgU3VwYWJhc2VTZWN1cml0eUxvZ2dlciB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2UvU3VwYWJhc2VTZWN1cml0eUxvZ2dlcic7XHJcbmltcG9ydCB7IGRlYnVnLCBlcnJvciBhcyBsb2dFcnJvciB9IGZyb20gJ0AvbGliL2xvZ2dlcic7XHJcblxyXG4vLyDinIUgRklYOiBEZWZpbmljacOzIHJvYnVzdGEgZGUgbGEgcmVzcG9zdGFcclxuZXhwb3J0IHR5cGUgQWN0aW9uUmVzcG9uc2UgPSB7XHJcbiAgICBzdWNjZXNzOiBib29sZWFuO1xyXG4gICAgcmVjaXBlSWQ/OiBzdHJpbmc7XHJcbiAgICBlcnJvcj86IHN0cmluZzsgLy8gSW1wb3J0YW50IHF1ZSBzaWd1aSBvcGNpb25hbCAoPylcclxufTtcclxuXHJcbi8vIFRpcHVzIHVuaWZpY2F0IHF1ZSBjb2JyZWl4aSBlbCBxdWUgdmUgZGUgbCdFZGl0b3IgaSBlbCBxdWUgdmUgZGUgbGEgSUFcclxuZXhwb3J0IGludGVyZmFjZSBTYXZlUmVjaXBlSW5wdXQge1xyXG4gIGlkPzogc3RyaW5nO1xyXG4gIG5hbWU6IHN0cmluZztcclxuICBwcmVwVGltZU1pbnV0ZXM6IG51bWJlciB8IHN0cmluZztcclxuICBcclxuICBpbmdyZWRpZW50czoge1xyXG4gICAgaWQ/OiBzdHJpbmc7XHJcbiAgICBuYW1lOiBzdHJpbmc7XHJcbiAgICBxdWFudGl0eTogbnVtYmVyO1xyXG4gICAgdW5pdDogc3RyaW5nO1xyXG4gICAgZW1vamk/OiBzdHJpbmc7XHJcbiAgICBlc3RpbWF0ZWRDb3N0PzogbnVtYmVyIHwgc3RyaW5nO1xyXG4gICAgbGlua2VkUHJvZHVjdElkPzogc3RyaW5nIHwgbnVsbDtcclxuICAgIGxpbmtlZFByb2R1Y3RJbWFnZT86IHN0cmluZyB8IG51bGw7XHJcbiAgfVtdO1xyXG4gIHN0ZXBzOiAoc3RyaW5nIHwgeyBpZDogc3RyaW5nOyBjb250ZW50OiBzdHJpbmcgfSlbXTtcclxuICB0YWdzPzogc3RyaW5nW107XHJcbiAgZGlldGFyeVRhZ3M/OiBzdHJpbmdbXTtcclxuICBpc0FpR2VuZXJhdGVkPzogYm9vbGVhbjtcclxufVxyXG5cclxuLy8gLS0tIEFDQ0nDkyBQUklOQ0lQQUw6IFNBVkUgLS0tXHJcbi8vIEFxdWVzdGEgY29udMOpIHRvdGEgbGEgbMOyZ2ljYSBcImludGVswrdsaWdlbnRcIiAocHJldXMsIGltYXRnZXMsIGVtb2ppcy4uLilcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNhdmVSZWNpcGVBY3Rpb24oZGF0YTogU2F2ZVJlY2lwZUlucHV0KTogUHJvbWlzZTxBY3Rpb25SZXNwb25zZT4ge1xyXG4gIGRlYnVnKCdbU0FWRSBBQ1RJT05dIHNhdmVSZWNpcGVBY3Rpb24nKTtcclxuXHJcbiAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICBpZiAoIXVzZXIpIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9O1xyXG5cclxuICB0cnkge1xyXG4gICAgbGV0IGF1dGhvck5hbWUgPSBcIlhlZiBBbsOybmltXCI7XHJcbiAgICBjb25zdCB7IGRhdGE6IHByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3ByZWZlcmVuY2VfcHJvZmlsZXMnKS5zZWxlY3QoJ3VzZXJuYW1lJykuZXEoJ3VzZXJfaWQnLCB1c2VyLmlkKS5zaW5nbGUoKTtcclxuICAgIGlmIChwcm9maWxlPy51c2VybmFtZSkgYXV0aG9yTmFtZSA9IHByb2ZpbGUudXNlcm5hbWU7XHJcblxyXG4gICAgLy8gMS4gQ8OgbGN1bCBkZSBjb3N0IHRvdGFsIChST0JVU1QpXHJcbiAgICBjb25zdCB0b3RhbENvc3QgPSBkYXRhLmluZ3JlZGllbnRzLnJlZHVjZSgoYWNjLCBpbmcpID0+IHtcclxuICAgICAgbGV0IGNvc3RWYWwgPSBpbmcuZXN0aW1hdGVkQ29zdDtcclxuICAgICAgaWYgKHR5cGVvZiBjb3N0VmFsID09PSAnc3RyaW5nJykgY29zdFZhbCA9IHBhcnNlRmxvYXQoY29zdFZhbCk7XHJcbiAgICAgIGNvbnN0IGNvc3QgPSBOdW1iZXIoY29zdFZhbCkgfHwgMDtcclxuICAgICAgcmV0dXJuIGFjYyArIGNvc3Q7XHJcbiAgICB9LCAwKTtcclxuXHJcbiAgICBsZXQgaXNBaUdlbmVyYXRlZCA9ICEhZGF0YS5pc0FpR2VuZXJhdGVkO1xyXG4gICAgaWYgKCFpc0FpR2VuZXJhdGVkICYmIGRhdGEuaWQpIHtcclxuICAgICAgY29uc3QgeyBkYXRhOiBvbGRSZWNpcGUgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3NhdmVkX3JlY2lwZXMnKS5zZWxlY3QoJ2lzX2FpX2dlbmVyYXRlZCcpLmVxKCdpZCcsIGRhdGEuaWQpLnNpbmdsZSgpO1xyXG4gICAgICBpZiAob2xkUmVjaXBlKSBpc0FpR2VuZXJhdGVkID0gb2xkUmVjaXBlLmlzX2FpX2dlbmVyYXRlZDtcclxuICAgIH1cclxuXHJcbiAgICAvLyAyLiBQUk9DRVNTQVIgSU5HUkVESUVOVFMgKyBJTUFUR0VTXHJcbiAgICBjb25zdCBpbmdyZWRpZW50c1BheWxvYWQgPSBhd2FpdCBQcm9taXNlLmFsbChkYXRhLmluZ3JlZGllbnRzLm1hcChhc3luYyAoaW5nKSA9PiB7XHJcbiAgICAgIGxldCBmaW5hbElkID0gaW5nLmlkO1xyXG4gICAgICBsZXQgZmluYWxFbW9qaSA9IGluZy5lbW9qaTtcclxuICAgICAgY29uc3QgZmluYWxOYW1lID0gaW5nLm5hbWU7XHJcbiAgICAgIGNvbnN0IGxpbmtlZFByb2R1Y3RJZCA9IGluZy5saW5rZWRQcm9kdWN0SWQ7XHJcbiAgICAgIGxldCBsaW5rZWRQcm9kdWN0SW1hZ2UgPSBpbmcubGlua2VkUHJvZHVjdEltYWdlO1xyXG4gICAgICBjb25zdCBlc3RpbWF0ZWRDb3N0ID0gaW5nLmVzdGltYXRlZENvc3QgPyBOdW1iZXIoaW5nLmVzdGltYXRlZENvc3QpIDogMDtcclxuXHJcbiAgICAgIGNvbnN0IGhhc0xpbmsgPSB0eXBlb2YgbGlua2VkUHJvZHVjdElkID09PSAnc3RyaW5nJyAmJiBsaW5rZWRQcm9kdWN0SWQubGVuZ3RoID4gMDtcclxuXHJcbiAgICAgIGlmIChoYXNMaW5rKSB7XHJcbiAgICAgICAgLy8gLi4uIChMw7JnaWNhIGRlIHJlY3VwZXJhY2nDsyBkJ2ltYXRnZXMgaWd1YWwgcXVlIHRlbmllcykgLi4uXHJcbiAgICAgICAgaWYgKCFsaW5rZWRQcm9kdWN0SW1hZ2UpIHtcclxuICAgICAgICAgIGNvbnN0IHsgZGF0YTogcHJvZHVjdCB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgncHJvZHVjdF9jYXRhbG9nJykuc2VsZWN0KCdpbWFnZV91cmwnKS5lcSgnaWQnLCBsaW5rZWRQcm9kdWN0SWQpLnNpbmdsZSgpO1xyXG4gICAgICAgICAgaWYgKHByb2R1Y3Q/LmltYWdlX3VybCkgbGlua2VkUHJvZHVjdEltYWdlID0gcHJvZHVjdC5pbWFnZV91cmw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghZmluYWxJZCB8fCBmaW5hbElkLmxlbmd0aCA8IDUpIGZpbmFsSWQgPSBsaW5rZWRQcm9kdWN0SWQhO1xyXG4gICAgICAgIGlmICghZmluYWxFbW9qaSB8fCBmaW5hbEVtb2ppID09PSAn8J+lmCcpIGZpbmFsRW1vamkgPSAn8J+Tpic7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gTWF0Y2hlciBkJ2Vtb2ppc1xyXG4gICAgICAgIGNvbnN0IGNsZWFuTmFtZSA9IGZpbmFsTmFtZS5yZXBsYWNlKC9cXGIoQk9OUFJFVXxQQVRDSEVGfC4uLilcXGIvZ2ksIFwiXCIpLnRyaW0oKTtcclxuICAgICAgICBjb25zdCBwcmVzZXQgPSBFbW9qaU1hdGNoZXJTZXJ2aWNlLm1hdGNoKGNsZWFuTmFtZSk7XHJcbiAgICAgICAgaWYgKHByZXNldCkge1xyXG4gICAgICAgICAgZmluYWxJZCA9IHByZXNldC5pZDtcclxuICAgICAgICAgIGZpbmFsRW1vamkgPSBwcmVzZXQuZW1vamk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGlmICghZmluYWxFbW9qaSkgZmluYWxFbW9qaSA9ICfwn6WYJztcclxuICAgICAgICAgIGlmICghZmluYWxJZCkgZmluYWxJZCA9IGNyeXB0by5yYW5kb21VVUlEKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIGlkOiBmaW5hbElkLFxyXG4gICAgICAgIG5hbWU6IGZpbmFsTmFtZSxcclxuICAgICAgICBxdWFudGl0eTogaW5nLnF1YW50aXR5LFxyXG4gICAgICAgIHVuaXQ6IGluZy51bml0LFxyXG4gICAgICAgIGVtb2ppOiBmaW5hbEVtb2ppLFxyXG4gICAgICAgIGxpbmtlZFByb2R1Y3RJZDogaGFzTGluayA/IGxpbmtlZFByb2R1Y3RJZCA6IG51bGwsXHJcbiAgICAgICAgbGlua2VkUHJvZHVjdEltYWdlOiBoYXNMaW5rID8gbGlua2VkUHJvZHVjdEltYWdlIDogbnVsbCxcclxuICAgICAgICBlc3RpbWF0ZWRDb3N0XHJcbiAgICAgIH07XHJcbiAgICB9KSk7XHJcblxyXG4gICAgLy8gMy4gUFJPQ0VTU0FSIFBBU1NPU1xyXG4gICAgY29uc3Qgc3RlcHNEYXRhID0gZGF0YS5zdGVwcy5tYXAocyA9PiB7XHJcbiAgICAgIGlmICh0eXBlb2YgcyA9PT0gJ3N0cmluZycpIHJldHVybiB7IGlkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLCBjb250ZW50OiBzIH07XHJcbiAgICAgIHJldHVybiB7IGlkOiBzLmlkIHx8IGNyeXB0by5yYW5kb21VVUlEKCksIGNvbnRlbnQ6IHMuY29udGVudCB8fCBcIlwiIH07XHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyA0LiBQQVlMT0FEIEJEXHJcbiAgICBjb25zdCByZWNpcGVQYXlsb2FkID0ge1xyXG4gICAgICB1c2VyX2lkOiB1c2VyLmlkLFxyXG4gICAgICBuYW1lOiBkYXRhLm5hbWUsXHJcbiAgICAgIGF1dGhvcl9uYW1lOiBhdXRob3JOYW1lLFxyXG4gICAgICBwcmVwX3RpbWVfbWludXRlczogTnVtYmVyKGRhdGEucHJlcFRpbWVNaW51dGVzKSB8fCAwLFxyXG4gICAgICBpbmdyZWRpZW50czogaW5ncmVkaWVudHNQYXlsb2FkLFxyXG4gICAgICBzdGVwczogc3RlcHNEYXRhLFxyXG4gICAgICB0YWdzOiBkYXRhLnRhZ3MgfHwgW10sXHJcbiAgICAgIGRpZXRhcnlfdGFnczogZGF0YS5kaWV0YXJ5VGFncyB8fCBbXSxcclxuICAgICAgZXN0aW1hdGVkX2Nvc3Q6IHRvdGFsQ29zdCxcclxuICAgICAgaXNfcHVibGljOiBmYWxzZSwgLy8gUGVyIGRlZmVjdGUgcHJpdmFkYSBxdWFuIGVzIGd1YXJkYVxyXG4gICAgICBpc19haV9nZW5lcmF0ZWQ6IGlzQWlHZW5lcmF0ZWQsXHJcbiAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCB0YWJsZSA9IHN1cGFiYXNlLmZyb20oJ3NhdmVkX3JlY2lwZXMnKTtcclxuICAgIGxldCByZXN1bHRJZDogc3RyaW5nO1xyXG5cclxuICAgIGlmIChkYXRhLmlkKSB7XHJcbiAgICAgIC8vIC4uLiBMw7JnaWNhIGQnVXBkYXRlIGV4aXN0ZW50IC4uLlxyXG4gICAgICAvLyAoU2ltcGxpZmljYWRhIGFxdcOtIHBlciBicmV2ZXRhdCwgY29waWEgbGEgdGV2YSBsw7JnaWNhIGQndXBkYXRlKVxyXG4gICAgICBjb25zdCB7IGRhdGE6IHVwZGF0ZWQsIGVycm9yIH0gPSBhd2FpdCB0YWJsZS51cHNlcnQoeyAuLi5yZWNpcGVQYXlsb2FkLCBpZDogZGF0YS5pZCB9KS5zZWxlY3QoJ2lkJykuc2luZ2xlKCk7XHJcbiAgICAgIGlmIChlcnJvcikgdGhyb3cgZXJyb3I7XHJcbiAgICAgIHJlc3VsdElkID0gdXBkYXRlZC5pZDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnN0IHsgZGF0YTogaW5zZXJ0ZWQsIGVycm9yIH0gPSBhd2FpdCB0YWJsZS5pbnNlcnQocmVjaXBlUGF5bG9hZCkuc2VsZWN0KCdpZCcpLnNpbmdsZSgpO1xyXG4gICAgICBpZiAoZXJyb3IpIHRocm93IGVycm9yO1xyXG4gICAgICByZXN1bHRJZCA9IGluc2VydGVkLmlkO1xyXG4gICAgfVxyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvcmVjaXBlcycpO1xyXG4gICAgaWYgKHJlc3VsdElkKSByZXZhbGlkYXRlUGF0aChgL3JlY2lwZXMvJHtyZXN1bHRJZH1gKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIHJlY2lwZUlkOiByZXN1bHRJZCB9O1xyXG5cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ3NhdmVSZWNpcGVBY3Rpb24gZmFpbGVkJywgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkVycm9yIGludGVybi5cIiB9O1xyXG4gIH1cclxufVxyXG4vLyBBY2Npw7MgcGVyIEZhdm9yaXRzIChOZWNlc3NpdGEgZWwgUmVwb3NpdG9yaSlcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHRvZ2dsZUZhdm9yaXRlQWN0aW9uKHJlY2lwZUlkOiBzdHJpbmcpIHtcclxuICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0gfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpO1xyXG5cclxuICBpZiAoIXVzZXIpIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9O1xyXG5cclxuICAvLyBBcmEgc8OtIHF1ZSB0ZW5pbSBsJ2ltcG9ydCBhIGRhbHRcclxuICBjb25zdCByZXBvID0gbmV3IFN1cGFiYXNlUmVjaXBlUmVwb3NpdG9yeSgpO1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgaXNGYXYgPSBhd2FpdCByZXBvLnRvZ2dsZUZhdm9yaXRlKHVzZXIuaWQsIHJlY2lwZUlkKTtcclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL3JlY2lwZXMnKTtcclxuICAgIHJldmFsaWRhdGVQYXRoKGAvcmVjaXBlcy8ke3JlY2lwZUlkfWApO1xyXG5cclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGlzRmF2b3JpdGU6IGlzRmF2IH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGxvZ0Vycm9yKCdFcnJvciB1cGRhdGluZyBmYXZvcml0ZScsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciB1cGRhdGluZyBmYXZvcml0ZVwiIH07XHJcbiAgfVxyXG5cclxuXHJcbn1cclxuLy8g4pyFIEFxdWVzdGEgYWNjacOzIHN1YnN0aXR1ZWl4IGxhIGzDsmdpY2EgY29tcGxleGEgcXVlIHRlbmllcyBhYmFucy5cclxuLy8gQXJhIGZhIHNlcnZpciBsJ2VzdHJhdMOoZ2lhIEjDrWJyaWRhIChCRCArIElBKSBxdWUgaGVtIGRlZmluaXQgYWwgU2VydmljZS5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlTWVudUFjdGlvbihcclxuICB1c2VySWQ6IHN0cmluZyxcclxuICBkaXNoTmFtZTogc3RyaW5nLFxyXG4gIG1vZGU6ICdGQVRFJyB8ICdDSEVGJyxcclxuICBlbmVyZ3k6IG51bWJlciA9IDUwLFxyXG4gIHRpbWU6IG51bWJlciA9IDMwLFxyXG4gIGxhbmc6IHN0cmluZyA9ICdjYSdcclxuKSB7XHJcbiAgZGVidWcoJ1tBQ1RJT05dIGdlbmVyYXRlTWVudUFjdGlvbicpO1xyXG5cclxuICAvLyAxLiBWQUxJREFDScOTIChab2QpXHJcbiAgY29uc3QgdmFsaWRhdGlvbiA9IEdlbmVyYXRlUmVjaXBlU2NoZW1hLnNhZmVQYXJzZSh7IHVzZXJJZCwgZGlzaE5hbWUsIGxhbmcgfSk7XHJcbiAgaWYgKCF2YWxpZGF0aW9uLnN1Y2Nlc3MpIHtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogdmFsaWRhdGlvbi5lcnJvci5pc3N1ZXNbMF0ubWVzc2FnZSB9O1xyXG4gIH1cclxuXHJcbiAgLy8gMi4gU0VHVVJFVEFUIChSYXRlIExpbWl0KVxyXG4gIGNvbnN0IGxpbWl0ZXIgPSBuZXcgU3VwYWJhc2VSYXRlTGltaXRlcigpO1xyXG4gIGNvbnN0IGxvZ2dlciA9IG5ldyBTdXBhYmFzZVNlY3VyaXR5TG9nZ2VyKCk7XHJcblxyXG4gIGNvbnN0IGNhblByb2NlZWQgPSBhd2FpdCBsaW1pdGVyLmNoZWNrKGBnZW46JHt1c2VySWR9YCwgMjAsIDM2MDApOyAvLyA1IGNvcHMvaG9yYVxyXG4gIGlmICghY2FuUHJvY2VlZCkge1xyXG4gICAgYXdhaXQgbG9nZ2VyLmxvZygnV0FSTicsICdSQVRFX0xJTUlUJywgdXNlcklkLCB7IGFjdGlvbjogJ2dlbmVyYXRlX21lbnUnIH0pO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkzDrW1pdCBzdXBlcmF0LiBFc3BlcmEgdW5hIGVzdG9uYS5cIiB9O1xyXG4gIH1cclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCBzZXJ2aWNlID0gY29udGFpbmVyLmdldEdlbmVyYXRlTWVudVNlcnZpY2Uoc3VwYWJhc2UpO1xyXG5cclxuICAgIC8vIEVYRUNVVEVNIEVMIFNFUlZFSSAoTCdPcmNoZXN0cmF0b3IgZGVjaWRlaXggaW50ZXJuYW1lbnQpXHJcbiAgICBjb25zdCByZWNpcGVzID0gYXdhaXQgc2VydmljZS5leGVjdXRlKFxyXG4gICAgICB1c2VySWQsXHJcbiAgICAgIG1vZGUsXHJcbiAgICAgIGRpc2hOYW1lLFxyXG4gICAgICBlbmVyZ3ksXHJcbiAgICAgIHRpbWUsXHJcbiAgICAgIGxhbmdcclxuICAgICk7XHJcblxyXG4gICAgLy8gQ09OVkVSU0nDkyBBIFBSSU1JVElWRVNcclxuICAgIC8vIDEuIENvbnZlcnRpbSBhIHByaW1pdGl2ZXMgKGFpeMOyIGphIGhvIGZhcylcclxuICAgIGNvbnN0IHBsYWluUmVjaXBlcyA9IHJlY2lwZXMubWFwKHIgPT4gci50b1ByaW1pdGl2ZXMoKSk7XHJcblxyXG4gICAgLy8gMi4g4pqg77iPIEFTU0VHVVJBJ1QgUVVFIGVzdGltYXRlZENvc3QgRVhJU1RFSVggQVFVw40g4pqg77iPXHJcbiAgICAvLyBTaSBwbGFpblJlY2lwZXNbMF0uZXN0aW1hdGVkQ29zdCDDqXMgdW5kZWZpbmVkLCBKU09OLnN0cmluZ2lmeSBsJ2VzYm9ycmFyw6AhXHJcbiAgICBpZiAocGxhaW5SZWNpcGVzLmxlbmd0aCA+IDAgJiYgcGxhaW5SZWNpcGVzWzBdLmVzdGltYXRlZENvc3QgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICBsb2dFcnJvcihcIuKaoO+4jyBBTEVSVEE6IGVzdGltYXRlZENvc3Qgw6lzIHVuZGVmaW5lZCBhYmFucyBkJ2VudmlhciBhbCBjbGllbnQhXCIpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIDMuIFNhbml0aXR6YWNpw7NcclxuICAgIGNvbnN0IGNsZWFuUmVjaXBlcyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkocGxhaW5SZWNpcGVzKSk7XHJcblxyXG4gICAgZGVidWcoJ1tBQ1RJT05dIGdlbmVyYXRlTWVudUFjdGlvbiBkb25lJyk7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogdHJ1ZSxcclxuICAgICAgcmVjaXBlczogY2xlYW5SZWNpcGVzXHJcbiAgICB9O1xyXG5cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ+KdjCBbQUNUSU9OIEVSUk9SXTonLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRXJyb3IgZ2VuZXJhbnQgZWwgbWVuw7ouXCIgfTtcclxuICB9XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1hdGVyaWFsaXplUmVjaXBlQWN0aW9uKHJhd0FpUmVjaXBlOiB1bmtub3duKTogUHJvbWlzZTxBY3Rpb25SZXNwb25zZT4ge1xyXG4gIGNvbnN0IHBhcnNlZCA9IE1hdGVyaWFsaXplUmVjaXBlU2NoZW1hLnNhZmVQYXJzZShyYXdBaVJlY2lwZSk7XHJcbiAgaWYgKCFwYXJzZWQuc3VjY2Vzcykge1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBwYXJzZWQuZXJyb3IuaXNzdWVzWzBdLm1lc3NhZ2UgfTtcclxuICB9XHJcblxyXG4gIGNvbnN0IHJlY2lwZURhdGEgPSBwYXJzZWQuZGF0YTtcclxuICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG5cclxuICAvLyDwn5SNIDEuIFBBUyBERSBERURVUExJQ0FDScOTOiBCdXNxdWVtIHNpIGphIGV4aXN0ZWl4XHJcbiAgdHJ5IHtcclxuICAgICAgY29uc3QgeyBkYXRhOiBleGlzdGluZyB9ID0gYXdhaXQgc3VwYWJhc2VcclxuICAgICAgICAgIC5mcm9tKCdzYXZlZF9yZWNpcGVzJylcclxuICAgICAgICAgIC5zZWxlY3QoJ2lkJylcclxuICAgICAgICAgIC5lcSgnbmFtZScsIHJlY2lwZURhdGEubmFtZSkgLy8gTWF0ZWl4IG5vbVxyXG4gICAgICAgICAgLmVxKCdpc19haV9nZW5lcmF0ZWQnLCB0cnVlKSAvLyBRdWUgc2lndWkgZGUgbGEgSUFcclxuICAgICAgICAgIC5lcSgnaXNfcHVibGljJywgdHJ1ZSkgLy8gUXVlIHNpZ3VpIGNvbXBhcnRpZGFcclxuICAgICAgICAgIC5saW1pdCgxKVxyXG4gICAgICAgICAgLnNpbmdsZSgpO1xyXG5cclxuICAgICAgaWYgKGV4aXN0aW5nKSB7XHJcbiAgICAgICAgICBkZWJ1ZygnW0FDVElPTl0gZGVkdXBsaWNhdGUgaGl0Jyk7XHJcbiAgICAgICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCByZWNpcGVJZDogZXhpc3RpbmcuaWQgfTtcclxuICAgICAgfVxyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgbG9nRXJyb3IoJ01hdGVyaWFsaXplUmVjaXBlQWN0aW9uIGVycm9yJywgZXJyKTtcclxuICAgICAgLy8gSWdub3JlbSBlcnJvcnMgZGUgY29uc3VsdGEgKGV4OiBubyB0cm9iYXQpLCBzZWd1aW0gZW5kYXZhbnQgcGVyIGNyZWFyLWxhXHJcbiAgfVxyXG5cclxuICAvLyDwn4yKIDIuIEZMVVggRCdFTlJJUVVJTUVOVCAoSWd1YWwgcXVlIHRlbmllcylcclxuICAvLyBTaSBubyBleGlzdGVpeCwgbCdoZW0gZGUgY3JlYXIgaSBlbnJpcXVpclxyXG4gIGNvbnN0IGVucmljaGVkSW5ncmVkaWVudHMgPSBhd2FpdCBQcm9taXNlLmFsbCgocmVjaXBlRGF0YS5pbmdyZWRpZW50cyB8fCBbXSkubWFwKGFzeW5jIChpbmcpID0+IHtcclxuICAgICAgbGV0IGxpbmtlZFByb2R1Y3RJZCA9IGluZy5saW5rZWRQcm9kdWN0SWQ7XHJcbiAgICAgIGxldCBsaW5rZWRQcm9kdWN0SW1hZ2UgPSBpbmcubGlua2VkUHJvZHVjdEltYWdlO1xyXG4gICAgICBsZXQgZXN0aW1hdGVkQ29zdCA9IGluZy5lc3RpbWF0ZWRDb3N0O1xyXG5cclxuICAgICAgaWYgKCFsaW5rZWRQcm9kdWN0SWQgfHwgIWxpbmtlZFByb2R1Y3RJbWFnZSkge1xyXG4gICAgICAgICAgY29uc3QgeyBkYXRhOiBtYXRjaCB9ID0gYXdhaXQgc3VwYWJhc2VcclxuICAgICAgICAgICAgICAuZnJvbSgncHJvZHVjdF9jYXRhbG9nJylcclxuICAgICAgICAgICAgICAuc2VsZWN0KCdpZCwgaW1hZ2VfdXJsLCBwcmljZScpXHJcbiAgICAgICAgICAgICAgLmlsaWtlKCduYW1lJywgYCUke2luZy5uYW1lfSVgKVxyXG4gICAgICAgICAgICAgIC5saW1pdCgxKVxyXG4gICAgICAgICAgICAgIC5zaW5nbGUoKTtcclxuXHJcbiAgICAgICAgICBpZiAobWF0Y2gpIHtcclxuICAgICAgICAgICAgICBsaW5rZWRQcm9kdWN0SWQgPSBtYXRjaC5pZDtcclxuICAgICAgICAgICAgICBsaW5rZWRQcm9kdWN0SW1hZ2UgPSBtYXRjaC5pbWFnZV91cmw7XHJcbiAgICAgICAgICAgICAgaWYgKCFlc3RpbWF0ZWRDb3N0ICYmIG1hdGNoLnByaWNlKSBlc3RpbWF0ZWRDb3N0ID0gbWF0Y2gucHJpY2U7IFxyXG4gICAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgbmFtZTogaW5nLm5hbWUsXHJcbiAgICAgICAgICBxdWFudGl0eTogaW5nLnF1YW50aXR5LFxyXG4gICAgICAgICAgdW5pdDogaW5nLnVuaXQsXHJcbiAgICAgICAgICBlbW9qaTogaW5nLmVtb2ppLFxyXG4gICAgICAgICAgZXN0aW1hdGVkQ29zdDogZXN0aW1hdGVkQ29zdCxcclxuICAgICAgICAgIGxpbmtlZFByb2R1Y3RJZDogbGlua2VkUHJvZHVjdElkLFxyXG4gICAgICAgICAgbGlua2VkUHJvZHVjdEltYWdlOiBsaW5rZWRQcm9kdWN0SW1hZ2UsXHJcbiAgICAgIH07XHJcbiAgfSkpO1xyXG5cclxuICAvLyDwn5K+IDMuIFBSRVBBUkFSIFBFUiBHVUFSREFSXHJcbiAgY29uc3QgaW5wdXQ6IFNhdmVSZWNpcGVJbnB1dCA9IHtcclxuICAgIG5hbWU6IHJlY2lwZURhdGEubmFtZSxcclxuICAgIHByZXBUaW1lTWludXRlczogcmVjaXBlRGF0YS5wcmVwVGltZU1pbnV0ZXMgfHwgMzAsXHJcbiAgICB0YWdzOiByZWNpcGVEYXRhLnRhZ3MgfHwgW10sXHJcbiAgICBkaWV0YXJ5VGFnczogcmVjaXBlRGF0YS5kaWV0YXJ5VGFncyB8fCBbXSxcclxuICAgIGlzQWlHZW5lcmF0ZWQ6IHRydWUsXHJcbiAgICBzdGVwczogcmVjaXBlRGF0YS5zdGVwcyB8fCBbXSxcclxuICAgIGluZ3JlZGllbnRzOiBlbnJpY2hlZEluZ3JlZGllbnRzXHJcbiAgfTtcclxuXHJcbiAgLy8g8J+UpSBUUlVDIEZJTkFMOiBHdWFyZGVtIGNvbSBhIFDDmkJMSUNBP1xyXG4gIC8vIFPDrSwgcGVycXXDqCBzaSB1biBhbHRyZSB1c3VhcmkgZGUgbGEgc2FsYSBmYSBjbGljLCB2b2xlbSBxdWUgdHJvYmkgYXF1ZXN0YSByZWNlcHRhIChQYXMgMSlcclxuICAvLyBpIG5vIGVuIGNyZcOvIHVuYSBkZSBub3ZhLlxyXG4gIC8vIE1vZGlmaXF1ZW0gc2F2ZVJlY2lwZUFjdGlvbiBwZXJxdcOoIGFjY2VwdGkgJ2lzUHVibGljJyBvIGhvIGZvcmNlbSBhIGxhIGzDsmdpY2EgZGUgc2F2ZS5cclxuICBcclxuICAvLyBPcGNpw7MgQTogU2kgc2F2ZVJlY2lwZUFjdGlvbiBhY2NlcHRhIGlzUHVibGljIGFsIGlucHV0LCBwYXNzYS1sJ2hpLlxyXG4gIC8vIE9wY2nDsyBCIChIYWNrIHLDoHBpZCk6IFNhdmVSZWNpcGVBY3Rpb24gcGVyIGRlZmVjdGUgbGVzIGZhIHByaXZhZGVzLiBcclxuICAvLyBQZXLDsiBjb20gcXVlIHJldG9ybmEgbCdJRCwgcG9kZW0gZmVyIHVuIHVwZGF0ZSByw6BwaWQgYXF1w60gcGVyIGZlci1sYSBww7pibGljYS5cclxuICBcclxuICBjb25zdCBzYXZlUmVzdWx0ID0gYXdhaXQgc2F2ZVJlY2lwZUFjdGlvbihpbnB1dCk7XHJcblxyXG4gIGlmIChzYXZlUmVzdWx0LnN1Y2Nlc3MgJiYgc2F2ZVJlc3VsdC5yZWNpcGVJZCkge1xyXG4gICAgICAvLyBMYSBmZW0gcMO6YmxpY2EgcGVycXXDqCBsYSB0cm9iaW4gZWxzIGFsdHJlcyBjb21wYW55cyBkZSBsYSBzYWxhXHJcbiAgICAgIGF3YWl0IHN1cGFiYXNlXHJcbiAgICAgICAgICAuZnJvbSgnc2F2ZWRfcmVjaXBlcycpXHJcbiAgICAgICAgICAudXBkYXRlKHsgaXNfcHVibGljOiB0cnVlIH0pXHJcbiAgICAgICAgICAuZXEoJ2lkJywgc2F2ZVJlc3VsdC5yZWNpcGVJZCk7XHJcbiAgICAgICAgICBcclxuICAgICAgZGVidWcoJ1tBQ1RJT05dIHJlY2lwZSBzaGFyZWQnKTtcclxuICB9XHJcblxyXG4gIHJldHVybiBzYXZlUmVzdWx0O1xyXG59XHJcblxyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6ImtTQTZDc0IsNkxBQUEifQ==
}),
"[project]/lib/utils/dish-emojis.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getDishEmoji",
    ()=>getDishEmoji
]);
function getDishEmoji(name) {
    if (!name) return '🍽️';
    const n = name.toLowerCase();
    // 🍕 Fast Food / Casual
    if (n.includes('pizza')) return '🍕';
    if (n.includes('burger') || n.includes('hamburg')) return '🍔';
    if (n.includes('taco') || n.includes('fajita') || n.includes('burrito')) return '🌮';
    if (n.includes('entrep') || n.includes('bocata') || n.includes('sandwich') || n.includes('bikini')) return '🥪';
    if (n.includes('frit') || n.includes('fregit') || n.includes('croquet')) return '🍟';
    // 🍝 Pasta & Arròs
    if (n.includes('pasta') || n.includes('espagueti') || n.includes('macarron') || n.includes('ravioli')) return '🍝';
    if (n.includes('arròs') || n.includes('paella') || n.includes('risotto')) return '🥘';
    if (n.includes('fideu')) return '🍜';
    // 🥗 Saludable / Verdures
    if (n.includes('amanida') || n.includes('enciam') || n.includes('salad') || n.includes('verd')) return '🥗';
    if (n.includes('sopa') || n.includes('crema') || n.includes('brou')) return '🥣';
    if (n.includes('albergínia') || n.includes('carbassó') || n.includes('pastanaga')) return '🥦';
    // 🥩 Proteïna
    if (n.includes('pollastre') || n.includes('pavo') || n.includes('au')) return '🍗';
    if (n.includes('carn') || n.includes('vedella') || n.includes('porc') || n.includes('filet') || n.includes('xai')) return '🥩';
    if (n.includes('sushi') || n.includes('maki')) return '🍣';
    if (n.includes('peix') || n.includes('luç') || n.includes('bacalla') || n.includes('salm') || n.includes('gamba')) return '🐟';
    if (n.includes('ou') || n.includes('truita') || n.includes('remenat')) return '🍳';
    // 🍰 Postres
    if (n.includes('postre') || n.includes('pastís') || n.includes('cake') || n.includes('tiramisú')) return '🍰';
    if (n.includes('gelat')) return '🍦';
    if (n.includes('xocolata') || n.includes('bombó')) return '🍫';
    if (n.includes('fruita') || n.includes('poma') || n.includes('maduixa')) return '🍎';
    if (n.includes('galet')) return '🍪';
    // 🥖 Acompanyaments
    if (n.includes('pa ') || n.includes('torrada')) return '🥖';
    if (n.includes('formatge')) return '🧀';
    return '🍽️';
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/RecipeGrid.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RecipeGrid",
    ()=>RecipeGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/sonner@2.0.7_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$2d7a82__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:2d7a82 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$Recipe$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/domain/entities/Recipe.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2f$dish$2d$emojis$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils/dish-emojis.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// src/components/recipes/RecipeGrid.tsx
'use client';
;
;
;
;
;
;
function RecipeGrid({ recipes, onCancel }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [savingId, setSavingId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // 🔍 DEBUG: Afegeix això per veure què arriba realment al navegador
    console.log("🔍 [RecipeGrid DEBUG] Receptes rebudes:", recipes.length);
    if (recipes.length > 0) {
        console.log("🔍 [RecipeGrid DEBUG] Mostra de la 1a recepta:", {
            nom: recipes[0].name,
            cost: recipes[0].estimatedCost,
            tipus_cost: typeof recipes[0].estimatedCost,
            ingredients_count: recipes[0].ingredients.length
        });
    }
    const handleSelect = async (recipe)=>{
        if (savingId) return;
        const recipeId = recipe.id;
        // Si ve com a classe, extraiem les primitives. Si ve com a objecte (JSON), ja ho és.
        const plainData = recipe instanceof __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$Recipe$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Recipe"] ? recipe.toPrimitives() : recipe;
        setSavingId(recipeId);
        console.log("📤 [RecipeGrid] Guardant:", plainData.name);
        const payload = {
            id: plainData.id,
            name: plainData.name,
            prepTimeMinutes: Number(plainData.prepTimeMinutes) || 30,
            description: "",
            servings: 2,
            difficulty: "medium",
            tags: plainData.tags || [],
            dietaryTags: plainData.dietaryTags || [],
            // 🔥 CORRECCIÓ DE DADES PERDUDES
            ingredients: plainData.ingredients.map((ing)=>{
                // Càsting per accedir a camps opcionals que poden venir del backend
                const extendedIng = ing;
                // DEBUG: Comprovem si el camp existeix abans d'enviar
                if (extendedIng.linkedProductId) {
                    console.log(`   💎 [GRID] Vincle trobat: ${extendedIng.name} -> ${extendedIng.linkedProductId}`);
                }
                return {
                    id: extendedIng.id,
                    name: extendedIng.name,
                    quantity: extendedIng.quantity,
                    unit: extendedIng.unit,
                    emoji: extendedIng.emoji,
                    // 🛑 CRUCIAL: Usem '|| null'.
                    // Si és undefined o null, enviem null. Així el JSON no ho elimina.
                    linkedProductId: extendedIng.linkedProductId || null,
                    linkedProductImage: extendedIng.linkedProductImage || null,
                    estimatedCost: extendedIng.estimatedCost || 0
                };
            }),
            steps: plainData.steps.map((step)=>{
                if (typeof step === 'string') return {
                    id: crypto.randomUUID(),
                    content: step
                };
                const stepObj = step;
                return {
                    id: stepObj.id || crypto.randomUUID(),
                    content: stepObj.content || ""
                };
            }),
            isAiGenerated: true
        };
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$2d7a82__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["saveRecipeAction"])(payload);
        if (result.success) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Recepta guardada correctament!");
            router.push(`/recipes/${result.recipeId}`);
        } else {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(result.error || "Error guardant la recepta.");
            setSavingId(null);
        }
    };
    if (!recipes || recipes.length === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-white p-4",
            children: "⚠️ No hi ha receptes per mostrar."
        }, void 0, false, {
            fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
            lineNumber: 114,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        id: "tour-dec-results",
        className: "space-y-6 w-full min-h-75",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-xl font-black text-white flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "👨‍🍳"
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                                        lineNumber: 122,
                                        columnNumber: 13
                                    }, this),
                                    " Propostes del Xef"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                                lineNumber: 121,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-slate-400",
                                children: "Tria la que més t'agradi."
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                                lineNumber: 124,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                        lineNumber: 120,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onCancel,
                        className: "text-xs font-bold text-slate-500 hover:text-white bg-slate-800/50 hover:bg-slate-700 px-3 py-1.5 rounded-full transition-colors",
                        children: "Tancar"
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                        lineNumber: 126,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                lineNumber: 119,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                children: recipes.map((recipe, idx)=>{
                    const isSaving = savingId === recipe.id;
                    // Assegurem que name no sigui null
                    const safeName = recipe.name || "Recepta sense nom";
                    const emoji = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2f$dish$2d$emojis$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDishEmoji"])(safeName);
                    const hasCost = recipe.estimatedCost && recipe.estimatedCost > 0;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        onClick: ()=>handleSelect(recipe),
                        className: `
                group relative flex flex-col justify-between
                p-5 rounded-3xl border cursor-pointer overflow-hidden transition-all duration-300
                bg-slate-900 border-slate-800 hover:border-purple-500
                ${isSaving ? 'opacity-50 pointer-events-none' : 'hover:shadow-xl hover:-translate-y-1'}
              `,
                        children: [
                            isSaving && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute inset-0 bg-black/60 flex flex-col items-center justify-center z-20",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-2xl animate-spin",
                                    children: "⏳"
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                                    lineNumber: 152,
                                    columnNumber: 19
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                                lineNumber: 151,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-start mb-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-3xl bg-slate-800 w-12 h-12 flex items-center justify-center rounded-2xl",
                                        children: emoji
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                                        lineNumber: 157,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-col items-end gap-1",
                                        children: [
                                            recipe.prepTimeMinutes && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[10px] font-bold bg-black/40 text-slate-300 px-2 py-1 rounded-full",
                                                children: [
                                                    recipe.prepTimeMinutes,
                                                    " min"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                                                lineNumber: 162,
                                                columnNumber: 21
                                            }, this),
                                            hasCost ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[10px] font-bold bg-emerald-900/40 text-emerald-400 px-2 py-1 rounded-full border border-emerald-500/20",
                                                children: [
                                                    recipe.estimatedCost?.toFixed(2),
                                                    "€"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                                                lineNumber: 167,
                                                columnNumber: 21
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[10px] font-bold text-red-400",
                                                children: "0.00€"
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                                                lineNumber: 171,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                                        lineNumber: 160,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                                lineNumber: 156,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                className: "font-bold text-lg text-white mb-2 line-clamp-2",
                                children: safeName
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                                lineNumber: 176,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-wrap gap-1 mb-4",
                                children: recipe.ingredients?.slice(0, 3).map((ing, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded",
                                        children: ing.name
                                    }, i, false, {
                                        fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                                        lineNumber: 180,
                                        columnNumber: 19
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                                lineNumber: 178,
                                columnNumber: 15
                            }, this)
                        ]
                    }, recipe.id || idx, true, {
                        fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                        lineNumber: 140,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
                lineNumber: 131,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/RecipeGrid.tsx",
        lineNumber: 118,
        columnNumber: 5
    }, this);
}
_s(RecipeGrid, "sYaqpc41vm9SlEF2DrnPtN0qHno=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = RecipeGrid;
var _c;
__turbopack_context__.k.register(_c, "RecipeGrid");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/decision/components/DecisionResults.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DecisionResults",
    ()=>DecisionResults
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$RecipeGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/RecipeGrid.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$TourTrigger$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/onboarding/TourTrigger.tsx [app-client] (ecmascript)");
// src/features/decision/components/DecisionResults.tsx
'use client';
;
;
;
function DecisionResults({ title, recipes, userId, onBack, tourSteps }) {
    return(// ✅ AQUEST ID ÉS CRUCIAL
    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        id: "tour-dec-results",
        className: "h-full w-full flex flex-col animate-in fade-in zoom-in-95 duration-300 bg-zinc-900/90 rounded-4xl overflow-hidden border border-zinc-800 relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between px-4 py-3 bg-black/20 border-b border-white/5 shrink-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-sm font-black text-white flex items-center gap-2 uppercase tracking-wide",
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/features/decision/components/DecisionResults.tsx",
                        lineNumber: 28,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$TourTrigger$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TourTrigger"], {
                        tourId: "decision-maker",
                        steps: tourSteps
                    }, void 0, false, {
                        fileName: "[project]/features/decision/components/DecisionResults.tsx",
                        lineNumber: 31,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/decision/components/DecisionResults.tsx",
                lineNumber: 27,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 overflow-y-auto p-2 min-h-0",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$RecipeGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RecipeGrid"], {
                    recipes: recipes,
                    userId: userId,
                    onCancel: onBack
                }, void 0, false, {
                    fileName: "[project]/features/decision/components/DecisionResults.tsx",
                    lineNumber: 35,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/decision/components/DecisionResults.tsx",
                lineNumber: 34,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/decision/components/DecisionResults.tsx",
        lineNumber: 24,
        columnNumber: 9
    }, this));
}
_c = DecisionResults;
var _c;
__turbopack_context__.k.register(_c, "DecisionResults");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/decision/hooks/useDecisionTour.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDecisionTour",
    ()=>useDecisionTour
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/onboarding/OnboardingContext.tsx [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
// ✅ DADES REALS DE LA TEVA BD (Copiat del teu JSON)
const DUMMY_RECIPES = [
    {
        id: "1090b513-97e9-4ea5-93ab-b8de7bb43c32",
        name: "Arròs Fregit \"Wok de l'Aprofitament\"",
        prepTimeMinutes: 25,
        ingredients: [
            {
                name: "Arròs cuit",
                unit: "g",
                quantity: 200
            },
            {
                name: "Ous",
                unit: "ut",
                quantity: 2
            },
            {
                name: "Ceba",
                unit: "ut",
                quantity: 0.5
            },
            {
                name: "Salsa de soja",
                unit: "cullerades",
                quantity: 2
            }
        ],
        // Posem un resum dels passos per no omplir massa codi, però ja val
        steps: [
            "Pica verdures.",
            "Salta al wok.",
            "Afegeix arròs i ou.",
            "Serveix."
        ],
        tags: [
            "ràpid",
            "asiàtic",
            "aprofitament"
        ],
        dietaryTags: [
            "vegetarian"
        ],
        authorId: 'demo-user',
        createdAt: new Date(),
        updatedAt: new Date(),
        privacy: 'PUBLIC',
        servings: 2,
        likesCount: 0
    },
    {
        id: "f5d2abe7-95b3-42fd-96fc-7db1d33bbd63",
        name: "Truita de Patata i Pebrot",
        prepTimeMinutes: 30,
        ingredients: [
            {
                name: "Patata",
                unit: "ut",
                quantity: 2
            },
            {
                name: "Ous",
                unit: "ut",
                quantity: 4
            },
            {
                name: "Pebrot vermell",
                unit: "ut",
                quantity: 0.5
            }
        ],
        steps: [
            "Fregir patates.",
            "Batre ous.",
            "Quallar truita."
        ],
        tags: [
            "clàssic",
            "ràpid",
            "vegetarià"
        ],
        dietaryTags: [
            "vegetarià"
        ],
        authorId: 'demo-user',
        createdAt: new Date(),
        updatedAt: new Date(),
        privacy: 'PUBLIC',
        servings: 2,
        likesCount: 0
    }
];
function useDecisionTour(setMode, expandMobile) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const { startTour, isActive, currentStepIndex, nextStep } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"])();
    const steps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useDecisionTour.useMemo[steps]": ()=>[
                {
                    targetId: 'tour-dec-header',
                    title: t.onboarding.decision.step1_title,
                    description: t.onboarding.decision.step1_desc
                },
                {
                    targetId: 'tour-dec-mode',
                    title: t.onboarding.decision.step2_title,
                    description: t.onboarding.decision.step2_desc
                },
                {
                    targetId: 'tour-dec-inputs',
                    title: t.onboarding.decision.step3_title,
                    description: t.onboarding.decision.step3_desc
                },
                {
                    targetId: 'tour-dec-action',
                    title: t.onboarding.decision.step4_title,
                    description: t.onboarding.decision.step4_desc
                },
                {
                    targetId: 'tour-dec-results',
                    title: t.onboarding.decision.step5_title,
                    description: t.onboarding.decision.step5_desc
                }
            ]
    }["useDecisionTour.useMemo[steps]"], [
        t
    ]);
    // 1. Iniciar
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useDecisionTour.useEffect": ()=>{
            startTour('decision-maker', steps);
        }
    }["useDecisionTour.useEffect"], [
        startTour,
        steps
    ]);
    // 2. Control UI
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useDecisionTour.useEffect": ()=>{
            if (!isActive) return;
            if (currentStepIndex >= 2 && currentStepIndex <= 3) {
                setMode('CHEF');
                expandMobile(true);
            }
        }
    }["useDecisionTour.useEffect"], [
        isActive,
        currentStepIndex,
        setMode,
        expandMobile
    ]);
    return {
        steps,
        isActive,
        currentStepIndex,
        nextStep,
        dummyRecipes: DUMMY_RECIPES
    };
}
_s(useDecisionTour, "lHxEe+cgINLLl2Hf4w1ffO9+r/A=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"],
        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/decision/components/IndividualDecisionForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IndividualDecisionForm",
    ()=>IndividualDecisionForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$context$2f$DecisionContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/context/DecisionContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$decision$2f$components$2f$views$2f$FateView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/decision/components/views/FateView.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$decision$2f$components$2f$views$2f$ChefView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/decision/components/views/ChefView.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$decision$2f$components$2f$LoadingOverlay$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/decision/components/LoadingOverlay.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$decision$2f$components$2f$DecisionHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/decision/components/DecisionHeader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$decision$2f$components$2f$DecisionResults$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/decision/components/DecisionResults.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$decision$2f$hooks$2f$useDecisionTour$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/decision/hooks/useDecisionTour.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/onboarding/OnboardingContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
function IndividualDecisionForm({ userId }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const logic = (0, __TURBOPACK__imported__module__$5b$project$5d2f$context$2f$DecisionContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDecision"])();
    const isFate = logic.mode === 'FATE';
    const [isMobileExpanded, setIsMobileExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // 1. DADES DEL TOUR
    const { isActive: isTourActive, currentStepIndex, nextStep } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"])();
    const tourData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$decision$2f$hooks$2f$useDecisionTour$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDecisionTour"])(logic.setMode, setIsMobileExpanded);
    // 2. ESTATS LOCALS
    const [simLoading, setSimLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showFakeResults, setShowFakeResults] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const isLoading = logic.isPending || simLoading;
    // LOG DE DEBUG (Opcional)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "IndividualDecisionForm.useEffect": ()=>{
        // console.log("🔄 [RENDER] Estat:", { isTourActive, currentStepIndex });
        }
    }["IndividualDecisionForm.useEffect"], [
        isTourActive,
        currentStepIndex
    ]);
    // 🚑 AUTO-SIMULACIÓ (CORREGIDA PER EVITAR ERROR DE REACT)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "IndividualDecisionForm.useEffect": ()=>{
            // Si estem al tour + Pas Resultats (4) + No tenim resultats
            if (isTourActive && currentStepIndex === 4 && !showFakeResults && !logic.hasActiveResult) {
                console.log("🚑 [AUTO-FIX] Forçant simulació...");
                // ✅ FIX: Usem un setTimeout per evitar "setState synchronously within an effect"
                const timer = setTimeout({
                    "IndividualDecisionForm.useEffect.timer": ()=>{
                        setSimLoading(true);
                        // Esperem 1.5s i mostrem resultats
                        setTimeout({
                            "IndividualDecisionForm.useEffect.timer": ()=>{
                                setSimLoading(false);
                                setShowFakeResults(true);
                            }
                        }["IndividualDecisionForm.useEffect.timer"], 1500);
                    }
                }["IndividualDecisionForm.useEffect.timer"], 0); // El 0 és suficient per trencar el cicle síncron
                return ({
                    "IndividualDecisionForm.useEffect": ()=>clearTimeout(timer)
                })["IndividualDecisionForm.useEffect"];
            }
        }
    }["IndividualDecisionForm.useEffect"], [
        isTourActive,
        currentStepIndex,
        showFakeResults,
        logic.hasActiveResult
    ]);
    // 3. HANDLE EXECUTE (PER SI CLICA EL BOTÓ REAL)
    const handleExecute = (dishNameOverride)=>{
        console.log("🔥 [CLICK] Botó apretat!");
        // Si estem al pas del botó (3), simulem
        if (isTourActive && currentStepIndex === 3) {
            console.log("🤡 [LOGIC] Simulació per click...");
            setSimLoading(true);
            setTimeout(()=>{
                setSimLoading(false);
                setShowFakeResults(true);
                // Avancem manualment al següent pas
                setTimeout(()=>nextStep(), 200);
            }, 2000);
            return;
        }
        // LÒGICA REAL
        console.log("🚀 [LOGIC] Lògica REAL.");
        let dishName = dishNameOverride || '';
        if (isFate && !dishName) dishName = "Recepta Sorpresa del Xef";
        if (!isFate && !dishName) {
            const energyLevel = logic.energy > 80 ? "Alta" : logic.energy < 30 ? "Baixa" : "Mitjana";
            dishName = `Recepta adequada per nivell d'energia ${energyLevel} i temps disponible ${logic.time} minuts`;
        }
        if (dishName) logic.generateMenu(userId, dishName);
    };
    const closeDemo = ()=>setShowFakeResults(false);
    // --- RENDERITZAT ---
    if (logic.hasActiveResult || showFakeResults) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$decision$2f$components$2f$DecisionResults$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecisionResults"], {
            title: showFakeResults ? "RESULTATS DE PROVA 🧪" : isFate ? t.decision.results.fate : t.decision.results.chef,
            recipes: showFakeResults ? tourData.dummyRecipes : logic.recipes,
            userId: userId,
            onBack: showFakeResults ? closeDemo : logic.reset,
            tourSteps: tourData.steps
        }, void 0, false, {
            fileName: "[project]/features/decision/components/IndividualDecisionForm.tsx",
            lineNumber: 93,
            columnNumber: 13
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `
            w-full flex flex-col bg-zinc-900/80 backdrop-blur-xl rounded-4xl border-2 border-zinc-800 shadow-2xl overflow-hidden relative transition-all duration-500 ease-in-out
            ${isMobileExpanded ? 'h-145' : 'h-14'} 
            lg:h-full lg:transition-none
        `,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$decision$2f$components$2f$LoadingOverlay$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LoadingOverlay"], {
                isVisible: isLoading,
                mode: logic.mode
            }, void 0, false, {
                fileName: "[project]/features/decision/components/IndividualDecisionForm.tsx",
                lineNumber: 110,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[70%] h-[70%] blur-[80px] rounded-full pointer-events-none transition-colors duration-500
                ${logic.error ? 'bg-red-500/20 opacity-40' : isFate ? 'bg-emerald-500/20' : 'bg-purple-500/20'} 
                opacity-20`
            }, void 0, false, {
                fileName: "[project]/features/decision/components/IndividualDecisionForm.tsx",
                lineNumber: 112,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$decision$2f$components$2f$DecisionHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecisionHeader"], {
                mode: logic.mode,
                setMode: logic.setMode,
                error: logic.error,
                isMobileExpanded: isMobileExpanded,
                setIsMobileExpanded: setIsMobileExpanded,
                tourSteps: tourData.steps
            }, void 0, false, {
                fileName: "[project]/features/decision/components/IndividualDecisionForm.tsx",
                lineNumber: 117,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `flex-1 flex flex-col p-4 md:p-6 z-10 min-h-0 transition-opacity duration-300 ${!isMobileExpanded ? 'opacity-0 lg:opacity-100' : 'opacity-100'}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 flex flex-col items-center justify-center min-h-0 text-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "animate-in zoom-in duration-300 flex flex-col items-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-6xl md:text-7xl mb-3 filter drop-shadow-2xl key={logic.mode} select-none",
                                    children: isFate ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "animate-bounce inline-block",
                                        children: "🎲"
                                    }, void 0, false, {
                                        fileName: "[project]/features/decision/components/IndividualDecisionForm.tsx",
                                        lineNumber: 131,
                                        columnNumber: 39
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "animate-pulse inline-block",
                                        children: "👨‍🍳"
                                    }, void 0, false, {
                                        fileName: "[project]/features/decision/components/IndividualDecisionForm.tsx",
                                        lineNumber: 131,
                                        columnNumber: 97
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/features/decision/components/IndividualDecisionForm.tsx",
                                    lineNumber: 130,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-lg font-black text-white leading-tight mb-1",
                                    children: isFate ? t.decision.states.fate_title : t.decision.states.chef_title
                                }, void 0, false, {
                                    fileName: "[project]/features/decision/components/IndividualDecisionForm.tsx",
                                    lineNumber: 133,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[11px] text-slate-400 max-w-55 leading-tight",
                                    children: isFate ? t.decision.states.fate_desc : t.decision.states.chef_desc
                                }, void 0, false, {
                                    fileName: "[project]/features/decision/components/IndividualDecisionForm.tsx",
                                    lineNumber: 136,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/features/decision/components/IndividualDecisionForm.tsx",
                            lineNumber: 129,
                            columnNumber: 22
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/decision/components/IndividualDecisionForm.tsx",
                        lineNumber: 128,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "shrink-0 w-full mt-2 relative z-40",
                        children: isFate ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$decision$2f$components$2f$views$2f$FateView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FateView"], {
                            onDecide: ()=>handleExecute(),
                            isPending: isLoading
                        }, void 0, false, {
                            fileName: "[project]/features/decision/components/IndividualDecisionForm.tsx",
                            lineNumber: 144,
                            columnNumber: 25
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$decision$2f$components$2f$views$2f$ChefView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChefView"], {
                            onSuggest: ()=>handleExecute(),
                            isPending: isLoading,
                            energy: logic.energy,
                            time: logic.time,
                            setEnergy: logic.setEnergy,
                            setTime: logic.setTime
                        }, void 0, false, {
                            fileName: "[project]/features/decision/components/IndividualDecisionForm.tsx",
                            lineNumber: 146,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/decision/components/IndividualDecisionForm.tsx",
                        lineNumber: 142,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/decision/components/IndividualDecisionForm.tsx",
                lineNumber: 126,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/decision/components/IndividualDecisionForm.tsx",
        lineNumber: 104,
        columnNumber: 9
    }, this);
}
_s(IndividualDecisionForm, "Ex0zxHQVIUT2Hx4csoHPnX2Ajqg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"],
        __TURBOPACK__imported__module__$5b$project$5d2f$context$2f$DecisionContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDecision"],
        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"],
        __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$decision$2f$hooks$2f$useDecisionTour$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDecisionTour"]
    ];
});
_c = IndividualDecisionForm;
var _c;
__turbopack_context__.k.register(_c, "IndividualDecisionForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/dashboard/components/QuickActionsPanel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "QuickActionsPanel",
    ()=>QuickActionsPanel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$decision$2f$components$2f$IndividualDecisionForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/decision/components/IndividualDecisionForm.tsx [app-client] (ecmascript)");
'use client';
;
;
function QuickActionsPanel({ userId }) {
    return(// h-full és clau perquè ocupi tota l'alçada que li donem (sigui la fixa de desktop o l'automàtica de mòbil)
    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "h-full w-full animate-in slide-in-from-left-4 duration-700",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$decision$2f$components$2f$IndividualDecisionForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IndividualDecisionForm"], {
            userId: userId
        }, void 0, false, {
            fileName: "[project]/features/dashboard/components/QuickActionsPanel.tsx",
            lineNumber: 12,
            columnNumber: 14
        }, this)
    }, void 0, false, {
        fileName: "[project]/features/dashboard/components/QuickActionsPanel.tsx",
        lineNumber: 11,
        columnNumber: 9
    }, this));
}
_c = QuickActionsPanel;
var _c;
__turbopack_context__.k.register(_c, "QuickActionsPanel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/core/constants/profile-data.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ✅ 1. Definició correcta dels tipus (exportats)
__turbopack_context__.s([
    "EXCLUSION_DATA",
    ()=>EXCLUSION_DATA,
    "FOOD_DATA",
    ()=>FOOD_DATA
]);
const EXCLUSION_DATA = [
    {
        id: "cat_allergens",
        items: [
            {
                id: 'gluten',
                emoji: '🍞'
            },
            {
                id: 'crustaceans',
                emoji: '🦐'
            },
            {
                id: 'eggs',
                emoji: '🥚'
            },
            {
                id: 'fish',
                emoji: '🐟'
            },
            {
                id: 'peanuts',
                emoji: '🥜'
            },
            {
                id: 'soybeans',
                emoji: '🫘'
            },
            {
                id: 'dairy',
                emoji: '🥛'
            },
            {
                id: 'nuts',
                emoji: '🌰'
            },
            {
                id: 'celery',
                emoji: '🥬'
            },
            {
                id: 'mustard',
                emoji: '🌭'
            },
            {
                id: 'sesame',
                emoji: '🥯'
            },
            {
                id: 'sulphites',
                emoji: '🍷'
            },
            {
                id: 'lupin',
                emoji: '🌼'
            },
            {
                id: 'molluscs',
                emoji: '🐙'
            }
        ]
    },
    {
        id: "cat_diets",
        items: [
            {
                id: 'vegan',
                emoji: '🌱'
            },
            {
                id: 'vegetarian',
                emoji: '🥗'
            },
            {
                id: 'pescatarian',
                emoji: '🎣'
            },
            {
                id: 'halal',
                emoji: '☪️'
            },
            {
                id: 'kosher',
                emoji: '✡️'
            },
            {
                id: 'keto',
                emoji: '🥑'
            },
            {
                id: 'paleo',
                emoji: '🍖'
            },
            {
                id: 'low_fodmap',
                emoji: '📉'
            }
        ]
    },
    {
        id: "cat_dislikes",
        items: [
            {
                id: 'onion',
                emoji: '🧅'
            },
            {
                id: 'garlic',
                emoji: '🧄'
            },
            {
                id: 'spicy',
                emoji: '🌶️'
            },
            {
                id: 'cilantro',
                emoji: '🌿'
            },
            {
                id: 'mushrooms',
                emoji: '🍄'
            },
            {
                id: 'pork',
                emoji: '🐖'
            },
            {
                id: 'beef',
                emoji: '🐄'
            },
            {
                id: 'alcohol',
                emoji: '🍺'
            },
            {
                id: 'caffeine',
                emoji: '☕'
            },
            {
                id: 'sugar',
                emoji: '🍬'
            },
            {
                id: 'fructose',
                emoji: '🍎'
            },
            {
                id: 'bell_pepper',
                emoji: '🫑'
            },
            {
                id: 'coconut',
                emoji: '🥥'
            },
            {
                id: 'cucumber',
                emoji: '🥒'
            }
        ]
    }
];
const FOOD_DATA = [
    {
        id: "cat_world_west",
        items: [
            {
                id: 'italian',
                emoji: '🍕'
            },
            {
                id: 'mediterranean',
                emoji: '🫒'
            },
            {
                id: 'spanish',
                emoji: '🥘'
            },
            {
                id: 'french',
                emoji: '🥐'
            },
            {
                id: 'greek',
                emoji: '🧀'
            },
            {
                id: 'mexican',
                emoji: '🌮'
            },
            {
                id: 'american',
                emoji: '🍔'
            },
            {
                id: 'brazilian',
                emoji: '🥩'
            },
            {
                id: 'peruvian',
                emoji: '🐟'
            },
            {
                id: 'argentinian',
                emoji: '🥩🔥'
            },
            {
                id: 'german',
                emoji: '🌭'
            }
        ]
    },
    {
        id: "cat_world_east",
        items: [
            {
                id: 'japanese',
                emoji: '🍣'
            },
            {
                id: 'chinese',
                emoji: '🥡'
            },
            {
                id: 'indian',
                emoji: '🍛'
            },
            {
                id: 'thai',
                emoji: '🍜'
            },
            {
                id: 'korean',
                emoji: '🥘🔥'
            },
            {
                id: 'vietnamese',
                emoji: '🍲'
            },
            {
                id: 'turkish',
                emoji: '🥙'
            },
            {
                id: 'lebanese',
                emoji: '🧆'
            },
            {
                id: 'poke',
                emoji: '🐟🥗'
            }
        ]
    },
    {
        id: "cat_fast",
        items: [
            {
                id: 'pizza',
                emoji: '🍕'
            },
            {
                id: 'burger',
                emoji: '🍔'
            },
            {
                id: 'fried_chicken',
                emoji: '🍗'
            },
            {
                id: 'kebab',
                emoji: '🌯'
            },
            {
                id: 'hotdog',
                emoji: '🌭'
            },
            {
                id: 'tacos',
                emoji: '🌮'
            },
            {
                id: 'sandwich',
                emoji: '🥪'
            },
            {
                id: 'crepes',
                emoji: '🥞'
            },
            {
                id: 'empanadas',
                emoji: '🥟'
            }
        ]
    },
    {
        id: "cat_specific",
        items: [
            {
                id: 'sushi',
                emoji: '🍣'
            },
            {
                id: 'ramen',
                emoji: '🍜'
            },
            {
                id: 'steak',
                emoji: '🥩'
            },
            {
                id: 'seafood_dish',
                emoji: '🦞'
            },
            {
                id: 'paella',
                emoji: '🥘'
            },
            {
                id: 'pasta',
                emoji: '🍝'
            },
            {
                id: 'bbq',
                emoji: '🍖'
            },
            {
                id: 'dimsum',
                emoji: '🥟'
            },
            {
                id: 'fondue',
                emoji: '🧀'
            }
        ]
    },
    {
        id: "cat_healthy",
        items: [
            {
                id: 'salad',
                emoji: '🥗'
            },
            {
                id: 'poke_bowl',
                emoji: '🥣'
            },
            {
                id: 'soup',
                emoji: '🍲'
            },
            {
                id: 'vegan_dish',
                emoji: '🥦'
            },
            {
                id: 'smoothies',
                emoji: '🫐'
            },
            {
                id: 'grilled_fish',
                emoji: '🐟'
            }
        ]
    },
    {
        id: "cat_sweet",
        items: [
            {
                id: 'breakfast',
                emoji: '🥑'
            },
            {
                id: 'croissant',
                emoji: '🥐'
            },
            {
                id: 'ice_cream',
                emoji: '🍦'
            },
            {
                id: 'coffee',
                emoji: '☕'
            },
            {
                id: 'bubble_tea',
                emoji: '🧋'
            },
            {
                id: 'donuts',
                emoji: '🍩'
            }
        ]
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/StackedEmoji.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StackedEmoji",
    ()=>StackedEmoji
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// src/components/ui/StackedEmoji.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
function StackedEmoji({ emoji, size = 'md', className = '' }) {
    _s();
    // ✅ SOLUCIÓ ERROR TS: Usem Array.from() en lloc de [...emoji]
    // Això funciona en totes les versions de JS/TS sense tocar config.
    const chars = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "StackedEmoji.useMemo[chars]": ()=>Array.from(emoji || '❓')
    }["StackedEmoji.useMemo[chars]"], [
        emoji
    ]);
    const isMulti = chars.length > 1;
    // Configuració de mides segons el lloc on es fa servir
    const config = {
        sm: {
            single: 'text-lg',
            multi: 'text-[12px]',
            offset: {
                x: 1,
                y: 0.5
            } // Píxels de desplaçament
        },
        md: {
            single: 'text-xl',
            multi: 'text-sm',
            offset: {
                x: 2.5,
                y: 3
            }
        }
    };
    const current = config[size];
    // CAS 1: Emoji simple
    if (!isMulti) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: `${current.single} ${className}`,
            children: emoji
        }, void 0, false, {
            fileName: "[project]/components/ui/StackedEmoji.tsx",
            lineNumber: 36,
            columnNumber: 7
        }, this);
    }
    // CAS 2: Emojis múltiples (Stacked)
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `relative w-full h-full flex items-center justify-center pointer-events-none ${className}`,
        children: chars.map((char, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: `
            absolute transition-transform leading-none
            ${current.multi}
            ${i === 0 ? 'opacity-80 scale-110' : 'z-10'}
          `,
                style: {
                    // Apliquem transformacions dinàmiques segons la mida
                    transform: i === 0 ? `translate(-${current.offset.x}px, -${current.offset.y}px)` : `translate(${current.offset.x}px, ${current.offset.y}px)`
                },
                children: char
            }, i, false, {
                fileName: "[project]/components/ui/StackedEmoji.tsx",
                lineNumber: 46,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/components/ui/StackedEmoji.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
_s(StackedEmoji, "E/+zzXN6BZjmDMGRry6lPfGevJ8=");
_c = StackedEmoji;
var _c;
__turbopack_context__.k.register(_c, "StackedEmoji");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/dashboard/components/UserPreferencesSidebar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "UserPreferencesSidebar",
    ()=>UserPreferencesSidebar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$constants$2f$profile$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/constants/profile-data.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/chevron-up.js [app-client] (ecmascript) <export default as ChevronUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$StackedEmoji$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/StackedEmoji.tsx [app-client] (ecmascript)"); // ✅ IMPORT NOU
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
// ✅ 1. HELPER: Accepta un diccionari genèric
const findItemData = (id, dataset, dictionary)=>{
    // A. Busquem l'emoji a les dades estàtiques
    let emoji = '❓';
    for (const category of dataset){
        const item = category.items.find((i)=>i.id === id);
        if (item) {
            emoji = item.emoji;
            break;
        }
    }
    // B. Busquem la traducció. Si no hi és, tornem l'ID
    const label = dictionary ? dictionary[id] || id : id;
    return {
        id,
        emoji,
        label
    };
};
function UserPreferencesSidebar({ foodPreferences, exclusions, className }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    // ✅ 2. GUSTOS: Fem servir 't.profile.food'
    const preferencesList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "UserPreferencesSidebar.useMemo[preferencesList]": ()=>{
            const safe = Array.isArray(foodPreferences) ? foodPreferences : [];
            // TRUC: Fem un cast a 'any' o 'Record' per evitar que TS es queixi si les claus no coincideixen exactament
            // Això imita el que fèiem al ProfileForm
            const dict = t.profile?.food || {};
            return safe.map({
                "UserPreferencesSidebar.useMemo[preferencesList]": (id)=>findItemData(id, __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$constants$2f$profile$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FOOD_DATA"], dict)
            }["UserPreferencesSidebar.useMemo[preferencesList]"]);
        }
    }["UserPreferencesSidebar.useMemo[preferencesList]"], [
        foodPreferences,
        t
    ]);
    // ✅ 3. EXCLUSIONS: Fem servir 't.profile.exclusions'
    const exclusionsList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "UserPreferencesSidebar.useMemo[exclusionsList]": ()=>{
            const safe = Array.isArray(exclusions) ? exclusions : [];
            // TRUC: Mateix sistema per les exclusions
            const dict = t.profile?.exclusions || {};
            return safe.map({
                "UserPreferencesSidebar.useMemo[exclusionsList]": (id)=>findItemData(id, __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$constants$2f$profile$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EXCLUSION_DATA"], dict)
            }["UserPreferencesSidebar.useMemo[exclusionsList]"]);
        }
    }["UserPreferencesSidebar.useMemo[exclusionsList]"], [
        exclusions,
        t
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
        className: `
      flex flex-col items-center py-3 w-full h-full overflow-hidden relative
      ${className}
    `,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "shrink-0 mb-2 z-20",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: "/profile",
                    className: "w-10 h-10 bg-indigo-600 hover:bg-indigo-500 rounded-xl flex items-center justify-center border-b-[3px] border-indigo-900 active:border-b-0 active:translate-y-0.75 transition-all group shadow-lg shadow-indigo-900/20",
                    title: t.profile?.sidebar?.edit || "Editar",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-xl group-hover:rotate-12 transition-transform filter drop-shadow-md",
                        children: "😎"
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                        lineNumber: 81,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                    lineNumber: 76,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                lineNumber: 75,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full flex-2 min-h-0 border-b border-zinc-800/50 flex flex-col relative",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ScrollableSection, {
                    title: t.profile?.sidebar?.likes || "GUSTOS",
                    items: preferencesList,
                    color: "green"
                }, void 0, false, {
                    fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                    lineNumber: 87,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                lineNumber: 86,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full flex-1 min-h-0 flex flex-col relative pt-2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ScrollableSection, {
                    title: t.profile?.sidebar?.alerts || "ALERTA",
                    items: exclusionsList,
                    color: "red"
                }, void 0, false, {
                    fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                    lineNumber: 96,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                lineNumber: 95,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
        lineNumber: 69,
        columnNumber: 9
    }, this);
}
_s(UserPreferencesSidebar, "mRaesorDOX9MJkqgLnMNdDFErQ0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = UserPreferencesSidebar;
function ScrollableSection({ title, items, color }) {
    _s1();
    const listRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [canScrollUp, setCanScrollUp] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [canScrollDown, setCanScrollDown] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const checkScroll = ()=>{
        if (listRef.current) {
            const { scrollTop, scrollHeight, clientHeight } = listRef.current;
            setCanScrollUp(scrollTop > 0);
            setCanScrollDown(scrollTop + clientHeight < scrollHeight - 1);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ScrollableSection.useEffect": ()=>{
            checkScroll();
            const element = listRef.current;
            if (!element) return;
            element.addEventListener('scroll', checkScroll);
            const resizeObserver = new ResizeObserver(checkScroll);
            resizeObserver.observe(element);
            return ({
                "ScrollableSection.useEffect": ()=>{
                    element.removeEventListener('scroll', checkScroll);
                    resizeObserver.disconnect();
                }
            })["ScrollableSection.useEffect"];
        }
    }["ScrollableSection.useEffect"], [
        items
    ]);
    const scroll = (direction)=>{
        if (listRef.current) {
            const scrollAmount = 120;
            listRef.current.scrollBy({
                top: direction === 'up' ? -scrollAmount : scrollAmount,
                behavior: 'smooth'
            });
        }
    };
    const labelColor = color === 'green' ? 'text-green-500' : 'text-red-500';
    if (items.length === 0) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col h-full w-full items-center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `text-[9px] font-black ${labelColor} uppercase tracking-widest py-1 opacity-80 shrink-0`,
                children: title
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                lineNumber: 156,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-6 shrink-0 flex items-center justify-center w-full",
                children: canScrollUp && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: ()=>scroll('up'),
                    className: "text-zinc-600 hover:text-white transition-colors animate-in fade-in slide-in-from-bottom-2 duration-200",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
                        size: 16
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                        lineNumber: 162,
                        columnNumber: 25
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                    lineNumber: 161,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                lineNumber: 159,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: listRef,
                className: "flex-1 w-full overflow-y-auto [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden flex flex-col items-center gap-2 py-1",
                children: [
                    items.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ItemBubble, {
                            ...item,
                            variant: color
                        }, item.id, false, {
                            fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                            lineNumber: 168,
                            columnNumber: 21
                        }, this)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-4 w-full shrink-0"
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                        lineNumber: 170,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                lineNumber: 166,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-6 shrink-0 flex items-center justify-center w-full",
                children: canScrollDown && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: ()=>scroll('down'),
                    className: "text-zinc-600 hover:text-white transition-colors animate-in fade-in slide-in-from-top-2 duration-200",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                        size: 16
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                        lineNumber: 175,
                        columnNumber: 25
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                    lineNumber: 174,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                lineNumber: 172,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
        lineNumber: 155,
        columnNumber: 9
    }, this);
}
_s1(ScrollableSection, "sMJTHqIP3sn5nLvWlOBqL/djnKU=");
_c1 = ScrollableSection;
// ----------------------------------------------------------------------
// COMPONENT: BUBBLE AMB SUPORT PER EMOJIS MULTIPLES (STACKED)
// ----------------------------------------------------------------------
function ItemBubble({ emoji, label, variant }) {
    _s2();
    const [isHovered, setIsHovered] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const triggerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [coords, setCoords] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        top: 0,
        left: 0
    });
    const handleMouseEnter = ()=>{
        if (triggerRef.current) {
            const rect = triggerRef.current.getBoundingClientRect();
            setCoords({
                top: rect.top + rect.height / 2,
                left: rect.right + 12
            });
            setIsHovered(true);
        }
    };
    const styles = {
        green: 'bg-green-900/10 border-green-500/20 text-green-400 hover:bg-green-500 hover:text-white hover:border-green-400',
        red: 'bg-red-900/10 border-red-500/20 text-red-400 hover:bg-red-500 hover:text-white hover:border-red-400'
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: triggerRef,
                onMouseEnter: handleMouseEnter,
                onMouseLeave: ()=>setIsHovered(false),
                "aria-label": label,
                className: `
                    w-12 h-12 shrink-0 rounded-lg border flex items-center justify-center cursor-help transition-all duration-200 relative overflow-hidden
                    ${styles[variant]} 
                    ${isHovered ? 'scale-110 shadow-lg ring-1 ring-white/20' : ''}
                `,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$StackedEmoji$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StackedEmoji"], {
                    emoji: emoji,
                    size: "md"
                }, void 0, false, {
                    fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                    lineNumber: 222,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                lineNumber: 210,
                columnNumber: 13
            }, this),
            isHovered && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PortalTooltip, {
                top: coords.top,
                left: coords.left,
                label: label
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                lineNumber: 226,
                columnNumber: 17
            }, this)
        ]
    }, void 0, true);
}
_s2(ItemBubble, "NbIpHpZCAOrFoOHivP0DSjR/R4o=");
_c2 = ItemBubble;
function PortalTooltip({ top, left, label }) {
    if (typeof document === 'undefined') return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed z-9999 pointer-events-none flex items-center animate-in fade-in zoom-in-95 duration-150",
        style: {
            top: top,
            left: left,
            transform: 'translateY(-50%)'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-0 h-0 border-t-[6px] border-t-transparent border-r-[6px] border-r-zinc-900 border-b-[6px] border-b-transparent -mr-px"
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                lineNumber: 236,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-zinc-900 border border-zinc-700 text-white text-xs font-bold px-3 py-1.5 rounded-md shadow-2xl whitespace-nowrap",
                children: label
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
                lineNumber: 237,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/dashboard/components/UserPreferencesSidebar.tsx",
        lineNumber: 235,
        columnNumber: 9
    }, this), document.body);
}
_c3 = PortalTooltip;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "UserPreferencesSidebar");
__turbopack_context__.k.register(_c1, "ScrollableSection");
__turbopack_context__.k.register(_c2, "ItemBubble");
__turbopack_context__.k.register(_c3, "PortalTooltip");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/dashboard/components/MobileuserPreferences.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MobileUserPreferences",
    ()=>MobileUserPreferences
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$constants$2f$profile$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/constants/profile-data.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$StackedEmoji$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/StackedEmoji.tsx [app-client] (ecmascript)"); // ✅ IMPORT NOU
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
// ✅ 1. HELPER ACTUALITZAT (Igual que al Sidebar)
const findItemData = (id, dataset, dictionary)=>{
    // A. Busquem l'emoji
    let emoji = '❓';
    for (const category of dataset){
        const item = category.items.find((i)=>i.id === id);
        if (item) {
            emoji = item.emoji;
            break;
        }
    }
    // B. Busquem la traducció al diccionari
    const label = dictionary ? dictionary[id] || id : id;
    return {
        id,
        emoji,
        label
    };
};
function MobileUserPreferences({ foodPreferences, exclusions, className }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    // ✅ 2. GUSTOS: Passem 't.profile.food'
    const preferencesList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "MobileUserPreferences.useMemo[preferencesList]": ()=>{
            const safe = Array.isArray(foodPreferences) ? foodPreferences : [];
            const dict = t.profile?.food || {};
            return safe.map({
                "MobileUserPreferences.useMemo[preferencesList]": (id)=>findItemData(id, __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$constants$2f$profile$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FOOD_DATA"], dict)
            }["MobileUserPreferences.useMemo[preferencesList]"]);
        }
    }["MobileUserPreferences.useMemo[preferencesList]"], [
        foodPreferences,
        t
    ]);
    // ✅ 3. EXCLUSIONS: Passem 't.profile.exclusions'
    const exclusionsList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "MobileUserPreferences.useMemo[exclusionsList]": ()=>{
            const safe = Array.isArray(exclusions) ? exclusions : [];
            const dict = t.profile?.exclusions || {};
            return safe.map({
                "MobileUserPreferences.useMemo[exclusionsList]": (id)=>findItemData(id, __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$constants$2f$profile$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EXCLUSION_DATA"], dict)
            }["MobileUserPreferences.useMemo[exclusionsList]"]);
        }
    }["MobileUserPreferences.useMemo[exclusionsList]"], [
        exclusions,
        t
    ]);
    const hasData = preferencesList.length > 0 || exclusionsList.length > 0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `w-full flex items-center gap-2 py-1 px-1 ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: "/profile",
                className: "shrink-0 w-9 h-9 bg-indigo-600 hover:bg-indigo-500 rounded-xl flex items-center justify-center border-b-[3px] border-indigo-900 active:border-b-0 active:translate-y-0.5 transition-all shadow-lg shadow-indigo-900/20 z-10",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-lg",
                    children: "😎"
                }, void 0, false, {
                    fileName: "[project]/features/dashboard/components/MobileuserPreferences.tsx",
                    lineNumber: 72,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/MobileuserPreferences.tsx",
                lineNumber: 68,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-6 w-px bg-zinc-700/50 shrink-0"
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/MobileuserPreferences.tsx",
                lineNumber: 75,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 overflow-x-auto [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden mask-linear-fade",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2 pr-4",
                    children: [
                        preferencesList.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MobileBubble, {
                                ...item,
                                variant: "green"
                            }, item.id, false, {
                                fileName: "[project]/features/dashboard/components/MobileuserPreferences.tsx",
                                lineNumber: 82,
                                columnNumber: 13
                            }, this)),
                        preferencesList.length > 0 && exclusionsList.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-1 w-1 rounded-full bg-zinc-600 shrink-0 mx-1"
                        }, void 0, false, {
                            fileName: "[project]/features/dashboard/components/MobileuserPreferences.tsx",
                            lineNumber: 86,
                            columnNumber: 13
                        }, this),
                        exclusionsList.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MobileBubble, {
                                ...item,
                                variant: "red"
                            }, item.id, false, {
                                fileName: "[project]/features/dashboard/components/MobileuserPreferences.tsx",
                                lineNumber: 90,
                                columnNumber: 13
                            }, this)),
                        !hasData && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-zinc-500 text-xs italic whitespace-nowrap pl-2",
                            children: t.profile?.no_data || "Sense dades"
                        }, void 0, false, {
                            fileName: "[project]/features/dashboard/components/MobileuserPreferences.tsx",
                            lineNumber: 94,
                            columnNumber: 14
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/features/dashboard/components/MobileuserPreferences.tsx",
                    lineNumber: 79,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/MobileuserPreferences.tsx",
                lineNumber: 78,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/dashboard/components/MobileuserPreferences.tsx",
        lineNumber: 65,
        columnNumber: 5
    }, this);
}
_s(MobileUserPreferences, "mRaesorDOX9MJkqgLnMNdDFErQ0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = MobileUserPreferences;
// ----------------------------------------------------------------
// BUBBLE MÒBIL AMB PORTAL TOOLTIP (CLICK)
// ----------------------------------------------------------------
function MobileBubble({ emoji, label, variant }) {
    _s1();
    const [isActive, setIsActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const triggerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [coords, setCoords] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        top: 0,
        left: 0
    });
    const handleClick = ()=>{
        if (triggerRef.current) {
            const rect = triggerRef.current.getBoundingClientRect();
            setCoords({
                top: rect.bottom + 8,
                left: rect.left + rect.width / 2
            });
            setIsActive(true);
            setTimeout(()=>setIsActive(false), 2500);
        }
    };
    const styles = {
        green: 'bg-green-900/20 border-green-500/30 text-green-400',
        red: 'bg-red-900/20 border-red-500/30 text-red-400'
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: triggerRef,
                onClick: handleClick,
                className: `
                shrink-0 w-9 h-9 rounded-full border flex items-center justify-center transition-transform active:scale-95 relative overflow-hidden
                ${styles[variant]}
                ${isActive ? 'ring-2 ring-white/20 scale-105' : ''}
            `,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$StackedEmoji$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StackedEmoji"], {
                    emoji: emoji,
                    size: "sm"
                }, void 0, false, {
                    fileName: "[project]/features/dashboard/components/MobileuserPreferences.tsx",
                    lineNumber: 143,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/MobileuserPreferences.tsx",
                lineNumber: 133,
                columnNumber: 9
            }, this),
            isActive && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MobilePortalTooltip, {
                top: coords.top,
                left: coords.left,
                label: label
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/MobileuserPreferences.tsx",
                lineNumber: 146,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true);
}
_s1(MobileBubble, "4q/mPSwYRf+hQsUVVW0F4Z5wWBk=");
_c1 = MobileBubble;
function MobilePortalTooltip({ top, left, label }) {
    if (typeof document === 'undefined') return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed z-9999 pointer-events-none flex flex-col items-center animate-in fade-in zoom-in-95 slide-in-from-top-2 duration-200",
        style: {
            top: top,
            left: left,
            transform: 'translateX(-50%)'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-b-[6px] border-b-zinc-900 -mt-1.5 mb-0"
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/MobileuserPreferences.tsx",
                lineNumber: 164,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-zinc-900 border border-zinc-700 text-white text-[11px] font-bold px-3 py-1.5 rounded-lg shadow-2xl whitespace-nowrap",
                children: label
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/MobileuserPreferences.tsx",
                lineNumber: 165,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/dashboard/components/MobileuserPreferences.tsx",
        lineNumber: 156,
        columnNumber: 9
    }, this), document.body);
}
_c2 = MobilePortalTooltip;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "MobileUserPreferences");
__turbopack_context__.k.register(_c1, "MobileBubble");
__turbopack_context__.k.register(_c2, "MobilePortalTooltip");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/use-media-query.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useMediaQuery",
    ()=>useMediaQuery
]);
// src/hooks/use-media-query.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
function useMediaQuery(query) {
    _s();
    // Inicialitzem en false per assegurar coherència amb el servidor (SSR)
    const [matches, setMatches] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMediaQuery.useEffect": ()=>{
            const media = window.matchMedia(query);
            // 1. Actualitzem l'estat inicial immediatament
            if (media.matches !== matches) {
                setMatches(media.matches);
            }
            // 2. Creem el listener per quan canviï la mida
            const listener = {
                "useMediaQuery.useEffect.listener": ()=>setMatches(media.matches)
            }["useMediaQuery.useEffect.listener"];
            // 3. Ens subscrivim
            media.addEventListener('change', listener);
            // 4. Netegem
            return ({
                "useMediaQuery.useEffect": ()=>media.removeEventListener('change', listener)
            })["useMediaQuery.useEffect"];
        // ⚠️ IMPORTANT: L'array de dependències NOMÉS té 'query'.
        // Hem tret 'matches' d'aquí per evitar el bucle infinit i l'error de React.
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["useMediaQuery.useEffect"], [
        query
    ]);
    return matches;
}
_s(useMediaQuery, "/aV7jSECvYA0Ea4uAEPK2AzROhs=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/dashboard/components/DashboardContent.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DashboardContent",
    ()=>DashboardContent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$dashboard$2f$components$2f$DashboardHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/dashboard/components/DashboardHeader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$dashboard$2f$components$2f$NavigationPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/dashboard/components/NavigationPanel.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$dashboard$2f$components$2f$QuickActionsPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/dashboard/components/QuickActionsPanel.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$dashboard$2f$components$2f$UserPreferencesSidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/dashboard/components/UserPreferencesSidebar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$dashboard$2f$components$2f$MobileuserPreferences$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/dashboard/components/MobileuserPreferences.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/onboarding/OnboardingContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$TourTrigger$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/onboarding/TourTrigger.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$use$2d$media$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/use-media-query.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
function DashboardContent({ userName, userId, profileData }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const { startTour } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"])();
    const isE2E = ("TURBOPACK compile-time value", "true") === 'true';
    // El hook ja gestiona la hidratació
    const isDesktop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$use$2d$media$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMediaQuery"])('(min-width: 1024px)');
    const onboardingSteps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "DashboardContent.useMemo[onboardingSteps]": ()=>[
                {
                    targetId: 'tour-dash-header',
                    title: t.onboarding.dashboard.step1_title,
                    description: t.onboarding.dashboard.step1_desc
                },
                {
                    targetId: isDesktop ? 'tour-dash-prefs-desktop' : 'tour-dash-prefs-mobile',
                    title: t.onboarding.dashboard.step2_title,
                    description: t.onboarding.dashboard.step2_desc
                },
                {
                    targetId: 'tour-dash-quick',
                    title: t.onboarding.dashboard.step3_title,
                    description: t.onboarding.dashboard.step3_desc
                },
                {
                    targetId: 'tour-dash-nav',
                    title: t.onboarding.dashboard.step4_title,
                    description: t.onboarding.dashboard.step4_desc
                },
                {
                    targetId: 'tour-dash-create',
                    title: t.onboarding.dashboard.step5_title,
                    description: t.onboarding.dashboard.step5_desc
                },
                {
                    targetId: 'tour-dash-join',
                    title: t.onboarding.dashboard.step6_title,
                    description: t.onboarding.dashboard.step6_desc
                },
                {
                    targetId: 'tour-dash-recipes',
                    title: t.onboarding.dashboard.step7_title,
                    description: t.onboarding.dashboard.step7_desc
                },
                {
                    targetId: 'tour-dash-ranking',
                    title: t.onboarding.dashboard.step8_title,
                    description: t.onboarding.dashboard.step8_desc
                },
                {
                    targetId: 'tour-dash-rooms',
                    title: t.onboarding.dashboard.step9_title,
                    description: t.onboarding.dashboard.step9_desc
                },
                {
                    targetId: 'tour-dash-inventory',
                    title: t.onboarding.dashboard.step10_title,
                    description: t.onboarding.dashboard.step10_desc
                },
                {
                    targetId: 'tour-dash-profile',
                    title: t.onboarding.dashboard.step11_title,
                    description: t.onboarding.dashboard.step11_desc
                }
            ]
    }["DashboardContent.useMemo[onboardingSteps]"], [
        t,
        isDesktop
    ]);
    // INICI AUTOMÀTIC DEL TOUR
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DashboardContent.useEffect": ()=>{
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
        }
    }["DashboardContent.useEffect"], [
        startTour,
        onboardingSteps,
        isE2E
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-dvh lg:h-dvh w-full flex flex-col relative bg-[#131f24] bg-gamified-pattern overflow-y-auto lg:overflow-hidden",
        children: [
            !isE2E && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `
          z-100 transition-all duration-500
          /* MÒBIL: Fixed a baix dreta (Tipus botó d'ajuda flotant) */
          fixed bottom-6 right-6
          /* ESCRIPTORI: Absolute a dalt dreta (Integrat al disseny) */
          lg:absolute lg:bottom-auto lg:top-6 lg:right-8
      `,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$TourTrigger$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TourTrigger"], {
                    tourId: "dashboard",
                    steps: onboardingSteps,
                    // Afegim ombra extra en mòbil perquè destaqui sobre el contingut
                    className: "shadow-2xl shadow-purple-900/50 lg:shadow-none"
                }, void 0, false, {
                    fileName: "[project]/features/dashboard/components/DashboardContent.tsx",
                    lineNumber: 89,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/DashboardContent.tsx",
                lineNumber: 82,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed top-[-20%] left-[-10%] w-150 h-150 bg-purple-600/10 rounded-full blur-[120px] pointer-events-none"
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/DashboardContent.tsx",
                lineNumber: 100,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed bottom-[-20%] right-[-10%] w-150 h-150 bg-blue-600/10 rounded-full blur-[120px] pointer-events-none"
            }, void 0, false, {
                fileName: "[project]/features/dashboard/components/DashboardContent.tsx",
                lineNumber: 101,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 w-full max-w-350 mx-auto p-4 md:px-6 md:pb-6 flex flex-col min-h-0 relative z-10",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        id: "tour-dash-header",
                        className: "shrink-0 pt-2 pb-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$dashboard$2f$components$2f$DashboardHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DashboardHeader"], {
                            userName: userName
                        }, void 0, false, {
                            fileName: "[project]/features/dashboard/components/DashboardContent.tsx",
                            lineNumber: 106,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/DashboardContent.tsx",
                        lineNumber: 105,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        id: "tour-dash-prefs-mobile",
                        className: "block lg:hidden mb-6 animate-in slide-in-from-top-4 fade-in duration-500",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$dashboard$2f$components$2f$MobileuserPreferences$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MobileUserPreferences"], {
                            foodPreferences: profileData.foodPreferences,
                            exclusions: profileData.exclusions
                        }, void 0, false, {
                            fileName: "[project]/features/dashboard/components/DashboardContent.tsx",
                            lineNumber: 111,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/dashboard/components/DashboardContent.tsx",
                        lineNumber: 110,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 lg:grid-cols-12 gap-4 h-auto lg:flex-1 lg:min-h-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                id: "tour-dash-prefs-desktop",
                                className: "hidden lg:block lg:col-span-1 min-h-0 h-full",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "h-full bg-zinc-900/30 border border-white/5 rounded-3xl backdrop-blur-sm",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$dashboard$2f$components$2f$UserPreferencesSidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UserPreferencesSidebar"], {
                                        foodPreferences: profileData.foodPreferences,
                                        exclusions: profileData.exclusions
                                    }, void 0, false, {
                                        fileName: "[project]/features/dashboard/components/DashboardContent.tsx",
                                        lineNumber: 122,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/features/dashboard/components/DashboardContent.tsx",
                                    lineNumber: 121,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/dashboard/components/DashboardContent.tsx",
                                lineNumber: 120,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                id: "tour-dash-quick",
                                className: "lg:col-span-7 h-auto lg:h-full lg:min-h-0",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$dashboard$2f$components$2f$QuickActionsPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuickActionsPanel"], {
                                    userId: userId
                                }, void 0, false, {
                                    fileName: "[project]/features/dashboard/components/DashboardContent.tsx",
                                    lineNumber: 130,
                                    columnNumber: 14
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/dashboard/components/DashboardContent.tsx",
                                lineNumber: 129,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "lg:col-span-4 h-auto lg:h-full lg:min-h-0 pb-8 lg:pb-0",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$dashboard$2f$components$2f$NavigationPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NavigationPanel"], {}, void 0, false, {
                                    fileName: "[project]/features/dashboard/components/DashboardContent.tsx",
                                    lineNumber: 134,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/dashboard/components/DashboardContent.tsx",
                                lineNumber: 133,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/dashboard/components/DashboardContent.tsx",
                        lineNumber: 117,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/dashboard/components/DashboardContent.tsx",
                lineNumber: 103,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/dashboard/components/DashboardContent.tsx",
        lineNumber: 78,
        columnNumber: 5
    }, this);
}
_s(DashboardContent, "HynfrKgtx5n3bmbrO3hZwqTyGLQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"],
        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$use$2d$media$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMediaQuery"]
    ];
});
_c = DashboardContent;
var _c;
__turbopack_context__.k.register(_c, "DashboardContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/onboarding/OnboardingOverlay.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OnboardingOverlay",
    ()=>OnboardingOverlay
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/onboarding/OnboardingContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function OnboardingOverlay() {
    _s();
    const { isActive, steps, currentStepIndex, nextStep, prevStep, skipTour } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"])();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [targetRect, setTargetRect] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [windowSize, setWindowSize] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        w: 0,
        h: 0
    });
    const currentStep = steps[currentStepIndex];
    // 1. Detectar posició i mida finestra
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OnboardingOverlay.useEffect": ()=>{
            if (!isActive || !currentStep) return;
            const updatePosition = {
                "OnboardingOverlay.useEffect.updatePosition": ()=>{
                    setWindowSize({
                        w: window.innerWidth,
                        h: window.innerHeight
                    });
                    const element = document.getElementById(currentStep.targetId);
                    if (element) {
                        // En mòbil preferim 'center' per tenir-lo a la vista, 
                        // la nostra nova lògica s'apartarà d'ell.
                        element.scrollIntoView({
                            behavior: 'smooth',
                            block: 'center'
                        });
                        setTimeout({
                            "OnboardingOverlay.useEffect.updatePosition": ()=>{
                                const rect = element.getBoundingClientRect();
                                setTargetRect(rect);
                            }
                        }["OnboardingOverlay.useEffect.updatePosition"], 150);
                    } else {
                        setTargetRect(null);
                    }
                }
            }["OnboardingOverlay.useEffect.updatePosition"];
            const timeout = setTimeout(updatePosition, 100);
            window.addEventListener('resize', updatePosition);
            window.addEventListener('scroll', updatePosition);
            return ({
                "OnboardingOverlay.useEffect": ()=>{
                    clearTimeout(timeout);
                    window.removeEventListener('resize', updatePosition);
                    window.removeEventListener('scroll', updatePosition);
                }
            })["OnboardingOverlay.useEffect"];
        }
    }["OnboardingOverlay.useEffect"], [
        isActive,
        currentStepIndex,
        currentStep
    ]);
    if (!isActive || !currentStep) return null;
    // --- LÒGICA DE POSICIONAMENT INTEL·LIGENT (MOBILE & DESKTOP) 🧠 ---
    const isMobile = windowSize.w > 0 && windowSize.w < 768;
    // 1. ESTAT BASE (Fallback segur: Fixat a baix)
    let cardStyles = {
        position: 'fixed',
        top: 'auto',
        bottom: 24,
        left: '50%',
        x: '-50%',
        y: 0,
        width: '90%',
        maxWidth: '400px'
    };
    if (targetRect && windowSize.h > 0) {
        // --- LÒGICA MÒBIL: HEMISFERI OPOSAT ---
        if (isMobile) {
            const elementCenterY = targetRect.top + targetRect.height / 2;
            const screenCenterY = windowSize.h / 2;
            // Si l'element està a la meitat INFERIOR de la pantalla (> centre)
            if (elementCenterY > screenCenterY) {
                // Posem la targeta a DALT
                cardStyles = {
                    position: 'fixed',
                    top: 24,
                    bottom: 'auto',
                    left: '50%',
                    x: '-50%',
                    y: 0,
                    width: '90%',
                    maxWidth: '400px'
                };
            } else {
                // Si l'element està a la meitat SUPERIOR (< centre)
                // Posem la targeta a BAIX (lògica per defecte, però explicita aquí)
                cardStyles = {
                    position: 'fixed',
                    top: 'auto',
                    bottom: 24,
                    left: '50%',
                    x: '-50%',
                    y: 0,
                    width: '90%',
                    maxWidth: '400px'
                };
            }
        } else {
            const spaceAbove = targetRect.top;
            const spaceBelow = windowSize.h - targetRect.bottom;
            const CARD_HEIGHT = 220;
            // Si tenim espai a SOTA -> Absolute a sota
            if (spaceBelow > CARD_HEIGHT) {
                cardStyles = {
                    position: 'absolute',
                    top: targetRect.bottom + 20,
                    bottom: 'auto',
                    left: Math.max(20, Math.min(targetRect.left, windowSize.w - 380)),
                    x: 0,
                    y: 0,
                    width: '380px',
                    maxWidth: '380px'
                };
            } else if (spaceAbove > CARD_HEIGHT) {
                cardStyles = {
                    position: 'absolute',
                    top: targetRect.top - 20,
                    bottom: 'auto',
                    left: Math.max(20, Math.min(targetRect.left, windowSize.w - 380)),
                    x: 0,
                    y: '-100%',
                    width: '380px',
                    maxWidth: '380px'
                };
            }
        // Si no hi cap enlloc (rar en desktop) -> Es queda fixed center o bottom (fallback)
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-9999 overflow-hidden pointer-events-none",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                className: "absolute rounded-xl pointer-events-none transition-all duration-500 ease-in-out box-content border-4 border-purple-500/50",
                initial: false,
                animate: {
                    top: targetRect ? targetRect.top - 4 : '50%',
                    left: targetRect ? targetRect.left - 4 : '50%',
                    width: targetRect ? targetRect.width + 8 : 0,
                    height: targetRect ? targetRect.height + 8 : 0,
                    opacity: targetRect ? 1 : 0,
                    boxShadow: `0 0 0 9999px rgba(2, 6, 23, 0.85)`
                }
            }, void 0, false, {
                fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                lineNumber: 157,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                mode: "wait",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "pointer-events-auto z-10000",
                    style: {
                        position: cardStyles.position,
                        width: cardStyles.width,
                        maxWidth: cardStyles.maxWidth,
                        // Apliquem top/bottom dinàmicament
                        top: cardStyles.top,
                        bottom: cardStyles.bottom,
                        left: cardStyles.left,
                        right: cardStyles.right
                    },
                    initial: {
                        opacity: 0,
                        scale: 0.9,
                        x: cardStyles.x,
                        y: cardStyles.y
                    },
                    animate: {
                        opacity: 1,
                        scale: 1,
                        // Necessitem passar explícitament top/bottom a l'animate per suavitzar canvis
                        top: cardStyles.top,
                        bottom: cardStyles.bottom,
                        left: cardStyles.left,
                        x: cardStyles.x,
                        y: cardStyles.y
                    },
                    exit: {
                        opacity: 0,
                        scale: 0.95
                    },
                    transition: {
                        duration: 0.4,
                        type: "spring",
                        damping: 25,
                        stiffness: 200
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-slate-900 border border-slate-700 text-white p-5 rounded-2xl shadow-2xl relative",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: skipTour,
                                className: "absolute top-3 right-3 text-slate-500 hover:text-white transition-colors",
                                title: t.onboarding.buttons.skip,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                    size: 16
                                }, void 0, false, {
                                    fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                    lineNumber: 209,
                                    columnNumber: 21
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                lineNumber: 204,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-6 pr-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-lg font-bold mb-2 flex items-center gap-2 text-purple-200",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "bg-purple-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs shadow-lg shadow-purple-500/30 shrink-0",
                                                children: currentStepIndex + 1
                                            }, void 0, false, {
                                                fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                                lineNumber: 215,
                                                columnNumber: 25
                                            }, this),
                                            currentStep.title
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                        lineNumber: 214,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-slate-300 text-sm leading-relaxed",
                                        children: currentStep.description
                                    }, void 0, false, {
                                        fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                        lineNumber: 220,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                lineNumber: 213,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex gap-1.5",
                                        children: steps.map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `w-1.5 h-1.5 rounded-full transition-colors ${i === currentStepIndex ? 'bg-purple-500 scale-125' : 'bg-slate-700'}`
                                            }, i, false, {
                                                fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                                lineNumber: 229,
                                                columnNumber: 29
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                        lineNumber: 227,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex gap-2",
                                        children: [
                                            currentStepIndex > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: prevStep,
                                                className: "px-3 py-2 rounded-lg text-sm font-bold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors",
                                                children: t.onboarding.buttons.back
                                            }, void 0, false, {
                                                fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                                lineNumber: 238,
                                                columnNumber: 29
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: nextStep,
                                                className: "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold bg-purple-600 hover:bg-purple-500 text-white shadow-lg shadow-purple-900/20 transition-all active:scale-95",
                                                children: currentStepIndex === steps.length - 1 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                    children: [
                                                        " ",
                                                        t.onboarding.buttons.finish,
                                                        " ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                                            size: 16
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                                            lineNumber: 251,
                                                            columnNumber: 66
                                                        }, this),
                                                        " "
                                                    ]
                                                }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                    children: [
                                                        " ",
                                                        t.onboarding.buttons.next,
                                                        " ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                                            size: 16
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                                            lineNumber: 253,
                                                            columnNumber: 64
                                                        }, this),
                                                        " "
                                                    ]
                                                }, void 0, true)
                                            }, void 0, false, {
                                                fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                                lineNumber: 246,
                                                columnNumber: 25
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                        lineNumber: 236,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                                lineNumber: 226,
                                columnNumber: 17
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                        lineNumber: 201,
                        columnNumber: 13
                    }, this)
                }, currentStepIndex, false, {
                    fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                    lineNumber: 172,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
                lineNumber: 171,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/onboarding/OnboardingOverlay.tsx",
        lineNumber: 154,
        columnNumber: 5
    }, this);
}
_s(OnboardingOverlay, "2zLw7UVeLwdBtmkHpjmSjIvvINg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = OnboardingOverlay;
var _c;
__turbopack_context__.k.register(_c, "OnboardingOverlay");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_a46c7f26._.js.map