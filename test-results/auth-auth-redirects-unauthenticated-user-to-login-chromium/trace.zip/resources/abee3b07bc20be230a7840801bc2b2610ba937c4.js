(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_9fa645e4._.js",
  "static/chunks/06bae_next_dist_compiled_react-dom_f22e60b5._.js",
  "static/chunks/06bae_next_dist_compiled_react-server-dom-turbopack_d5396a28._.js",
  "static/chunks/06bae_next_dist_compiled_next-devtools_index_e9264f50.js",
  "static/chunks/06bae_next_dist_compiled_f95c0291._.js",
  "static/chunks/06bae_next_dist_client_d7530642._.js",
  "static/chunks/06bae_next_dist_91b0d147._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
