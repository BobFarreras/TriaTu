(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/i18n/locales/ca.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ca",
    ()=>ca
]);
const ca = {
    common: {
        loading: 'Pensant...',
        error: 'Alguna cosa ha anat malament',
        start_over: 'Tornar a començar',
        switch_lang: 'Canviar idioma'
    },
    dashboard: {
        nav: {
            multiplayer_badge: 'MULTIPLAYER',
            guest_badge: 'GUEST',
            recipes: 'Comunitat Receptes',
            recipes_badge: 'Social',
            ranking: 'Rànquing Usuaris',
            ranking_badge: 'Top Xefs',
            my_rooms: 'Les Meves Sales',
            my_rooms_badge: 'Actius',
            inventory: 'El meu Inventari',
            inventory_badge: 'Rebost',
            profile: 'El meu Perfil',
            profile_badge: 'Configuració'
        },
        rooms_card: {
            hub: 'SOCIAL HUB',
            title: 'Les Meves Sales',
            desc: 'Gestiona, crea o uneix-te'
        },
        // --- NOVES CLAUS UI ---
        greeting: 'Hola,',
        // ----------------------
        level: 'Nivell 1: La vida fàcil',
        config: 'Configuració',
        quick_decision: 'Decisió Ràpida',
        create_room: 'Crear Sala',
        create_desc: 'Convida amics i decidiu junts',
        join_room: 'Unir-se',
        join_desc: 'Tens un codi d\'invitació?',
        active_rooms_title: 'Les teves Sales',
        active_rooms_empty: 'No tens cap sala activa.',
        continue_btn: 'Continuar'
    },
    decision: {
        title_food: 'Què mengem avui? 🍽️',
        energy_label: 'Nivell d\'Energia',
        time_label: 'Temps disponible',
        button_decide: '🎲 Decideix per mi!',
        disclaimer: '*Sense devolucions, el destí és definitiu.',
        // Resultat
        fate_spoken: 'El destí ha parlat',
        why: 'Per què?',
        roll_again: '🔄 Tornar a tirar',
        // --- NOVES CLAUS UI NECESSÀRIES PER AL COMPONENT ---
        results: {
            fate: '🎲 Resultat',
            chef: '👨‍🍳 Propostes',
            back: 'Tornar'
        },
        mobile: {
            fast_mode: 'Mode Ràpid',
            actions: 'Obrir Accions'
        },
        selector: {
            fate: 'DESTÍ',
            chef: 'XEF'
        },
        states: {
            error_title: 'Ups! Alguna cosa ha fallat',
            fate_title: 'Avui cuina la sort',
            fate_desc: 'Deixa la ment en blanc. Triarem per tu.',
            chef_title: 'Menú Intel·ligent',
            chef_desc: 'Analitzem el teu inventari per suggerir plats.'
        },
        actions: {
            generate_menu: 'GENERAR MENÚ',
            surprise_me: 'SORPRÈN-ME!' // ✅ NOVA CLAU
        },
        // ----------------------------------------------------
        energy_levels: {
            low: 'Mode peresa',
            mid: 'Ni fu ni fa',
            high: 'A menjar-se el món!'
        },
        reasons: {
            high_energy: "Tens bona energia! He triat alguna cosa dels teus favorits a l'atzar.",
            low_energy: "Energia baixa detectada. He triat una opció fàcil i reconfortant.",
            balanced: "Una opció equilibrada per al temps que tens.",
            random: "El destí ha decidit completament a l'atzar.",
            default: "Sembla una bona opció per ara."
        }
    },
    room: {
        back_home: '← Tornar a l\'inici',
        new_room_title: 'Nova Sala',
        id_label: 'ID',
        copy_code: 'Copiar Codi',
        code_copied: 'Codi copiat al porta-retalls! 📋',
        kick_confirm: 'Vols expulsar aquest jugador?',
        host_badge: '👑 Host',
        you_badge: 'Tu',
        user_prefix: 'User',
        mode_auto: '✨ AUTO',
        mode_manual: '📝 MANUAL',
        voting_blind: 'Votació Oculta',
        voting_public: 'Votació Pública',
        blind_desc: 'Ningú veu les opcions dels altres.',
        public_desc: 'Tothom veu el que s\'escriu.',
        btn_change: 'Canviar',
        empty_options: 'Encara no hi ha opcions',
        input_placeholder: 'Escriu una opció...',
        add_btn: 'Afegir',
        hidden_candidate: '??????',
        magic_title: 'El Destí Mana',
        magic_desc: 'L\'algoritme analitzarà els perfils de menjar de tots els participants per trobar la coincidència matemàtica perfecta.',
        decide_magic: '✨ Fer Màgia i Decidir',
        decide_roll: '🎲 Tirar els Daus!',
        waiting_host: 'Esperant al Host...',
        history_title: 'Historial',
        trophy_empty_title: 'Sala de Trofeus buida',
        trophy_empty_desc: 'Encara no s\'ha pres cap decisió.',
        wall_fame: 'Mur de la Fama',
        view_more: '✨ Veure {count} victòries més...',
        clean_room: '💣 Netejar sala',
        clean_confirm: 'Segur que vols esborrar l\'historial?',
        err_kick: 'Error expulsant usuari',
        err_clean: 'Error netejant historial',
        err_add: 'Error afegint opció',
        err_general: 'Error desconegut',
        invite_cta: "Invitar Amics",
        link_copied: "Enllaç copiat!",
        copy_error: "Error al copiar l'enllaç",
        // Textos per compartir per WhatsApp:
        share_title: "Uneix-te a '{name}'",
        share_text: "Ei! Ajuda'm a decidir què fem a la sala '{name}'. Entra aquí:",
        // ✅ AFEGEIX AQUEST BLOC NOU:
        history: {
            title: "Mur de la Fama",
            empty: "Encara no hi ha trofeus",
            type_recipe: "Recepta",
            type_algo: "Algoritme",
            type_manual: "Manual",
            match: "Coincidència",
            allergies: "Al·lèrgies",
            safe: "Segura",
            view_recipe: "Veure Ingredients i Passos",
            show_more: "Mostrar {count} decisions més...",
            // ✅ CLAUS NOVES PER A LA LÒGICA DE DECISIÓ:fa
            magic_match: "✨ Màgia! Aquesta recepta encaixa amb els gustos de {count} persones!",
            magic_safe: "⚠️ Opció Segura: No hi ha coincidències de gustos, però és apta per a tothom.",
            manual_reason: "La sort ha decidit! 🎲"
        }
    },
    landing: {
        // ... (Mantén el teu contingut de landing)
        phrases: [
            {
                text: "No sé, decideix tu...",
                emoji: "🙄"
            },
            {
                text: "A mi m'és igual, de debò...",
                emoji: "🥱"
            },
            {
                text: "On anem a sopar?",
                emoji: "😫"
            },
            {
                text: "Una altra vegada pizza?",
                emoji: "🍕"
            },
            {
                text: "Tria tu que jo no vull pensar",
                emoji: "🤯"
            }
        ],
        hero_title: 'Adéu a perdre temps decidint.',
        hero_subtitle: 'Hola a quedar més i pensar menys.',
        btn_login: 'Ja tinc compte',
        btn_start: '🚀 COMENÇAR'
    },
    auth: {
        // ... (Mantén el teu contingut de auth)
        email_label: 'Email',
        email_placeholder: 'nom@exemple.com',
        password_label: 'Contrasenya',
        password_placeholder: '••••••••',
        password_min: 'Mínim 6 caràcters',
        back: 'ENRERE',
        login_title: 'Hola de nou!',
        login_subtitle: 'La teva sala t\'espera.',
        forgot_password: 'Has oblidat la contrasenya?',
        login_btn: 'ENTRAR',
        no_account: 'No tens compte?',
        register_link: "Registra't aquí",
        register_title: 'Uneix-te al club',
        register_subtitle: 'Comença l\'aventura avui.',
        register_btn: 'CREAR COMPTE',
        has_account: 'Ja tens compte?',
        login_link: 'Entra per aquí'
    },
    create_room: {
        // ... (Mantén el teu contingut)
        back_cancel: '← CANCEL·LAR',
        hero_title: 'Nova Aventura',
        hero_subtitle: 'Crea un espai per decidir amb el teu grup.',
        label_name: 'Nom de la Sala',
        placeholder_name: 'ex: Sopar de Divendres 🍕',
        btn_create: '🪄 CREAR SALA',
        host_info: 'Tu seràs l\'amfitrió (Host) 👑',
        err_name_required: 'El nom de la sala és obligatori.',
        err_unknown: 'Error desconegut al crear la sala.'
    },
    join_room: {
        // ... (Mantén el teu contingut)
        back: '← ENRERE',
        hero_title: 'Tens una invitació?',
        hero_subtitle: 'Introdueix el codi per unir-te a la festa.',
        label_code: 'CODI DE LA SALA (UUID)',
        placeholder_code: 'enganxa-ho-aqui...',
        btn_join: 'ENTRAR ARA 🍿',
        err_code_required: 'El codi és obligatori.'
    },
    profile: {
        // Identitat
        chef_name: 'Nom de Xef',
        chef_placeholder: 'Ex: Chef Ramsay',
        chef_hint: 'Aquest és el nom que veuran els altres al Rànquing.',
        // Seccions
        menu_title: 'Menú Preferit',
        menu_desc: "Què t'agrada?",
        blacklist_title: 'Exclusions',
        blacklist_desc: 'Prohibit entrar',
        // Extres
        extra_label: 'Extra',
        warning_title: "T'has deixat alguna cosa?",
        warning_placeholder: 'Escriu i prem Enter',
        // Tolerància
        flexibility_title: 'Nivell de Flexibilitat',
        rigid: 'RÍGID',
        flexible: 'FLEXIBLE',
        // Botons
        back: '🔙',
        title: 'El teu Personatge',
        subtitle: 'Configuració del perfil',
        saved: '✅ Guardat!',
        save_btn: '💾 Guardar Canvis',
        sidebar: {
            edit: 'Editar Perfil',
            likes: 'GUSTOS',
            alerts: 'ALERTA'
        },
        // --- NOVA CLAU UI ---
        no_data: 'Sense dades...',
        // --------------------
        search_food: '🍕 Buscar menjar (ex: Sushi...)',
        search_allergy: '🥜 Buscar al·lèrgia (ex: Gluten...)',
        warning_text: 'T\'has deixat alguna cosa important?',
        warning_example: 'Ex: Coriandre, Préssec, Colorant E-120...',
        flexibility_desc: 'Com de fàcil ets de convèncer?',
        levels: {
            low: 'NO NEGOCIABLE',
            mid: 'NI FU NI FA',
            high: 'M\'ADAPTO A TOT'
        },
        food: {
            // Copia tot el teu objecte food aquí (és molt llarg per repetir-lo sencer, però no canvia)
            cat_world_west: "🌍 Cuines del Món (Europa & Amèrica)",
            cat_world_east: "🥢 Cuines del Món (Àsia & Orient)",
            cat_fast: "🍔 Fast Food & Casual",
            cat_specific: "🍣 Plats Específics i Delicatessen",
            cat_healthy: "🥗 Saludable i Lleuger",
            cat_sweet: "🧁 Esmorzars i Dolços",
            italian: 'Italiana',
            mediterranean: 'Mediterrània',
            spanish: 'Espanyola',
            french: 'Francesa',
            greek: 'Grega',
            mexican: 'Mexicana',
            american: 'Americana',
            brazilian: 'Brasilera',
            peruvian: 'Peruana',
            argentinian: 'Argentina',
            german: 'Alemanya',
            japanese: 'Japonesa',
            chinese: 'Xinesa',
            indian: 'Índia',
            thai: 'Tailandesa',
            korean: 'Coreana',
            vietnamese: 'Vietnamita',
            turkish: 'Turca',
            lebanese: 'Libanesa',
            poke: 'Hawaiana (Poke)',
            pizza: 'Pizza',
            burger: 'Hamburguesa',
            fried_chicken: 'Pollastre Fregit',
            kebab: 'Kebab/Dürüm',
            hotdog: 'Frankfurt/Hot Dog',
            tacos: 'Tacos/Burritos',
            sandwich: 'Entrepans/Wraps',
            crepes: 'Creps',
            empanadas: 'Empanades',
            sushi: 'Sushi',
            ramen: 'Ramen',
            steak: 'Carn a la brasa',
            seafood_dish: 'Mariscada',
            paella: 'Paella/Arròs',
            pasta: 'Pasta',
            bbq: 'Barbacoa/Costelles',
            dimsum: 'Dim Sum/Gyozas',
            fondue: 'Fondue/Raclette',
            salad: 'Amanides',
            poke_bowl: 'Poke Bowl',
            soup: 'Sopes/Cremes',
            vegan_dish: 'Plats Vegans',
            smoothies: 'Smoothies/Fruita',
            grilled_fish: 'Peix a la planxa',
            breakfast: 'Brunch',
            croissant: 'Pastisseria',
            ice_cream: 'Gelat',
            coffee: 'Cafeteria',
            bubble_tea: 'Bubble Tea',
            donuts: 'Donuts/Berlines'
        },
        exclusions: {
            cat_allergens: "⚠️ Les 14 Al·lèrgens Principals (UE)",
            cat_diets: "🚫 Dietes i Estils de Vida",
            cat_dislikes: "❌ Intoleràncies i Aversions Comuns",
            gluten: 'Gluten',
            crustaceans: 'Crustacis',
            eggs: 'Ous',
            fish: 'Peix',
            peanuts: 'Cacauets',
            soybeans: 'Soja',
            dairy: 'Llet/Lactosa',
            nuts: 'Fruits de closca',
            celery: 'Api',
            mustard: 'Mostassa',
            sesame: 'Sèsam',
            sulphites: 'Sulfits',
            lupin: 'Tramussos',
            molluscs: 'Mol·luscs',
            vegan: 'Vegà (Sense animals)',
            vegetarian: 'Vegetarià',
            pescatarian: 'Pescatarià',
            halal: 'Halal',
            kosher: 'Kosher',
            keto: 'Keto (Baix carbs)',
            paleo: 'Paleo',
            low_fodmap: 'Low FODMAP',
            onion: 'Ceba',
            garlic: 'All',
            spicy: 'Picant',
            cilantro: 'Cilandre',
            mushrooms: 'Bolets',
            pork: 'Porc',
            beef: 'Vedella',
            alcohol: 'Alcohol',
            caffeine: 'Cafeïna',
            sugar: 'Sucre afegit',
            fructose: 'Fructosa',
            bell_pepper: 'Pebrot',
            coconut: 'Coco',
            cucumber: 'Cogombre'
        }
    },
    food: {
        categories: {
            protein: '🥩 Proteïna',
            veggie: '🥦 Verdura',
            fruit: '🍎 Fruita',
            dairy: '🥛 Lactic',
            cereal: '🥖 Cereals',
            drink: '🥤 Beguda',
            snack: '🍪 Snack',
            spice: '🧂 Condiments'
        },
        items: {
            // 🍎 FRUITA
            f1: 'Poma vermella',
            f2: 'Poma verda',
            f3: 'Poma groga',
            f4: 'Plàtan',
            f5: 'Plàtan mascle',
            f6: 'Pera conference',
            f7: 'Pera blanquilla',
            f8: 'Taronja',
            f9: 'Mandarina',
            f10: 'Llimona',
            f11: 'Llima',
            f12: 'Aranja',
            f13: 'Maduixa',
            f14: 'Nabius',
            f15: 'Cireres',
            f16: 'Raïm blanc',
            f17: 'Raïm negre',
            f18: 'Préssec',
            f19: 'Nectarina',
            f20: 'Paraguaià',
            f21: 'Pruna',
            f22: 'Albercoc',
            f23: 'Kiwi verd',
            f24: 'Kiwi groc',
            f25: 'Pinya',
            f26: 'Mango',
            f27: 'Meló',
            f28: 'Síndria',
            f29: 'Coco',
            f30: 'Codony',
            f31: 'Figa',
            f32: 'Dàtil fresc',
            // 🥦 VERDURA
            v1: 'Pastanaga',
            v2: 'Patata',
            v3: 'Ceba blanca',
            v4: 'Ceba morada',
            v5: 'All',
            v6: 'Tomàquet madur',
            v7: 'Tomàquet cherry',
            v8: 'Bròquil',
            v9: 'Cogombre',
            v10: 'Enciam iceberg',
            v11: 'Enciam romà',
            v12: 'Enciam fulla de roure',
            v13: 'Espinacs frescos',
            v14: 'Rúcula',
            v15: 'Albergínia',
            v16: 'Pebrot verd',
            v17: 'Pebrot vermell',
            v18: 'Pebrot groc',
            v19: 'Carbassó',
            v20: 'Coliflor',
            v21: 'Col verda',
            v22: 'Col llombarda',
            v23: 'Gingebre',
            v24: 'Nap',
            v25: 'Remolatxa',
            v26: 'Blat de moro',
            v27: 'Pèsols',
            v28: 'Mongetes verdes',
            v29: 'Xampinyons',
            v30: 'Bolets variats',
            // 🥩 PROTEÏNA
            p1: 'Pollastre sencer',
            p2: 'Pit de pollastre',
            p3: 'Cuixes de pollastre',
            p11: 'Aletes de pollastre',
            p12: 'Vedella fresca',
            p13: 'Vedella picada',
            p14: 'Entrecot de vedella',
            p15: 'Filet de vedella',
            p16: 'Llom de porc',
            p17: 'Costelles de porc',
            p18: 'Carn picada de porc',
            p19: 'Bacon',
            p20: 'Xai (cuixa)',
            p21: 'Costelles de xai',
            p22: 'Lluç',
            p23: 'Bacallà fresc',
            p24: 'Bacallà dessalat',
            p25: 'Orada',
            p26: 'Llobarro',
            p27: 'Sardines',
            p28: 'Verat',
            p29: 'Salmó fresc',
            p30: 'Salmó congelat',
            p31: 'Tonyina fresca',
            p32: 'Gambes',
            p33: 'Calamar',
            p34: 'Musclos',
            p35: 'Llagostí',
            p36: 'Tonyina en conserva',
            p37: 'Sardines en conserva',
            p38: 'Ous',
            p39: 'Llenties cuites',
            p40: 'Cigrons cuits',
            p41: 'Tofu',
            // 🥛 LÀCTIC
            l1: 'Llet sencera',
            l2: 'Llet semi',
            l3: 'Llet desnatada',
            l4: 'Llet sense lactosa',
            l5: 'Formatge curat',
            l6: 'Formatge semicurat',
            l7: 'Formatge tendre',
            l8: 'Formatge ratllat',
            l9: 'Mozzarella',
            l10: 'Formatge parmesà',
            l11: 'Formatge fresc',
            l12: 'Formatge blau',
            l13: 'Iogurt natural',
            l14: 'Iogurt grec',
            l15: 'Iogurt de maduixa',
            l16: 'Flam',
            l17: 'Natilles',
            l18: 'Mantega',
            l19: 'Nata per cuinar',
            l20: 'Gelat',
            // 🥖 CEREALS
            c1: 'Pa blanc',
            c2: 'Pa integral',
            c3: 'Pasta espagueti',
            c4: 'Pasta macarrons',
            c5: 'Arròs blanc',
            c6: 'Barra de pa',
            c7: 'Croissant',
            c8: 'Bagel',
            c9: 'Pa de motlle',
            c10: 'Pasta fusilli',
            c11: 'Pasta penne',
            c12: 'Fideus',
            c13: 'Arròs integral',
            c14: 'Arròs basmati',
            c15: 'Arròs jazmín',
            c16: 'Cuscús',
            c17: 'Quinoa',
            c18: 'Cereals d’esmorzar',
            c19: 'Flocs de civada',
            c20: 'Muesli',
            c21: 'Farina de blat',
            c22: 'Farina integral',
            c23: 'Farina de civada',
            c24: 'Ensaïmada',
            c25: 'Pa de pessic',
            c26: 'Tortilles de blat',
            // 🥤 BEGUDA
            b1: 'Aigua',
            b2: 'Cafè mòlt',
            b3: 'Te',
            b4: 'Refresc cola',
            b5: 'Refresc taronja',
            b6: 'Refresc llimona',
            b7: 'Suc de taronja',
            b8: 'Suc de poma',
            b9: 'Cafè en gra',
            b10: 'Cafè soluble',
            b11: 'Infusions',
            b12: 'Beguda vegetal de civada',
            b13: 'Beguda vegetal d’ametlla',
            b14: 'Cervesa',
            b15: 'Vi',
            b16: 'Vi blanc',
            b17: 'Cava',
            b18: 'Vermut',
            b19: 'Tònica',
            co13: 'Brou de pollastre',
            co14: 'Brou de peix',
            // 🍪 SNACK
            s1: 'Galetes',
            s2: 'Xocolata negra',
            s3: 'Crispetes',
            s4: 'Ametlles',
            s5: 'Xocolata amb llet',
            s6: 'Xocolata blanca',
            s7: 'Caramels',
            s8: 'Pirulís',
            s9: 'Magdalena',
            s10: 'Dònut',
            s11: 'Bastonets salats',
            s12: 'Pretzels',
            s13: 'Patates fregides',
            s14: 'Nachos',
            s15: 'Avellanes',
            s16: 'Nous',
            s17: 'Anacards',
            s18: 'Cacauets',
            s19: 'Pipes de gira-sol',
            s20: 'Galetes salades',
            s21: 'Crackers',
            s22: 'Barretes de cereals',
            s23: 'Mel',
            // 🧂 CONDIMENTS
            co1: 'Oli d\'oliva verge',
            co2: 'Oli de gira-sol',
            co3: 'Sal',
            co4: 'Pebre negre',
            co5: 'Vinagre de vi',
            co6: 'Vinagre de mòdena',
            co7: 'Mantega',
            co8: 'Margarina',
            co9: 'Quètxup',
            co10: 'Maionesa',
            co11: 'Mostassa',
            co12: 'Melmelada',
            co15: 'Tomàquet fregit',
            // 🥖 CONGELATS RÀPIDS (Z)
            z1: 'Pizza congelada',
            z2: 'Patates pre-fregides',
            z3: 'Lassanya preparada',
            z4: 'Croquetes'
        }
    },
    community: {
        title: 'Comunitat',
        title_suffix: 'Foodie',
        subtitle: 'Explora què cuina la gent.',
        search_placeholder: 'Cercar ingredients...',
        filters: {
            all: 'Totes',
            fast: 'Ràpides',
            veggie: 'Vegetarià',
            vegan: 'Vegà',
            gluten_free: 'Sense Gluten',
            dairy_free: 'Sense Lactosa',
            dessert: 'Postres'
        },
        empty_state: 'No s\'han trobat receptes.',
        pagination: {
            page: 'Pàgina',
            of: 'de'
        },
        steps: {
            title: 'Instruccions',
            count_suffix: 'passos',
            empty: 'Sense passos detallats.'
        }
    },
    ranking: {
        top_label: 'TOP',
        title: 'Saló de la Fama',
        season: 'Temporada 1',
        aspirants: 'Aspirants',
        empty_list: 'Aquí no hi ha ningú... 👻',
        you_suffix: '(Tu)',
        points_abbr: 'PTS'
    },
    inventory: {
        header: {
            title_prefix: 'Revost',
            title_suffix: 'Digital',
            subtitle: "Control d'estoc i caducitats",
            items_label: 'ITEMS:'
        },
        dashboard: {
            title_all: "📦 Tot l'Inventari",
            title_expiring: "⚠️ Caduca Aviat",
            filter_prefix: "📂",
            clear_filter: "✕ Netejar",
            scan_btn: "Escanejar IA",
            add_btn: "Afegir",
            close_btn: "Tancar"
        },
        list: {
            empty_title: "👻",
            empty_text: "No s'han trobat aliments aquí.",
            status: {
                expired: "Caducat",
                expiring: "Caduca Aviat"
            }
        },
        scanner: {
            title_suffix: "Productes",
            subtitle: "Revisa abans de guardar",
            no_items: "No queden items.",
            back: "Tornar",
            photo_btn: "Foto",
            confirm_btn: "Confirmar tot",
            saving: "Guardant...",
            error_save: "Error guardant els items."
        },
        actions: {
            add: "Afegir",
            close: "Tancar",
            scan: "Escanejar IA",
            clear: "Netejar",
            save: "📥 Guardar al Rebost",
            saving: "Guardant..."
        },
        form: {
            add_title: "Afegir nou aliment",
            name_placeholder: "Què afegim al revost?",
            quantity_label: "Quantitat",
            product_placeholder: "Escriu 'Llet' o tria categoria...",
            location: {
                fridge: "Nevera",
                pantry: "Revost",
                freezer: "Congelador"
            },
            unit: {
                ut: "Unit",
                kg: "Kg",
                l: "L",
                g: "g"
            }
        },
        add_item: {
            main_btn: 'Afegir nou element',
            close_btn: 'Tancar escàner'
        }
    },
    social: {
        title: 'Zona Social',
        actions: {
            create_badge: 'NOVA',
            create_title: 'Crear Sala',
            join_badge: 'GUEST',
            join_title: 'Unir-me'
        },
        grid: {
            title: 'Sales Actives',
            empty: 'Cap sala activa encara.',
            role_admin: 'Admin',
            role_member: 'Membre'
        }
    },
    create_recipe: {
        steps: {
            title: 'Instruccions',
            placeholder: 'Escriu el pas aquí... (Clica els ingredients de sota per inserir-los)',
            quick_insert: 'Inserció ràpida:',
            timer: 'Temporitzador',
            add_timer: '+ ⏰ Temps',
            warning_ingredients: 'Afegeix primer els ingredients de l’esquerra',
            add_btn: 'Afegir Pas ↵',
            empty_state: 'El camí cap a l’èxit comença aquí',
            step_label: 'Pas'
        },
        ingredients: {
            title: 'Rebost Màgic',
            selected: 'seleccionats',
            search_placeholder: 'Què necessites? (ex: Tomàquet)',
            category_all: '🌍 Tot',
            empty_search: 'No hem trobat res... prova amb una altra categoria.',
            basket_title: 'La teva cistella:',
            basket_empty: 'Encara buida...',
            unit_select: 'ut' // Opcional si vols traduir unitats
        },
        form: {
            title: 'Nova Recepta',
            label_title: 'Títol',
            placeholder_title: 'Ex: Truita de patates',
            label_ingredients: 'Ingredients (separats per comes)',
            placeholder_ingredients: 'Ous, Patates, Oli, Sal',
            label_steps: 'Passos (un per línia)',
            placeholder_steps: 'Tallar patates\nFregir\nBatre els ous',
            submit_btn: 'Publicar Recepta',
            success: 'Recepta publicada!',
            error_generic: 'Error en publicar'
        },
        card: {
            view_sr: 'Veure',
            prep_time: 'm',
            created_by_you: 'Creat per tu',
            created_by_community: 'Comunitat'
        },
        editor: {
            btn_publish: 'PUBLICAR RECEPTA',
            btn_cooking: 'CUINANT...'
        },
        toasts: {
            missing_name: 'Ei! Com es diu aquesta meravella? 🤔',
            missing_ingredients: 'La màgia necessita ingredients! 🥕',
            missing_steps: 'Explica’ns el secret (els passos)! 📜',
            success_title: '✨ Recepta publicada!',
            success_desc: 'Ja està disponible per a la comunitat.',
            error_title: 'Ups! Alguna cosa ha fallat'
        },
        meta: {
            placeholder_name: 'Posa-li un nom èpic...',
            minutes_label: 'minuts',
            tags_title: 'Etiquetes',
            tags: {
                vegan: 'Vegà',
                vegetarian: 'Vegetarià',
                gluten_free: 'Sense gluten',
                dairy_free: 'Sense lactosa',
                quick: 'Ràpid',
                healthy: 'Saludable',
                dessert: 'Postres'
            }
        },
        errors: {
            title_missing: "Falta el Títol",
            title_missing_desc: "Posa-li un nom a la teva obra mestra abans de guardar 👨‍🍳",
            ingredients_missing: "Falten Ingredients",
            ingredients_missing_desc: "No es pot cuinar sense menjar! Afegeix almenys un ingredient.",
            steps_missing: "Falten els Passos",
            steps_missing_desc: "Explica'ns com es fa la recepta, pas a pas.",
            missing_prefix: "Falten"
        }
    },
    onboarding: {
        buttons: {
            next: "Següent",
            back: "Enrere",
            finish: "Entesos! 🚀",
            skip: "Saltar tour"
        },
        // Aquí posarem els textos específics de l'editor
        editor: {
            step1_title: "1. Bateja la teva creació",
            step1_desc: "Tot comença amb un bon nom. Escriu alguna cosa que faci venir gana!",
            step2_title: "2. El Temps és Or",
            step2_desc: "Quan trigarem? Sigues realista, no volem que se'ns cremi l'arròs.",
            step3_title: "3. Etiqueta-ho",
            step3_desc: "És Vegà? Sense Gluten? Picant? Ajuda a la gent a filtrar.",
            step4_title: "4. A la Cistella!",
            step4_desc: "Busca ingredients (ex: 'Ceba') i afegeix quantitats. Fes servir el teu inventari!",
            step5_title: "5. Gestió d'Ingredients",
            step5_desc: "Aquí veuràs la llista. Si t'equivoques, clica la icona per esborrar-los.",
            step6_title: "6. La Màgia (Pas a Pas)",
            step6_desc: "Explica com es fa. Sigues clar i concís.",
            step7_title: "7. Superpoder: Inserció Ràpida",
            step7_desc: "Clica aquests ingredients per afegir-los al text amb la seva icona. Queda súper pro!",
            step8_title: "8. Publicar",
            step8_desc: "Revisa-ho tot i prem el botó màgic per guardar."
        },
        dashboard: {
            step1_title: "Benvingut a la Cuina! 🏠",
            step1_desc: "Aquest és el teu centre de comandament. Des d'aquí pots gestionar-ho tot.",
            step2_title: "Preferències (Sidebar)",
            step2_desc: "Aquí veus què t'agrada i què no. Important per quan la IA et recomani receptes!",
            step3_title: "Accions Ràpides",
            step3_desc: "Accés directe a les sales recents o accions suggerides per a tu.",
            step4_title: "Navegació Principal",
            step4_desc: "El menú principal. Totes les eines que necessites estan aquí.",
            step5_title: "Crea una Partida",
            step5_desc: "Vols decidir què sopar amb amics? Crea una sala i comenceu a votar!",
            step6_title: "Unir-se",
            step6_desc: "Tens un codi o QR? Entra a la sala d'un amic ràpidament.",
            step7_title: "Comunitat de Receptes",
            step7_desc: "Inspira't amb el que cuinen els altres. Copia receptes i fes-les teves!",
            step8_title: "El Rànquing",
            step8_desc: "Qui és el millor xef? Competeix per punts i medalles.",
            step9_title: "Les Teves Sales",
            step9_desc: "Accés ràpid a les partides on ja estàs jugant o has jugat.",
            step10_title: "El Teu Rebost",
            step10_desc: "Gestiona què tens a la nevera per rebre recomanacions precises.",
            step11_title: "Perfil i Configuració",
            step11_desc: "Canvia el teu avatar, nom i preferències globals aquí."
        },
        inventory: {
            step1_title: "El Teu Rebost Digital 📦",
            step1_desc: "Aquí tens tot el que has comprat. Controla què tens i on ho tens.",
            step2_title: "Filtres Ràpids",
            step2_desc: "Prem aquestes targetes per veure només el que hi ha a la Nevera, Congelador o Rebost.",
            step3_title: "Alerta de Caducitat ⚠️",
            step3_desc: "Importantíssim! Si surt un número aquí, tens productes a punt de fer-se malbé. Prioritza'ls!",
            step4_title: "Escàner Màgic 📷",
            step4_desc: "No escriguis! Fes una foto al tiquet o als productes i la IA els afegirà sola.",
            step5_title: "Afegir Manualment",
            step5_desc: "Si prefereixes fer-ho a l'antiga, prem aquí per omplir el formulari.",
            step6_title: "La Llista",
            step6_desc: "Aquí apareixeran els productes. Pots editar-los o esborrar-los clicant a sobre."
        },
        decision: {
            step1_title: "Què mengem avui? 🤔",
            step1_desc: "Aquesta és l'eina de decisió ràpida. T'ajudem a triar plat en segons.",
            step2_title: "Tria el teu Mode",
            step2_desc: "🎲 'Destí' si vols sort pura. 👨‍🍳 'Xef' si vols afinar per temps i energia.",
            step3_title: "Configura els paràmetres",
            step3_desc: "Mou els controls segons com et sentis avui. Poc temps? Poca energia? Digues-li al Xef!",
            step4_title: "Fes la Màgia ✨",
            step4_desc: "Prem el botó! (Tranquil, això és una simulació, no gastaràs res).",
            step5_title: "Els Resultats 🍽️",
            step5_desc: "Aquí tens les propostes. Clica una recepta per guardar-la i cuinar-la, o torna enrere per provar de nou."
        },
        profile: {
            step1_title: "La teva Identitat de Xef 👨‍🍳",
            step1_desc: "Tria el teu avatar i posa't un nom èpic. Així et veuran al rànquing!",
            step2_title: "Què t'agrada menjar? 😋",
            step2_desc: "Selecciona els teus ingredients i plats preferits per afinar les recomanacions.",
            step3_title: "Exclusions i Al·lèrgies 🚫",
            step3_desc: "Molt important! Marca el que no pots (o no vols) menjar.",
            step4_title: "Nivell de Tolerància ⚖️",
            step4_desc: "Ets rígid amb les normes o flexible? Això afecta com la IA suggereix receptes.",
            step5_title: "Guardar Canvis 💾",
            step5_desc: "No t'oblidis de guardar quan acabis!"
        },
        room: {
            step1_title: "Benvingut a la Sala! 👋",
            step1_desc: "Mira qui està connectat i invitar amics a la sala",
            step2_title: "Mode Màgic o Manual? ✨",
            step2_desc: "Tria 'Màgic' per deixar que la IA decideixi o 'Manual' per votar democràticament.",
            step3_title: "Pren el Control 🎮",
            step3_desc: "Afegeix opcions, vota o prem el botó vermell per generar una decisió final.",
            step4_title: "Historial de Decisions 📜",
            step4_desc: "Aquí es guardaran totes les decisions preses. Pots consultar-les o netejar la llista.",
            step_mode_title: "Votació Cega o Pública? 👁️",
            step_mode_desc: "Pots amagar les opcions dels altres per evitar que es copiïn, o fer-ho tot visible.",
            step_candidates_title: "Les Opcions 📝",
            step_candidates_desc: "Aquí apareixeran totes les propostes del grup. Si ets el Host, pots esborrar les que no t'agradin.",
            // ✅ AFEGEIX AQUESTES CLAUS NOVES QUE EL CODI DEMANA:
            step_input_title: "Proposa una opció",
            step_input_desc: "Escriu aquí la teva proposta per al grup.",
            step_action_title: "El Botó de la Veritat 🔴",
            step_action_desc: "Quan tothom hagi posat les seves opcions, prem aquest botó i la IA decidirà el guanyador!"
        },
        shopping: {
            step_welcome_title: "👋 Benvingut a la Compra Intel·ligent",
            step_welcome_desc: "Aquest assistent connecta el teu rebost amb el catàleg real del supermercat.",
            step_tabs_title: "📜 Historial i Llista",
            step_tabs_desc: "Navega entre la teva llista activa i els tiquets de compres passades.",
            step_stats_title: "💰 Control de Pressupost",
            step_stats_desc: "Mira en temps real quan et costarà tot i quant portes gastat al carret.",
            step_add_title: "🔎 Cercador de Catàleg",
            step_add_desc: "Prem aquí per buscar productes reals amb foto i preu actualitzat.",
            step_finish_title: "🏁 Finalitzar i Guardar",
            step_finish_desc: "En acabar, mourem els productes al teu inventari (calculant la caducitat) i guardarem el tiquet."
        }
    },
    errors: {
        username_empty: "El nom d'usuari és obligatori.",
        save_error: "No s'ha pogut guardar. Torna-ho a provar.",
        generic: "Ha passat un error inesperat."
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/i18n/locales/es.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "es",
    ()=>es
]);
const es = {
    common: {
        loading: 'Pensando...',
        error: 'Algo ha salido mal',
        start_over: 'Volver a empezar',
        switch_lang: 'Cambiar idioma'
    },
    dashboard: {
        nav: {
            multiplayer_badge: 'MULTIPLAYER',
            guest_badge: 'INVITADO',
            recipes: 'Comunidad Recetas',
            recipes_badge: 'Social',
            ranking: 'Ranking Usuarios',
            ranking_badge: 'Top Chefs',
            my_rooms: 'Mis Salas',
            my_rooms_badge: 'Activos',
            inventory: 'Mi Inventario',
            inventory_badge: 'Despensa',
            profile: 'Mi Perfil',
            profile_badge: 'Configuración'
        },
        rooms_card: {
            hub: 'SOCIAL HUB',
            title: 'Mis Salas',
            desc: 'Gestiona, crea o únete'
        },
        // --- NUEVAS CLAVES UI ---
        greeting: 'Hola,',
        // ----------------------
        level: 'Nivel 1: La vida fácil',
        config: 'Configuración',
        quick_decision: 'Decisión Rápida',
        create_room: 'Crear Sala',
        create_desc: 'Invita a amigos y decidid juntos',
        join_room: 'Unirse',
        join_desc: '¿Tienes un código de invitación?',
        active_rooms_title: 'Tus Salas',
        active_rooms_empty: 'No tienes ninguna sala activa.',
        continue_btn: 'Continuar'
    },
    decision: {
        title_food: '¿Qué comemos hoy? 🍽️',
        energy_label: 'Nivel de Energía',
        time_label: 'Tiempo disponible',
        button_decide: '🎲 ¡Decide por mí!',
        disclaimer: '*Sin devoluciones, el destino es definitivo.',
        // Resultado
        fate_spoken: 'El destino ha hablado',
        why: '¿Por qué?',
        roll_again: '🔄 Volver a tirar',
        // --- NUEVAS CLAVES UI NECESARIAS PARA EL COMPONENTE ---
        results: {
            fate: '🎲 Resultado',
            chef: '👨‍🍳 Propuestas',
            back: 'Volver'
        },
        mobile: {
            fast_mode: 'Modo Rápido',
            actions: 'Abrir Acciones'
        },
        selector: {
            fate: 'DESTINO',
            chef: 'CHEF'
        },
        states: {
            error_title: '¡Ups! Algo ha fallado',
            fate_title: 'Hoy cocina la suerte',
            fate_desc: 'Deja la mente en blanco. Elegiremos por ti.',
            chef_title: 'Menú Inteligente',
            chef_desc: 'Analizamos tu inventario para sugerir platos.'
        },
        actions: {
            generate_menu: 'GENERAR MENÚ',
            surprise_me: '¡SORPRÉNDEME!' // ✅ NOVA CLAU
        },
        // ----------------------------------------------------
        energy_levels: {
            low: 'Modo pereza',
            mid: 'Ni fu ni fa',
            high: '¡A comerse el mundo!'
        },
        reasons: {
            high_energy: "¡Tienes buena energía! He elegido algo de tus favoritos al azar.",
            low_energy: "Energía baja detectada. He elegido una opción fácil y reconfortante.",
            balanced: "Una opción equilibrada para el tiempo que tienes.",
            random: "El destino ha decidido completamente al azar.",
            default: "Parece una buena opción por ahora."
        }
    },
    room: {
        back_home: '← Volver al inicio',
        new_room_title: 'Nueva Sala',
        id_label: 'ID',
        copy_code: 'Copiar Código',
        code_copied: '¡Código copiado al portapapeles! 📋',
        kick_confirm: '¿Quieres expulsar a este jugador?',
        host_badge: '👑 Host',
        you_badge: 'Tú',
        user_prefix: 'User',
        mode_auto: '✨ AUTO',
        mode_manual: '📝 MANUAL',
        voting_blind: 'Votación Oculta',
        voting_public: 'Votación Pública',
        blind_desc: 'Nadie ve las opciones de los demás.',
        public_desc: 'Todo el mundo ve lo que se escribe.',
        btn_change: 'Cambiar',
        empty_options: 'Aún no hay opciones',
        input_placeholder: 'Escribe una opción...',
        add_btn: 'Añadir',
        hidden_candidate: '??????',
        magic_title: 'El Destino Manda',
        magic_desc: 'El algoritmo analizará los perfiles de comida de todos los participantes para encontrar la coincidencia matemática perfecta.',
        decide_magic: '✨ Hacer Magia y Decidir',
        decide_roll: '🎲 ¡Tirar los Dados!',
        waiting_host: 'Esperando al Anfitrión...',
        history_title: 'Historial',
        trophy_empty_title: 'Sala de Trofeos vacía',
        trophy_empty_desc: 'Aún no se ha tomado ninguna decisión.',
        wall_fame: 'Muro de la Fama',
        view_more: '✨ Ver {count} victorias más...',
        clean_room: '💣 Limpiar sala',
        clean_confirm: '¿Seguro que quieres borrar el historial?',
        err_kick: 'Error expulsando usuario',
        err_clean: 'Error limpiando historial',
        err_add: 'Error añadiendo opción',
        err_general: 'Error desconocido',
        invite_cta: "Invitar amigos",
        invite_sent: "¡Enlace enviado!",
        link_copied: "¡Enlace copiado!",
        copy_error: "Error al copiar el enlace",
        share_title: "Únete a '{name}'",
        share_text: "¡Ey! Ayúdame a decidir qué hacemos en la sala '{name}'. Entra aquí:",
        history: {
            title: "Muro de la Fama",
            empty: "Aún no hay trofeos",
            type_recipe: "Receta",
            type_algo: "Algoritmo",
            type_manual: "Manual",
            match: "Coincidencia",
            allergies: "Alergias",
            safe: "Segura",
            view_recipe: "Ver Ingredientes y Pasos",
            show_more: "Mostrar {count} decisiones más...",
            magic_match: "✨ ¡Magia! ¡Esta receta encaja con los gustos de {count} personas!",
            magic_safe: "⚠️ Opción Segura: Sin coincidencias de gustos, pero apta para todos.",
            manual_reason: "¡La suerte ha decidido! 🎲"
        }
    },
    landing: {
        phrases: [
            {
                text: "No sé, decide tú...",
                emoji: "🙄"
            },
            {
                text: "A mí me da igual, de verdad...",
                emoji: "🥱"
            },
            {
                text: "¿Dónde vamos a cenar?",
                emoji: "😫"
            },
            {
                text: "¿Otra vez pizza?",
                emoji: "🍕"
            },
            {
                text: "Elige tú que yo no quiero pensar",
                emoji: "🤯"
            }
        ],
        hero_title: 'Adiós a perder tiempo decidiendo.',
        hero_subtitle: 'Hola a quedar más y pensar menos.',
        btn_login: 'Ya tengo cuenta',
        btn_start: '🚀 EMPEZAR'
    },
    auth: {
        email_label: 'Email',
        email_placeholder: 'nombre@ejemplo.com',
        password_label: 'Contraseña',
        password_placeholder: '••••••••',
        password_min: 'Mínimo 6 caracteres',
        back: 'ATRÁS',
        login_title: '¡Hola de nuevo!',
        login_subtitle: 'Tu sala te espera.',
        forgot_password: '¿Has olvidado la contraseña?',
        login_btn: 'ENTRAR',
        no_account: '¿No tienes cuenta?',
        register_link: "Regístrate aquí",
        register_title: 'Únete al club',
        register_subtitle: 'Empieza la aventura hoy.',
        register_btn: 'CREAR CUENTA',
        has_account: '¿Ya tienes cuenta?',
        login_link: 'Entra por aquí'
    },
    create_room: {
        back_cancel: '← CANCELAR',
        hero_title: 'Nueva Aventura',
        hero_subtitle: 'Crea un espacio para decidir con tu grupo.',
        label_name: 'Nombre de la Sala',
        placeholder_name: 'ej: Cena del Viernes 🍕',
        btn_create: '🪄 CREAR SALA',
        host_info: 'Tú serás el anfitrión (Host) 👑',
        err_name_required: 'El nombre de la sala es obligatorio.',
        err_unknown: 'Error desconocido al crear la sala.'
    },
    join_room: {
        back: '← ATRÁS',
        hero_title: '¿Tienes una invitación?',
        hero_subtitle: 'Introduce el código para unirte a la fiesta.',
        label_code: 'CÓDIGO DE LA SALA (UUID)',
        placeholder_code: 'pégalo-aquí...',
        btn_join: 'ENTRAR AHORA 🍿',
        err_code_required: 'El código es obligatorio.'
    },
    profile: {
        // Identitat
        chef_name: 'Nombre de Chef',
        chef_placeholder: 'Ej: Chef Ramsay',
        chef_hint: 'Este es el nombre que verán los demás en el Ranking.',
        // Seccions
        menu_title: 'Menú Favorito',
        menu_desc: '¿Qué te gusta?',
        blacklist_title: 'Exclusiones',
        blacklist_desc: 'Prohibida la entrada',
        // Extres
        extra_label: 'Extra',
        warning_title: '¿Te has dejado algo?',
        warning_placeholder: 'Escribe y pulsa Enter',
        // Tolerància
        flexibility_title: 'Nivel de Flexibilidad',
        rigid: 'RÍGIDO',
        flexible: 'FLEXIBLE',
        // Botons
        back: '🔙',
        title: 'Tu Personaje',
        subtitle: 'Configuración del perfil',
        saved: '✅ ¡Guardado!',
        save_btn: '💾 Guardar Cambios',
        sidebar: {
            edit: 'Editar Perfil',
            likes: 'GUSTOS',
            alerts: 'ALERTA'
        },
        // --- NOVA CLAU UI ---
        no_data: 'Sin datos...',
        // --------------------
        search_food: '🍕 Buscar comida (ej: Sushi...)',
        search_allergy: '🥜 Buscar alergia (ej: Gluten...)',
        warning_text: '¿Te has dejado algo importante?',
        warning_example: 'Ej: Cilantro, Melocotón, Colorante E-120...',
        flexibility_desc: '¿Cómo de fácil es convencerte?',
        levels: {
            low: 'NO NEGOCIABLE',
            mid: 'NI FU NI FA',
            high: 'ME ADAPTO A TODO'
        },
        food: {
            cat_world_west: "🌍 Cocinas del Mundo (Europa & América)",
            cat_world_east: "🥢 Cocinas del Mundo (Asia & Oriente)",
            cat_fast: "🍔 Fast Food & Casual",
            cat_specific: "🍣 Platos Específicos y Delicatessen",
            cat_healthy: "🥗 Saludable y Ligero",
            cat_sweet: "🧁 Desayunos y Dulces",
            italian: 'Italiana',
            mediterranean: 'Mediterránea',
            spanish: 'Española',
            french: 'Francesa',
            greek: 'Griega',
            mexican: 'Mexicana',
            american: 'Americana',
            brazilian: 'Brasileña',
            peruvian: 'Peruana',
            argentinian: 'Argentina',
            german: 'Alemana',
            japanese: 'Japonesa',
            chinese: 'China',
            indian: 'India',
            thai: 'Tailandesa',
            korean: 'Coreana',
            vietnamese: 'Vietnamita',
            turkish: 'Turca',
            lebanese: 'Libanesa',
            poke: 'Hawaiana (Poke)',
            pizza: 'Pizza',
            burger: 'Hamburguesa',
            fried_chicken: 'Pollo Frito',
            kebab: 'Kebab/Dürüm',
            hotdog: 'Frankfurt/Perrito',
            tacos: 'Tacos/Burritos',
            sandwich: 'Bocadillos/Wraps',
            crepes: 'Crepes',
            empanadas: 'Empanadas',
            sushi: 'Sushi',
            ramen: 'Ramen',
            steak: 'Carne a la brasa',
            seafood_dish: 'Mariscada',
            paella: 'Paella/Arroz',
            pasta: 'Pasta',
            bbq: 'Barbacoa/Costillas',
            dimsum: 'Dim Sum/Gyozas',
            fondue: 'Fondue/Raclette',
            salad: 'Ensaladas',
            poke_bowl: 'Poke Bowl',
            soup: 'Sopas/Cremas',
            vegan_dish: 'Platos Veganos',
            smoothies: 'Smoothies/Fruta',
            grilled_fish: 'Pescado a la plancha',
            breakfast: 'Brunch',
            croissant: 'Bollería',
            ice_cream: 'Helado',
            coffee: 'Cafetería',
            bubble_tea: 'Bubble Tea',
            donuts: 'Donuts/Berlinas'
        },
        exclusions: {
            cat_allergens: "⚠️ Los 14 Alérgenos Principales (UE)",
            cat_diets: "🚫 Dietas y Estilos de Vida",
            cat_dislikes: "❌ Intolerancias y Aversiones Comunes",
            gluten: 'Gluten',
            crustaceans: 'Crustáceos',
            eggs: 'Huevos',
            fish: 'Pescado',
            peanuts: 'Cacahuetes',
            soybeans: 'Soja',
            dairy: 'Leche/Lactosa',
            nuts: 'Frutos de cáscara',
            celery: 'Apio',
            mustard: 'Mostaza',
            sesame: 'Sésamo',
            sulphites: 'Sulfitos',
            lupin: 'Altramuces',
            molluscs: 'Moluscos',
            vegan: 'Vegano (Sin animales)',
            vegetarian: 'Vegetariano',
            pescatarian: 'Pescatariano',
            halal: 'Halal',
            kosher: 'Kosher',
            keto: 'Keto (Bajo carbs)',
            paleo: 'Paleo',
            low_fodmap: 'Low FODMAP',
            onion: 'Cebolla',
            garlic: 'Ajo',
            spicy: 'Picante',
            cilantro: 'Cilantro',
            mushrooms: 'Setas/Champiñones',
            pork: 'Cerdo',
            beef: 'Ternera',
            alcohol: 'Alcohol',
            caffeine: 'Cafeína',
            sugar: 'Azúcar añadido',
            fructose: 'Fructosa',
            bell_pepper: 'Pimiento',
            coconut: 'Coco',
            cucumber: 'Pepino'
        }
    },
    food: {
        categories: {
            protein: '🥩 Proteína',
            veggie: '🥦 Verdura',
            fruit: '🍎 Fruta',
            dairy: '🥛 Lácteo',
            cereal: '🥖 Cereales',
            drink: '🥤 Bebida',
            snack: '🍪 Snack',
            spice: '🧂 Condimentos'
        },
        items: {
            // 🍎 FRUTA
            f1: 'Manzana roja',
            f2: 'Manzana verde',
            f3: 'Manzana amarilla',
            f4: 'Plátano',
            f5: 'Plátano macho',
            f6: 'Pera conferencia',
            f7: 'Pera blanquilla',
            f8: 'Naranja',
            f9: 'Mandarina',
            f10: 'Limón',
            f11: 'Lima',
            f12: 'Pomelo',
            f13: 'Fresa',
            f14: 'Arándanos',
            f15: 'Cerezas',
            f16: 'Uva blanca',
            f17: 'Uva negra',
            f18: 'Melocotón',
            f19: 'Nectarina',
            f20: 'Paraguayo',
            f21: 'Ciruela',
            f22: 'Albaricoque',
            f23: 'Kiwi verde',
            f24: 'Kiwi amarillo',
            f25: 'Piña',
            f26: 'Mango',
            f27: 'Melón',
            f28: 'Sandía',
            f29: 'Coco',
            f30: 'Membrillo',
            f31: 'Higo',
            f32: 'Dátil fresco',
            // 🥦 VERDURA
            v1: 'Zanahoria',
            v2: 'Patata',
            v3: 'Cebolla blanca',
            v4: 'Cebolla morada',
            v5: 'Ajo',
            v6: 'Tomate maduro',
            v7: 'Tomate cherry',
            v8: 'Brócoli',
            v9: 'Pepino',
            v10: 'Lechuga iceberg',
            v11: 'Lechuga romana',
            v12: 'Lechuga hoja de roble',
            v13: 'Espinacas frescas',
            v14: 'Rúcula',
            v15: 'Berenjena',
            v16: 'Pimiento verde',
            v17: 'Pimiento rojo',
            v18: 'Pimiento amarillo',
            v19: 'Calabacín',
            v20: 'Coliflor',
            v21: 'Col verde',
            v22: 'Lombarda',
            v23: 'Jengibre',
            v24: 'Nabo',
            v25: 'Remolacha',
            v26: 'Maíz',
            v27: 'Guisantes',
            v28: 'Judías verdes',
            v29: 'Champiñones',
            v30: 'Setas variadas',
            // 🥩 PROTEÍNA
            p1: 'Pollo entero',
            p2: 'Pechuga de pollo',
            p3: 'Muslos de pollo',
            p11: 'Alitas de pollo',
            p12: 'Ternera fresca',
            p13: 'Ternera picada',
            p14: 'Entrecot de ternera',
            p15: 'Solomillo de ternera',
            p16: 'Lomo de cerdo',
            p17: 'Costillas de cerdo',
            p18: 'Carne picada de cerdo',
            p19: 'Bacon',
            p20: 'Cordero (pierna)',
            p21: 'Chuletas de cordero',
            p22: 'Merluza',
            p23: 'Bacalao fresco',
            p24: 'Bacalao desalado',
            p25: 'Dorada',
            p26: 'Lubina',
            p27: 'Sardinas',
            p28: 'Caballa',
            p29: 'Salmón fresco',
            p30: 'Salmón congelado',
            p31: 'Atún fresco',
            p32: 'Gambas',
            p33: 'Calamar',
            p34: 'Mejillones',
            p35: 'Langostino',
            p36: 'Atún en conserva',
            p37: 'Sardinas en conserva',
            p38: 'Huevos',
            p39: 'Lentejas cocidas',
            p40: 'Garbanzos cocidos',
            p41: 'Tofu',
            // 🥛 LÁCTEO
            l1: 'Leche entera',
            l2: 'Leche semi',
            l3: 'Leche desnatada',
            l4: 'Leche sin lactosa',
            l5: 'Queso curado',
            l6: 'Queso semicurado',
            l7: 'Queso tierno',
            l8: 'Queso rallado',
            l9: 'Mozzarella',
            l10: 'Queso parmesano',
            l11: 'Queso fresco',
            l12: 'Queso azul',
            l13: 'Yogur natural',
            l14: 'Yogur griego',
            l15: 'Yogur de fresa',
            l16: 'Flan',
            l17: 'Natillas',
            l18: 'Mantequilla',
            l19: 'Nata para cocinar',
            l20: 'Helado',
            // 🥖 CEREALES
            c1: 'Pan blanco',
            c2: 'Pan integral',
            c3: 'Pasta espagueti',
            c4: 'Pasta macarrones',
            c5: 'Arroz blanco',
            c6: 'Barra de pan',
            c7: 'Croissant',
            c8: 'Bagel',
            c9: 'Pan de molde',
            c10: 'Pasta fusilli',
            c11: 'Pasta penne',
            c12: 'Fideos',
            c13: 'Arroz integral',
            c14: 'Arroz basmati',
            c15: 'Arroz jazmín',
            c16: 'Cuscús',
            c17: 'Quinoa',
            c18: 'Cereales de desayuno',
            c19: 'Copos de avena',
            c20: 'Muesli',
            c21: 'Harina de trigo',
            c22: 'Harina integral',
            c23: 'Harina de avena',
            c24: 'Ensaimada',
            c25: 'Bizcocho',
            c26: 'Tortillas de trigo',
            // 🥤 BEBIDA
            b1: 'Agua',
            b2: 'Café molido',
            b3: 'Té',
            b4: 'Refresco cola',
            b5: 'Refresco naranja',
            b6: 'Refresco limón',
            b7: 'Zumo de naranja',
            b8: 'Zumo de manzana',
            b9: 'Café en grano',
            b10: 'Café soluble',
            b11: 'Infusiones',
            b12: 'Bebida vegetal de avena',
            b13: 'Bebida vegetal de almendra',
            b14: 'Cerveza',
            b15: 'Vino',
            b16: 'Vino blanco',
            b17: 'Cava',
            b18: 'Vermut',
            b19: 'Tónica',
            co13: 'Caldo de pollo',
            co14: 'Caldo de pescado',
            // 🍪 SNACK
            s1: 'Galletas',
            s2: 'Chocolate negro',
            s3: 'Palomitas',
            s4: 'Almendras',
            s5: 'Chocolate con leche',
            s6: 'Chocolate blanco',
            s7: 'Caramelos',
            s8: 'Piruletas',
            s9: 'Magdalena',
            s10: 'Donut',
            s11: 'Palitos salados',
            s12: 'Pretzels',
            s13: 'Patatas fritas',
            s14: 'Nachos',
            s15: 'Avellanas',
            s16: 'Nueces',
            s17: 'Anacardos',
            s18: 'Cacahuetes',
            s19: 'Pipas de girasol',
            s20: 'Galletas saladas',
            s21: 'Crackers',
            s22: 'Barritas de cereales',
            s23: 'Miel',
            // 🧂 CONDIMENTOS
            co1: 'Aceite de oliva virgen',
            co2: 'Aceite de girasol',
            co3: 'Sal',
            co4: 'Pimienta negra',
            co5: 'Vinagre de vino',
            co6: 'Vinagre de módena',
            co7: 'Mantequilla',
            co8: 'Margarina',
            co9: 'Kétchup',
            co10: 'Mayonesa',
            co11: 'Mostaza',
            co12: 'Mermelada',
            co15: 'Tomate frito',
            // 🥖 CONGELADOS RÁPIDOS (Z)
            z1: 'Pizza congelada',
            z2: 'Patatas pre-fritas',
            z3: 'Lasaña preparada',
            z4: 'Croquetas'
        }
    },
    community: {
        title: 'Comunidad',
        title_suffix: 'Foodie',
        subtitle: 'Explora qué cocina la gente.',
        search_placeholder: 'Buscar ingredientes...',
        filters: {
            all: 'Todas',
            fast: 'Rápidas',
            veggie: 'Vegetariano',
            vegan: 'Vegano',
            gluten_free: 'Sin Gluten',
            dairy_free: 'Sin Lactosa',
            dessert: 'Postres'
        },
        empty_state: 'No se han encontrado recetas.',
        pagination: {
            page: 'Página',
            of: 'de'
        },
        steps: {
            title: 'Instrucciones',
            count_suffix: 'pasos',
            empty: 'Sin pasos detallados.'
        }
    },
    ranking: {
        top_label: 'TOP',
        title: 'Salón de la Fama',
        season: 'Temporada 1',
        aspirants: 'Aspirantes',
        empty_list: 'Aquí no hay nadie... 👻',
        you_suffix: '(Tú)',
        points_abbr: 'PTS'
    },
    inventory: {
        header: {
            title_prefix: 'Despensa',
            title_suffix: 'Digital',
            subtitle: "Control de stock y caducidades",
            items_label: 'ITEMS:'
        },
        dashboard: {
            title_all: "📦 Todo el Inventario",
            title_expiring: "⚠️ Caduca Pronto",
            filter_prefix: "📂",
            clear_filter: "✕ Limpiar",
            scan_btn: "Escanear IA",
            add_btn: "Añadir",
            close_btn: "Cerrar"
        },
        list: {
            empty_title: "👻",
            empty_text: "No se han encontrado alimentos aquí.",
            status: {
                expired: "Caducado",
                expiring: "Caduca Pronto"
            }
        },
        scanner: {
            title_suffix: "Productos",
            subtitle: "Revisa antes de guardar",
            no_items: "No quedan items.",
            back: "Volver",
            photo_btn: "Foto",
            confirm_btn: "Confirmar todo",
            saving: "Guardando...",
            error_save: "Error guardando los items."
        },
        actions: {
            add: "Añadir",
            close: "Cerrar",
            scan: "Escanear IA",
            clear: "Limpiar",
            save: "📥 Guardar en Despensa",
            saving: "Guardando..."
        },
        form: {
            add_title: "Añadir nuevo alimento",
            name_placeholder: "¿Qué añadimos a la despensa?",
            quantity_label: "Cantidad",
            product_placeholder: "Escribe 'Leche' o elige una categoría...",
            location: {
                fridge: "Nevera",
                pantry: "Despensa",
                freezer: "Congelador"
            },
            unit: {
                ut: "Ud",
                kg: "Kg",
                l: "L",
                g: "g"
            }
        },
        add_item: {
            main_btn: 'Añadir nuevo alimento',
            close_btn: 'Cerrar escáner'
        }
    },
    social: {
        title: 'Zona Social',
        actions: {
            create_badge: 'NUEVA',
            create_title: 'Crear Sala',
            join_badge: 'INVITADO',
            join_title: 'Unirme'
        },
        grid: {
            title: 'Salas Activas',
            empty: 'Ninguna sala activa aún.',
            role_admin: 'Admin',
            role_member: 'Miembro'
        }
    },
    create_recipe: {
        steps: {
            title: 'Instrucciones',
            placeholder: 'Escribe el paso aquí... (Clica los ingredientes de abajo para insertarlos)',
            quick_insert: 'Insertar rápido:',
            timer: 'Temporizador',
            add_timer: '+ ⏰ Tiempo',
            warning_ingredients: 'Añade ingredientes a la izquierda primero',
            add_btn: 'Añadir Paso ↵',
            empty_state: 'El camino al éxito empieza aquí',
            step_label: 'Paso'
        },
        ingredients: {
            title: 'Despensa Mágica',
            selected: 'seleccionados',
            search_placeholder: '¿Qué necesitas? (ej: Tomate)',
            category_all: '🌍 Todo',
            empty_search: 'No hemos encontrado nada... prueba con otra categoría.',
            basket_title: 'Tu cesta:',
            basket_empty: 'Aún vacía...',
            unit_select: 'ut' // Opcional si vols traduir unitats
        },
        form: {
            title: 'Nueva Receta',
            label_title: 'Título',
            placeholder_title: 'Ej: Tortilla de patatas',
            label_ingredients: 'Ingredientes (separados por coma)',
            placeholder_ingredients: 'Huevos, Patatas, Aceite, Sal',
            label_steps: 'Pasos (uno por línea)',
            placeholder_steps: 'Cortar patatas\nFreír\nBatir huevos',
            submit_btn: 'Publicar Receta',
            success: '¡Receta publicada!',
            error_generic: 'Error al publicar'
        },
        card: {
            view_sr: 'Ver',
            prep_time: 'm',
            created_by_you: 'Creado por ti',
            created_by_community: 'Comunidad'
        },
        editor: {
            btn_publish: 'PUBLICAR RECETA',
            btn_cooking: 'COCINANDO...'
        },
        toasts: {
            missing_name: '¡Ey! ¿Cómo se llama esta maravilla? 🤔',
            missing_ingredients: '¡La magia necesita ingredientes! 🥕',
            missing_steps: '¡Cuéntanos el secreto (los pasos)! 📜',
            success_title: '✨ ¡Receta Publicada!',
            success_desc: 'Ya está disponible para la comunidad.',
            error_title: '¡Ups! Algo ha fallado'
        },
        meta: {
            placeholder_name: 'Dale un nombre épico...',
            minutes_label: 'minutos',
            tags_title: 'Etiquetas',
            tags: {
                vegan: 'Vegano',
                vegetarian: 'Vegetariano',
                gluten_free: 'Sin Gluten',
                dairy_free: 'Sin Lactosa',
                quick: 'Rápido',
                healthy: 'Sano',
                dessert: 'Postre'
            }
        },
        errors: {
            title_missing: "Falta el título",
            title_missing_desc: "Ponle un nombre a tu obra maestra antes de guardar 👨‍🍳",
            ingredients_missing: "Faltan ingredientes",
            ingredients_missing_desc: "¡No se puede cocinar sin comida! Añade al menos un ingrediente.",
            steps_missing: "Faltan los pasos",
            steps_missing_desc: "Explícanos cómo se hace la receta, paso a paso.",
            missing_prefix: "Falta el prefijo o formato incorrecto"
        }
    },
    onboarding: {
        buttons: {
            next: "Siguiente",
            back: "Atrás",
            finish: "¡Entendido! 🚀",
            skip: "Saltar tour"
        },
        // Aquí pondremos los textos específicos del editor
        editor: {
            step1_title: "1. Bautiza tu creación",
            step1_desc: "Todo empieza con un buen nombre. ¡Escribe algo que abra el apetito!",
            step2_title: "2. El Tiempo es Oro",
            step2_desc: "¿Cuánto tardaremos? Sé realista, no queremos que se nos queme el arroz.",
            step3_title: "3. Etiquétalo",
            step3_desc: "¿Es Vegano? ¿Sin Gluten? ¿Picante? Ayuda a la gente a filtrar.",
            step4_title: "4. ¡A la Cesta!",
            step4_desc: "Busca ingredientes (ej: 'Cebolla') y añade cantidades. ¡Usa tu inventario!",
            step5_title: "5. Gestión de Ingredientes",
            step5_desc: "Aquí verás la lista. Si te equivocas, haz clic en el icono para eliminarlos.",
            step6_title: "6. La Magia (Paso a Paso)",
            step6_desc: "Explica cómo se hace. Sé claro y conciso.",
            step7_title: "7. Superpoder: Inserción Rápida",
            step7_desc: "Haz clic en estos ingredientes para añadirlos al texto con su icono. ¡Queda súper pro!",
            step8_title: "8. Publicar",
            step8_desc: "Revísalo todo y pulsa el botón mágico para guardar."
        },
        dashboard: {
            step1_title: "¡Bienvenido a la Cocina! 🏠",
            step1_desc: "Este es tu centro de mando. Desde aquí puedes gestionarlo todo.",
            step2_title: "Preferencias (Barra Lateral)",
            step2_desc: "Aquí ves lo que te gusta y lo que no. ¡Importante para cuando la IA te recomiende recetas!",
            step3_title: "Acciones Rápidas",
            step3_desc: "Acceso directo a las salas recientes o acciones sugeridas para ti.",
            step4_title: "Navegación Principal",
            step4_desc: "El menú principal. Todas las herramientas que necesitas están aquí.",
            step5_title: "Crear una Partida",
            step5_desc: "¿Quieres decidir qué cenar con amigos? ¡Crea una sala y empezad a votar!",
            step6_title: "Unirse",
            step6_desc: "¿Tienes un código o QR? Entra rápidamente en la sala de un amigo.",
            step7_title: "Comunidad de Recetas",
            step7_desc: "Inspírate con lo que cocinan los demás. ¡Copia recetas y hazlas tuyas!",
            step8_title: "El Ranking",
            step8_desc: "¿Quién es el mejor chef? Compite por puntos y medallas.",
            step9_title: "Tus Salas",
            step9_desc: "Acceso rápido a las partidas en las que ya estás jugando o has jugado.",
            step10_title: "Tu Despensa",
            step10_desc: "Gestiona lo que tienes en la nevera para recibir recomendaciones precisas.",
            step11_title: "Perfil y Configuración",
            step11_desc: "Cambia tu avatar, nombre y preferencias globales aquí."
        },
        inventory: {
            step1_title: "Tu Despensa Digital 📦",
            step1_desc: "Aquí tienes todo lo que has comprado. Controla qué tienes y dónde lo tienes.",
            step2_title: "Filtros Rápidos",
            step2_desc: "Pulsa estas tarjetas para ver solo lo que hay en la Nevera, Congelador o Despensa.",
            step3_title: "Alerta de Caducidad ⚠️",
            step3_desc: "¡Importantísimo! Si aparece un número aquí, tienes productos a punto de estropearse. ¡Priorízalos!",
            step4_title: "Escáner Mágico 📷",
            step4_desc: "¡No escribas! Haz una foto al ticket o a los productos y la IA los añadirá sola.",
            step5_title: "Añadir Manualmente",
            step5_desc: "Si prefieres hacerlo a la antigua, pulsa aquí para rellenar el formulario.",
            step6_title: "La Lista",
            step6_desc: "Aquí aparecerán los productos. Puedes editarlos o eliminarlos haciendo clic sobre ellos."
        },
        decision: {
            step1_title: "¿Qué comemos hoy? 🤔",
            step1_desc: "Esta es la herramienta de decisión rápida. Te ayudamos a elegir plato en segundos.",
            step2_title: "Elige tu Modo",
            step2_desc: "🎲 'Destino' si quieres pura suerte. 👨‍🍳 'Chef' si quieres afinar según tiempo y energía.",
            step3_title: "Configura los parámetros",
            step3_desc: "Mueve los controles según cómo te sientas hoy. ¿Poco tiempo? ¿Poca energía? ¡Díselo al Chef!",
            step4_title: "Haz la Magia ✨",
            step4_desc: "¡Pulsa el botón! (Tranquilo, es una simulación, no gastarás nada).",
            step5_title: "Los Resultados 🍽️",
            step5_desc: "Aquí tienes las propuestas. Haz clic en una receta para guardarla y cocinarla, o vuelve atrás para probar otra vez."
        },
        profile: {
            step1_title: "Tu Identidad de Chef 👨‍🍳",
            step1_desc: "Elige tu avatar y ponte un nombre épico. ¡Así te verán en el ranking!",
            step2_title: "¿Qué te gusta comer? 😋",
            step2_desc: "Selecciona tus ingredientes y platos favoritos para afinar las recomendaciones.",
            step3_title: "Exclusiones y Alergias 🚫",
            step3_desc: "¡Muy importante! Marca lo que no puedes (o no quieres) comer.",
            step4_title: "Nivel de Tolerancia ⚖️",
            step4_desc: "¿Eres rígido con las normas o flexible? Esto afecta a cómo la IA sugiere recetas.",
            step5_title: "Guardar Cambios 💾",
            step5_desc: "¡No te olvides de guardar cuando termines!"
        },
        room: {
            step1_title: "¡Bienvenido a la Sala! 👋",
            step1_desc: "Aquí puedes ver quién está conectado e invitar amigos a unirse a la sala.",
            step2_title: "¿Modo Mágico o Manual? ✨",
            step2_desc: "Elige 'Mágico' para dejar que la IA decida o 'Manual' para votar de forma democrática.",
            step3_title: "Toma el Control 🎮",
            step3_desc: "Añade opciones, vota o pulsa el botón rojo para generar una decisión final.",
            step4_title: "Historial de Decisiones 📜",
            step4_desc: "Aquí se guardarán todas las decisiones tomadas. Puedes consultarlas o limpiar la lista.",
            step_mode_title: "¿Votación Ciega o Pública? 👁️",
            step_mode_desc: "Puedes ocultar las opciones de los demás para evitar influencias o hacerlo todo visible.",
            step_candidates_title: "Las Opciones 📝",
            step_candidates_desc: "Aquí aparecerán todas las propuestas del grupo. Si eres el Host, puedes eliminar las que no te gusten.",
            step_input_title: "¡Propón Algo! 💡",
            step_input_desc: "Escribe tu idea (ej: «Pizza», «Sushi») y pulsa el botón + para añadirla a la lista.",
            step_action_title: "El Botón de la Verdad 🔴",
            step_action_desc: "Cuando todos hayan añadido sus opciones, pulsa este botón y la IA decidirá al ganador."
        },
        shopping: {
            step_welcome_title: "👋 Bienvenido a la Compra Inteligente",
            step_welcome_desc: "Este asistente conecta tu despensa con el catálogo real del supermercado.",
            step_tabs_title: "📜 Historial y Lista",
            step_tabs_desc: "Navega entre tu lista activa y los tickets de compras pasadas.",
            step_stats_title: "💰 Control de Presupuesto",
            step_stats_desc: "Mira en tiempo real cuánto te costará todo y cuánto llevas gastado en el carro.",
            step_add_title: "🔎 Buscador de Catálogo",
            step_add_desc: "Pulsa aquí para buscar productos reales con foto y precio actualizado.",
            step_finish_title: "🏁 Finalizar y Guardar",
            step_finish_desc: "Al terminar, moveremos los productos a tu inventario (calculando caducidad) y guardaremos el ticket."
        }
    },
    errors: {
        username_empty: "El nombre de usuario es obligatorio.",
        save_error: "No se pudo guardar. Inténtalo de nuevo.",
        generic: "Ocurrió un error inesperado."
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/i18n/locales/en.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "en",
    ()=>en
]);
const en = {
    common: {
        loading: 'Thinking...',
        error: 'Something went wrong',
        start_over: 'Start over',
        switch_lang: 'Change language'
    },
    dashboard: {
        nav: {
            multiplayer_badge: 'MULTIPLAYER',
            guest_badge: 'GUEST',
            recipes: 'Recipe Community',
            recipes_badge: 'Social',
            ranking: 'User Ranking',
            ranking_badge: 'Top Chefs',
            my_rooms: 'My Rooms',
            my_rooms_badge: 'Active',
            inventory: 'My Inventory',
            inventory_badge: 'Pantry',
            profile: 'My Profile',
            profile_badge: 'Settings'
        },
        rooms_card: {
            hub: 'SOCIAL HUB',
            title: 'My Rooms',
            desc: 'Manage, create or join'
        },
        greeting: 'Hello,',
        level: 'Level 1: Easy Living',
        config: 'Settings',
        quick_decision: 'Quick Decision',
        create_room: 'Create Room',
        create_desc: 'Invite friends and decide together',
        join_room: 'Join',
        join_desc: 'Got an invite code?',
        active_rooms_title: 'Your Rooms',
        active_rooms_empty: 'No active rooms.',
        continue_btn: 'Continue'
    },
    decision: {
        title_food: 'What are we eating? 🍽️',
        energy_label: 'Energy Level',
        time_label: 'Available Time',
        button_decide: '🎲 Decide for me!',
        disclaimer: '*No refunds, fate is final.',
        // Result
        fate_spoken: 'Fate has spoken',
        why: 'Why?',
        roll_again: '🔄 Roll again',
        // UI Keys
        results: {
            fate: '🎲 Result',
            chef: '👨‍🍳 Proposals',
            back: 'Back'
        },
        mobile: {
            fast_mode: 'Quick Mode',
            actions: 'Open Actions'
        },
        selector: {
            fate: 'FATE',
            chef: 'CHEF'
        },
        states: {
            error_title: 'Oops! Something went wrong',
            fate_title: 'Luck is cooking today',
            fate_desc: 'Empty your mind. We\'ll choose for you.',
            chef_title: 'Smart Menu',
            chef_desc: 'Scanning inventory to suggest dishes.'
        },
        actions: {
            generate_menu: 'GENERATE MENU',
            surprise_me: 'SURPRISE ME!' // ✅ NOVA CLAU
        },
        energy_levels: {
            low: 'Lazy Mode',
            mid: 'Meh / So-so',
            high: 'Conquer the World!'
        },
        reasons: {
            high_energy: "You've got good vibes! I picked something from your random favorites.",
            low_energy: "Low energy detected. I chose something easy and comforting.",
            balanced: "A balanced option for the time you have.",
            random: "Fate has decided completely at random.",
            default: "Seems like a good option for now."
        }
    },
    room: {
        back_home: '← Back to home',
        new_room_title: 'New Room',
        id_label: 'ID',
        copy_code: 'Copy Code',
        code_copied: 'Code copied to clipboard! 📋',
        kick_confirm: 'Do you want to kick this player?',
        host_badge: '👑 Host',
        you_badge: 'You',
        user_prefix: 'User',
        mode_auto: '✨ AUTO',
        mode_manual: '📝 MANUAL',
        voting_blind: 'Blind Voting',
        voting_public: 'Public Voting',
        blind_desc: 'No one sees others\' choices.',
        public_desc: 'Everyone sees what is typed.',
        btn_change: 'Change',
        empty_options: 'No options yet',
        input_placeholder: 'Type an option...',
        add_btn: 'Add',
        hidden_candidate: '??????',
        magic_title: 'Fate Rules',
        magic_desc: 'The algorithm will analyze everyone\'s food profiles to find the perfect mathematical match.',
        decide_magic: '✨ Do Magic & Decide',
        decide_roll: '🎲 Roll the Dice!',
        waiting_host: 'Waiting for Host...',
        history_title: 'History',
        trophy_empty_title: 'Trophy Room Empty',
        trophy_empty_desc: 'No decisions made yet.',
        wall_fame: 'Wall of Fame',
        view_more: '✨ View {count} more victories...',
        clean_room: '💣 Clear room',
        clean_confirm: 'Are you sure you want to clear history?',
        err_kick: 'Error kicking user',
        err_clean: 'Error clearing history',
        err_add: 'Error adding option',
        err_general: 'Unknown error',
        invite_cta: "Invite Friends",
        invite_sent: "Link sent!",
        link_copied: "Link copied!",
        copy_error: "Error copying link",
        share_title: "Join '{name}'",
        share_text: "Hey! Help me decide in room '{name}'. Join here:",
        history: {
            title: "Wall of Fame",
            empty: "There are no trophies yet",
            type_recipe: "Recipe",
            type_algo: "Algorithm",
            type_manual: "Manual",
            match: "Match",
            allergies: "Allergies",
            safe: "Safe",
            view_recipe: "View Ingredients and Steps",
            show_more: "Show {count} more decisions...",
            magic_match: "✨ Magic! This recipe matches the tastes of {count} people!",
            magic_safe: "⚠️ Safe Bet: No taste matches, but it's safe for everyone.",
            manual_reason: "Luck has decided! 🎲"
        }
    },
    landing: {
        phrases: [
            {
                text: "I don't know, you decide...",
                emoji: "🙄"
            },
            {
                text: "I really don't care...",
                emoji: "🥱"
            },
            {
                text: "Where are we having dinner?",
                emoji: "😫"
            },
            {
                text: "Pizza again?",
                emoji: "🍕"
            },
            {
                text: "You choose, I don't want to think",
                emoji: "🤯"
            }
        ],
        hero_title: 'Stop wasting time deciding.',
        hero_subtitle: 'Hello to hanging out more and thinking less.',
        btn_login: 'I have an account',
        btn_start: '🚀 GET STARTED'
    },
    auth: {
        email_label: 'Email',
        email_placeholder: 'name@example.com',
        password_label: 'Password',
        password_placeholder: '••••••••',
        password_min: 'Min 6 characters',
        back: 'BACK',
        login_title: 'Welcome back!',
        login_subtitle: 'Your room awaits.',
        forgot_password: 'Forgot password?',
        login_btn: 'LOG IN',
        no_account: 'No account?',
        register_link: "Sign up here",
        register_title: 'Join the club',
        register_subtitle: 'Start the adventure today.',
        register_btn: 'CREATE ACCOUNT',
        has_account: 'Already have an account?',
        login_link: 'Log in here'
    },
    create_room: {
        back_cancel: '← CANCEL',
        hero_title: 'New Adventure',
        hero_subtitle: 'Create a space to decide with your group.',
        label_name: 'Room Name',
        placeholder_name: 'ex: Friday Dinner 🍕',
        btn_create: '🪄 CREATE ROOM',
        host_info: 'You will be the Host 👑',
        err_name_required: 'Room name is required.',
        err_unknown: 'Unknown error creating room.'
    },
    join_room: {
        back: '← BACK',
        hero_title: 'Got an invite?',
        hero_subtitle: 'Enter the code to join the party.',
        label_code: 'ROOM CODE (UUID)',
        placeholder_code: 'paste-it-here...',
        btn_join: 'JOIN NOW 🍿',
        err_code_required: 'Code is required.'
    },
    profile: {
        // Identitat
        chef_name: 'Chef Name',
        chef_placeholder: 'Ex: Chef Ramsay',
        chef_hint: 'This is the name others will see on the Leaderboard.',
        // Seccions
        menu_title: 'Favorite Menu',
        menu_desc: 'What do you like?',
        blacklist_title: 'Exclusions',
        blacklist_desc: 'Strictly prohibited',
        // Extres
        extra_label: 'Extra',
        warning_title: 'Did you forget something?',
        warning_placeholder: 'Type and press Enter',
        // Tolerància
        flexibility_title: 'Flexibility Level',
        rigid: 'RIGID',
        flexible: 'FLEXIBLE',
        // Botons
        back: '🔙',
        title: 'Your Character',
        subtitle: 'Profile settings',
        saved: '✅ Saved!',
        save_btn: '💾 Save Changes',
        sidebar: {
            edit: 'Edit Profile',
            likes: 'LIKES',
            alerts: 'ALERTS'
        },
        // --- NOVA CLAU UI ---
        no_data: 'No data...',
        // --------------------
        search_food: '🍕 Search food (ex: Sushi...)',
        search_allergy: '🥜 Search allergy (ex: Gluten...)',
        warning_text: 'Did you miss anything important?',
        warning_example: 'Ex: Cilantro, Peach, Dye E-120...',
        flexibility_desc: 'How easy are you to convince?',
        levels: {
            low: 'NON-NEGOTIABLE',
            mid: 'MEH / WHATEVER',
            high: 'UP FOR ANYTHING'
        },
        food: {
            cat_world_west: "🌍 World Cuisines (Europe & Americas)",
            cat_world_east: "🥢 World Cuisines (Asia & East)",
            cat_fast: "🍔 Fast Food & Casual",
            cat_specific: "🍣 Specific Dishes & Deli",
            cat_healthy: "🥗 Healthy & Light",
            cat_sweet: "🧁 Breakfast & Sweets",
            italian: 'Italian',
            mediterranean: 'Mediterranean',
            spanish: 'Spanish',
            french: 'French',
            greek: 'Greek',
            mexican: 'Mexican',
            american: 'American',
            brazilian: 'Brazilian',
            peruvian: 'Peruvian',
            argentinian: 'Argentinian',
            german: 'German',
            japanese: 'Japanese',
            chinese: 'Chinese',
            indian: 'Indian',
            thai: 'Thai',
            korean: 'Korean',
            vietnamese: 'Vietnamese',
            turkish: 'Turkish',
            lebanese: 'Lebanese',
            poke: 'Hawaiian (Poke)',
            pizza: 'Pizza',
            burger: 'Burger',
            fried_chicken: 'Fried Chicken',
            kebab: 'Kebab/Shawarma',
            hotdog: 'Hot Dog',
            tacos: 'Tacos/Burritos',
            sandwich: 'Sandwiches/Wraps',
            crepes: 'Crepes',
            empanadas: 'Empanadas/Pies',
            sushi: 'Sushi',
            ramen: 'Ramen',
            steak: 'Steak / Grilled Meat',
            seafood_dish: 'Seafood Platter',
            paella: 'Paella/Rice Dish',
            pasta: 'Pasta',
            bbq: 'BBQ / Ribs',
            dimsum: 'Dim Sum / Gyozas',
            fondue: 'Fondue / Raclette',
            salad: 'Salads',
            poke_bowl: 'Poke Bowl',
            soup: 'Soups/Creams',
            vegan_dish: 'Vegan Dishes',
            smoothies: 'Smoothies/Fruit',
            grilled_fish: 'Grilled Fish',
            breakfast: 'Brunch',
            croissant: 'Pastries',
            ice_cream: 'Ice Cream',
            coffee: 'Coffee Shop',
            bubble_tea: 'Bubble Tea',
            donuts: 'Donuts'
        },
        exclusions: {
            cat_allergens: "⚠️ The 14 Major Allergens (EU)",
            cat_diets: "🚫 Diets & Lifestyles",
            cat_dislikes: "❌ Common Intolerances & Dislikes",
            gluten: 'Gluten',
            crustaceans: 'Crustaceans',
            eggs: 'Eggs',
            fish: 'Fish',
            peanuts: 'Peanuts',
            soybeans: 'Soy',
            dairy: 'Milk/Lactose',
            nuts: 'Tree Nuts',
            celery: 'Celery',
            mustard: 'Mustard',
            sesame: 'Sesame',
            sulphites: 'Sulphites',
            lupin: 'Lupin',
            molluscs: 'Molluscs',
            vegan: 'Vegan (No animals)',
            vegetarian: 'Vegetarian',
            pescatarian: 'Pescatarians',
            halal: 'Halal',
            kosher: 'Kosher',
            keto: 'Keto (Low carb)',
            paleo: 'Paleo',
            low_fodmap: 'Low FODMAP',
            onion: 'Onion',
            garlic: 'Garlic',
            spicy: 'Spicy',
            cilantro: 'Cilantro',
            mushrooms: 'Mushrooms',
            pork: 'Pork',
            beef: 'Beef',
            alcohol: 'Alcohol',
            caffeine: 'Caffeine',
            sugar: 'Added Sugar',
            fructose: 'Fructose',
            bell_pepper: 'Bell Pepper',
            coconut: 'Coconut',
            cucumber: 'Cucumber'
        }
    },
    // ✅ FOOD PRESETS TRANSLATION
    food: {
        categories: {
            protein: '🥩 Protein',
            veggie: '🥦 Veggie',
            fruit: '🍎 Fruit',
            dairy: '🥛 Dairy',
            cereal: '🥖 Cereals',
            drink: '🥤 Drink',
            snack: '🍪 Snack',
            spice: '🧂 Condiments'
        },
        items: {
            // 🍎 FRUIT
            f1: 'Red apple',
            f2: 'Green apple',
            f3: 'Yellow apple',
            f4: 'Banana',
            f5: 'Plantain',
            f6: 'Conference pear',
            f7: 'White pear',
            f8: 'Orange',
            f9: 'Tangerine',
            f10: 'Lemon',
            f11: 'Lime',
            f12: 'Grapefruit',
            f13: 'Strawberry',
            f14: 'Blueberry',
            f15: 'Cherry',
            f16: 'White grape',
            f17: 'Red grape',
            f18: 'Peach',
            f19: 'Nectarine',
            f20: 'Flat peach',
            f21: 'Plum',
            f22: 'Apricot',
            f23: 'Green kiwi',
            f24: 'Yellow kiwi',
            f25: 'Pineapple',
            f26: 'Mango',
            f27: 'Melon',
            f28: 'Watermelon',
            f29: 'Coconut',
            f30: 'Quince',
            f31: 'Fig',
            f32: 'Fresh date',
            // 🥦 VEGGIE
            v1: 'Carrot',
            v2: 'Potato',
            v3: 'White onion',
            v4: 'Red onion',
            v5: 'Garlic',
            v6: 'Ripe tomato',
            v7: 'Cherry tomato',
            v8: 'Broccoli',
            v9: 'Cucumber',
            v10: 'Iceberg lettuce',
            v11: 'Romaine lettuce',
            v12: 'Oak leaf lettuce',
            v13: 'Fresh spinach',
            v14: 'Arugula',
            v15: 'Eggplant',
            v16: 'Green pepper',
            v17: 'Red pepper',
            v18: 'Yellow pepper',
            v19: 'Zucchini',
            v20: 'Cauliflower',
            v21: 'Kale/Cabbage',
            v22: 'Red cabbage',
            v23: 'Ginger',
            v24: 'Turnip',
            v25: 'Beetroot',
            v26: 'Corn',
            v27: 'Peas',
            v28: 'Green beans',
            v29: 'Mushrooms',
            v30: 'Mixed mushrooms',
            // 🥩 PROTEIN
            p1: 'Whole chicken',
            p2: 'Chicken breast',
            p3: 'Chicken thighs',
            p11: 'Chicken wings',
            p12: 'Fresh beef',
            p13: 'Minced beef',
            p14: 'Beef steak',
            p15: 'Beef fillet',
            p16: 'Pork loin',
            p17: 'Pork ribs',
            p18: 'Minced pork',
            p19: 'Bacon',
            p20: 'Lamb (leg)',
            p21: 'Lamb chops',
            p22: 'Hake',
            p23: 'Fresh cod',
            p24: 'Desalted cod',
            p25: 'Sea bream',
            p26: 'Sea bass',
            p27: 'Sardines',
            p28: 'Mackerel',
            p29: 'Fresh salmon',
            p30: 'Frozen salmon',
            p31: 'Fresh tuna',
            p32: 'Prawns',
            p33: 'Squid',
            p34: 'Mussels',
            p35: 'Langoustine',
            p36: 'Canned tuna',
            p37: 'Canned sardines',
            p38: 'Eggs',
            p39: 'Cooked lentils',
            p40: 'Cooked chickpeas',
            p41: 'Tofu',
            // 🥛 DAIRY
            l1: 'Whole milk',
            l2: 'Semi-skimmed milk',
            l3: 'Skimmed milk',
            l4: 'Lactose-free milk',
            l5: 'Cured cheese',
            l6: 'Semi-cured cheese',
            l7: 'Soft cheese',
            l8: 'Grated cheese',
            l9: 'Mozzarella',
            l10: 'Parmesan cheese',
            l11: 'Fresh cheese',
            l12: 'Blue cheese',
            l13: 'Natural yogurt',
            l14: 'Greek yogurt',
            l15: 'Strawberry yogurt',
            l16: 'Flan/Pudding',
            l17: 'Custard',
            l18: 'Butter',
            l19: 'Cooking cream',
            l20: 'Ice cream',
            // 🥖 CEREALS
            c1: 'White bread',
            c2: 'Whole wheat bread',
            c3: 'Spaghetti',
            c4: 'Macaroni',
            c5: 'White rice',
            c6: 'Baguette',
            c7: 'Croissant',
            c8: 'Bagel',
            c9: 'Sliced bread',
            c10: 'Fusilli',
            c11: 'Penne pasta',
            c12: 'Noodles',
            c13: 'Brown rice',
            c14: 'Basmati rice',
            c15: 'Jasmine rice',
            c16: 'Couscous',
            c17: 'Quinoa',
            c18: 'Breakfast cereal',
            c19: 'Oat flakes',
            c20: 'Muesli',
            c21: 'Wheat flour',
            c22: 'Whole wheat flour',
            c23: 'Oat flour',
            c24: 'Ensaïmada',
            c25: 'Sponge cake',
            c26: 'Wheat tortillas',
            // 🥤 DRINK
            b1: 'Water',
            b2: 'Ground coffee',
            b3: 'Tea',
            b4: 'Cola soda',
            b5: 'Orange soda',
            b6: 'Lemon soda',
            b7: 'Orange juice',
            b8: 'Apple juice',
            b9: 'Coffee beans',
            b10: 'Instant coffee',
            b11: 'Herbal tea',
            b12: 'Oat milk',
            b13: 'Almond milk',
            b14: 'Beer',
            b15: 'Wine',
            b16: 'White wine',
            b17: 'Cava/Champagne',
            b18: 'Vermouth',
            b19: 'Tonic water',
            co13: 'Chicken broth',
            co14: 'Fish broth',
            // 🍪 SNACK
            s1: 'Cookies',
            s2: 'Dark chocolate',
            s3: 'Popcorn',
            s4: 'Almonds',
            s5: 'Milk chocolate',
            s6: 'White chocolate',
            s7: 'Candies',
            s8: 'Lollipops',
            s9: 'Muffin',
            s10: 'Donut',
            s11: 'Breadsticks',
            s12: 'Pretzels',
            s13: 'Potato chips',
            s14: 'Nachos',
            s15: 'Hazelnuts',
            s16: 'Walnuts',
            s17: 'Cashews',
            s18: 'Peanuts',
            s19: 'Sunflower seeds',
            s20: 'Salted crackers',
            s21: 'Crackers',
            s22: 'Cereal bars',
            s23: 'Honey',
            // 🧂 CONDIMENTS
            co1: 'Virgin olive oil',
            co2: 'Sunflower oil',
            co3: 'Salt',
            co4: 'Black pepper',
            co5: 'Wine vinegar',
            co6: 'Balsamic vinegar',
            co7: 'Butter',
            co8: 'Margarine',
            co9: 'Ketchup',
            co10: 'Mayonnaise',
            co11: 'Mustard',
            co12: 'Jam/Marmalade',
            co15: 'Fried tomato sauce',
            // 🥖 QUICK FROZEN (Z)
            z1: 'Frozen pizza',
            z2: 'Frozen fries',
            z3: 'Ready lasagna',
            z4: 'Croquettes'
        }
    },
    community: {
        title: 'Community',
        title_suffix: 'Foodie',
        subtitle: 'Explore what people are cooking.',
        search_placeholder: 'Search ingredients...',
        filters: {
            all: 'All',
            fast: 'Fast',
            veggie: 'Veggie',
            vegan: 'Vegan',
            gluten_free: 'Gluten Free',
            dairy_free: 'Dairy Free',
            dessert: 'Dessert'
        },
        empty_state: 'No recipes found.',
        pagination: {
            page: 'Page',
            of: 'of'
        },
        steps: {
            title: 'Instructions',
            count_suffix: 'steps',
            empty: 'No detailed steps.'
        }
    },
    ranking: {
        top_label: 'TOP',
        title: 'Hall of Fame',
        season: 'Season 1',
        aspirants: 'Contenders',
        empty_list: 'Nobody here yet... 👻',
        you_suffix: '(You)',
        points_abbr: 'PTS'
    },
    inventory: {
        header: {
            title_prefix: 'Digital',
            title_suffix: 'Pantry',
            subtitle: "Stock and expiration control",
            items_label: 'ITEMS:'
        },
        dashboard: {
            title_all: "📦 All Inventory",
            title_expiring: "⚠️ Expiring Soon",
            filter_prefix: "📂",
            clear_filter: "✕ Clear",
            scan_btn: "AI Scan",
            add_btn: "Add",
            close_btn: "Close"
        },
        list: {
            empty_title: "👻",
            empty_text: "No items found here.",
            status: {
                expired: "Expired",
                expiring: "Expiring Soon"
            }
        },
        scanner: {
            title_suffix: "Products",
            subtitle: "Review before saving",
            no_items: "No items left.",
            back: "Back",
            photo_btn: "Photo",
            confirm_btn: "Confirm all",
            saving: "Saving...",
            error_save: "Error saving items."
        },
        actions: {
            add: "Add",
            close: "Close",
            scan: "AI Scan",
            clear: "Clear",
            save: "📥 Save to Pantry",
            saving: "Saving..."
        },
        form: {
            add_title: "Add new item",
            name_placeholder: "What are we adding?",
            quantity_label: "Quantity",
            product_placeholder: "Type 'Milk' or choose a category...",
            location: {
                fridge: "Fridge",
                pantry: "Pantry",
                freezer: "Freezer"
            },
            unit: {
                ut: "Unit",
                kg: "Kg",
                l: "L",
                g: "g"
            }
        },
        add_item: {
            main_btn: 'Add new item',
            close_btn: 'Close scanner'
        }
    },
    social: {
        title: 'Social Zone',
        actions: {
            create_badge: 'NEW',
            create_title: 'Create Room',
            join_badge: 'GUEST',
            join_title: 'Join'
        },
        grid: {
            title: 'Active Rooms',
            empty: 'No active rooms yet.',
            role_admin: 'Admin',
            role_member: 'Member'
        }
    },
    create_recipe: {
        steps: {
            title: 'Instructions',
            placeholder: 'Write step here... (Click ingredients below to insert)',
            quick_insert: 'Quick insert:',
            timer: 'Timer',
            add_timer: '+ ⏰ Time',
            warning_ingredients: 'Add ingredients on the left first',
            add_btn: 'Add Step ↵',
            empty_state: 'The road to success starts here',
            step_label: 'Step'
        },
        ingredients: {
            title: 'Magic Pantry',
            selected: 'selected',
            search_placeholder: 'What do you need? (ex: Tomato)',
            category_all: '🌍 All',
            empty_search: 'Nothing found... try another category.',
            basket_title: 'Your basket:',
            basket_empty: 'Still empty...',
            unit_select: 'ut'
        },
        form: {
            title: 'New Recipe',
            label_title: 'Title',
            placeholder_title: 'Ex: Spanish Omelette',
            label_ingredients: 'Ingredients (comma separated)',
            placeholder_ingredients: 'Eggs, Potatoes, Oil, Salt',
            label_steps: 'Steps (one per line)',
            placeholder_steps: 'Cut potatoes\nFry\nWhisk eggs',
            submit_btn: 'Publish Recipe',
            success: 'Recipe published!',
            error_generic: 'Error publishing'
        },
        card: {
            view_sr: 'View',
            prep_time: 'm',
            created_by_you: 'Created by you',
            created_by_community: 'Community'
        },
        editor: {
            btn_publish: 'PUBLISH RECIPE',
            btn_cooking: 'COOKING...'
        },
        toasts: {
            missing_name: 'Hey! What is this masterpiece called? 🤔',
            missing_ingredients: 'Magic needs ingredients! 🥕',
            missing_steps: 'Tell us the secret (the steps)! 📜',
            success_title: '✨ Recipe Published!',
            success_desc: 'Now available to the community.',
            error_title: 'Oops! Something went wrong'
        },
        meta: {
            placeholder_name: 'Give it an epic name...',
            minutes_label: 'minutes',
            tags_title: 'Tags',
            tags: {
                vegan: 'Vegan',
                vegetarian: 'Vegetarian',
                gluten_free: 'Gluten Free',
                dairy_free: 'Dairy Free',
                quick: 'Quick',
                healthy: 'Healthy',
                dessert: 'Dessert'
            }
        },
        errors: {
            title_missing: "Title missing",
            title_missing_desc: "Give your masterpiece a name before saving 👨‍🍳",
            ingredients_missing: "Ingredients missing",
            ingredients_missing_desc: "You can't cook without food! Add at least one ingredient.",
            steps_missing: "Steps missing",
            steps_missing_desc: "Tell us how to make the recipe, step by step.",
            missing_prefix: "Missing prefix or incorrect format"
        }
    },
    onboarding: {
        buttons: {
            next: "Next",
            back: "Back",
            finish: "Got it! 🚀",
            skip: "Skip tour"
        },
        // Here we will place the editor-specific texts
        editor: {
            step1_title: "1. Name Your Creation",
            step1_desc: "Everything starts with a good name. Write something that makes people hungry!",
            step2_title: "2. Time Is Gold",
            step2_desc: "How long will it take? Be realistic—we don't want to burn the rice.",
            step3_title: "3. Tag It",
            step3_desc: "Is it Vegan? Gluten-Free? Spicy? Help people filter it.",
            step4_title: "4. Into the Basket!",
            step4_desc: "Search for ingredients (e.g. 'Onion') and add quantities. Use your inventory!",
            step5_title: "5. Ingredient Management",
            step5_desc: "Here you'll see the list. If you make a mistake, click the icon to remove them.",
            step6_title: "6. The Magic (Step by Step)",
            step6_desc: "Explain how it's made. Be clear and concise.",
            step7_title: "7. Superpower: Quick Insert",
            step7_desc: "Click these ingredients to add them to the text with their icon. It looks super pro!",
            step8_title: "8. Publish",
            step8_desc: "Review everything and press the magic button to save."
        },
        dashboard: {
            step1_title: "Welcome to the Kitchen! 🏠",
            step1_desc: "This is your command center. From here you can manage everything.",
            step2_title: "Preferences (Sidebar)",
            step2_desc: "Here you can see what you like and dislike. Important for when the AI recommends recipes!",
            step3_title: "Quick Actions",
            step3_desc: "Direct access to recent rooms or actions suggested for you.",
            step4_title: "Main Navigation",
            step4_desc: "The main menu. All the tools you need are here.",
            step5_title: "Create a Session",
            step5_desc: "Want to decide what to have for dinner with friends? Create a room and start voting!",
            step6_title: "Join",
            step6_desc: "Got a code or QR? Quickly join a friend's room.",
            step7_title: "Recipe Community",
            step7_desc: "Get inspired by what others are cooking. Copy recipes and make them your own!",
            step8_title: "The Ranking",
            step8_desc: "Who is the best chef? Compete for points and medals.",
            step9_title: "Your Rooms",
            step9_desc: "Quick access to the sessions you're currently playing or have played.",
            step10_title: "Your Pantry",
            step10_desc: "Manage what you have in your fridge to get accurate recommendations.",
            step11_title: "Profile & Settings",
            step11_desc: "Change your avatar, name, and global preferences here."
        },
        inventory: {
            step1_title: "Your Digital Pantry 📦",
            step1_desc: "Here you’ll find everything you’ve bought. Keep track of what you have and where it is.",
            step2_title: "Quick Filters",
            step2_desc: "Tap these cards to see only what’s in the Fridge, Freezer or Pantry.",
            step3_title: "Expiration Alert ⚠️",
            step3_desc: "Very important! If a number appears here, some products are about to expire. Prioritize them!",
            step4_title: "Magic Scanner 📷",
            step4_desc: "No typing! Take a photo of the receipt or the products and the AI will add them automatically.",
            step5_title: "Add Manually",
            step5_desc: "If you prefer the old-school way, tap here to fill out the form.",
            step6_title: "The List",
            step6_desc: "Your products will appear here. You can edit or delete them by clicking on them."
        },
        decision: {
            step1_title: "What are we eating today? 🤔",
            step1_desc: "This is the quick decision tool. We help you choose a dish in seconds.",
            step2_title: "Choose Your Mode",
            step2_desc: "🎲 'Fate' if you want pure luck. 👨‍🍳 'Chef' if you want to fine-tune by time and energy.",
            step3_title: "Set the Parameters",
            step3_desc: "Adjust the controls based on how you feel today. Short on time? Low energy? Tell the Chef!",
            step4_title: "Work the Magic ✨",
            step4_desc: "Press the button! (Relax, it’s just a simulation — nothing will be used up).",
            step5_title: "The Results 🍽️",
            step5_desc: "Here are your suggestions. Click a recipe to save it and cook it, or go back and try again."
        },
        profile: {
            step1_title: "Your Chef Identity 👨‍🍳",
            step1_desc: "Choose your avatar and give yourself an epic name. That’s how you’ll appear in the ranking!",
            step2_title: "What do you like to eat? 😋",
            step2_desc: "Select your favorite ingredients and dishes to fine-tune the recommendations.",
            step3_title: "Exclusions & Allergies 🚫",
            step3_desc: "Very important! Mark what you can’t (or don’t want to) eat.",
            step4_title: "Tolerance Level ⚖️",
            step4_desc: "Are you strict or flexible? This affects how the AI suggests recipes.",
            step5_title: "Save Changes 💾",
            step5_desc: "Don’t forget to save when you’re done!"
        },
        room: {
            step1_title: "Welcome to the Room! 👋",
            step1_desc: "Here you can see who’s connected and invite friends to join the room.",
            step2_title: "Magic or Manual Mode? ✨",
            step2_desc: "Choose 'Magic' to let the AI decide or 'Manual' to vote democratically.",
            step3_title: "Take Control 🎮",
            step3_desc: "Add options, vote, or press the red button to generate a final decision.",
            step4_title: "Decision History 📜",
            step4_desc: "All decisions made will be saved here. You can review them or clear the list.",
            step_mode_title: "Blind or Public Voting? 👁️",
            step_mode_desc: "Hide other people’s options to avoid influence, or make everything visible.",
            step_candidates_title: "The Options 📝",
            step_candidates_desc: "All group proposals will appear here. If you’re the Host, you can remove the ones you don’t like.",
            step_input_title: "Suggest Something! 💡",
            step_input_desc: "Write your idea (e.g. “Pizza”, “Sushi”) and press the + button to add it to the list.",
            step_action_title: "The Button of Truth 🔴",
            step_action_desc: "Once everyone has added their options, press this button and the AI will choose the winner!"
        },
        shopping: {
            step_welcome_title: "👋 Welcome to Smart Shopping",
            step_welcome_desc: "This assistant connects your pantry with the real supermarket catalog.",
            step_tabs_title: "📜 History & List",
            step_tabs_desc: "Switch between your active list and past receipts.",
            step_stats_title: "💰 Budget Control",
            step_stats_desc: "See in real-time the total cost and what's currently in your cart.",
            step_add_title: "🔎 Catalog Search",
            step_add_desc: "Click here to search for real products with photos and updated prices.",
            step_finish_title: "🏁 Finish & Save",
            step_finish_desc: "When done, we'll move items to inventory (calculating expiry) and save the receipt."
        }
    },
    errors: {
        username_empty: "Username is required.",
        save_error: "Could not save. Please try again.",
        generic: "An unexpected error occurred."
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/i18n/dictionaries.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "dictionaries",
    ()=>dictionaries
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$locales$2f$ca$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/locales/ca.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$locales$2f$es$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/locales/es.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$locales$2f$en$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/locales/en.ts [app-client] (ecmascript)");
;
;
;
const dictionaries = {
    ca: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$locales$2f$ca$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ca"],
    es: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$locales$2f$es$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["es"],
    en: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$locales$2f$en$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["en"]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LanguageProvider",
    ()=>LanguageProvider,
    "useLanguage",
    ()=>useLanguage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$dictionaries$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/dictionaries.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
const LanguageContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function LanguageProvider({ children }) {
    _s();
    // Per defecte català, però aquí podries llegir localStorage o cookies
    const [locale, setLocale] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('ca');
    const changeLanguage = (lang)=>{
        setLocale(lang);
    // Opcional: Guardar a localStorage aquí
    // localStorage.setItem('lang', lang); 
    };
    const value = {
        locale,
        t: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$dictionaries$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dictionaries"][locale],
        changeLanguage
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LanguageContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/lib/i18n/LanguageContext.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
_s(LanguageProvider, "os5YqdpuXmYAoeBj6CsTxNCOqZM=");
_c = LanguageProvider;
function useLanguage() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(LanguageContext);
    if (!context) {
        throw new Error('useLanguage must be used within a LanguageProvider');
    }
    return context;
}
_s1(useLanguage, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "LanguageProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/core/domain/entities/Recipe.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Recipe",
    ()=>Recipe
]);
class Recipe {
    props;
    constructor(props){
        this.props = props;
        // 🔥 Validem SEMPRE en crear
        this.validate();
    }
    // Getters
    get id() {
        return this.props.id;
    }
    get name() {
        return this.props.name;
    }
    get ingredients() {
        return this.props.ingredients;
    }
    get authorId() {
        return this.props.authorId;
    }
    get steps() {
        return this.props.steps;
    }
    get tags() {
        return this.props.tags;
    }
    get dietaryTags() {
        return this.props.dietaryTags;
    }
    get prepTimeMinutes() {
        return this.props.prepTimeMinutes;
    }
    get estimatedCost() {
        return this.props.estimatedCost;
    }
    get isAiGenerated() {
        return this.props.isAiGenerated;
    }
    get isFavorite() {
        return this.props.isFavorite ?? false;
    }
    get ratingSummary() {
        return this.props.ratingSummary;
    }
    get isPublic() {
        return this.props.isPublic;
    }
    // 🔥 GETTERS QUE FALTAVEN I QUE EL MAPPER NECESSITA
    get createdAt() {
        return this.props.createdAt;
    }
    get likesCount() {
        return this.props.likesCount;
    }
    get authorName() {
        return this.props.authorName;
    }
    isSafeFor(restrictions) {
        if (!restrictions || restrictions.length === 0) return true;
        const normalizedRestrictions = restrictions.map((r)=>r.toLowerCase());
        const tags = (this.props.dietaryTags || []).map((t)=>t.toLowerCase());
        return normalizedRestrictions.every((restriction)=>{
            if (tags.includes(`${restriction}-free`)) return true;
            if (tags.includes(`sense ${restriction}`)) return true;
            if (tags.includes(`sense-${restriction}`)) return true;
            return true;
        });
    }
    toPrimitives() {
        return {
            ...this.props,
            // Assegurem la còpia profunda i correcta dels ingredients
            ingredients: this.props.ingredients.map((i)=>({
                    id: i.id,
                    name: i.name,
                    quantity: i.quantity,
                    unit: i.unit,
                    emoji: i.emoji,
                    linkedProductId: i.linkedProductId || null,
                    linkedProductImage: i.linkedProductImage || null,
                    estimatedCost: i.estimatedCost || 0
                }))
        };
    }
    validate() {
        // 1. Validar Nom
        if (!this.props.name || this.props.name.trim().length < 3) {
            throw new Error("El nom ha de tenir almenys 3 caràcters");
        }
        // 2. Validar Ingredients
        if (!this.props.ingredients || this.props.ingredients.length === 0) {
            throw new Error("La recepta ha de tenir almenys un ingredient");
        }
        // 3. Validar consistència d'ingredients
        this.props.ingredients.forEach((ing, index)=>{
            if (!ing.name || ing.name.trim() === '') {
                throw new Error(`L'ingredient a la posició ${index} no té nom`);
            }
            if (ing.quantity <= 0) {
                throw new Error(`L'ingredient "${ing.name}" ha de tenir una quantitat positiva`);
            }
        });
        // 🔥 4. NOVA VALIDACIÓ: Passos obligatoris
        // Això és el que farà passar el test que et falla
        if (!this.props.steps || this.props.steps.length === 0) {
            throw new Error("La recepta ha de tenir almenys un pas d'instruccions");
        }
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:6fdb57 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "generateMenuAction",
    ()=>$$RSC_SERVER_ACTION_2
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"7ea95fa32ddcdb1d2217f337bcbb96d7b39c79d662":"generateMenuAction"},"app/actions/recipe-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("7ea95fa32ddcdb1d2217f337bcbb96d7b39c79d662", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "generateMenuAction");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vcmVjaXBlLWFjdGlvbnMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQVJYSVU6IGFwcC9hY3Rpb25zL3JlY2lwZS1hY3Rpb25zLnRzXHJcbid1c2Ugc2VydmVyJ1xyXG5cclxuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSAnQC9hZGFwdGVycy9zdXBhYmFzZS9zZXJ2ZXInO1xyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gJ25leHQvY2FjaGUnO1xyXG4vLyDinIUgRklYOiBJbXBvcnRlbSBlbCByZXBvc2l0b3JpIHF1ZSBmYWx0YXZhXHJcbmltcG9ydCB7IFN1cGFiYXNlUmVjaXBlUmVwb3NpdG9yeSB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2UvU3VwYWJhc2VSZWNpcGVSZXBvc2l0b3J5JztcclxuaW1wb3J0IHsgY29udGFpbmVyIH0gZnJvbSAnQC9zZXJ2aWNlcy9jb250YWluZXInO1xyXG5pbXBvcnQgeyBFbW9qaU1hdGNoZXJTZXJ2aWNlIH0gZnJvbSAnQC9jb3JlL2FwcGxpY2F0aW9uL3NlcnZpY2VzL0Vtb2ppTWF0Y2hlclNlcnZpY2UnOyAvLyDinIUgSW1wb3J0ZW0gZWwgTWF0Y2hlclxyXG5pbXBvcnQgeyBHZW5lcmF0ZVJlY2lwZVNjaGVtYSwgTWF0ZXJpYWxpemVSZWNpcGVTY2hlbWEgfSBmcm9tICdAL2NvcmUvYXBwbGljYXRpb24vc2NoZW1hcy9pbnB1dFNjaGVtYXMnO1xyXG5pbXBvcnQgeyBTdXBhYmFzZVJhdGVMaW1pdGVyIH0gZnJvbSAnQC9hZGFwdGVycy9zdXBhYmFzZS9TdXBhYmFzZVJhdGVMaW1pdGVyJztcclxuaW1wb3J0IHsgU3VwYWJhc2VTZWN1cml0eUxvZ2dlciB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2UvU3VwYWJhc2VTZWN1cml0eUxvZ2dlcic7XHJcbmltcG9ydCB7IGRlYnVnLCBlcnJvciBhcyBsb2dFcnJvciB9IGZyb20gJ0AvbGliL2xvZ2dlcic7XHJcblxyXG4vLyDinIUgRklYOiBEZWZpbmljacOzIHJvYnVzdGEgZGUgbGEgcmVzcG9zdGFcclxuZXhwb3J0IHR5cGUgQWN0aW9uUmVzcG9uc2UgPSB7XHJcbiAgICBzdWNjZXNzOiBib29sZWFuO1xyXG4gICAgcmVjaXBlSWQ/OiBzdHJpbmc7XHJcbiAgICBlcnJvcj86IHN0cmluZzsgLy8gSW1wb3J0YW50IHF1ZSBzaWd1aSBvcGNpb25hbCAoPylcclxufTtcclxuXHJcbi8vIFRpcHVzIHVuaWZpY2F0IHF1ZSBjb2JyZWl4aSBlbCBxdWUgdmUgZGUgbCdFZGl0b3IgaSBlbCBxdWUgdmUgZGUgbGEgSUFcclxuZXhwb3J0IGludGVyZmFjZSBTYXZlUmVjaXBlSW5wdXQge1xyXG4gIGlkPzogc3RyaW5nO1xyXG4gIG5hbWU6IHN0cmluZztcclxuICBwcmVwVGltZU1pbnV0ZXM6IG51bWJlciB8IHN0cmluZztcclxuICBcclxuICBpbmdyZWRpZW50czoge1xyXG4gICAgaWQ/OiBzdHJpbmc7XHJcbiAgICBuYW1lOiBzdHJpbmc7XHJcbiAgICBxdWFudGl0eTogbnVtYmVyO1xyXG4gICAgdW5pdDogc3RyaW5nO1xyXG4gICAgZW1vamk/OiBzdHJpbmc7XHJcbiAgICBlc3RpbWF0ZWRDb3N0PzogbnVtYmVyIHwgc3RyaW5nO1xyXG4gICAgbGlua2VkUHJvZHVjdElkPzogc3RyaW5nIHwgbnVsbDtcclxuICAgIGxpbmtlZFByb2R1Y3RJbWFnZT86IHN0cmluZyB8IG51bGw7XHJcbiAgfVtdO1xyXG4gIHN0ZXBzOiAoc3RyaW5nIHwgeyBpZDogc3RyaW5nOyBjb250ZW50OiBzdHJpbmcgfSlbXTtcclxuICB0YWdzPzogc3RyaW5nW107XHJcbiAgZGlldGFyeVRhZ3M/OiBzdHJpbmdbXTtcclxuICBpc0FpR2VuZXJhdGVkPzogYm9vbGVhbjtcclxufVxyXG5cclxuLy8gLS0tIEFDQ0nDkyBQUklOQ0lQQUw6IFNBVkUgLS0tXHJcbi8vIEFxdWVzdGEgY29udMOpIHRvdGEgbGEgbMOyZ2ljYSBcImludGVswrdsaWdlbnRcIiAocHJldXMsIGltYXRnZXMsIGVtb2ppcy4uLilcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNhdmVSZWNpcGVBY3Rpb24oZGF0YTogU2F2ZVJlY2lwZUlucHV0KTogUHJvbWlzZTxBY3Rpb25SZXNwb25zZT4ge1xyXG4gIGRlYnVnKCdbU0FWRSBBQ1RJT05dIHNhdmVSZWNpcGVBY3Rpb24nKTtcclxuXHJcbiAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICBpZiAoIXVzZXIpIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9O1xyXG5cclxuICB0cnkge1xyXG4gICAgbGV0IGF1dGhvck5hbWUgPSBcIlhlZiBBbsOybmltXCI7XHJcbiAgICBjb25zdCB7IGRhdGE6IHByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3ByZWZlcmVuY2VfcHJvZmlsZXMnKS5zZWxlY3QoJ3VzZXJuYW1lJykuZXEoJ3VzZXJfaWQnLCB1c2VyLmlkKS5zaW5nbGUoKTtcclxuICAgIGlmIChwcm9maWxlPy51c2VybmFtZSkgYXV0aG9yTmFtZSA9IHByb2ZpbGUudXNlcm5hbWU7XHJcblxyXG4gICAgLy8gMS4gQ8OgbGN1bCBkZSBjb3N0IHRvdGFsIChST0JVU1QpXHJcbiAgICBjb25zdCB0b3RhbENvc3QgPSBkYXRhLmluZ3JlZGllbnRzLnJlZHVjZSgoYWNjLCBpbmcpID0+IHtcclxuICAgICAgbGV0IGNvc3RWYWwgPSBpbmcuZXN0aW1hdGVkQ29zdDtcclxuICAgICAgaWYgKHR5cGVvZiBjb3N0VmFsID09PSAnc3RyaW5nJykgY29zdFZhbCA9IHBhcnNlRmxvYXQoY29zdFZhbCk7XHJcbiAgICAgIGNvbnN0IGNvc3QgPSBOdW1iZXIoY29zdFZhbCkgfHwgMDtcclxuICAgICAgcmV0dXJuIGFjYyArIGNvc3Q7XHJcbiAgICB9LCAwKTtcclxuXHJcbiAgICBsZXQgaXNBaUdlbmVyYXRlZCA9ICEhZGF0YS5pc0FpR2VuZXJhdGVkO1xyXG4gICAgaWYgKCFpc0FpR2VuZXJhdGVkICYmIGRhdGEuaWQpIHtcclxuICAgICAgY29uc3QgeyBkYXRhOiBvbGRSZWNpcGUgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3NhdmVkX3JlY2lwZXMnKS5zZWxlY3QoJ2lzX2FpX2dlbmVyYXRlZCcpLmVxKCdpZCcsIGRhdGEuaWQpLnNpbmdsZSgpO1xyXG4gICAgICBpZiAob2xkUmVjaXBlKSBpc0FpR2VuZXJhdGVkID0gb2xkUmVjaXBlLmlzX2FpX2dlbmVyYXRlZDtcclxuICAgIH1cclxuXHJcbiAgICAvLyAyLiBQUk9DRVNTQVIgSU5HUkVESUVOVFMgKyBJTUFUR0VTXHJcbiAgICBjb25zdCBpbmdyZWRpZW50c1BheWxvYWQgPSBhd2FpdCBQcm9taXNlLmFsbChkYXRhLmluZ3JlZGllbnRzLm1hcChhc3luYyAoaW5nKSA9PiB7XHJcbiAgICAgIGxldCBmaW5hbElkID0gaW5nLmlkO1xyXG4gICAgICBsZXQgZmluYWxFbW9qaSA9IGluZy5lbW9qaTtcclxuICAgICAgY29uc3QgZmluYWxOYW1lID0gaW5nLm5hbWU7XHJcbiAgICAgIGNvbnN0IGxpbmtlZFByb2R1Y3RJZCA9IGluZy5saW5rZWRQcm9kdWN0SWQ7XHJcbiAgICAgIGxldCBsaW5rZWRQcm9kdWN0SW1hZ2UgPSBpbmcubGlua2VkUHJvZHVjdEltYWdlO1xyXG4gICAgICBjb25zdCBlc3RpbWF0ZWRDb3N0ID0gaW5nLmVzdGltYXRlZENvc3QgPyBOdW1iZXIoaW5nLmVzdGltYXRlZENvc3QpIDogMDtcclxuXHJcbiAgICAgIGNvbnN0IGhhc0xpbmsgPSB0eXBlb2YgbGlua2VkUHJvZHVjdElkID09PSAnc3RyaW5nJyAmJiBsaW5rZWRQcm9kdWN0SWQubGVuZ3RoID4gMDtcclxuXHJcbiAgICAgIGlmIChoYXNMaW5rKSB7XHJcbiAgICAgICAgLy8gLi4uIChMw7JnaWNhIGRlIHJlY3VwZXJhY2nDsyBkJ2ltYXRnZXMgaWd1YWwgcXVlIHRlbmllcykgLi4uXHJcbiAgICAgICAgaWYgKCFsaW5rZWRQcm9kdWN0SW1hZ2UpIHtcclxuICAgICAgICAgIGNvbnN0IHsgZGF0YTogcHJvZHVjdCB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgncHJvZHVjdF9jYXRhbG9nJykuc2VsZWN0KCdpbWFnZV91cmwnKS5lcSgnaWQnLCBsaW5rZWRQcm9kdWN0SWQpLnNpbmdsZSgpO1xyXG4gICAgICAgICAgaWYgKHByb2R1Y3Q/LmltYWdlX3VybCkgbGlua2VkUHJvZHVjdEltYWdlID0gcHJvZHVjdC5pbWFnZV91cmw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghZmluYWxJZCB8fCBmaW5hbElkLmxlbmd0aCA8IDUpIGZpbmFsSWQgPSBsaW5rZWRQcm9kdWN0SWQhO1xyXG4gICAgICAgIGlmICghZmluYWxFbW9qaSB8fCBmaW5hbEVtb2ppID09PSAn8J+lmCcpIGZpbmFsRW1vamkgPSAn8J+Tpic7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gTWF0Y2hlciBkJ2Vtb2ppc1xyXG4gICAgICAgIGNvbnN0IGNsZWFuTmFtZSA9IGZpbmFsTmFtZS5yZXBsYWNlKC9cXGIoQk9OUFJFVXxQQVRDSEVGfC4uLilcXGIvZ2ksIFwiXCIpLnRyaW0oKTtcclxuICAgICAgICBjb25zdCBwcmVzZXQgPSBFbW9qaU1hdGNoZXJTZXJ2aWNlLm1hdGNoKGNsZWFuTmFtZSk7XHJcbiAgICAgICAgaWYgKHByZXNldCkge1xyXG4gICAgICAgICAgZmluYWxJZCA9IHByZXNldC5pZDtcclxuICAgICAgICAgIGZpbmFsRW1vamkgPSBwcmVzZXQuZW1vamk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGlmICghZmluYWxFbW9qaSkgZmluYWxFbW9qaSA9ICfwn6WYJztcclxuICAgICAgICAgIGlmICghZmluYWxJZCkgZmluYWxJZCA9IGNyeXB0by5yYW5kb21VVUlEKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIGlkOiBmaW5hbElkLFxyXG4gICAgICAgIG5hbWU6IGZpbmFsTmFtZSxcclxuICAgICAgICBxdWFudGl0eTogaW5nLnF1YW50aXR5LFxyXG4gICAgICAgIHVuaXQ6IGluZy51bml0LFxyXG4gICAgICAgIGVtb2ppOiBmaW5hbEVtb2ppLFxyXG4gICAgICAgIGxpbmtlZFByb2R1Y3RJZDogaGFzTGluayA/IGxpbmtlZFByb2R1Y3RJZCA6IG51bGwsXHJcbiAgICAgICAgbGlua2VkUHJvZHVjdEltYWdlOiBoYXNMaW5rID8gbGlua2VkUHJvZHVjdEltYWdlIDogbnVsbCxcclxuICAgICAgICBlc3RpbWF0ZWRDb3N0XHJcbiAgICAgIH07XHJcbiAgICB9KSk7XHJcblxyXG4gICAgLy8gMy4gUFJPQ0VTU0FSIFBBU1NPU1xyXG4gICAgY29uc3Qgc3RlcHNEYXRhID0gZGF0YS5zdGVwcy5tYXAocyA9PiB7XHJcbiAgICAgIGlmICh0eXBlb2YgcyA9PT0gJ3N0cmluZycpIHJldHVybiB7IGlkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLCBjb250ZW50OiBzIH07XHJcbiAgICAgIHJldHVybiB7IGlkOiBzLmlkIHx8IGNyeXB0by5yYW5kb21VVUlEKCksIGNvbnRlbnQ6IHMuY29udGVudCB8fCBcIlwiIH07XHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyA0LiBQQVlMT0FEIEJEXHJcbiAgICBjb25zdCByZWNpcGVQYXlsb2FkID0ge1xyXG4gICAgICB1c2VyX2lkOiB1c2VyLmlkLFxyXG4gICAgICBuYW1lOiBkYXRhLm5hbWUsXHJcbiAgICAgIGF1dGhvcl9uYW1lOiBhdXRob3JOYW1lLFxyXG4gICAgICBwcmVwX3RpbWVfbWludXRlczogTnVtYmVyKGRhdGEucHJlcFRpbWVNaW51dGVzKSB8fCAwLFxyXG4gICAgICBpbmdyZWRpZW50czogaW5ncmVkaWVudHNQYXlsb2FkLFxyXG4gICAgICBzdGVwczogc3RlcHNEYXRhLFxyXG4gICAgICB0YWdzOiBkYXRhLnRhZ3MgfHwgW10sXHJcbiAgICAgIGRpZXRhcnlfdGFnczogZGF0YS5kaWV0YXJ5VGFncyB8fCBbXSxcclxuICAgICAgZXN0aW1hdGVkX2Nvc3Q6IHRvdGFsQ29zdCxcclxuICAgICAgaXNfcHVibGljOiBmYWxzZSwgLy8gUGVyIGRlZmVjdGUgcHJpdmFkYSBxdWFuIGVzIGd1YXJkYVxyXG4gICAgICBpc19haV9nZW5lcmF0ZWQ6IGlzQWlHZW5lcmF0ZWQsXHJcbiAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCB0YWJsZSA9IHN1cGFiYXNlLmZyb20oJ3NhdmVkX3JlY2lwZXMnKTtcclxuICAgIGxldCByZXN1bHRJZDogc3RyaW5nO1xyXG5cclxuICAgIGlmIChkYXRhLmlkKSB7XHJcbiAgICAgIC8vIC4uLiBMw7JnaWNhIGQnVXBkYXRlIGV4aXN0ZW50IC4uLlxyXG4gICAgICAvLyAoU2ltcGxpZmljYWRhIGFxdcOtIHBlciBicmV2ZXRhdCwgY29waWEgbGEgdGV2YSBsw7JnaWNhIGQndXBkYXRlKVxyXG4gICAgICBjb25zdCB7IGRhdGE6IHVwZGF0ZWQsIGVycm9yIH0gPSBhd2FpdCB0YWJsZS51cHNlcnQoeyAuLi5yZWNpcGVQYXlsb2FkLCBpZDogZGF0YS5pZCB9KS5zZWxlY3QoJ2lkJykuc2luZ2xlKCk7XHJcbiAgICAgIGlmIChlcnJvcikgdGhyb3cgZXJyb3I7XHJcbiAgICAgIHJlc3VsdElkID0gdXBkYXRlZC5pZDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnN0IHsgZGF0YTogaW5zZXJ0ZWQsIGVycm9yIH0gPSBhd2FpdCB0YWJsZS5pbnNlcnQocmVjaXBlUGF5bG9hZCkuc2VsZWN0KCdpZCcpLnNpbmdsZSgpO1xyXG4gICAgICBpZiAoZXJyb3IpIHRocm93IGVycm9yO1xyXG4gICAgICByZXN1bHRJZCA9IGluc2VydGVkLmlkO1xyXG4gICAgfVxyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvcmVjaXBlcycpO1xyXG4gICAgaWYgKHJlc3VsdElkKSByZXZhbGlkYXRlUGF0aChgL3JlY2lwZXMvJHtyZXN1bHRJZH1gKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIHJlY2lwZUlkOiByZXN1bHRJZCB9O1xyXG5cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ3NhdmVSZWNpcGVBY3Rpb24gZmFpbGVkJywgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkVycm9yIGludGVybi5cIiB9O1xyXG4gIH1cclxufVxyXG4vLyBBY2Npw7MgcGVyIEZhdm9yaXRzIChOZWNlc3NpdGEgZWwgUmVwb3NpdG9yaSlcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHRvZ2dsZUZhdm9yaXRlQWN0aW9uKHJlY2lwZUlkOiBzdHJpbmcpIHtcclxuICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0gfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpO1xyXG5cclxuICBpZiAoIXVzZXIpIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9O1xyXG5cclxuICAvLyBBcmEgc8OtIHF1ZSB0ZW5pbSBsJ2ltcG9ydCBhIGRhbHRcclxuICBjb25zdCByZXBvID0gbmV3IFN1cGFiYXNlUmVjaXBlUmVwb3NpdG9yeSgpO1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgaXNGYXYgPSBhd2FpdCByZXBvLnRvZ2dsZUZhdm9yaXRlKHVzZXIuaWQsIHJlY2lwZUlkKTtcclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL3JlY2lwZXMnKTtcclxuICAgIHJldmFsaWRhdGVQYXRoKGAvcmVjaXBlcy8ke3JlY2lwZUlkfWApO1xyXG5cclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGlzRmF2b3JpdGU6IGlzRmF2IH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGxvZ0Vycm9yKCdFcnJvciB1cGRhdGluZyBmYXZvcml0ZScsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciB1cGRhdGluZyBmYXZvcml0ZVwiIH07XHJcbiAgfVxyXG5cclxuXHJcbn1cclxuLy8g4pyFIEFxdWVzdGEgYWNjacOzIHN1YnN0aXR1ZWl4IGxhIGzDsmdpY2EgY29tcGxleGEgcXVlIHRlbmllcyBhYmFucy5cclxuLy8gQXJhIGZhIHNlcnZpciBsJ2VzdHJhdMOoZ2lhIEjDrWJyaWRhIChCRCArIElBKSBxdWUgaGVtIGRlZmluaXQgYWwgU2VydmljZS5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlTWVudUFjdGlvbihcclxuICB1c2VySWQ6IHN0cmluZyxcclxuICBkaXNoTmFtZTogc3RyaW5nLFxyXG4gIG1vZGU6ICdGQVRFJyB8ICdDSEVGJyxcclxuICBlbmVyZ3k6IG51bWJlciA9IDUwLFxyXG4gIHRpbWU6IG51bWJlciA9IDMwLFxyXG4gIGxhbmc6IHN0cmluZyA9ICdjYSdcclxuKSB7XHJcbiAgZGVidWcoJ1tBQ1RJT05dIGdlbmVyYXRlTWVudUFjdGlvbicpO1xyXG5cclxuICAvLyAxLiBWQUxJREFDScOTIChab2QpXHJcbiAgY29uc3QgdmFsaWRhdGlvbiA9IEdlbmVyYXRlUmVjaXBlU2NoZW1hLnNhZmVQYXJzZSh7IHVzZXJJZCwgZGlzaE5hbWUsIGxhbmcgfSk7XHJcbiAgaWYgKCF2YWxpZGF0aW9uLnN1Y2Nlc3MpIHtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogdmFsaWRhdGlvbi5lcnJvci5pc3N1ZXNbMF0ubWVzc2FnZSB9O1xyXG4gIH1cclxuXHJcbiAgLy8gMi4gU0VHVVJFVEFUIChSYXRlIExpbWl0KVxyXG4gIGNvbnN0IGxpbWl0ZXIgPSBuZXcgU3VwYWJhc2VSYXRlTGltaXRlcigpO1xyXG4gIGNvbnN0IGxvZ2dlciA9IG5ldyBTdXBhYmFzZVNlY3VyaXR5TG9nZ2VyKCk7XHJcblxyXG4gIGNvbnN0IGNhblByb2NlZWQgPSBhd2FpdCBsaW1pdGVyLmNoZWNrKGBnZW46JHt1c2VySWR9YCwgMjAsIDM2MDApOyAvLyA1IGNvcHMvaG9yYVxyXG4gIGlmICghY2FuUHJvY2VlZCkge1xyXG4gICAgYXdhaXQgbG9nZ2VyLmxvZygnV0FSTicsICdSQVRFX0xJTUlUJywgdXNlcklkLCB7IGFjdGlvbjogJ2dlbmVyYXRlX21lbnUnIH0pO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkzDrW1pdCBzdXBlcmF0LiBFc3BlcmEgdW5hIGVzdG9uYS5cIiB9O1xyXG4gIH1cclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCBzZXJ2aWNlID0gY29udGFpbmVyLmdldEdlbmVyYXRlTWVudVNlcnZpY2Uoc3VwYWJhc2UpO1xyXG5cclxuICAgIC8vIEVYRUNVVEVNIEVMIFNFUlZFSSAoTCdPcmNoZXN0cmF0b3IgZGVjaWRlaXggaW50ZXJuYW1lbnQpXHJcbiAgICBjb25zdCByZWNpcGVzID0gYXdhaXQgc2VydmljZS5leGVjdXRlKFxyXG4gICAgICB1c2VySWQsXHJcbiAgICAgIG1vZGUsXHJcbiAgICAgIGRpc2hOYW1lLFxyXG4gICAgICBlbmVyZ3ksXHJcbiAgICAgIHRpbWUsXHJcbiAgICAgIGxhbmdcclxuICAgICk7XHJcblxyXG4gICAgLy8gQ09OVkVSU0nDkyBBIFBSSU1JVElWRVNcclxuICAgIC8vIDEuIENvbnZlcnRpbSBhIHByaW1pdGl2ZXMgKGFpeMOyIGphIGhvIGZhcylcclxuICAgIGNvbnN0IHBsYWluUmVjaXBlcyA9IHJlY2lwZXMubWFwKHIgPT4gci50b1ByaW1pdGl2ZXMoKSk7XHJcblxyXG4gICAgLy8gMi4g4pqg77iPIEFTU0VHVVJBJ1QgUVVFIGVzdGltYXRlZENvc3QgRVhJU1RFSVggQVFVw40g4pqg77iPXHJcbiAgICAvLyBTaSBwbGFpblJlY2lwZXNbMF0uZXN0aW1hdGVkQ29zdCDDqXMgdW5kZWZpbmVkLCBKU09OLnN0cmluZ2lmeSBsJ2VzYm9ycmFyw6AhXHJcbiAgICBpZiAocGxhaW5SZWNpcGVzLmxlbmd0aCA+IDAgJiYgcGxhaW5SZWNpcGVzWzBdLmVzdGltYXRlZENvc3QgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICBsb2dFcnJvcihcIuKaoO+4jyBBTEVSVEE6IGVzdGltYXRlZENvc3Qgw6lzIHVuZGVmaW5lZCBhYmFucyBkJ2VudmlhciBhbCBjbGllbnQhXCIpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIDMuIFNhbml0aXR6YWNpw7NcclxuICAgIGNvbnN0IGNsZWFuUmVjaXBlcyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkocGxhaW5SZWNpcGVzKSk7XHJcblxyXG4gICAgZGVidWcoJ1tBQ1RJT05dIGdlbmVyYXRlTWVudUFjdGlvbiBkb25lJyk7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogdHJ1ZSxcclxuICAgICAgcmVjaXBlczogY2xlYW5SZWNpcGVzXHJcbiAgICB9O1xyXG5cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ+KdjCBbQUNUSU9OIEVSUk9SXTonLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRXJyb3IgZ2VuZXJhbnQgZWwgbWVuw7ouXCIgfTtcclxuICB9XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1hdGVyaWFsaXplUmVjaXBlQWN0aW9uKHJhd0FpUmVjaXBlOiB1bmtub3duKTogUHJvbWlzZTxBY3Rpb25SZXNwb25zZT4ge1xyXG4gIGNvbnN0IHBhcnNlZCA9IE1hdGVyaWFsaXplUmVjaXBlU2NoZW1hLnNhZmVQYXJzZShyYXdBaVJlY2lwZSk7XHJcbiAgaWYgKCFwYXJzZWQuc3VjY2Vzcykge1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBwYXJzZWQuZXJyb3IuaXNzdWVzWzBdLm1lc3NhZ2UgfTtcclxuICB9XHJcblxyXG4gIGNvbnN0IHJlY2lwZURhdGEgPSBwYXJzZWQuZGF0YTtcclxuICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG5cclxuICAvLyDwn5SNIDEuIFBBUyBERSBERURVUExJQ0FDScOTOiBCdXNxdWVtIHNpIGphIGV4aXN0ZWl4XHJcbiAgdHJ5IHtcclxuICAgICAgY29uc3QgeyBkYXRhOiBleGlzdGluZyB9ID0gYXdhaXQgc3VwYWJhc2VcclxuICAgICAgICAgIC5mcm9tKCdzYXZlZF9yZWNpcGVzJylcclxuICAgICAgICAgIC5zZWxlY3QoJ2lkJylcclxuICAgICAgICAgIC5lcSgnbmFtZScsIHJlY2lwZURhdGEubmFtZSkgLy8gTWF0ZWl4IG5vbVxyXG4gICAgICAgICAgLmVxKCdpc19haV9nZW5lcmF0ZWQnLCB0cnVlKSAvLyBRdWUgc2lndWkgZGUgbGEgSUFcclxuICAgICAgICAgIC5lcSgnaXNfcHVibGljJywgdHJ1ZSkgLy8gUXVlIHNpZ3VpIGNvbXBhcnRpZGFcclxuICAgICAgICAgIC5saW1pdCgxKVxyXG4gICAgICAgICAgLnNpbmdsZSgpO1xyXG5cclxuICAgICAgaWYgKGV4aXN0aW5nKSB7XHJcbiAgICAgICAgICBkZWJ1ZygnW0FDVElPTl0gZGVkdXBsaWNhdGUgaGl0Jyk7XHJcbiAgICAgICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCByZWNpcGVJZDogZXhpc3RpbmcuaWQgfTtcclxuICAgICAgfVxyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgbG9nRXJyb3IoJ01hdGVyaWFsaXplUmVjaXBlQWN0aW9uIGVycm9yJywgZXJyKTtcclxuICAgICAgLy8gSWdub3JlbSBlcnJvcnMgZGUgY29uc3VsdGEgKGV4OiBubyB0cm9iYXQpLCBzZWd1aW0gZW5kYXZhbnQgcGVyIGNyZWFyLWxhXHJcbiAgfVxyXG5cclxuICAvLyDwn4yKIDIuIEZMVVggRCdFTlJJUVVJTUVOVCAoSWd1YWwgcXVlIHRlbmllcylcclxuICAvLyBTaSBubyBleGlzdGVpeCwgbCdoZW0gZGUgY3JlYXIgaSBlbnJpcXVpclxyXG4gIGNvbnN0IGVucmljaGVkSW5ncmVkaWVudHMgPSBhd2FpdCBQcm9taXNlLmFsbCgocmVjaXBlRGF0YS5pbmdyZWRpZW50cyB8fCBbXSkubWFwKGFzeW5jIChpbmcpID0+IHtcclxuICAgICAgbGV0IGxpbmtlZFByb2R1Y3RJZCA9IGluZy5saW5rZWRQcm9kdWN0SWQ7XHJcbiAgICAgIGxldCBsaW5rZWRQcm9kdWN0SW1hZ2UgPSBpbmcubGlua2VkUHJvZHVjdEltYWdlO1xyXG4gICAgICBsZXQgZXN0aW1hdGVkQ29zdCA9IGluZy5lc3RpbWF0ZWRDb3N0O1xyXG5cclxuICAgICAgaWYgKCFsaW5rZWRQcm9kdWN0SWQgfHwgIWxpbmtlZFByb2R1Y3RJbWFnZSkge1xyXG4gICAgICAgICAgY29uc3QgeyBkYXRhOiBtYXRjaCB9ID0gYXdhaXQgc3VwYWJhc2VcclxuICAgICAgICAgICAgICAuZnJvbSgncHJvZHVjdF9jYXRhbG9nJylcclxuICAgICAgICAgICAgICAuc2VsZWN0KCdpZCwgaW1hZ2VfdXJsLCBwcmljZScpXHJcbiAgICAgICAgICAgICAgLmlsaWtlKCduYW1lJywgYCUke2luZy5uYW1lfSVgKVxyXG4gICAgICAgICAgICAgIC5saW1pdCgxKVxyXG4gICAgICAgICAgICAgIC5zaW5nbGUoKTtcclxuXHJcbiAgICAgICAgICBpZiAobWF0Y2gpIHtcclxuICAgICAgICAgICAgICBsaW5rZWRQcm9kdWN0SWQgPSBtYXRjaC5pZDtcclxuICAgICAgICAgICAgICBsaW5rZWRQcm9kdWN0SW1hZ2UgPSBtYXRjaC5pbWFnZV91cmw7XHJcbiAgICAgICAgICAgICAgaWYgKCFlc3RpbWF0ZWRDb3N0ICYmIG1hdGNoLnByaWNlKSBlc3RpbWF0ZWRDb3N0ID0gbWF0Y2gucHJpY2U7IFxyXG4gICAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgbmFtZTogaW5nLm5hbWUsXHJcbiAgICAgICAgICBxdWFudGl0eTogaW5nLnF1YW50aXR5LFxyXG4gICAgICAgICAgdW5pdDogaW5nLnVuaXQsXHJcbiAgICAgICAgICBlbW9qaTogaW5nLmVtb2ppLFxyXG4gICAgICAgICAgZXN0aW1hdGVkQ29zdDogZXN0aW1hdGVkQ29zdCxcclxuICAgICAgICAgIGxpbmtlZFByb2R1Y3RJZDogbGlua2VkUHJvZHVjdElkLFxyXG4gICAgICAgICAgbGlua2VkUHJvZHVjdEltYWdlOiBsaW5rZWRQcm9kdWN0SW1hZ2UsXHJcbiAgICAgIH07XHJcbiAgfSkpO1xyXG5cclxuICAvLyDwn5K+IDMuIFBSRVBBUkFSIFBFUiBHVUFSREFSXHJcbiAgY29uc3QgaW5wdXQ6IFNhdmVSZWNpcGVJbnB1dCA9IHtcclxuICAgIG5hbWU6IHJlY2lwZURhdGEubmFtZSxcclxuICAgIHByZXBUaW1lTWludXRlczogcmVjaXBlRGF0YS5wcmVwVGltZU1pbnV0ZXMgfHwgMzAsXHJcbiAgICB0YWdzOiByZWNpcGVEYXRhLnRhZ3MgfHwgW10sXHJcbiAgICBkaWV0YXJ5VGFnczogcmVjaXBlRGF0YS5kaWV0YXJ5VGFncyB8fCBbXSxcclxuICAgIGlzQWlHZW5lcmF0ZWQ6IHRydWUsXHJcbiAgICBzdGVwczogcmVjaXBlRGF0YS5zdGVwcyB8fCBbXSxcclxuICAgIGluZ3JlZGllbnRzOiBlbnJpY2hlZEluZ3JlZGllbnRzXHJcbiAgfTtcclxuXHJcbiAgLy8g8J+UpSBUUlVDIEZJTkFMOiBHdWFyZGVtIGNvbSBhIFDDmkJMSUNBP1xyXG4gIC8vIFPDrSwgcGVycXXDqCBzaSB1biBhbHRyZSB1c3VhcmkgZGUgbGEgc2FsYSBmYSBjbGljLCB2b2xlbSBxdWUgdHJvYmkgYXF1ZXN0YSByZWNlcHRhIChQYXMgMSlcclxuICAvLyBpIG5vIGVuIGNyZcOvIHVuYSBkZSBub3ZhLlxyXG4gIC8vIE1vZGlmaXF1ZW0gc2F2ZVJlY2lwZUFjdGlvbiBwZXJxdcOoIGFjY2VwdGkgJ2lzUHVibGljJyBvIGhvIGZvcmNlbSBhIGxhIGzDsmdpY2EgZGUgc2F2ZS5cclxuICBcclxuICAvLyBPcGNpw7MgQTogU2kgc2F2ZVJlY2lwZUFjdGlvbiBhY2NlcHRhIGlzUHVibGljIGFsIGlucHV0LCBwYXNzYS1sJ2hpLlxyXG4gIC8vIE9wY2nDsyBCIChIYWNrIHLDoHBpZCk6IFNhdmVSZWNpcGVBY3Rpb24gcGVyIGRlZmVjdGUgbGVzIGZhIHByaXZhZGVzLiBcclxuICAvLyBQZXLDsiBjb20gcXVlIHJldG9ybmEgbCdJRCwgcG9kZW0gZmVyIHVuIHVwZGF0ZSByw6BwaWQgYXF1w60gcGVyIGZlci1sYSBww7pibGljYS5cclxuICBcclxuICBjb25zdCBzYXZlUmVzdWx0ID0gYXdhaXQgc2F2ZVJlY2lwZUFjdGlvbihpbnB1dCk7XHJcblxyXG4gIGlmIChzYXZlUmVzdWx0LnN1Y2Nlc3MgJiYgc2F2ZVJlc3VsdC5yZWNpcGVJZCkge1xyXG4gICAgICAvLyBMYSBmZW0gcMO6YmxpY2EgcGVycXXDqCBsYSB0cm9iaW4gZWxzIGFsdHJlcyBjb21wYW55cyBkZSBsYSBzYWxhXHJcbiAgICAgIGF3YWl0IHN1cGFiYXNlXHJcbiAgICAgICAgICAuZnJvbSgnc2F2ZWRfcmVjaXBlcycpXHJcbiAgICAgICAgICAudXBkYXRlKHsgaXNfcHVibGljOiB0cnVlIH0pXHJcbiAgICAgICAgICAuZXEoJ2lkJywgc2F2ZVJlc3VsdC5yZWNpcGVJZCk7XHJcbiAgICAgICAgICBcclxuICAgICAgZGVidWcoJ1tBQ1RJT05dIHJlY2lwZSBzaGFyZWQnKTtcclxuICB9XHJcblxyXG4gIHJldHVybiBzYXZlUmVzdWx0O1xyXG59XHJcblxyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Im9TQTJMc0IsK0xBQUEifQ==
}),
"[project]/context/DecisionContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DecisionProvider",
    ()=>DecisionProvider,
    "useDecision",
    ()=>useDecision
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$Recipe$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/domain/entities/Recipe.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$6fdb57__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:6fdb57 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/sonner@2.0.7_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const DecisionContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function DecisionProvider({ children }) {
    _s();
    const { locale } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        isPending: false,
        recipes: [],
        mode: 'FATE',
        error: null,
        energy: 50,
        time: 30
    });
    const setEnergy = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "DecisionProvider.useCallback[setEnergy]": (v)=>{
            setState({
                "DecisionProvider.useCallback[setEnergy]": (prev)=>({
                        ...prev,
                        energy: v
                    })
            }["DecisionProvider.useCallback[setEnergy]"]);
        }
    }["DecisionProvider.useCallback[setEnergy]"], []);
    const setTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "DecisionProvider.useCallback[setTime]": (v)=>{
            setState({
                "DecisionProvider.useCallback[setTime]": (prev)=>({
                        ...prev,
                        time: v
                    })
            }["DecisionProvider.useCallback[setTime]"]);
        }
    }["DecisionProvider.useCallback[setTime]"], []);
    const setMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "DecisionProvider.useCallback[setMode]": (mode)=>{
            console.log("🎛️ [DecisionContext] Mode change:", mode);
            setState({
                "DecisionProvider.useCallback[setMode]": (prev)=>{
                    if (prev.mode === mode) return prev;
                    return {
                        ...prev,
                        mode
                    };
                }
            }["DecisionProvider.useCallback[setMode]"]);
        }
    }["DecisionProvider.useCallback[setMode]"], []);
    // Function to clean and validate raw data from server
    const sanitizeRecipeProps = (input)=>{
        const props = input;
        return {
            id: props.id || crypto.randomUUID(),
            authorId: props.authorId || 'unknown',
            name: props.name || 'Recipe without name',
            prepTimeMinutes: props.prepTimeMinutes || 0,
            likesCount: props.likesCount || 0,
            isPublic: !!props.isPublic,
            createdAt: props.createdAt ? new Date(props.createdAt) : new Date(),
            estimatedCost: props.estimatedCost || 0,
            isAiGenerated: props.isAiGenerated,
            ratingSummary: {
                average: props.ratingSummary?.average || 0,
                count: props.ratingSummary?.count || 0,
                distribution: props.ratingSummary?.distribution || {}
            },
            dietaryTags: props.dietaryTags || [],
            // ✅ CRITICAL FIX: Mapping Ingredients correctly
            ingredients: (Array.isArray(props.ingredients) ? props.ingredients : []).map((ing)=>({
                    id: ing.id || crypto.randomUUID(),
                    name: ing.name || "Ingredient",
                    unit: ing.unit || "ut",
                    quantity: !ing.quantity || ing.quantity <= 0 ? 1 : ing.quantity,
                    emoji: ing.emoji,
                    // 🛑 THIS WAS THE BUG: Passing the image through
                    linkedProductId: ing.linkedProductId || null,
                    linkedProductImage: ing.linkedProductImage || null,
                    estimatedCost: ing.estimatedCost || 0
                })),
            steps: Array.isArray(props.steps) ? props.steps : [],
            tags: Array.isArray(props.tags) ? props.tags : []
        };
    };
    const generateMenu = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "DecisionProvider.useCallback[generateMenu]": async (userId, dishName = '')=>{
            const currentMode = state.mode;
            console.log(`🚀 [DecisionContext] Starting generation. Mode: ${currentMode}`);
            setState({
                "DecisionProvider.useCallback[generateMenu]": (prev)=>({
                        ...prev,
                        isPending: true,
                        error: null,
                        recipes: []
                    })
            }["DecisionProvider.useCallback[generateMenu]"]);
            try {
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$6fdb57__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateMenuAction"])(userId, dishName, currentMode, state.energy, state.time, locale);
                if (result.success && result.recipes) {
                    console.log(`✅ [DecisionContext] Received ${result.recipes.length} raw recipes.`);
                    const recipeInstances = result.recipes.map({
                        "DecisionProvider.useCallback[generateMenu].recipeInstances": (props)=>{
                            try {
                                const cleanProps = sanitizeRecipeProps(props);
                                return new __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$Recipe$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Recipe"](cleanProps);
                            } catch (e) {
                                console.warn("⚠️ Skipped recipe due to incorrect data:", e);
                                return null;
                            }
                        }
                    }["DecisionProvider.useCallback[generateMenu].recipeInstances"]).filter({
                        "DecisionProvider.useCallback[generateMenu].recipeInstances": (r)=>r !== null
                    }["DecisionProvider.useCallback[generateMenu].recipeInstances"]);
                    setState({
                        "DecisionProvider.useCallback[generateMenu]": (prev)=>({
                                ...prev,
                                isPending: false,
                                recipes: recipeInstances
                            })
                    }["DecisionProvider.useCallback[generateMenu]"]);
                    if (recipeInstances.length > 0) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success(`👨‍🍳 Menu ready: ${recipeInstances.length} proposals!`);
                    } else {
                        throw new Error("Could not validate recipes.");
                    }
                } else {
                    throw new Error(result.error || "Unknown error");
                }
            } catch (err) {
                let errorMessage = "Unknown error";
                if (err instanceof Error) errorMessage = err.message;
                else if (typeof err === 'string') errorMessage = err;
                const isLimitError = errorMessage.toLowerCase().includes('limit') || errorMessage.toLowerCase().includes('límit');
                if (isLimitError) {
                    console.warn("⏳ Rate Limit Hit:", errorMessage);
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].warning("⏳ Limit Reached", {
                        description: "You've generated too many menus. Wait a bit!",
                        duration: 5000
                    });
                } else {
                    console.warn("❌ Error generateMenu:", errorMessage);
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Oven Error", {
                        description: errorMessage
                    });
                }
                setState({
                    "DecisionProvider.useCallback[generateMenu]": (prev)=>({
                            ...prev,
                            isPending: false,
                            error: errorMessage
                        })
                }["DecisionProvider.useCallback[generateMenu]"]);
            }
        }
    }["DecisionProvider.useCallback[generateMenu]"], [
        locale,
        state.mode,
        state.energy,
        state.time
    ]);
    const reset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "DecisionProvider.useCallback[reset]": ()=>{
            setState({
                "DecisionProvider.useCallback[reset]": (prev)=>({
                        ...prev,
                        recipes: [],
                        error: null,
                        isPending: false
                    })
            }["DecisionProvider.useCallback[reset]"]);
        }
    }["DecisionProvider.useCallback[reset]"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DecisionContext.Provider, {
        value: {
            ...state,
            setMode,
            setEnergy,
            setTime,
            generateMenu,
            reset,
            hasActiveResult: state.recipes.length > 0
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/context/DecisionContext.tsx",
        lineNumber: 213,
        columnNumber: 9
    }, this);
}
_s(DecisionProvider, "i/xE9uEwi9KrzkypLIHGDbhhIU8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = DecisionProvider;
function useDecision() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(DecisionContext);
    if (!context) throw new Error("useDecision must be used within DecisionProvider");
    return context;
}
_s1(useDecision, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "DecisionProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/navigation/RouteTracker.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RouteTracker",
    ()=>RouteTracker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/navigation.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function RouteTracker() {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const prevPathRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RouteTracker.useEffect": ()=>{
            if (!pathname) return;
            const query = ("TURBOPACK compile-time truthy", 1) ? window.location.search : "TURBOPACK unreachable";
            const fullPath = query ? `${pathname}${query}` : pathname;
            const prevPath = prevPathRef.current;
            if (pathname === '/recipes') {
                if (prevPath && prevPath !== '/recipes') {
                    sessionStorage.setItem('back-origin:/recipes', prevPath);
                }
            } else {
                sessionStorage.setItem('back-origin:/recipes', fullPath);
            }
            prevPathRef.current = fullPath;
        }
    }["RouteTracker.useEffect"], [
        pathname
    ]);
    return null;
}
_s(RouteTracker, "AqySGtSXthZMdN9AdGPTJkA1gyk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = RouteTracker;
var _c;
__turbopack_context__.k.register(_c, "RouteTracker");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_ac082111._.js.map