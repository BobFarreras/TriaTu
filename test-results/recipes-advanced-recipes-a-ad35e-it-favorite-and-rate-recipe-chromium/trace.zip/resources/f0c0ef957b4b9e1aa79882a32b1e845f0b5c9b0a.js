(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/core/domain/entities/StorageLocation.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/domain/inventory/StorageLocation.ts
__turbopack_context__.s([
    "StorageLocation",
    ()=>StorageLocation
]);
var StorageLocation = /*#__PURE__*/ function(StorageLocation) {
    StorageLocation["FRIDGE"] = "FRIDGE";
    StorageLocation["FREEZER"] = "FREEZER";
    StorageLocation["PANTRY"] = "PANTRY"; // Revost
    return StorageLocation;
}({});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/types.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/lib/food-presets/types.ts
__turbopack_context__.s([
    "DAYS",
    ()=>DAYS
]);
const DAYS = {
    FRESH_MEAT: 4,
    FRESH_FISH: 3,
    FRUIT: 14,
    BERRIES: 7,
    CITRUS: 30,
    VEGGIE: 12,
    ROOTS: 45,
    LEAFY: 7,
    DAIRY: 60,
    CHEESE: 30,
    PANTRY: 180,
    LONG_PANTRY: 665,
    FROZEN: 365,
    BAKERY: 3
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/fruit.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FRUIT_PRESETS",
    ()=>FRUIT_PRESETS
]);
// src/lib/food-presets/fruit.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/domain/entities/StorageLocation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/types.ts [app-client] (ecmascript)");
;
;
const FRUIT_PRESETS = [
    {
        id: 'f1',
        emoji: '🍎',
        name: 'Poma vermella',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRUIT
    },
    {
        id: 'f2',
        emoji: '🍏',
        name: 'Poma verda',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRUIT
    },
    {
        id: 'f3',
        emoji: '🍎',
        name: 'Poma groga',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRUIT
    },
    {
        id: 'f4',
        emoji: '🍌',
        name: 'Plàtan',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'f5',
        emoji: '🍌',
        name: 'Plàtan mascle',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'f6',
        emoji: '🍐',
        name: 'Pera conference',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRUIT
    },
    {
        id: 'f7',
        emoji: '🍐',
        name: 'Pera blanquilla',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRUIT
    },
    {
        id: 'f8',
        emoji: '🍊',
        name: 'Taronja',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].CITRUS
    },
    {
        id: 'f9',
        emoji: '🍊',
        name: 'Mandarina',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].CITRUS
    },
    {
        id: 'f10',
        emoji: '🍋',
        name: 'Llimona',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].CITRUS
    },
    {
        id: 'f11',
        emoji: '🍋',
        name: 'Llima',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].CITRUS
    },
    {
        id: 'f12',
        emoji: '🍊',
        name: 'Aranja',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].CITRUS
    },
    {
        id: 'f13',
        emoji: '🍓',
        name: 'Maduixa',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].BERRIES
    },
    {
        id: 'f14',
        emoji: '🫐',
        name: 'Nabius',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].BERRIES
    },
    {
        id: 'f15',
        emoji: '🍒',
        name: 'Cireres',
        category: '🍎 Fruita',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.2,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].BERRIES
    },
    {
        id: 'f16',
        emoji: '🍇',
        name: 'Raïm blanc',
        category: '🍎 Fruita',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.1,
        expirationDays: 10
    },
    {
        id: 'f17',
        emoji: '🍇',
        name: 'Raïm negre',
        category: '🍎 Fruita',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.1,
        expirationDays: 10
    },
    {
        id: 'f18',
        emoji: '🍑',
        name: 'Préssec',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'f19',
        emoji: '🍑',
        name: 'Nectarina',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'f20',
        emoji: '🍑',
        name: 'Paraguaià',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'f21',
        emoji: '🍒',
        name: 'Pruna',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'f22',
        emoji: '🍒',
        name: 'Albercoc',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'f23',
        emoji: '🥝',
        name: 'Kiwi verd',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    },
    {
        id: 'f24',
        emoji: '🥝',
        name: 'Kiwi groc',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    },
    {
        id: 'f25',
        emoji: '🍍',
        name: 'Pinya',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'f26',
        emoji: '🥭',
        name: 'Mango',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'f27',
        emoji: '🍈',
        name: 'Meló',
        category: '🍎 Fruita',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: 10
    },
    {
        id: 'f28',
        emoji: '🍉',
        name: 'Síndria',
        category: '🍎 Fruita',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: 10
    },
    {
        id: 'f29',
        emoji: '🥥',
        name: 'Coco',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 20
    },
    {
        id: 'f30',
        emoji: '🍎',
        name: 'Codony',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 30
    },
    {
        id: 'f31',
        emoji: '🍎',
        name: 'Figa',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    {
        id: 'f32',
        emoji: '🍌',
        name: 'Dàtil fresc',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 30
    },
    // Fruits tropicals
    {
        id: 'f33',
        emoji: '🍍',
        name: 'Papaia',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'f34',
        emoji: '🥭',
        name: 'Guaiaba',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'f35',
        emoji: '🍌',
        name: 'Plàtan vermell',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 7
    },
    // Fruits del bosc (més)
    {
        id: 'f36',
        emoji: '🫐',
        name: 'Gerds',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].BERRIES
    },
    {
        id: 'f37',
        emoji: '🫐',
        name: 'Mores',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].BERRIES
    },
    {
        id: 'f38',
        emoji: '🍓',
        name: 'Fruita del bosc barrejada',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 250,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    // Fruits secs / deshidratats
    {
        id: 'f39',
        emoji: '🍇',
        name: 'Panses',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'f40',
        emoji: '🍑',
        name: 'Albercocs secs',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'f41',
        emoji: '🍎',
        name: 'Poma deshidratada',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 50,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    // Altres comuns
    {
        id: 'f42',
        emoji: '🍐',
        name: 'Caqui',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'f43',
        emoji: '🍊',
        name: 'Clementina',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].CITRUS
    },
    {
        id: 'f44',
        emoji: '🍋',
        name: 'Kumquat',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 250,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].CITRUS
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/vegetables.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VEGETABLE_PRESETS",
    ()=>VEGETABLE_PRESETS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/domain/entities/StorageLocation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/types.ts [app-client] (ecmascript)");
;
;
const VEGETABLE_PRESETS = [
    // 🥕 Arrels i tubercles
    {
        id: 'v1',
        emoji: '🥕',
        name: 'Pastanaga',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].ROOTS
    },
    {
        id: 'v2',
        emoji: '🥔',
        name: 'Patata',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].ROOTS
    },
    {
        id: 'v31',
        emoji: '🍠',
        name: 'Moniato',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].ROOTS
    },
    {
        id: 'v33',
        emoji: '🥔',
        name: 'Yuca',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].ROOTS
    },
    {
        id: 'v24',
        emoji: '🫚',
        name: 'Nap',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    },
    {
        id: 'v25',
        emoji: '🥕',
        name: 'Remolatxa',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: 14
    },
    // 🧅 Bulbs i aromàtiques
    {
        id: 'v3',
        emoji: '🧅',
        name: 'Ceba blanca',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].ROOTS
    },
    {
        id: 'v4',
        emoji: '🧅',
        name: 'Ceba morada',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].ROOTS
    },
    {
        id: 'v35',
        emoji: '🧅',
        name: 'Ceba tendra',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'v5',
        emoji: '🧄',
        name: 'All',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].ROOTS
    },
    {
        id: 'v36',
        emoji: '🧄',
        name: 'All tendre',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'v37',
        emoji: '🧅',
        name: 'Escalunya',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].ROOTS
    },
    {
        id: 'v23',
        emoji: '🫚',
        name: 'Gingebre',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 50,
        expirationDays: 30
    },
    {
        id: 'v34',
        emoji: '🫚',
        name: 'Cúrcuma fresca',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 50,
        expirationDays: 30
    },
    // 🍅 Fruita-verdura / mediterrànies
    {
        id: 'v6',
        emoji: '🍅',
        name: 'Tomàquet madur',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: 7
    },
    {
        id: 'v7',
        emoji: '🍅',
        name: 'Tomàquet cherry',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 250,
        expirationDays: 10
    },
    {
        id: 'v43',
        emoji: '🍅',
        name: 'Tomàquet pera',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: 7
    },
    {
        id: 'v44',
        emoji: '🍅',
        name: 'Tomàquet cor de bou',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: 6
    },
    {
        id: 'v15',
        emoji: '🍆',
        name: 'Albergínia',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'v19',
        emoji: '🥒',
        name: 'Carbassó',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'v9',
        emoji: '🥒',
        name: 'Cogombre',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'v45',
        emoji: '🌶️',
        name: 'Bitxo',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 50,
        expirationDays: 14
    },
    {
        id: 'v16',
        emoji: '🌶️',
        name: 'Pebrot verd',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    },
    {
        id: 'v17',
        emoji: '🌶️',
        name: 'Pebrot vermell',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    },
    {
        id: 'v18',
        emoji: '🌶️',
        name: 'Pebrot groc',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    },
    // 🥬 Fulles
    {
        id: 'v10',
        emoji: '🥬',
        name: 'Enciam iceberg',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    },
    {
        id: 'v11',
        emoji: '🥬',
        name: 'Enciam romà',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LEAFY
    },
    {
        id: 'v12',
        emoji: '🥬',
        name: 'Enciam fulla de roure',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LEAFY
    },
    {
        id: 'v13',
        emoji: '🥬',
        name: 'Espinacs frescos',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 5
    },
    {
        id: 'v14',
        emoji: '🥬',
        name: 'Rúcula',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 50,
        expirationDays: 5
    },
    {
        id: 'v38',
        emoji: '🥬',
        name: 'Bledes',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 250,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LEAFY
    },
    {
        id: 'v39',
        emoji: '🥬',
        name: 'Canonges',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 5
    },
    {
        id: 'v40',
        emoji: '🥬',
        name: 'Endívia',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    // 🥦 Crucíferes
    {
        id: 'v8',
        emoji: '🥦',
        name: 'Bròquil',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'v20',
        emoji: '🥦',
        name: 'Coliflor',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'v21',
        emoji: '🥬',
        name: 'Col verda',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    },
    {
        id: 'v22',
        emoji: '🥬',
        name: 'Col llombarda',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    },
    {
        id: 'v41',
        emoji: '🥦',
        name: 'Cols de Brussel·les',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 500,
        expirationDays: 10
    },
    {
        id: 'v42',
        emoji: '🥦',
        name: 'Romanesco',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    // 🍄 Fongs
    {
        id: 'v29',
        emoji: '🍄',
        name: 'Xampinyons',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 250,
        expirationDays: 5
    },
    {
        id: 'v30',
        emoji: '🍄',
        name: 'Bolets variats',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 250,
        expirationDays: 5
    },
    // 🫘 Llegums i vegetals proteics
    {
        id: 'v28',
        emoji: '🫘',
        name: 'Mongetes verdes',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: 7
    },
    {
        id: 'v26',
        emoji: '🌽',
        name: 'Blat de moro',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    {
        id: 'v49',
        emoji: '🫘',
        name: 'Faves fresques',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: 7
    },
    {
        id: 'v27',
        emoji: '🫛',
        name: 'Pèsols',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 250,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'v50',
        emoji: '🫛',
        name: 'Edamame',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 400,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    // 🌍 Asiàtics / internacionals
    {
        id: 'v46',
        emoji: '🥬',
        name: 'Pak choi',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'v47',
        emoji: '🥬',
        name: 'Col xinesa',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'v48',
        emoji: '🎋',
        name: 'Brot de bambú',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 400,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/protein.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PROTEIN_PRESETS",
    ()=>PROTEIN_PRESETS
]);
// src/lib/food-presets/protein.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/domain/entities/StorageLocation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/types.ts [app-client] (ecmascript)");
;
;
const PROTEIN_PRESETS = [
    {
        id: 'p1',
        emoji: '🍗',
        name: 'Pollastre sencer',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p2',
        emoji: '🍗',
        name: 'Pit de pollastre',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p3',
        emoji: '🍗',
        name: 'Cuixes de pollastre',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p11',
        emoji: '🍗',
        name: 'Aletes de pollastre',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p12',
        emoji: '🥩',
        name: 'Vedella fresca',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_MEAT
    },
    {
        id: 'p13',
        emoji: '🥩',
        name: 'Vedella picada',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p14',
        emoji: '🥩',
        name: 'Entrecot de vedella',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_MEAT
    },
    {
        id: 'p15',
        emoji: '🥩',
        name: 'Filet de vedella',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.3,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_MEAT
    },
    {
        id: 'p16',
        emoji: '🐖',
        name: 'Llom de porc',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_MEAT
    },
    {
        id: 'p17',
        emoji: '🐖',
        name: 'Costelles de porc',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p18',
        emoji: '🐖',
        name: 'Carn picada de porc',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p19',
        emoji: '🥓',
        name: 'Bacon',
        category: '🥩 Proteïna',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 200,
        expirationDays: 30
    },
    {
        id: 'p20',
        emoji: '🐑',
        name: 'Xai (cuixa)',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p21',
        emoji: '🐑',
        name: 'Costelles de xai',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p22',
        emoji: '🐟',
        name: 'Lluç',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.3,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_FISH
    },
    {
        id: 'p23',
        emoji: '🐟',
        name: 'Bacallà fresc',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.3,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_FISH
    },
    {
        id: 'p25',
        emoji: '🐟',
        name: 'Orada',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.3,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_FISH
    },
    {
        id: 'p26',
        emoji: '🐟',
        name: 'Llobarro',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.3,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_FISH
    },
    {
        id: 'p29',
        emoji: '🐟',
        name: 'Salmó fresc',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.2,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_FISH
    },
    {
        id: 'p30',
        emoji: '🐟',
        name: 'Salmó congelat',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p32',
        emoji: '🦐',
        name: 'Gambes',
        category: '🥩 Proteïna',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 250,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p38',
        emoji: '🥚',
        name: 'Ous',
        category: '🥩 Proteïna',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 6,
        expirationDays: 21
    },
    {
        id: 'p41',
        emoji: '🌱',
        name: 'Tofu',
        category: '🥩 Proteïna',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    // 🍗 Aus extra
    {
        id: 'p42',
        emoji: '🦃',
        name: 'Gall dindi (pit)',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p43',
        emoji: '🦃',
        name: 'Gall dindi picat',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p44',
        emoji: '🍗',
        name: 'Conill',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    // 🥩 Vedella / boví extra
    {
        id: 'p45',
        emoji: '🥩',
        name: 'Hamburgueses de vedella',
        category: '🥩 Proteïna',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 2,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p46',
        emoji: '🥩',
        name: 'Estofat de vedella',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_MEAT
    },
    {
        id: 'p47',
        emoji: '🥩',
        name: 'Costella de vedella',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    // 🐖 Porc extra
    {
        id: 'p48',
        emoji: '🐖',
        name: 'Botifarra',
        category: '🥩 Proteïna',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 2,
        expirationDays: 10
    },
    {
        id: 'p49',
        emoji: '🐖',
        name: 'Salsitxes',
        category: '🥩 Proteïna',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 4,
        expirationDays: 10
    },
    {
        id: 'p50',
        emoji: '🐖',
        name: 'Pernil dolç',
        category: '🥩 Proteïna',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 150,
        expirationDays: 15
    },
    {
        id: 'p51',
        emoji: '🥓',
        name: 'Xoriço',
        category: '🥩 Proteïna',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 150,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'p52',
        emoji: '🥓',
        name: 'Fuet',
        category: '🥩 Proteïna',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 150,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    // 🐟 Peix extra
    {
        id: 'p53',
        emoji: '🐟',
        name: 'Tonyina fresca',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.3,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_FISH
    },
    {
        id: 'p54',
        emoji: '🐟',
        name: 'Tonyina en conserva',
        category: '🥩 Proteïna',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 200,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'p55',
        emoji: '🐟',
        name: 'Sardines',
        category: '🥩 Proteïna',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 300,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_FISH
    },
    {
        id: 'p56',
        emoji: '🐟',
        name: 'Seitons',
        category: '🥩 Proteïna',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 300,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_FISH
    },
    {
        id: 'p57',
        emoji: '🐟',
        name: 'Verat',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.3,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_FISH
    },
    // 🦐 Marisc extra
    {
        id: 'p58',
        emoji: '🦑',
        name: 'Calamars',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p59',
        emoji: '🦑',
        name: 'Pop',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p60',
        emoji: '🦐',
        name: 'Musclos',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 2
    },
    {
        id: 'p61',
        emoji: '🦐',
        name: 'Escamarlans',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    // 🥚 Ous i derivats
    {
        id: 'p62',
        emoji: '🥚',
        name: 'Clares d’ou',
        category: '🥩 Proteïna',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: 5
    },
    // 🌱 Proteïna vegetal
    {
        id: 'p63',
        emoji: '🌱',
        name: 'Tempeh',
        category: '🥩 Proteïna',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'p64',
        emoji: '🌱',
        name: 'Seitan',
        category: '🥩 Proteïna',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'p65',
        emoji: '🌱',
        name: 'Proteïna vegetal texturitzada',
        category: '🥩 Proteïna',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 250,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    // 🏋️‍♂️ Fitness / complements
    {
        id: 'p66',
        emoji: '🥤',
        name: 'Batuts de proteïna',
        category: '🥩 Proteïna',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: 180
    },
    {
        id: 'p67',
        emoji: '💊',
        name: 'Proteïna en pols',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: 365
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/dairy.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DAIRY_PRESETS",
    ()=>DAIRY_PRESETS
]);
// src/lib/food-presets/dairy.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/domain/entities/StorageLocation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/types.ts [app-client] (ecmascript)");
;
;
const DAIRY_PRESETS = [
    {
        id: 'l1',
        emoji: '🥛',
        name: 'Llet sencera',
        category: '🥛 Lactic',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    {
        id: 'l2',
        emoji: '🥛',
        name: 'Llet semi',
        category: '🥛 Lactic',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    {
        id: 'l3',
        emoji: '🥛',
        name: 'Llet desnatada',
        category: '🥛 Lactic',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    {
        id: 'l4',
        emoji: '🥛',
        name: 'Llet sense lactosa',
        category: '🥛 Lactic',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    {
        id: 'l5',
        emoji: '🧀',
        name: 'Formatge curat',
        category: '🥛 Lactic',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 60
    },
    {
        id: 'l6',
        emoji: '🧀',
        name: 'Formatge semicurat',
        category: '🥛 Lactic',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 45
    },
    {
        id: 'l7',
        emoji: '🧀',
        name: 'Formatge tendre',
        category: '🥛 Lactic',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 10
    },
    {
        id: 'l8',
        emoji: '🧀',
        name: 'Formatge ratllat',
        category: '🥛 Lactic',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 14
    },
    {
        id: 'l9',
        emoji: '🧀',
        name: 'Mozzarella',
        category: '🥛 Lactic',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'l10',
        emoji: '🧀',
        name: 'Formatge parmesà',
        category: '🥛 Lactic',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 90
    },
    {
        id: 'l11',
        emoji: '🧀',
        name: 'Formatge fresc',
        category: '🥛 Lactic',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    {
        id: 'l12',
        emoji: '🧀',
        name: 'Formatge blau',
        category: '🥛 Lactic',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 20
    },
    {
        id: 'l13',
        emoji: '🥣',
        name: 'Iogurt natural',
        category: '🥛 Lactic',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 20
    },
    {
        id: 'l14',
        emoji: '🥣',
        name: 'Iogurt grec',
        category: '🥛 Lactic',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 20
    },
    {
        id: 'l15',
        emoji: '🥣',
        name: 'Iogurt de maduixa',
        category: '🥛 Lactic',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 20
    },
    {
        id: 'l16',
        emoji: '🍮',
        name: 'Flam',
        category: '🥛 Lactic',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 20
    },
    {
        id: 'l17',
        emoji: '🍮',
        name: 'Natilles',
        category: '🥛 Lactic',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 20
    },
    {
        id: 'l18',
        emoji: '🧈',
        name: 'Mantega',
        category: '🥛 Lactic',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 90
    },
    {
        id: 'l19',
        emoji: '🧴',
        name: 'Nata per cuinar',
        category: '🥛 Lactic',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 200,
        expirationDays: 30
    },
    {
        id: 'l20',
        emoji: '🍦',
        name: 'Gelat',
        category: '🥛 Lactic',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/cereals.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CEREAL_PRESETS",
    ()=>CEREAL_PRESETS
]);
// src/lib/food-presets/dairy.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/domain/entities/StorageLocation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/types.ts [app-client] (ecmascript)");
;
;
const CEREAL_PRESETS = [
    // 🥖 CEREALS
    {
        id: 'c1',
        emoji: '🍞',
        name: 'Pa blanc',
        category: '🥖 Cereals',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].BAKERY
    },
    {
        id: 'c2',
        emoji: '🍞',
        name: 'Pa integral',
        category: '🥖 Cereals',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].BAKERY
    },
    {
        id: 'c3',
        emoji: '🍝',
        name: 'Pasta espagueti',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    {
        id: 'c4',
        emoji: '🍝',
        name: 'Pasta macarrons',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    {
        id: 'c5',
        emoji: '🍚',
        name: 'Arròs blanc',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    // Pa i brioixeria
    {
        id: 'c6',
        emoji: '🥖',
        name: 'Barra de pa',
        category: '🥖 Cereals',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].BAKERY
    },
    {
        id: 'c7',
        emoji: '🥐',
        name: 'Croissant',
        category: '🥖 Cereals',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].BAKERY
    },
    {
        id: 'c8',
        emoji: '🥯',
        name: 'Bagel',
        category: '🥖 Cereals',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 5
    },
    {
        id: 'c9',
        emoji: '🍞',
        name: 'Pa de motlle',
        category: '🥖 Cereals',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 10
    },
    // Pasta i derivats
    {
        id: 'c10',
        emoji: '🍝',
        name: 'Pasta fusilli',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    {
        id: 'c11',
        emoji: '🍝',
        name: 'Pasta penne',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    {
        id: 'c12',
        emoji: '🍜',
        name: 'Fideus',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    // Arròs i grans
    {
        id: 'c13',
        emoji: '🍚',
        name: 'Arròs integral',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    {
        id: 'c14',
        emoji: '🍚',
        name: 'Arròs basmati',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    {
        id: 'c15',
        emoji: '🍚',
        name: 'Arròs jazmín',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    {
        id: 'c16',
        emoji: '🌾',
        name: 'Cuscús',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    {
        id: 'c17',
        emoji: '🌾',
        name: 'Quinoa',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    // Esmorzar
    {
        id: 'c18',
        emoji: '🥣',
        name: 'Cereals d’esmorzar',
        category: '🥖 Cereals',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 250,
        expirationDays: 90
    },
    {
        id: 'c19',
        emoji: '🥣',
        name: 'Flocs de civada',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: 90
    },
    {
        id: 'c20',
        emoji: '🥣',
        name: 'Muesli',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: 90
    },
    // Farines
    {
        id: 'c21',
        emoji: '🌾',
        name: 'Farina de blat',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 180
    },
    {
        id: 'c22',
        emoji: '🌾',
        name: 'Farina integral',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 180
    },
    {
        id: 'c23',
        emoji: '🌾',
        name: 'Farina de civada',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 180
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/drinks.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DRINK_PRESETS",
    ()=>DRINK_PRESETS
]);
// src/lib/food-presets/drinks.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/domain/entities/StorageLocation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/types.ts [app-client] (ecmascript)");
;
;
const DRINK_PRESETS = [
    // 🥤 BEGUDA
    {
        id: 'b1',
        emoji: '💧',
        name: 'Aigua',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'b2',
        emoji: '☕',
        name: 'Cafè mòlt',
        category: '🥤 Beguda',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 250,
        expirationDays: 180
    },
    {
        id: 'b3',
        emoji: '🍵',
        name: 'Te',
        category: '🥤 Beguda',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 20,
        expirationDays: 365
    },
    {
        id: 'b4',
        emoji: '🥤',
        name: 'Refresc cola',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 180
    },
    // Begudes fredes
    {
        id: 'b5',
        emoji: '🥤',
        name: 'Refresc taronja',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 180
    },
    {
        id: 'b6',
        emoji: '🥤',
        name: 'Refresc llimona',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 180
    },
    {
        id: 'b7',
        emoji: '🧃',
        name: 'Suc de taronja',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'b8',
        emoji: '🧃',
        name: 'Suc de poma',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    // Begudes calentes
    {
        id: 'b9',
        emoji: '☕',
        name: 'Cafè en gra',
        category: '🥤 Beguda',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 250,
        expirationDays: 180
    },
    {
        id: 'b10',
        emoji: '☕',
        name: 'Cafè soluble',
        category: '🥤 Beguda',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 200,
        expirationDays: 365
    },
    {
        id: 'b11',
        emoji: '🍵',
        name: 'Infusions',
        category: '🥤 Beguda',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 20,
        expirationDays: 365
    },
    // Altres
    {
        id: 'b12',
        emoji: '🥛',
        name: 'Beguda vegetal de civada',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'b13',
        emoji: '🥛',
        name: 'Beguda vegetal d’ametlla',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'b14',
        emoji: '🍺',
        name: 'Cervesa',
        category: '🥤 Beguda',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 180
    },
    {
        id: 'b15',
        emoji: '🍷',
        name: 'Vi',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.75,
        expirationDays: 365
    },
    {
        id: 'b16',
        emoji: '🥂',
        name: 'Vi blanc',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.75,
        expirationDays: 365
    },
    {
        id: 'b17',
        emoji: '🍾',
        name: 'Cava',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.75,
        expirationDays: 365
    },
    {
        id: 'b18',
        emoji: '🥃',
        name: 'Vermut',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 365
    },
    {
        id: 'b19',
        emoji: '🥤',
        name: 'Tònica',
        category: '🥤 Beguda',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 180
    },
    // 🧃 Més sucs
    {
        id: 'b20',
        emoji: '🧃',
        name: 'Suc de pinya',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'b21',
        emoji: '🧃',
        name: 'Suc de préssec',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'b22',
        emoji: '🧃',
        name: 'Suc multifruites',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    // ⚡ Begudes energètiques / esportives
    {
        id: 'b23',
        emoji: '⚡',
        name: 'Beguda energètica',
        category: '🥤 Beguda',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 365
    },
    {
        id: 'b24',
        emoji: '🥤',
        name: 'Beguda isotònica',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 180
    },
    // 🌱 Begudes vegetals (més)
    {
        id: 'b25',
        emoji: '🥛',
        name: 'Beguda vegetal de soja',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'b26',
        emoji: '🥛',
        name: 'Beguda vegetal d’arròs',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'b27',
        emoji: '🥛',
        name: 'Beguda vegetal de coco',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    // 🍷 Alcohols habituals
    {
        id: 'b28',
        emoji: '🍷',
        name: 'Vi negre',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.75,
        expirationDays: 365
    },
    {
        id: 'b29',
        emoji: '🥃',
        name: 'Ginebra',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.7,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'b30',
        emoji: '🥃',
        name: 'Rom',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.7,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'b31',
        emoji: '🥃',
        name: 'Vodka',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.7,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    // 🍹 Altres
    {
        id: 'b32',
        emoji: '🍹',
        name: 'Sangria',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    {
        id: 'b33',
        emoji: '🍶',
        name: 'Sake',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.75,
        expirationDays: 365
    },
    {
        id: 'b34',
        emoji: '🫖',
        name: 'Te matcha',
        category: '🥤 Beguda',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 50,
        expirationDays: 180
    },
    {
        id: 'b35',
        emoji: '🍵',
        name: 'Kombutxa',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/snacks.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SNACK_PRESETS",
    ()=>SNACK_PRESETS
]);
// src/lib/food-presets/snacks.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/domain/entities/StorageLocation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/types.ts [app-client] (ecmascript)");
;
;
const SNACK_PRESETS = [
    {
        id: 's1',
        emoji: '🍪',
        name: 'Galetes',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    {
        id: 's2',
        emoji: '🍫',
        name: 'Xocolata negra',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 365
    },
    {
        id: 's3',
        emoji: '🍿',
        name: 'Crispetes',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 180
    },
    {
        id: 's4',
        emoji: '🥜',
        name: 'Ametlles',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    // Dolços
    {
        id: 's5',
        emoji: '🍫',
        name: 'Xocolata amb llet',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 365
    },
    {
        id: 's6',
        emoji: '🍫',
        name: 'Xocolata blanca',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 365
    },
    {
        id: 's7',
        emoji: '🍬',
        name: 'Caramels',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 365
    },
    {
        id: 's8',
        emoji: '🍭',
        name: 'Pirulís',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 365
    },
    {
        id: 's9',
        emoji: '🧁',
        name: 'Magdalena',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 7
    },
    {
        id: 's10',
        emoji: '🍩',
        name: 'Dònut',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 3
    },
    // Salats
    {
        id: 's11',
        emoji: '🥨',
        name: 'Bastonets salats',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    {
        id: 's12',
        emoji: '🥨',
        name: 'Pretzels',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    {
        id: 's13',
        emoji: '🍟',
        name: 'Patates fregides',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    {
        id: 's14',
        emoji: '🌮',
        name: 'Nachos',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    // Fruits secs i llavors
    {
        id: 's15',
        emoji: '🥜',
        name: 'Avellanes',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    {
        id: 's16',
        emoji: '🥜',
        name: 'Nous',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    {
        id: 's17',
        emoji: '🥜',
        name: 'Anacards',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    {
        id: 's18',
        emoji: '🌰',
        name: 'Cacauets',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    {
        id: 's19',
        emoji: '🌻',
        name: 'Pipes de gira-sol',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    // Altres
    {
        id: 's20',
        emoji: '🍪',
        name: 'Galetes salades',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    {
        id: 's21',
        emoji: '🍪',
        name: 'Crackers',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    {
        id: 's22',
        emoji: '🍫',
        name: 'Barretes de cereals',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 90
    },
    {
        id: 's23',
        emoji: '🍯',
        name: 'Mel',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 250,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    // 🍫 Dolços extra / rebosteria
    {
        id: 's24',
        emoji: '🍰',
        name: 'Pastís envasat',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 10
    },
    {
        id: 's25',
        emoji: '🥧',
        name: 'Tarta dolça',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    {
        id: 's26',
        emoji: '🍪',
        name: 'Cookies amb xips de xocolata',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 14
    },
    {
        id: 's27',
        emoji: '🍩',
        name: 'Croissant',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 3
    },
    {
        id: 's28',
        emoji: '🥐',
        name: 'Croissant farcit',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 3
    },
    // 🍿 Salats extra
    {
        id: 's29',
        emoji: '🧀',
        name: 'Snacks de formatge',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    {
        id: 's30',
        emoji: '🥓',
        name: 'Snacks de bacon',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 60
    },
    {
        id: 's31',
        emoji: '🍘',
        name: 'Crackers d’arròs',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 120
    },
    {
        id: 's32',
        emoji: '🍘',
        name: 'Galetes d’arròs',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 120
    },
    {
        id: 's33',
        emoji: '🥠',
        name: 'Snacks asiàtics',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 120
    },
    // 🥜 Fruits secs premium / saludables
    {
        id: 's34',
        emoji: '🥜',
        name: 'Festucs',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    {
        id: 's35',
        emoji: '🥜',
        name: 'Ametlles torrades',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    {
        id: 's36',
        emoji: '🌰',
        name: 'Nous pecanes',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    {
        id: 's37',
        emoji: '🥥',
        name: 'Xips de coco',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    // 🧃 Healthy / fitness
    {
        id: 's38',
        emoji: '🍎',
        name: 'Fruita deshidratada',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    {
        id: 's39',
        emoji: '🍫',
        name: 'Barreta proteica',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 180
    },
    {
        id: 's40',
        emoji: '🫘',
        name: 'Cigrons torrats',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    {
        id: 's41',
        emoji: '🌽',
        name: 'Blat de moro torrat',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    // ❄️ Nevera / congelador
    {
        id: 's42',
        emoji: '🍦',
        name: 'Gelat',
        category: '🍪 Snack',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 's43',
        emoji: '🧊',
        name: 'Polos de gel',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 's44',
        emoji: '🍫',
        name: 'Brownie',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    // 🌍 Internacionals / street food
    {
        id: 's45',
        emoji: '🥟',
        name: 'Empanadilles',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 6,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 's46',
        emoji: '🍙',
        name: 'Onigiri',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 2
    },
    {
        id: 's47',
        emoji: '🥙',
        name: 'Falàfel',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 200,
        expirationDays: 5
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/condiments.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CONDIMENT_PRESETS",
    ()=>CONDIMENT_PRESETS
]);
// src/lib/food-presets/condiments.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/domain/entities/StorageLocation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/types.ts [app-client] (ecmascript)");
;
;
const CONDIMENT_PRESETS = [
    {
        id: 'co1',
        emoji: '🫒',
        name: 'Oli d\'oliva verge',
        category: '🧂 Condiments',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co3',
        emoji: '🧂',
        name: 'Sal',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 500,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co4',
        emoji: '🧂',
        name: 'Pebre negre',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 50,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co5',
        emoji: '🍯',
        name: 'Vinagre de vi',
        category: '🧂 Condiments',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co9',
        emoji: '🍅',
        name: 'Quètxup',
        category: '🧂 Condiments',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 180
    },
    {
        id: 'co10',
        emoji: '🥚',
        name: 'Maionesa',
        category: '🧂 Condiments',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 30
    },
    {
        id: 'co15',
        emoji: '🥘',
        name: 'Tomàquet fregit',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 400,
        expirationDays: 180
    },
    // 🌿 Olis i vinagres
    {
        id: 'co16',
        emoji: '🫒',
        name: 'Oli de gira-sol',
        category: '🧂 Condiments',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co17',
        emoji: '🫒',
        name: 'Oli de coco',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 500,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co18',
        emoji: '🍯',
        name: 'Vinagre de poma',
        category: '🧂 Condiments',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co19',
        emoji: '🍯',
        name: 'Vinagre balsàmic',
        category: '🧂 Condiments',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    // 🧂 Espècies bàsiques
    {
        id: 'co20',
        emoji: '🌶️',
        name: 'Pebre blanc',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 50,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co21',
        emoji: '🌶️',
        name: 'Pebre vermell dolç',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 50,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co22',
        emoji: '🌶️',
        name: 'Pebre vermell picant',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 50,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co23',
        emoji: '🧄',
        name: 'All en pols',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 50,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co24',
        emoji: '🧅',
        name: 'Ceba en pols',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 50,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    // 🌿 Herbes aromàtiques
    {
        id: 'co25',
        emoji: '🌿',
        name: 'Orenga',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 20,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co26',
        emoji: '🌿',
        name: 'Alfàbrega seca',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 20,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co27',
        emoji: '🌿',
        name: 'Farigola',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 20,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co28',
        emoji: '🌿',
        name: 'Romaní',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 20,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    // 🥫 Salses
    {
        id: 'co29',
        emoji: '🥫',
        name: 'Mostassa',
        category: '🧂 Condiments',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 180
    },
    {
        id: 'co30',
        emoji: '🥫',
        name: 'Salsa barbacoa',
        category: '🧂 Condiments',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 180
    },
    {
        id: 'co31',
        emoji: '🥫',
        name: 'Salsa de soja',
        category: '🧂 Condiments',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 250,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co32',
        emoji: '🌶️',
        name: 'Salsa picant',
        category: '🧂 Condiments',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 365
    },
    // 🍯 Altres
    {
        id: 'co33',
        emoji: '🍯',
        name: 'Sucre blanc',
        category: '🧂 Condiments',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co34',
        emoji: '🍯',
        name: 'Sucre morè',
        category: '🧂 Condiments',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co35',
        emoji: '🍯',
        name: 'Mel',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 250,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// src/lib/food-presets/index.ts
__turbopack_context__.s([
    "FOOD_PRESETS",
    ()=>FOOD_PRESETS,
    "PRESET_CATEGORIES",
    ()=>PRESET_CATEGORIES
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$fruit$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/fruit.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$vegetables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/vegetables.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$protein$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/protein.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$dairy$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/dairy.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$cereals$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/cereals.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$drinks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/drinks.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$snacks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/snacks.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$condiments$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/condiments.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/types.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
const FOOD_PRESETS = [
    ...__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$fruit$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FRUIT_PRESETS"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$vegetables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VEGETABLE_PRESETS"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$protein$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROTEIN_PRESETS"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$dairy$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAIRY_PRESETS"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$cereals$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CEREAL_PRESETS"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$drinks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DRINK_PRESETS"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$snacks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SNACK_PRESETS"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$condiments$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CONDIMENT_PRESETS"]
];
const PRESET_CATEGORIES = Array.from(new Set(FOOD_PRESETS.map((p)=>p.category)));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/ingredients/useIngredientsManager.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useIngredientsManager",
    ()=>useIngredientsManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/food-presets/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
function useIngredientsManager(data, update) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [query, setQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [selectedCategory, setSelectedCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('ALL');
    const [activeItem, setActiveItem] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [qty, setQty] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    // 1. TRADUCCIÓ
    const translatedPresets = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useIngredientsManager.useMemo[translatedPresets]": ()=>{
            return __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["FOOD_PRESETS"].map({
                "useIngredientsManager.useMemo[translatedPresets]": (preset)=>{
                    const itemTranslations = t.food?.items;
                    const translatedName = itemTranslations?.[preset.id] || preset.name;
                    const catTranslations = t.food?.categories;
                    const translatedCategory = catTranslations?.[preset.category] || preset.category;
                    return {
                        ...preset,
                        name: translatedName,
                        category: translatedCategory,
                        defaultUnit: preset.defaultUnit,
                        step: preset.step || 1
                    };
                }
            }["useIngredientsManager.useMemo[translatedPresets]"]);
        }
    }["useIngredientsManager.useMemo[translatedPresets]"], [
        t
    ]);
    // 2. FILTRATGE
    const filteredPresets = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useIngredientsManager.useMemo[filteredPresets]": ()=>{
            return translatedPresets.filter({
                "useIngredientsManager.useMemo[filteredPresets]": (preset)=>{
                    const matchesSearch = preset.name.toLowerCase().includes(query.toLowerCase());
                    const matchesCategory = selectedCategory === 'ALL' || preset.category === selectedCategory;
                    return matchesSearch && matchesCategory;
                }
            }["useIngredientsManager.useMemo[filteredPresets]"]);
        }
    }["useIngredientsManager.useMemo[filteredPresets]"], [
        query,
        selectedCategory,
        translatedPresets
    ]);
    const getIncrementStep = (unit)=>{
        switch(unit){
            case 'g':
                return 100;
            case 'ml':
                return 100;
            case 'kg':
                return 0.5;
            case 'l':
                return 0.5;
            default:
                return 1;
        }
    };
    const quickAdd = (preset)=>{
        const existingIndex = data.ingredients.findIndex((i)=>i.name === preset.name);
        const step = getIncrementStep(preset.defaultUnit);
        const newIngredients = [
            ...data.ingredients
        ];
        if (existingIndex >= 0) {
            const current = newIngredients[existingIndex];
            newIngredients[existingIndex] = {
                ...current,
                quantity: current.quantity + step
            };
        } else {
            newIngredients.push({
                id: crypto.randomUUID(),
                name: preset.name,
                quantity: step,
                unit: preset.defaultUnit,
                emoji: preset.emoji
            });
        }
        update({
            ...data,
            ingredients: newIngredients
        });
        if (typeof navigator !== 'undefined' && navigator.vibrate) {
            navigator.vibrate(50);
        }
    };
    // ✅ CORRECCIÓ CLAU: Ara acceptem 'id' (string) en lloc de 'index' (number)
    const removeIngredient = (id)=>{
        update({
            ...data,
            ingredients: data.ingredients.filter((item)=>item.id !== id)
        });
    };
    const openSelection = (preset)=>{
        setActiveItem({
            name: preset.name,
            emoji: preset.emoji,
            unit: preset.defaultUnit
        });
        setQty(1);
    };
    const closeSelection = ()=>{
        setActiveItem(null);
        setQty(1);
    };
    const confirmAdd = ()=>{
        if (!activeItem) return;
        const existingIndex = data.ingredients.findIndex((i)=>i.name === activeItem.name);
        const newIngredients = [
            ...data.ingredients
        ];
        if (existingIndex >= 0) {
            const current = newIngredients[existingIndex];
            newIngredients[existingIndex] = {
                ...current,
                quantity: current.quantity + qty,
                unit: activeItem.unit
            };
        } else {
            newIngredients.push({
                id: crypto.randomUUID(),
                name: activeItem.name,
                quantity: qty,
                unit: activeItem.unit,
                emoji: activeItem.emoji
            });
        }
        update({
            ...data,
            ingredients: newIngredients
        });
        closeSelection();
    };
    return {
        query,
        setQuery,
        selectedCategory,
        setSelectedCategory,
        activeItem,
        setActiveItem,
        qty,
        setQty,
        filteredPresets,
        quickAdd,
        openSelection,
        closeSelection,
        confirmAdd,
        removeIngredient
    };
}
_s(useIngredientsManager, "ekZIwu+O+dzXe1LtNpsektnOZ+c=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IngredientActionSheet",
    ()=>IngredientActionSheet
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// src/components/recipes/ingredients/IngredientActionSheet.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Minus$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/minus.js [app-client] (ecmascript) <export default as Minus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
;
;
;
// Definim les unitats com a constant, potser en un fitxer de constants global en el futur
const UNITS = [
    'ut',
    'g',
    'ml',
    'tbsp',
    'tsp',
    'cup'
];
function IngredientActionSheet({ activeItem, qty, setQty, updateItemUnit, onClose, onConfirm }) {
    const adjustQty = (delta)=>setQty(Math.max(0.5, qty + delta));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
        children: activeItem && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            id: "tour-ing-input",
            className: "fixed inset-0 z-9999 flex items-end justify-center sm:items-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    exit: {
                        opacity: 0
                    },
                    onClick: onClose,
                    className: "absolute inset-0 bg-black/80 backdrop-blur-sm"
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                    lineNumber: 26,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        y: "100%"
                    },
                    animate: {
                        y: 0
                    },
                    exit: {
                        y: "100%"
                    },
                    transition: {
                        type: "spring",
                        damping: 25,
                        stiffness: 350
                    },
                    className: "relative w-full sm:max-w-md bg-slate-900 border-t sm:border border-slate-700 rounded-t-4xl sm:rounded-4xl shadow-2xl overflow-hidden",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "absolute top-3 left-1/2 -translate-x-1/2 w-12 h-1.5 bg-slate-700 rounded-full sm:hidden"
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                            lineNumber: 39,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-6 pt-8 flex flex-col gap-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-between items-start",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-4xl bg-slate-800 p-2 rounded-2xl border border-slate-700",
                                                    children: activeItem.emoji
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                                    lineNumber: 46,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-xs font-bold text-slate-400 uppercase tracking-wider mb-0.5",
                                                            children: "Afegir ingredient"
                                                        }, void 0, false, {
                                                            fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                                            lineNumber: 48,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            className: "text-2xl font-black text-white leading-tight",
                                                            children: activeItem.name
                                                        }, void 0, false, {
                                                            fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                                            lineNumber: 49,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                                    lineNumber: 47,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                            lineNumber: 45,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: onClose,
                                            className: "bg-slate-800 hover:bg-slate-700 text-slate-400 p-2 rounded-full transition-colors",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                size: 20
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                                lineNumber: 53,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                            lineNumber: 52,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                    lineNumber: 44,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-slate-950/50 p-4 rounded-3xl border border-slate-800 flex flex-col gap-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "text-xs font-bold text-slate-500 uppercase ml-2",
                                            children: "Quantitat"
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                            lineNumber: 59,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center justify-between bg-slate-900 rounded-2xl p-2 border border-slate-800",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>adjustQty(-1),
                                                    className: "w-14 h-14 flex items-center justify-center bg-slate-800 hover:bg-slate-700 active:scale-95 text-white rounded-xl transition-all",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Minus$3e$__["Minus"], {
                                                        size: 24
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                                        lineNumber: 62,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                                    lineNumber: 61,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-1 flex justify-center",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "number",
                                                        value: qty,
                                                        onChange: (e)=>setQty(parseFloat(e.target.value) || 0),
                                                        className: "w-24 bg-transparent text-center text-4xl font-black text-white outline-none appearance-none m-0 p-0"
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                                        lineNumber: 65,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                                    lineNumber: 64,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>adjustQty(1),
                                                    className: "w-14 h-14 flex items-center justify-center bg-purple-600 hover:bg-purple-500 active:scale-95 text-white rounded-xl transition-all shadow-[0_0_15px_rgba(147,51,234,0.3)]",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                        size: 24
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                                        lineNumber: 72,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                                    lineNumber: 71,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                            lineNumber: 60,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                    lineNumber: 58,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "text-xs font-bold text-slate-500 uppercase ml-2 mb-3 block",
                                            children: "Unitat"
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                            lineNumber: 79,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex gap-2 overflow-x-auto pb-2 no-scrollbar mask-linear-fade-right",
                                            children: UNITS.map((u)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>updateItemUnit(u),
                                                    className: `px-6 py-3 rounded-xl font-bold text-sm whitespace-nowrap transition-all border ${activeItem.unit === u ? 'bg-white text-black border-white shadow-[0_0_15px_rgba(255,255,255,0.3)] scale-105' : 'bg-slate-800 text-slate-400 border-slate-700 hover:border-slate-500'}`,
                                                    children: u
                                                }, u, false, {
                                                    fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                                    lineNumber: 82,
                                                    columnNumber: 21
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                            lineNumber: 80,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                    lineNumber: 78,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: onConfirm,
                                    className: "w-full bg-linear-to-r from-purple-600 to-pink-600 text-white py-4 rounded-2xl font-black text-lg shadow-xl active:scale-[0.98] transition-transform flex items-center justify-center gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                            size: 24,
                                            strokeWidth: 3
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                            lineNumber: 95,
                                            columnNumber: 17
                                        }, this),
                                        "Afegir a la recepta"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                    lineNumber: 94,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "h-4 sm:hidden"
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                                    lineNumber: 99,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                            lineNumber: 41,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
                    lineNumber: 33,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
            lineNumber: 23,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
}
_c = IngredientActionSheet;
var _c;
__turbopack_context__.k.register(_c, "IngredientActionSheet");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/ingredients/IngredientTools.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CalculatorGrid",
    ()=>CalculatorGrid,
    "SearchHeader",
    ()=>SearchHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
// src/components/recipes/editor/ingredients/IngredientTools.tsx
'use client';
;
;
;
function SearchHeader({ query, setQuery, selectedCategory, setSelectedCategory, labels, categories }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col gap-3 p-3 z-20 shrink-0",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-y-0 left-3 flex items-center pointer-events-none",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                            className: "text-slate-500",
                            size: 16
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                            lineNumber: 25,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                        lineNumber: 24,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        value: query,
                        onChange: (e)=>setQuery(e.target.value),
                        placeholder: labels.search_placeholder,
                        "data-testid": "recipe-ingredient-search",
                        className: "w-full bg-slate-900/50 border border-slate-700/50 rounded-xl py-2 pl-9 pr-9 text-sm text-white outline-none focus:border-purple-500 focus:bg-slate-900 transition-all placeholder:text-slate-600"
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                        lineNumber: 27,
                        columnNumber: 9
                    }, this),
                    query && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setQuery(''),
                        className: "absolute inset-y-0 right-2 flex items-center p-1 text-slate-500 hover:text-white",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                            size: 14
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                            lineNumber: 34,
                            columnNumber: 141
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                        lineNumber: 34,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-2 overflow-x-auto no-scrollbar mask-linear-fade-right pb-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CategoryPill, {
                        active: selectedCategory === 'ALL',
                        onClick: ()=>setSelectedCategory('ALL'),
                        label: labels.category_all
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                        lineNumber: 39,
                        columnNumber: 9
                    }, this),
                    categories.map((cat)=>// Use String(cat) per seguretat visual
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CategoryPill, {
                            active: selectedCategory === cat,
                            onClick: ()=>setSelectedCategory(cat),
                            label: String(cat)
                        }, String(cat), false, {
                            fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                            lineNumber: 42,
                            columnNumber: 11
                        }, this))
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
}
_c = SearchHeader;
function CategoryPill({ active, onClick, label }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        onClick: onClick,
        className: `px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wide whitespace-nowrap transition-all border ${active ? 'bg-white text-black border-white shadow-lg' : 'bg-slate-800/50 text-slate-400 border-slate-700/30 hover:bg-slate-700'}`,
        children: label
    }, void 0, false, {
        fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, this);
}
_c1 = CategoryPill;
function CalculatorGrid({ presets, inventory, currentIngredients, onQuickAdd, emptyLabel }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "h-full overflow-y-auto p-2 sm:p-4 custom-scrollbar relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-9 gap-2 pb-32",
                children: presets.map((preset)=>{
                    const inPantry = inventory.some((i)=>i.name.toLowerCase().includes(preset.name.toLowerCase()));
                    const selectedItem = currentIngredients.find((i)=>i.name === preset.name);
                    const count = selectedItem ? selectedItem.quantity : 0;
                    const unitDisplay = selectedItem ? selectedItem.unit : preset.defaultUnit;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
                        whileTap: {
                            scale: 0.9
                        },
                        onClick: ()=>onQuickAdd(preset),
                        "data-testid": `recipe-ingredient-${preset.id}`,
                        className: `
                relative flex flex-col items-center justify-center gap-1 p-1 h-20 sm:h-24 rounded-xl border transition-all text-center group overflow-hidden
                ${count > 0 ? 'bg-purple-900/20 border-purple-500/50 shadow-[inset_0_0_15px_rgba(168,85,247,0.1)]' : 'bg-slate-800/30 border-slate-700/30 hover:border-slate-600 hover:bg-slate-800/50'}
              `,
                        children: [
                            inPantry && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-emerald-500 rounded-full shadow-[0_0_6px_rgba(16,185,129,0.8)] z-10"
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                                lineNumber: 94,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-3xl drop-shadow-md filter select-none",
                                children: preset.emoji
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                                lineNumber: 96,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `text-[9px] font-bold leading-tight line-clamp-1 w-full px-1 ${count > 0 ? 'text-purple-200' : 'text-slate-400'}`,
                                children: preset.name
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                                lineNumber: 97,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                                children: count > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                    initial: {
                                        scale: 0
                                    },
                                    animate: {
                                        scale: 1
                                    },
                                    exit: {
                                        scale: 0
                                    },
                                    className: "absolute top-1 left-1 bg-white text-black text-[9px] font-black px-1.5 py-0.5 rounded shadow-lg min-w-4.5",
                                    children: [
                                        count < 10 && count % 1 === 0 ? count : Math.round(count),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-[7px] opacity-60 ml-0.5",
                                            children: unitDisplay
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                                            lineNumber: 109,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                                    lineNumber: 103,
                                    columnNumber: 19
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                                lineNumber: 101,
                                columnNumber: 15
                            }, this)
                        ]
                    }, preset.id, true, {
                        fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                        lineNumber: 80,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                lineNumber: 72,
                columnNumber: 7
            }, this),
            presets.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col items-center justify-center h-40 opacity-50",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-3xl mb-2",
                        children: "🤷‍♂️"
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                        lineNumber: 120,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs font-medium text-slate-500",
                        children: emptyLabel
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                        lineNumber: 121,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
                lineNumber: 119,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/ingredients/IngredientTools.tsx",
        lineNumber: 71,
        columnNumber: 5
    }, this);
}
_c2 = CalculatorGrid;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "SearchHeader");
__turbopack_context__.k.register(_c1, "CategoryPill");
__turbopack_context__.k.register(_c2, "CalculatorGrid");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/ingredients/IngredientDock.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IngredientDock",
    ()=>IngredientDock
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$basket$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingBasket$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/shopping-basket.js [app-client] (ecmascript) <export default as ShoppingBasket>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/sparkles.js [app-client] (ecmascript) <export default as Sparkles>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/chevron-up.js [app-client] (ecmascript) <export default as ChevronUp>");
;
var _s = __turbopack_context__.k.signature();
// src/components/editor/IngredientDock.tsx
'use client';
;
;
;
function IngredientDock({ ingredients, onRemove, labels, onOpenLinker }) {
    _s();
    // Estat local per controlar si el dock està desplegat o minimitzat
    const [isExpanded, setIsExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    // Estat buit: sense canvis en disseny, només es mostra si no hi ha ingredients
    if (ingredients.length === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full bg-slate-900/90 backdrop-blur-md border-t border-slate-800 p-4 pb-8 flex items-center justify-center gap-3 text-slate-500 transition-all z-50",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$basket$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingBasket$3e$__["ShoppingBasket"], {
                    size: 20
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                    lineNumber: 24,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-sm font-medium",
                    children: labels.empty
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                    lineNumber: 25,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
            lineNumber: 23,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
        initial: {
            y: 100
        },
        animate: {
            y: 0
        },
        className: "w-full bg-slate-900/95 backdrop-blur-xl border-t border-slate-700/50 shadow-[0_-10px_40px_rgba(0,0,0,0.5)] z-50 flex flex-col relative transition-all duration-300 ease-in-out",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                children: isExpanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        opacity: 0,
                        scale: 0.8
                    },
                    animate: {
                        opacity: 1,
                        scale: 1
                    },
                    exit: {
                        opacity: 0,
                        scale: 0.8
                    },
                    className: "absolute right-4 -top-5 pointer-events-auto z-50",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: (e)=>{
                            e.stopPropagation(); // Evitem que el click tanqui el dock
                            onOpenLinker();
                        },
                        className: "flex items-center gap-2 bg-slate-900/90 backdrop-blur-md border border-emerald-500/50 text-emerald-300 px-4 py-2 rounded-full shadow-xl hover:bg-emerald-900/20 hover:scale-105 transition-all active:scale-95 group ring-1 ring-white/10",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"], {
                                className: "w-4 h-4 group-hover:animate-spin-slow text-emerald-400"
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                                lineNumber: 54,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xs font-black uppercase tracking-wider",
                                children: "Calcular"
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                                lineNumber: 55,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                        lineNumber: 47,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                    lineNumber: 41,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>setIsExpanded(!isExpanded),
                className: "flex items-center justify-between px-4 py-3 border-b border-slate-800/50 bg-slate-900/50 hover:bg-slate-800/50 transition-colors w-full cursor-pointer focus:outline-none",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "bg-purple-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full shadow-lg shadow-purple-500/30",
                            children: ingredients.length
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                            lineNumber: 69,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-xs font-bold text-slate-300 uppercase tracking-widest",
                            children: labels.title
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                            lineNumber: 74,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
                            size: 16,
                            className: `text-slate-400 transition-transform duration-300 ${isExpanded ? 'rotate-180' : 'rotate-0'}`
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                            lineNumber: 79,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                    lineNumber: 67,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                initial: false,
                animate: {
                    height: isExpanded ? 'auto' : 0,
                    opacity: isExpanded ? 1 : 0
                },
                transition: {
                    type: "spring",
                    stiffness: 300,
                    damping: 30
                },
                className: "overflow-hidden",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-wrap gap-2 max-h-[35vh] overflow-y-auto custom-scrollbar content-start pr-1",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                            mode: "popLayout",
                            children: ingredients.map((ing)=>{
                                const hasLink = !!ing.linkedProductId;
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                    layout: true,
                                    initial: {
                                        scale: 0,
                                        opacity: 0
                                    },
                                    animate: {
                                        scale: 1,
                                        opacity: 1
                                    },
                                    exit: {
                                        scale: 0,
                                        opacity: 0
                                    },
                                    className: `
                      group relative flex items-center gap-2 pl-1.5 pr-2 py-1.5 rounded-xl transition-all cursor-default select-none border
                      ${hasLink ? 'bg-slate-800/80 border-emerald-500/30 hover:border-emerald-500/60' : 'bg-slate-800 border-slate-700 hover:border-red-500/50'}
                    `,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-9 h-9 rounded-lg bg-white flex items-center justify-center overflow-hidden shrink-0 shadow-sm",
                                            children: ing.linkedProductImage ? /* eslint-disable-next-line @next/next/no-img-element */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: ing.linkedProductImage,
                                                className: "w-full h-full object-contain",
                                                alt: ""
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                                                lineNumber: 121,
                                                columnNumber: 25
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xl leading-none",
                                                children: ing.emoji || '🥗'
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                                                lineNumber: 123,
                                                columnNumber: 25
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                                            lineNumber: 118,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-col items-start min-w-0 mr-6",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: `text-xs font-bold truncate max-w-30 ${hasLink ? 'text-white' : 'text-slate-200'}`,
                                                    children: ing.name
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                                                    lineNumber: 128,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-1.5 mt-0.5",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-[9px] text-slate-400 font-mono leading-none",
                                                            children: [
                                                                ing.quantity,
                                                                ing.unit
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                                                            lineNumber: 133,
                                                            columnNumber: 25
                                                        }, this),
                                                        ing.estimatedCost && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-[9px] font-black text-emerald-400 bg-emerald-950/50 px-1 rounded",
                                                            children: [
                                                                Number(ing.estimatedCost).toFixed(2),
                                                                "€"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                                                            lineNumber: 139,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                                                    lineNumber: 132,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                                            lineNumber: 127,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>onRemove(ing.id),
                                            className: "absolute right-1 top-1 bottom-1 w-6 flex items-center justify-center rounded-lg hover:bg-red-500/20 text-slate-500 hover:text-red-400 transition-colors",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                size: 14,
                                                strokeWidth: 3
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                                                lineNumber: 152,
                                                columnNumber: 23
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                                            lineNumber: 148,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, ing.id, true, {
                                    fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                                    lineNumber: 103,
                                    columnNumber: 19
                                }, this);
                            })
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                            lineNumber: 98,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                        lineNumber: 97,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                    lineNumber: 96,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
                lineNumber: 87,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/ingredients/IngredientDock.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
_s(IngredientDock, "MzqrZ0LJxgqPa6EOF1Vxw0pgYA4=");
_c = IngredientDock;
var _c;
__turbopack_context__.k.register(_c, "IngredientDock");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:04d964 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "searchProductsAction",
    ()=>$$RSC_SERVER_ACTION_7
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"40d49c562930eb6e6f0eee10da0020fae5257cecd1":"searchProductsAction"},"app/actions/inventory.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40d49c562930eb6e6f0eee10da0020fae5257cecd1", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "searchProductsAction");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vaW52ZW50b3J5LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEFSWElVOiBzcmMvYXBwL2FjdGlvbnMvaW52ZW50b3J5LnRzXHJcbid1c2Ugc2VydmVyJztcclxuXHJcbmltcG9ydCB7IHogfSBmcm9tICd6b2QnO1xyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gJ25leHQvY2FjaGUnO1xyXG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tICdAL2FkYXB0ZXJzL3N1cGFiYXNlL3NlcnZlcic7XHJcbmltcG9ydCB7IGNvbnRhaW5lciB9IGZyb20gJ0Avc2VydmljZXMvY29udGFpbmVyJztcclxuaW1wb3J0IHsgU3RvcmFnZUxvY2F0aW9uIH0gZnJvbSAnQC9jb3JlL2RvbWFpbi9lbnRpdGllcy9TdG9yYWdlTG9jYXRpb24nO1xyXG5pbXBvcnQgeyBJbnZlbnRvcnlJdGVtIH0gZnJvbSAnQC9jb3JlL2RvbWFpbi9lbnRpdGllcy9JbnZlbnRvcnlJdGVtJzsgLy8gQXNzZWd1cmEndCBxdWUgbCdFbnRpdHkgamEgdMOpIHJvb21JZCBhbCBjb25zdHJ1Y3RvciFcclxuaW1wb3J0IHsgRk9PRF9QUkVTRVRTIH0gZnJvbSAnQC9saWIvZm9vZC1wcmVzZXRzJztcclxuaW1wb3J0IHsgRXhwaXJ5U2FmZXR5U2VydmljZSB9IGZyb20gJ0AvY29yZS9hcHBsaWNhdGlvbi9zZXJ2aWNlcy9FeHBpcnlTYWZldHlTZXJ2aWNlJztcclxuaW1wb3J0IHsgRW1vamlNYXRjaGVyU2VydmljZSB9IGZyb20gJ0AvY29yZS9hcHBsaWNhdGlvbi9zZXJ2aWNlcy9FbW9qaU1hdGNoZXJTZXJ2aWNlJztcclxuaW1wb3J0IHsgZXJyb3IgYXMgbG9nRXJyb3IgfSBmcm9tICdAL2xpYi9sb2dnZXInO1xyXG5pbXBvcnQge1xyXG4gIEludmVudG9yeUl0ZW1TY2hlbWEsXHJcbiAgQ29uc3VtZUl0ZW1TY2hlbWEsXHJcbn0gZnJvbSAnQC9jb3JlL2FwcGxpY2F0aW9uL3NjaGVtYXMvaW5wdXRTY2hlbWFzJztcclxuXHJcbi8vIERlZmluaW0gcXXDqCByZXRvcm5lbSBhIGxhIFVJIChTZXJpYWxpdHphYmxlLCBzZW5zZSBjbGFzc2VzKVxyXG5leHBvcnQgaW50ZXJmYWNlIFByb2R1Y3RSZXN1bHQge1xyXG4gIGlkOiBzdHJpbmc7XHJcbiAgbmFtZTogc3RyaW5nO1xyXG4gIHByaWNlOiBudW1iZXI7XHJcbiAgaW1hZ2U6IHN0cmluZztcclxuICBzb3VyY2U6IHN0cmluZztcclxuICBlbW9qaTogc3RyaW5nO1xyXG4gIHRhZ3M6IHN0cmluZ1tdO1xyXG4gIHF1YW50aXR5QW1vdW50PzogbnVtYmVyO1xyXG4gIHF1YW50aXR5VW5pdD86IHN0cmluZztcclxufVxyXG5cclxuLy8gLS0tIEhFTFBFUlMgLS0tXHJcbmZ1bmN0aW9uIGNhbGN1bGF0ZUV4cGlyeURhdGUobmFtZTogc3RyaW5nLCBlbW9qaT86IHN0cmluZyk6IERhdGUgfCB1bmRlZmluZWQge1xyXG4gIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XHJcbiAgY29uc3QgcHJlc2V0ID0gRk9PRF9QUkVTRVRTLmZpbmQocCA9PlxyXG4gICAgcC5uYW1lLnRvTG93ZXJDYXNlKCkgPT09IG5hbWUudG9Mb3dlckNhc2UoKSB8fFxyXG4gICAgKGVtb2ppICYmIHAuZW1vamkgPT09IGVtb2ppKVxyXG4gICk7XHJcbiAgaWYgKHByZXNldCkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gbmV3IERhdGUoKTtcclxuICAgIHJlc3VsdC5zZXREYXRlKG5vdy5nZXREYXRlKCkgKyBwcmVzZXQuZXhwaXJhdGlvbkRheXMpO1xyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxuICB9XHJcbiAgcmV0dXJuIHVuZGVmaW5lZDtcclxufVxyXG5cclxuLy8gQWN0dWFsaXR6ZW0gbCdzY2hlbWEgcGVyIGFjY2VwdGFyIHJvb21JZFxyXG5jb25zdCBCYXRjaEludmVudG9yeVNjaGVtYSA9IHouYXJyYXkoSW52ZW50b3J5SXRlbVNjaGVtYS5vbWl0KHsgdXNlcklkOiB0cnVlIH0pLmV4dGVuZCh7IHJvb21JZDogei5zdHJpbmcoKS5vcHRpb25hbCgpIH0pKTtcclxuXHJcbmZ1bmN0aW9uIGdldFpvZEVycm9yKGVycm9yOiB6LlpvZEVycm9yPHVua25vd24+KTogc3RyaW5nIHsgcmV0dXJuIGVycm9yLmlzc3Vlc1swXT8ubWVzc2FnZSB8fCBcIkRhZGVzIGludsOgbGlkZXNcIjsgfVxyXG5mdW5jdGlvbiBnZXRFcnJvck1lc3NhZ2UoZXJyb3I6IHVua25vd24pOiBzdHJpbmcgeyByZXR1cm4gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBTdHJpbmcoZXJyb3IpOyB9XHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gMC4gR0VUIElOVkVOVE9SWSAoTk9WQSBBQ0NJw5MgUEVSIExMSVNUQVIpXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SW52ZW50b3J5QWN0aW9uKHJvb21JZD86IHN0cmluZykge1xyXG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgaWYgKCF1c2VyKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfTtcclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlcG8gPSBjb250YWluZXIuZ2V0SW52ZW50b3J5UmVwbyhzdXBhYmFzZSk7XHJcbiAgICAvLyBDcmlkZW0gYWwgbm91IG3DqHRvZGUgZGVsIHJlcG8gcXVlIHZhbSBjcmVhciBhbCBwYXMgYW50ZXJpb3JcclxuICAgIGNvbnN0IGl0ZW1zID0gYXdhaXQgcmVwby5maW5kQnlDb250ZXh0KHVzZXIuaWQsIHJvb21JZCk7XHJcblxyXG4gICAgLy8gU2VyaWFsaXR6ZW0gZGF0ZXMgcGVyIGFsIGNsaWVudFxyXG4gICAgY29uc3Qgc2VyaWFsaXplZCA9IGl0ZW1zLm1hcChpID0+ICh7XHJcbiAgICAgIC4uLmkudG9QcmltaXRpdmVzKCksXHJcbiAgICAgIGV4cGlyeURhdGU6IGkuZXhwaXJ5RGF0ZSA/IGkuZXhwaXJ5RGF0ZS50b0lTT1N0cmluZygpIDogbnVsbCxcclxuICAgICAgYWRkZWRBdDogaS5hZGRlZEF0LnRvSVNPU3RyaW5nKCksXHJcbiAgICAgIHJvb21JZDogaS5yb29tSWQgfHwgdW5kZWZpbmVkXHJcbiAgICB9KSk7XHJcblxyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgZGF0YTogc2VyaWFsaXplZCB9O1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldEVycm9yTWVzc2FnZShlcnJvcikgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAxLiBBREQgSVRFTSAoQW1iIHN1cG9ydCBSb29tKVxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFkZEl0ZW1BY3Rpb24oZm9ybURhdGE6IEZvcm1EYXRhKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICAgIGlmICghdXNlcikgdGhyb3cgbmV3IEVycm9yKCdVbmF1dGhvcml6ZWQnKTtcclxuXHJcbiAgICBjb25zdCBuYW1lID0gU3RyaW5nKGZvcm1EYXRhLmdldCgnbmFtZScpIHx8ICdQcm9kdWN0ZScpO1xyXG4gICAgbGV0IGVtb2ppID0gZm9ybURhdGEuZ2V0KCdlbW9qaScpPy50b1N0cmluZygpIHx8ICfwn5OmJztcclxuICAgIGNvbnN0IHJvb21JZCA9IGZvcm1EYXRhLmdldCgncm9vbUlkJyk/LnRvU3RyaW5nKCkgfHwgdW5kZWZpbmVkOyAvLyA8LS0tIExMRUdJTSBFTCBDT05URVhUXHJcblxyXG4gICAgLy8gRU5SSVFVSU1FTlQgRU1PSklcclxuICAgIGlmIChlbW9qaSA9PT0gJ/Cfk6YnIHx8IGVtb2ppID09PSAn8J+bkicpIHtcclxuICAgICAgY29uc3QgYmV0dGVyRW1vamkgPSBFbW9qaU1hdGNoZXJTZXJ2aWNlLmdldEVtb2ppKG5hbWUpO1xyXG4gICAgICBpZiAoYmV0dGVyRW1vamkgIT09ICfwn5OmJykgZW1vamkgPSBiZXR0ZXJFbW9qaTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBsb2NhdGlvbiA9IFN0cmluZyhmb3JtRGF0YS5nZXQoJ2xvY2F0aW9uJykgfHwgJ1BBTlRSWScpO1xyXG4gICAgbGV0IGV4cGlyeVN0cmluZyA9IGZvcm1EYXRhLmdldCgnZXhwaXJ5RGF0ZScpPy50b1N0cmluZygpO1xyXG5cclxuICAgIC8vIFNFR1VSRVRBVCBEQVRBXHJcbiAgICBpZiAoIWV4cGlyeVN0cmluZyB8fCBleHBpcnlTdHJpbmcgPT09ICdudWxsJyB8fCBleHBpcnlTdHJpbmcgPT09ICd1bmRlZmluZWQnIHx8IGV4cGlyeVN0cmluZyA9PT0gJycpIHtcclxuICAgICAgY29uc3Qgc2FmZURhdGVZTUQgPSBFeHBpcnlTYWZldHlTZXJ2aWNlLmFwcGx5U2FmZXR5UnVsZXMobmFtZSwgbG9jYXRpb24sIHVuZGVmaW5lZCk7XHJcbiAgICAgIGV4cGlyeVN0cmluZyA9IG5ldyBEYXRlKHNhZmVEYXRlWU1EKS50b0lTT1N0cmluZygpO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHJhd0RhdGEgPSB7XHJcbiAgICAgIHVzZXJJZDogdXNlci5pZCxcclxuICAgICAgbmFtZTogbmFtZSxcclxuICAgICAgcXVhbnRpdHk6IE51bWJlcihmb3JtRGF0YS5nZXQoJ3F1YW50aXR5JykpLFxyXG4gICAgICB1bml0OiBmb3JtRGF0YS5nZXQoJ3VuaXQnKSxcclxuICAgICAgbG9jYXRpb246IGxvY2F0aW9uLFxyXG4gICAgICBleHBpcnlEYXRlOiBleHBpcnlTdHJpbmcsXHJcbiAgICAgIGVtb2ppOiBlbW9qaSxcclxuICAgICAgcHJvZHVjdElkOiBmb3JtRGF0YS5nZXQoJ3Byb2R1Y3RJZCcpICYmIGZvcm1EYXRhLmdldCgncHJvZHVjdElkJykgIT09ICdudWxsJ1xyXG4gICAgICAgID8gU3RyaW5nKGZvcm1EYXRhLmdldCgncHJvZHVjdElkJykpXHJcbiAgICAgICAgOiBudWxsLFxyXG4gICAgICByb29tSWQ6IHJvb21JZCAvLyA8LS0tIFBBU1NFTSBFTCBST09NIElEIEFMIFZBTElEQVRPUlxyXG4gICAgfTtcclxuXHJcbiAgICAvLyBOZWNlc3NpdGVtIGVzdGVuZHJlIGwnc2NoZW1hIGJhc2UgcGVyIGFjY2VwdGFyIHJvb21JZCBzaSBubyBobyBmYVxyXG4gICAgY29uc3QgdmFsaWRhdGlvbiA9IEludmVudG9yeUl0ZW1TY2hlbWEuZXh0ZW5kKHsgcm9vbUlkOiB6LnN0cmluZygpLm9wdGlvbmFsKCkgfSkuc2FmZVBhcnNlKHJhd0RhdGEpO1xyXG5cclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSB7XHJcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZ2V0Wm9kRXJyb3IodmFsaWRhdGlvbi5lcnJvcikgfTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBmaW5hbERhdGEgPSB2YWxpZGF0aW9uLmRhdGE7XHJcbiAgICBjb25zdCBmaW5hbEV4cGlyeURhdGUgPSBmaW5hbERhdGEuZXhwaXJ5RGF0ZSA/IG5ldyBEYXRlKGZpbmFsRGF0YS5leHBpcnlEYXRlKSA6IHVuZGVmaW5lZDtcclxuXHJcbiAgICAvLyBVU0VNIEVMIFJFUE8gRElSRUNUQU1FTlQgKE8gVXNlQ2FzZSBhY3R1YWxpdHphdClcclxuICAgIC8vIFBlciBzaW1wbGlmaWNhciBpIGV2aXRhciB0b2NhciAxMCBhcnhpdXMgZGUgVXNlQ2FzZSwgYXF1w60gY3JpZGFyZW0gYWwgUmVwbyxcclxuICAgIC8vIGphIHF1ZSBBZGRJdGVtVXNlQ2FzZSBwb3RzZXIgbm8gZXNwZXJhIHJvb21JZC5cclxuICAgIC8vIEwnaWRlYWwgc2VyaWEgYWN0dWFsaXR6YXIgQWRkSXRlbVVzZUNhc2UsIHBlcsOyIGNvbSBxdWUgZWwgUmVwbyBqYSDDqXMgbGxlc3Q6XHJcbiAgICBjb25zdCByZXBvID0gY29udGFpbmVyLmdldEludmVudG9yeVJlcG8oc3VwYWJhc2UpO1xyXG5cclxuICAgIGNvbnN0IG5ld0l0ZW0gPSBJbnZlbnRvcnlJdGVtLmNyZWF0ZSh7XHJcbiAgICAgIGlkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxyXG4gICAgICB1c2VySWQ6IHVzZXIuaWQsXHJcbiAgICAgIHJvb21JZDogZmluYWxEYXRhLnJvb21JZCB8fCBudWxsLCAvLyA8LS0tIEFRVUkgRVMgR1VBUkRBIExBIE1BQUdJQVxyXG4gICAgICBuYW1lOiBTdHJpbmcoZmluYWxEYXRhLm5hbWUpLFxyXG4gICAgICBxdWFudGl0eTogTnVtYmVyKGZpbmFsRGF0YS5xdWFudGl0eSksXHJcbiAgICAgIHVuaXQ6IFN0cmluZyhmaW5hbERhdGEudW5pdCksXHJcbiAgICAgIGxvY2F0aW9uOiBmaW5hbERhdGEubG9jYXRpb24gYXMgU3RvcmFnZUxvY2F0aW9uLFxyXG4gICAgICBleHBpcnlEYXRlOiBmaW5hbEV4cGlyeURhdGUsXHJcbiAgICAgIGVtb2ppOiBTdHJpbmcoZmluYWxEYXRhLmVtb2ppKSxcclxuICAgICAgYWRkZWRBdDogbmV3IERhdGUoKSxcclxuICAgICAgcHJvZHVjdElkOiBmaW5hbERhdGEucHJvZHVjdElkXHJcbiAgICB9KTtcclxuXHJcbiAgICBhd2FpdCByZXBvLnNhdmUobmV3SXRlbSk7XHJcblxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvaW52ZW50b3J5Jyk7XHJcbiAgICBpZiAocm9vbUlkKSByZXZhbGlkYXRlUGF0aChgL3Jvb21zLyR7cm9vbUlkfWApOyAvLyBSZXZhbGlkYXIgc2FsYSBzaSBjYWxcclxuXHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcblxyXG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XHJcbiAgICBsb2dFcnJvcihcIvCfkqUgRXJyb3IgZmF0YWwgYSBhZGRJdGVtQWN0aW9uOlwiLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldEVycm9yTWVzc2FnZShlcnJvcikgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAyLiBDT05TVU1FIElURU0gKFNlbnNlIGNhbnZpcywgbCdJRCDDqXMgw7puaWMpXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY29uc3VtZUl0ZW1BY3Rpb24oaXRlbUlkOiBzdHJpbmcsIGFtb3VudDogbnVtYmVyKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHZhbGlkYXRpb24gPSBDb25zdW1lSXRlbVNjaGVtYS5zYWZlUGFyc2UoeyBpdGVtSWQsIGFtb3VudCB9KTtcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldFpvZEVycm9yKHZhbGlkYXRpb24uZXJyb3IpIH07XHJcblxyXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICAgIGNvbnN0IHVzZUNhc2UgPSBjb250YWluZXIuZ2V0Q29uc3VtZUl0ZW0oc3VwYWJhc2UpO1xyXG4gICAgLy8gRWwgVXNlQ2FzZSBub23DqXMgbmVjZXNzaXRhIGwnSUQuIEVsIFJlcG8gdHJvYmFyw6AgbCdpdGVtIHNpZ3VpIGRlIHNhbGEgbyB1c3VhcmkuXHJcbiAgICBhd2FpdCB1c2VDYXNlLmV4ZWN1dGUodmFsaWRhdGlvbi5kYXRhLml0ZW1JZCwgdmFsaWRhdGlvbi5kYXRhLmFtb3VudCk7XHJcblxyXG4gICAgLy8g4pyFIEFGRUdFSVggQUlYw5IgQUwgRklOQUwgREUgVE9UOlxyXG4gICAgLy8gQWl4w7Igb2JsaWdhIGEgTmV4dC5qcyBhIHJlZnJlc2NhciBsZXMgZGFkZXMgZGUgbGEgcnV0YSAvaW52ZW50b3J5IGF1dG9tw6B0aWNhbWVudFxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9pbnZlbnRvcnknKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxuICB9IGNhdGNoIChlcnJvcjogdW5rbm93bikge1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBnZXRFcnJvck1lc3NhZ2UoZXJyb3IpIH07XHJcbiAgfVxyXG59XHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gMy4gVVBEQVRFIElURU1cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbmludGVyZmFjZSBVcGRhdGVJdGVtRFRPIHsgaWQ6IHN0cmluZzsgbmFtZTogc3RyaW5nOyBxdWFudGl0eTogbnVtYmVyOyB1bml0OiBzdHJpbmc7IGVtb2ppOiBzdHJpbmc7IGV4cGlyeURhdGU/OiBEYXRlIHwgbnVsbDsgbG9jYXRpb24/OiBzdHJpbmc7IHJvb21JZD86IHN0cmluZzsgfVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUl0ZW1BY3Rpb24oaXRlbTogVXBkYXRlSXRlbURUTykge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgICBpZiAoIXVzZXIpIHRocm93IG5ldyBFcnJvcignVW5hdXRob3JpemVkJyk7XHJcblxyXG4gICAgaWYgKCFpdGVtLmlkIHx8ICFpdGVtLm5hbWUpIHRocm93IG5ldyBFcnJvcihcIkRhZGVzIGluY29tcGxldGVzXCIpO1xyXG5cclxuICAgIGNvbnN0IHJlcG8gPSBjb250YWluZXIuZ2V0SW52ZW50b3J5UmVwbyhzdXBhYmFzZSk7XHJcblxyXG4gICAgLy8gUmVjdXBlcmVtIGwnaXRlbSBvcmlnaW5hbCBwZXIgbm8gcGVyZHJlIGVsIHJvb21JZFxyXG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCByZXBvLmZpbmRCeUlkKGl0ZW0uaWQpO1xyXG4gICAgaWYgKCFleGlzdGluZykgdGhyb3cgbmV3IEVycm9yKFwiSXRlbSBub3QgZm91bmRcIik7XHJcblxyXG4gICAgLy8gQ3JlZW0gbGEgbm92YSB2ZXJzacOzIChJbW11dGFibGUpXHJcbiAgICBjb25zdCB1cGRhdGVkID0gSW52ZW50b3J5SXRlbS5jcmVhdGUoe1xyXG4gICAgICAuLi5leGlzdGluZy50b1ByaW1pdGl2ZXMoKSwgLy8gTWFudGVuaW0gZGFkZXMgdmVsbGVzIChjb20gYWRkZWRBdCwgcm9vbUlkLCB1c2VySWQpXHJcbiAgICAgIG5hbWU6IGl0ZW0ubmFtZSxcclxuICAgICAgZW1vamk6IGl0ZW0uZW1vamkgfHwgJ/Cfk6YnLFxyXG4gICAgICBxdWFudGl0eTogaXRlbS5xdWFudGl0eSxcclxuICAgICAgdW5pdDogaXRlbS51bml0LFxyXG4gICAgICBsb2NhdGlvbjogKGl0ZW0ubG9jYXRpb24gYXMgU3RvcmFnZUxvY2F0aW9uKSB8fCBTdG9yYWdlTG9jYXRpb24uUEFOVFJZLFxyXG4gICAgICBleHBpcnlEYXRlOiBpdGVtLmV4cGlyeURhdGUgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAvLyByb29tSWQgZXMgbWFudMOpIGRlIGwnb3JpZ2luYWwgYSB0b1ByaW1pdGl2ZXMoKSwgbyBlbCBwb3RzIGZvcsOnYXIgc2kgdm9sZ3Vlc3NpcyBtb3VyZSdsXHJcbiAgICB9KTtcclxuXHJcbiAgICBhd2FpdCByZXBvLnNhdmUodXBkYXRlZCk7XHJcblxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvaW52ZW50b3J5Jyk7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcbiAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZ2V0RXJyb3JNZXNzYWdlKGVycm9yKSB9O1xyXG4gIH1cclxufVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIDQuIERFTEVURSBJVEVNIChJZ3VhbClcclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVJdGVtQWN0aW9uKGl0ZW1JZDogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGlmICghaXRlbUlkKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiSUQgaW52w6BsaWRcIiB9O1xyXG5cclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICAvLyBBcXXDrSBwb2Ryw61lbSB1c2FyIGVsIFJlcG8gZGlyZWN0YW1lbnQgdGFtYsOpXHJcbiAgICBjb25zdCB1c2VDYXNlID0gY29udGFpbmVyLmdldERlbGV0ZUl0ZW0oc3VwYWJhc2UpO1xyXG4gICAgYXdhaXQgdXNlQ2FzZS5leGVjdXRlKGl0ZW1JZCk7XHJcblxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvaW52ZW50b3J5Jyk7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcbiAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZ2V0RXJyb3JNZXNzYWdlKGVycm9yKSB9O1xyXG4gIH1cclxufVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIDUuIEJVTEsgQUREIElURU1TXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYWRkQmF0Y2hJdGVtc0FjdGlvbihpdGVtczogei5pbmZlcjx0eXBlb2YgQmF0Y2hJbnZlbnRvcnlTY2hlbWE+KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICAgIGlmICghdXNlcikgdGhyb3cgbmV3IEVycm9yKCdVbmF1dGhvcml6ZWQnKTtcclxuXHJcbiAgICBjb25zdCB2YWxpZGF0aW9uID0gQmF0Y2hJbnZlbnRvcnlTY2hlbWEuc2FmZVBhcnNlKGl0ZW1zKTtcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldFpvZEVycm9yKHZhbGlkYXRpb24uZXJyb3IpIH07XHJcblxyXG4gICAgY29uc3QgcmVwbyA9IGNvbnRhaW5lci5nZXRJbnZlbnRvcnlSZXBvKHN1cGFiYXNlKTtcclxuXHJcbiAgICBjb25zdCBlbnRpdGllcyA9IHZhbGlkYXRpb24uZGF0YS5tYXAoZCA9PiB7XHJcbiAgICAgIGxldCBmaW5hbERhdGUgPSBkLmV4cGlyeURhdGUgPyBuZXcgRGF0ZShkLmV4cGlyeURhdGUpIDogdW5kZWZpbmVkO1xyXG4gICAgICBpZiAoIWZpbmFsRGF0ZSkge1xyXG4gICAgICAgIGZpbmFsRGF0ZSA9IGNhbGN1bGF0ZUV4cGlyeURhdGUoZC5uYW1lLCBkLmVtb2ppKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIEludmVudG9yeUl0ZW0uY3JlYXRlKHtcclxuICAgICAgICBpZDogY3J5cHRvLnJhbmRvbVVVSUQoKSxcclxuICAgICAgICB1c2VySWQ6IHVzZXIuaWQsXHJcbiAgICAgICAgcm9vbUlkOiBkLnJvb21JZCB8fCBudWxsLCAvLyA8LS0tIEFRVUkgVEFNQsOJXHJcbiAgICAgICAgbmFtZTogZC5uYW1lLFxyXG4gICAgICAgIHF1YW50aXR5OiBkLnF1YW50aXR5LFxyXG4gICAgICAgIHVuaXQ6IGQudW5pdCxcclxuICAgICAgICBsb2NhdGlvbjogZC5sb2NhdGlvbiBhcyBTdG9yYWdlTG9jYXRpb24sXHJcbiAgICAgICAgZXhwaXJ5RGF0ZTogZmluYWxEYXRlLFxyXG4gICAgICAgIGVtb2ppOiBkLmVtb2ppIHx8ICfwn5OmJyxcclxuICAgICAgICBhZGRlZEF0OiBuZXcgRGF0ZSgpLFxyXG4gICAgICAgIHByb2R1Y3RJZDogZC5wcm9kdWN0SWRcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBhd2FpdCByZXBvLnNhdmVCYXRjaChlbnRpdGllcyk7XHJcblxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvaW52ZW50b3J5Jyk7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcblxyXG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XHJcbiAgICBsb2dFcnJvcignRXJyb3IgaW4gYWRkQmF0Y2hJdGVtc0FjdGlvbjonLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldEVycm9yTWVzc2FnZShlcnJvcikgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyA2LiBRVUlDSyBBRERcclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBxdWlja0FkZEludmVudG9yeUFjdGlvbihcclxuICBuYW1lOiBzdHJpbmcsXHJcbiAgcXVhbnRpdHk6IG51bWJlcixcclxuICB1bml0OiBzdHJpbmcsXHJcbiAgZW1vamk/OiBzdHJpbmcsXHJcbiAgcHJvZHVjdElkPzogc3RyaW5nLFxyXG4gIHJvb21JZD86IHN0cmluZyAvLyA8LS0tIE5PVSBQQVLDgE1FVFJFXHJcbikge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgICBpZiAoIXVzZXIpIHRocm93IG5ldyBFcnJvcihcIlVuYXV0aG9yaXplZFwiKTtcclxuXHJcbiAgICBjb25zdCBleHBpcnlZTUQgPSBFeHBpcnlTYWZldHlTZXJ2aWNlLmFwcGx5U2FmZXR5UnVsZXMobmFtZSwgJ1BBTlRSWScsIHVuZGVmaW5lZCk7XHJcbiAgICBjb25zdCBleHBpcnlEYXRlID0gbmV3IERhdGUoZXhwaXJ5WU1EKTtcclxuXHJcbiAgICBjb25zdCByZXBvID0gY29udGFpbmVyLmdldEludmVudG9yeVJlcG8oc3VwYWJhc2UpO1xyXG5cclxuICAgIGNvbnN0IG5ld0l0ZW0gPSBJbnZlbnRvcnlJdGVtLmNyZWF0ZSh7XHJcbiAgICAgIGlkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxyXG4gICAgICB1c2VySWQ6IHVzZXIuaWQsXHJcbiAgICAgIHJvb21JZDogcm9vbUlkIHx8IG51bGwsIC8vIDwtLS0gR1VBUkRFTVxyXG4gICAgICBuYW1lOiBuYW1lLFxyXG4gICAgICBxdWFudGl0eTogcXVhbnRpdHksXHJcbiAgICAgIHVuaXQ6IHVuaXQsXHJcbiAgICAgIGxvY2F0aW9uOiBTdG9yYWdlTG9jYXRpb24uUEFOVFJZLFxyXG4gICAgICBleHBpcnlEYXRlOiBleHBpcnlEYXRlLFxyXG4gICAgICBlbW9qaTogZW1vamkgfHwgJ/Cfk6YnLFxyXG4gICAgICBhZGRlZEF0OiBuZXcgRGF0ZSgpLFxyXG4gICAgICBwcm9kdWN0SWQ6IHByb2R1Y3RJZCB8fCBudWxsXHJcbiAgICB9KTtcclxuXHJcbiAgICBhd2FpdCByZXBvLnNhdmUobmV3SXRlbSk7XHJcblxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvaW52ZW50b3J5Jyk7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcblxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBsb2dFcnJvcihcIkVycm9yIHF1aWNrIGFkZGluZyB0byBpbnZlbnRvcnk6XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciBhZmVnaW50IGEgbCdpbnZlbnRhcmkuXCIgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyA3LiBTRUFSQ0ggKElndWFsLCBubyBkZXDDqG4gZGUgbGEgc2FsYSlcclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZWFyY2hQcm9kdWN0c0FjdGlvbihxdWVyeTogc3RyaW5nKTogUHJvbWlzZTx7IHN1Y2Nlc3M6IGJvb2xlYW4sIGRhdGE/OiBQcm9kdWN0UmVzdWx0W10sIGVycm9yPzogc3RyaW5nIH0+IHtcclxuICBpZiAoIXF1ZXJ5IHx8IHF1ZXJ5Lmxlbmd0aCA8IDMpIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGRhdGE6IFtdIH07XHJcblxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gICAgY29uc3Qgc2VhcmNoZXIgPSBjb250YWluZXIuZ2V0U2VhcmNoQW5kQ2FjaGVQcm9kdWN0cyhzdXBhYmFzZSk7XHJcbiAgICBjb25zdCBwcm9kdWN0cyA9IGF3YWl0IHNlYXJjaGVyLmV4ZWN1dGUocXVlcnkpO1xyXG5cclxuICAgIGNvbnN0IHNlcmlhbGl6ZWQgPSBwcm9kdWN0cy5tYXAocCA9PiAoe1xyXG4gICAgICBpZDogcC5wcm9wcy5pZCxcclxuICAgICAgbmFtZTogcC5wcm9wcy5uYW1lLFxyXG4gICAgICBwcmljZTogcC5wcm9wcy5wcmljZSxcclxuICAgICAgaW1hZ2U6IHAucHJvcHMuaW1hZ2UsXHJcbiAgICAgIHNvdXJjZTogcC5wcm9wcy5zb3VyY2UsXHJcbiAgICAgIGVtb2ppOiBwLnByb3BzLmVtb2ppLFxyXG4gICAgICB0YWdzOiBwLnByb3BzLnRhZ3NcclxuICAgIH0pKTtcclxuXHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCBkYXRhOiBzZXJpYWxpemVkIH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGxvZ0Vycm9yKFwiRXJyb3IgY2VyY2FudCBwcm9kdWN0ZXM6XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJObyBzJ2hhIHBvZ3V0IGNvbXBsZXRhciBsYSBjZXJjYS5cIiB9O1xyXG4gIH1cclxufVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIDguIERFTEVURSBCQVRDSCAoSWd1YWwpXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlQmF0Y2hJdGVtc0FjdGlvbihpZHM6IHN0cmluZ1tdKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICAgIGlmICghdXNlcikgdGhyb3cgbmV3IEVycm9yKCdVbmF1dGhvcml6ZWQnKTtcclxuXHJcbiAgICBjb25zdCByZXBvID0gY29udGFpbmVyLmdldEludmVudG9yeVJlcG8oc3VwYWJhc2UpO1xyXG4gICAgYXdhaXQgcmVwby5iYXRjaERlbGV0ZShpZHMpO1xyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvZGFzaGJvYXJkL2ludmVudG9yeScpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldEVycm9yTWVzc2FnZShlcnJvcikgfTtcclxuICB9XHJcbn1cclxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJpU0FvVnNCLGlNQUFBIn0=
}),
"[project]/lib/taxonamy/fruit.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FRUIT_CATEGORY",
    ()=>FRUIT_CATEGORY
]);
const FRUIT_CATEGORY = {
    id: 'fruit',
    label: 'Fruita',
    emoji: '🍎',
    gradient: 'from-red-900/30 to-orange-900/30 border-red-800/40',
    subcategories: [
        // --- 🍌 BÀSICS DE FRUITERIA ---
        {
            id: 'banana',
            label: 'Plàtan',
            emoji: '🍌',
            query: 'Plàtan banana',
            exclude: [
                'iogurt',
                'batut',
                'postre',
                'gelat',
                'xips',
                'fregit',
                'sec',
                'deshidratat',
                'galeta',
                'pastís',
                'brioix',
                'CAN'
            ]
        },
        {
            id: 'apple',
            label: 'Pomes',
            emoji: '🍎',
            // Totes les varietats fresques
            query: [
                'Poma Golden',
                'Poma Fuji',
                'Poma Royal Gala',
                'Poma Granny Smith'
            ],
            exclude: [
                'suc',
                'compota',
                'pastís',
                'sidra',
                'vinagre',
                'iogurt',
                'bossa',
                'xips',
                'forn',
                'caramel'
            ]
        },
        {
            id: 'pear',
            label: 'Peres',
            emoji: '🍐',
            query: [
                'Pera Conferència',
                'Pera Blanquilla',
                'Pera Ercolini',
                'Pera Llimonera'
            ],
            exclude: [
                'suc',
                'iogurt',
                'almívar',
                'pot',
                'conserva',
                'LA COLLITA',
                'Tomàquet'
            ]
        },
        // --- 🍊 CÍTRICS ---
        {
            id: 'orange',
            label: 'Taronges',
            emoji: '🍊',
            query: 'Taronja Premium',
            exclude: [
                'suc',
                'fanta',
                'kas',
                'refresc',
                'melmelada',
                'gelat',
                'iogurt',
                'galeta',
                'xocolata',
                'ambientador',
                'sabó',
                'detergent',
                'GRANINI' // "Taronja" surt molt a neteja
            ]
        },
        {
            id: 'mandarin',
            label: 'Mandarina',
            emoji: '🍊',
            query: [
                'Mans Mandarina'
            ],
            exclude: [
                'suc',
                'iogurt',
                'sorbet'
            ]
        },
        {
            id: 'lemon',
            label: 'Llimona/Llima',
            emoji: '🍋',
            query: [
                'LA COLLITA Llimona',
                'Llima'
            ],
            exclude: [
                'suc',
                'refresc',
                'fanta',
                'schweppes',
                'cervesa',
                'galeta',
                'iogurt',
                'postre',
                'neteja',
                'rentavaixelles',
                'lleixiu' // Molt important excloure neteja
            ]
        },
        // --- 🍓 VERMELLS I BOSC ---
        {
            id: 'strawberry',
            label: 'Maduixes',
            emoji: '🍓',
            query: [
                'Maduixa en caixa'
            ],
            exclude: [
                'iogurt',
                'batut',
                'melmelada',
                'gelat',
                'nata',
                'galeta',
                'caramel',
                'xiclet',
                'suc'
            ]
        },
        {
            id: 'cherry',
            label: 'Cireres/Picotes',
            emoji: '🍒',
            query: [
                'Cireres'
            ],
            exclude: [
                'iogurt',
                'melmelada',
                'bombó',
                'licor',
                'confitada',
                'pot'
            ]
        },
        {
            id: 'berries',
            label: 'Fruits del Bosc',
            emoji: '🫐',
            query: [
                'Nabius',
                'Gerds',
                'Mores',
                'Grosella'
            ],
            exclude: [
                'iogurt',
                'melmelada',
                'congelat',
                'sec',
                'deshidratat',
                'BICENTURY',
                'Coquetes',
                'moro'
            ]
        },
        // --- 🥝 TROPICAL ---
        {
            id: 'avocado',
            label: 'Alvocat',
            emoji: '🥑',
            query: [
                'Alvocat',
                'Alvocat hass'
            ],
            exclude: [
                'guacamole',
                'salsa',
                'oli',
                'crema'
            ] // Evitem el guacamole preparat
        },
        {
            id: 'kiwi',
            label: 'Kiwi',
            emoji: '🥝',
            query: [
                'Kiwi verd',
                'Kiwi groc',
                'Kiwi gold'
            ],
            exclude: [
                'iogurt',
                'suc',
                'gelat'
            ]
        },
        {
            id: 'mango',
            label: 'Mango',
            emoji: '🥭',
            query: [
                'Mango fresc'
            ],
            exclude: [
                'suc',
                'iogurt',
                'deshidratat',
                'tires',
                'chutney',
                'salsa'
            ]
        },
        {
            id: 'pineapple',
            label: 'Pinya',
            emoji: '🍍',
            query: [
                'Pinya'
            ],
            // Molta cura amb la pinya en llauna (almívar/suc)
            exclude: [
                'suc',
                'almívar',
                'llauna',
                'pot',
                'rodanxes',
                'trossos',
                'pizza',
                'iogurt'
            ]
        },
        {
            id: 'papaya',
            label: 'Papaia',
            emoji: '🥭',
            query: 'Papaies',
            exclude: [
                'deshidratada',
                'suc'
            ]
        },
        // --- 🍇 ESTACIONALS ---
        {
            id: 'melon',
            label: 'Meló',
            emoji: '🍈',
            query: [
                'Meló',
                'Melons'
            ],
            exclude: [
                'pernil',
                'xiclet',
                'iogurt',
                'tallejat',
                'PUERTO'
            ]
        },
        {
            id: 'watermelon',
            label: 'Síndria',
            emoji: '🍉',
            query: [
                'Síndries tmpoc hi an'
            ],
            exclude: [
                'xiclet',
                'caramel',
                'gaspatxo',
                'tallejada'
            ]
        },
        {
            id: 'peach',
            label: 'Préssec/Nectarina',
            emoji: '🍑',
            query: [
                'Préssecs no i han '
            ],
            exclude: [
                'suc',
                'iogurt',
                'almívar',
                'pot',
                'melmelada',
                'sec',
                'orellana'
            ]
        },
        {
            id: 'grape',
            label: 'Raïm',
            emoji: '🍇',
            query: [
                'Raïm blanc',
                'Raïm negre',
                'Raïm sense llavors'
            ],
            exclude: [
                'suc',
                'most',
                'panses',
                'vi',
                'cava'
            ] // "Panses" i "Vi" són els enemics aquí
        },
        {
            id: 'pomegranate',
            label: 'Magrana',
            emoji: '🍎',
            query: 'Punica granatum',
            exclude: [
                'suc',
                'iogurt'
            ]
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/vegetables.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VEGETABLES_CATEGORY",
    ()=>VEGETABLES_CATEGORY
]);
const VEGETABLES_CATEGORY = {
    id: 'vegetables',
    label: 'Verdura',
    emoji: '🥦',
    gradient: 'from-green-900/30 to-emerald-900/30 border-green-800/40',
    subcategories: [
        // --- BÀSICS CUINA ---
        {
            id: 'potato',
            label: 'Patates',
            emoji: '🥔',
            query: [
                'Patates',
                'Patata',
                'Patates mini en bossa'
            ],
            // Exclusions MOLT importants per netejar la llista
            exclude: [
                'xips',
                'fregides',
                'bravas',
                'congelades',
                'truita',
                'gnocchi',
                'snack',
                'pelades',
                'tonyina',
                'farcellets',
                'preparada',
                'microones',
                'deluxe',
                'puré',
                'lay\'s',
                'pringles',
                'ruffles',
                'doritos',
                'cheetos',
                'Ceba',
                'SANTA ANA',
                'fregir',
                'TERRA I TAST',
                'TERESA'
            ]
        },
        {
            id: 'onion',
            label: 'Cebes',
            emoji: '🧅',
            query: [
                'Ceba seca',
                'Ceba figueres',
                'Ceba morada',
                'Ceba dolça'
            ],
            exclude: [
                'fregida',
                'cruixent',
                'congelada',
                'caramel',
                'pot',
                'en pols',
                'LENOR',
                'PIERNAS GRANADA'
            ]
        },
        {
            id: 'garlic',
            label: 'Alls',
            emoji: '🧄',
            query: 'Alls secs',
            exclude: [
                'talls',
                'picada',
                'salsa',
                'oli'
            ]
        },
        {
            id: 'carrot',
            label: 'Pastanaga',
            emoji: '🥕',
            query: [
                'Pastanaga',
                'Pastanages',
                'fresca'
            ],
            exclude: [
                'ratllada',
                'brot',
                'pastís',
                'suc',
                'Burger',
                'Barreja',
                'PAGO',
                'HIPP'
            ] // Evitem pastanaga ratllada o sucs
        },
        // --- AMANIDA ---
        {
            id: 'lettuce',
            label: 'Enciam',
            emoji: '🥬',
            query: 'Enciam fresc',
            exclude: [
                'bossa'
            ] // Si vols evitar les bosses preparades, sinó treu-ho
        },
        {
            id: 'tomato',
            label: 'Tomàquet',
            emoji: '🍅',
            query: 'Tomàquet amanida',
            exclude: [
                'fregit',
                'triturat',
                'salsa',
                'sec'
            ]
        },
        {
            id: 'tomato_cherry',
            label: 'Cherry',
            emoji: '🍅',
            query: 'Tomàquet cherry',
            exclude: [
                'confitat'
            ]
        },
        {
            id: 'cucumber',
            label: 'Cogombre',
            emoji: '🥒',
            query: 'Cogombre',
            exclude: [
                'in vinagre',
                'adobats'
            ] // Evitem els de pot
        },
        // --- CUINAR ---
        {
            id: 'zucchini',
            label: 'Carbassó',
            emoji: '🥒',
            query: 'Carbassó',
            exclude: [
                'crema',
                'puré',
                'fregit'
            ]
        },
        {
            id: 'eggplant',
            label: 'Albergínia',
            emoji: '🍆',
            query: 'Albergínia',
            exclude: [
                'farcida',
                'arrebossada',
                'crema'
            ]
        },
        // --- 🌶️ PEBROTS MILLORATS ---
        {
            id: 'pepper_red',
            label: 'Pebrot Vermell',
            emoji: '🌶️',
            // ESTRATÈGIA: 
            // 1. "Pebrot vermell": El clàssic.
            // 2. "Pebrot tricolor": Molt important, sovint és l'única manera de comprar-ne.
            // 3. "Pebrot California": És la varietat tècnica del vermell gruixut.
            query: [
                'Pebrot vermell',
                'Pebrot tricolor',
                'Pebrot groc'
            ],
            // EXCLUSIONS:
            // "Piquillo" i "Nyora" solen sortir com a vermells però són conserves o secs.
            // "Escalivat" és el gran enemic aquí.
            exclude: [
                'escalivat',
                'farcit',
                'conserva',
                'melmelada',
                'bitxo',
                'pot',
                'llauna',
                'tires',
                'piquillo',
                'nyora',
                'fregit',
                'cuit',
                'verd',
                'Pebre'
            ]
        },
        {
            id: 'pepper_green',
            label: 'Pebrot Verd/Italià',
            emoji: '🫑',
            // ESTRATÈGIA:
            // 1. "Pebrot verd": El de carn gruixuda.
            // 2. "Pebrot italià": El llarg i prim (el més venut).
            // 3. "Pebrot Padrón": Els petits per fregir.
            query: [
                'Pebrot verd',
                'Pebrot italià',
                'Pebrot Padrón'
            ],
            exclude: [
                'fregit',
                'conserva',
                'vinagre',
                'bitxo',
                'guindilla',
                'IFA'
            ]
        },
        {
            id: 'mushrooms',
            label: 'Bolets',
            emoji: '🍄',
            // ESTRATÈGIA: Busquem les espècies concretes, no la paraula genèrica "Bolet"
            query: [
                'Xampinyó',
                'Portobello',
                'Gírgola',
                'Shiitake',
                'Bolets variats',
                'Mochardon' // Moixernó (a vegades fresc, a vegades sec, l'exclude farà la feina)
            ],
            // FILTRE ANTI-REBOST:
            exclude: [
                'conserva',
                'pot',
                'llauna',
                'sec',
                'deshidratat',
                'crema',
                'brou',
                'congelat',
                'risotto',
                'arròs',
                'fideus',
                'confitat',
                'saltat',
                'Burger' // Sol ser congelat
            ]
        },
        {
            id: 'spinach',
            label: 'Espinacs',
            emoji: '🍃',
            query: 'Espinacs frescos',
            exclude: [
                'congelat',
                'crema',
                'bossa',
                'TERRA I TAST',
                'Raviolis',
                'PETRAS'
            ]
        },
        {
            id: 'pumpkin',
            label: 'Carbassa',
            emoji: '🎃',
            query: 'Carbassa',
            exclude: [
                'crema',
                'cabell',
                'pipes'
            ] // Evitem crema de carbassa o cabell d'àngel
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/meat.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MEAT_CATEGORY",
    ()=>MEAT_CATEGORY
]);
const MEAT_CATEGORY = {
    id: 'meat',
    label: 'Carnisseria',
    emoji: '🥩',
    gradient: 'from-red-900/20 to-rose-900/20 border-red-800/30',
    subcategories: [
        // --- 🐔 POLLASTRE I AUS ---
        {
            id: 'chicken_breast',
            label: 'Pit de Pollastre',
            emoji: '🍗',
            query: [
                'Pit pollastre',
                'Filet de pollastre',
                'Pit de gall d\'indi'
            ],
            mustContain: [
                'pit',
                'filet'
            ],
            exclude: [
                'embotit',
                'cuit',
                'brasa',
                'fiambre',
                'llesques',
                'arrebossat',
                'croquetes',
                'canelons',
                'brou',
                'sopa',
                'gat',
                'gos',
                'piz'
            ]
        },
        {
            id: 'chicken_thigh',
            label: 'Cuixes',
            emoji: '🍗',
            query: [
                'Cuixa pollastre',
                'Pernilets pollastre',
                'Contra cuixa'
            ],
            mustContain: [
                'cuixa',
                'pernilet'
            ],
            exclude: [
                'farcit',
                'congelat',
                'preparat',
                'canelons',
                'brou'
            ]
        },
        {
            id: 'chicken_wings',
            label: 'Aletes',
            emoji: '🍗',
            query: 'Aletes pollastre',
            mustContain: 'Ales',
            exclude: [
                'barbacoa',
                'cuites',
                'congelat',
                'adobades'
            ]
        },
        {
            id: 'chicken_whole',
            label: 'Pollastre Sencer',
            emoji: '🐓',
            query: [
                'Pollastre sencer',
                'Pollastre net'
            ],
            mustContain: 'pollastre',
            exclude: [
                'a l\'ast',
                'cuit',
                'farcit',
                'brou',
                'croquetes'
            ]
        },
        {
            id: 'breaded',
            label: 'Arrebossats/Nuggets',
            emoji: '🍘',
            query: [
                'Pollastre arrebossat',
                'Nuggets'
            ],
            exclude: [
                'congelat',
                'vegetal'
            ]
        },
        // --- 🥩 VEDELLA ---
        {
            id: 'beef_steak',
            label: 'Bistec/Entrecot',
            emoji: '🥩',
            query: [
                'Bistec vedella',
                'Entrecot vedella',
                'Filet vedella'
            ],
            mustContain: [
                'bistec',
                'entrecot',
                'filet'
            ],
            exclude: [
                'hamburguesa',
                'carpaccio',
                'congelat',
                'brou',
                'pastilla'
            ]
        },
        {
            id: 'beef_stew',
            label: 'Vedella Estofar',
            emoji: '🥘',
            query: [
                'Estofat de vedella'
            ],
            exclude: [
                'cuinat',
                'brou',
                'conserva'
            ]
        },
        // --- 🐖 PORC ---
        {
            id: 'pork_loin',
            label: 'Llom',
            emoji: '🐖',
            query: [
                'Llom porc',
                'Cinta de llom'
            ],
            mustContain: 'llom',
            exclude: [
                'embotit',
                'curat',
                'cuit',
                'cap de llom',
                'adobat',
                'fumat',
                'llesques'
            ]
        },
        {
            id: 'pork_ribs',
            label: 'Costelles',
            emoji: '🍖',
            query: [
                'Costella porc',
                'Costelló'
            ],
            mustContain: [
                'costella',
                'costelló'
            ],
            exclude: [
                'barbacoa',
                'adobat',
                'cuit'
            ]
        },
        {
            id: 'sausages',
            label: 'Botifarres/Salsitxes',
            emoji: '🌭',
            query: [
                'Botifarra crua',
                'Salsitxes porc',
                'Salsitxes pollastre',
                'Llonganissa fresca'
            ],
            exclude: [
                'frankfurt',
                'cuit',
                'curada',
                'sec',
                'fuet',
                'vegana'
            ]
        },
        // --- 🍔 PREPARATS I PICADA ---
        {
            id: 'minced_meat',
            label: 'Carn Picada',
            emoji: '🍝',
            query: [
                'Carn picada',
                'Picada mixta',
                'Picada vedella',
                'Picada pollastre'
            ],
            mustContain: 'picada',
            exclude: [
                'congelada',
                'bolognesa',
                'salsa'
            ]
        },
        {
            id: 'burgers',
            label: 'Hamburgueses',
            emoji: '🍔',
            query: [
                'Burger meat',
                'Hamburguesa vedella',
                'Hamburguesa pollastre'
            ],
            mustContain: [
                'burger',
                'hamburguesa'
            ],
            exclude: [
                'pa',
                'vegetal',
                'vegana',
                'congelada',
                'mc',
                'ketchup'
            ]
        },
        // --- 🐑 TRADICIONAL ---
        {
            id: 'lamb',
            label: 'Xai',
            emoji: '🐑',
            query: [
                'Costelles xai',
                'Cuixa xai',
                'Espatlla xai'
            ],
            mustContain: 'xai',
            exclude: [
                'congelat'
            ]
        },
        {
            id: 'rabbit',
            label: 'Conill',
            emoji: '🐇',
            query: [
                'Conill sencer',
                'Conill trossejat',
                'Espatlla conill'
            ],
            mustContain: 'conill',
            exclude: [
                'menjar',
                'gat',
                'gos'
            ]
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/fish.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FISH_CATEGORY",
    ()=>FISH_CATEGORY
]);
const FISH_CATEGORY = {
    id: 'fish',
    label: 'Peixateria',
    emoji: '🐟',
    gradient: 'from-blue-900/20 to-cyan-900/20 border-blue-800/30',
    subcategories: [
        {
            id: 'salmon',
            label: 'Salmó',
            emoji: '🍣',
            query: 'Salmó fresc'
        },
        {
            id: 'hake',
            label: 'Lluç',
            emoji: '🐟',
            query: 'Lluç fresc'
        },
        {
            id: 'cod',
            label: 'Bacallà',
            emoji: '🐟',
            query: 'Bacallà'
        },
        {
            id: 'tuna',
            label: 'Tonyina',
            emoji: '🦈',
            query: 'Tonyina fresca'
        },
        {
            id: 'prawns',
            label: 'Gambes',
            emoji: '🦐',
            query: 'Gamba'
        },
        {
            id: 'mussels',
            label: 'Musclos',
            emoji: '🦪',
            query: 'Musclos'
        },
        {
            id: 'squid',
            label: 'Sípia/Calamar',
            emoji: '🦑',
            query: 'Sípia bruta'
        },
        {
            id: 'sushi',
            label: 'Sushi',
            emoji: '🍱',
            query: 'Sushi'
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/dairy.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DAIRY_CATEGORY",
    ()=>DAIRY_CATEGORY
]);
const DAIRY_CATEGORY = {
    id: 'dairy',
    label: 'Làctics i Ous',
    emoji: '🧀',
    gradient: 'from-amber-100/10 to-orange-100/10 border-orange-200/20',
    subcategories: [
        // Llet
        {
            id: 'milk_whole',
            label: 'Llet Sencera',
            emoji: '🥛',
            query: 'Llet sencera'
        },
        {
            id: 'milk_semi',
            label: 'Llet Semi',
            emoji: '🥛',
            query: 'Llet semidesnatada'
        },
        {
            id: 'milk_veg',
            label: 'Beguda Vegetal',
            emoji: '🌱',
            query: 'Beguda civada'
        },
        // Iogurts
        {
            id: 'yogurt',
            label: 'Iogurt Natural',
            emoji: '🥣',
            query: 'Iogurt natural'
        },
        {
            id: 'yogurt_flav',
            label: 'Iogurt Sabors',
            emoji: '🍓',
            query: 'Iogurt maduixa'
        },
        {
            id: 'dessert',
            label: 'Postres',
            emoji: '🍮',
            query: 'Natilles'
        },
        // Formatges
        {
            id: 'cheese_fresh',
            label: 'Formatge Fresc',
            emoji: '🧀',
            query: 'Formatge fresc'
        },
        {
            id: 'cheese_sliced',
            label: 'Formatge Talls',
            emoji: '🥪',
            query: 'Formatge talls'
        },
        {
            id: 'cheese_cured',
            label: 'Formatge Curat',
            emoji: '🧀',
            query: 'Formatge curat'
        },
        {
            id: 'cheese_grated',
            label: 'Formatge Ratllat',
            emoji: '🍝',
            query: 'Formatge ratllat'
        },
        // Altres
        {
            id: 'eggs',
            label: 'Ous',
            emoji: '🥚',
            query: 'Ous'
        },
        {
            id: 'butter',
            label: 'Mantega',
            emoji: '🧈',
            query: 'Mantega'
        },
        {
            id: 'cream',
            label: 'Nata Cuina',
            emoji: '🥘',
            query: 'Nata cuinar'
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/charcuterie.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CHARCUTERIE_CATEGORY",
    ()=>CHARCUTERIE_CATEGORY
]);
const CHARCUTERIE_CATEGORY = {
    id: 'charcuterie',
    label: 'Xarcuteria',
    emoji: '🥓',
    gradient: 'from-pink-900/20 to-rose-800/20 border-pink-800/30',
    subcategories: [
        {
            id: 'ham_sweet',
            label: 'Pernil Dolç',
            emoji: '🥪',
            query: 'Pernil cuit'
        },
        {
            id: 'turkey_breast',
            label: 'Pit Gall D\'indi',
            emoji: '🦃',
            query: 'Pit gall indi llesques'
        },
        {
            id: 'serrano',
            label: 'Pernil Salat',
            emoji: '🍖',
            query: 'Pernil serrano'
        },
        {
            id: 'fuet',
            label: 'Fuet/Llonganissa',
            emoji: '🥖',
            query: 'Fuet'
        },
        {
            id: 'chorizo',
            label: 'Xoriço',
            emoji: '🌭',
            query: 'Xoriço'
        },
        {
            id: 'frankfurt',
            label: 'Frankfurt',
            emoji: '🌭',
            query: 'Frankfurt'
        },
        {
            id: 'pate',
            label: 'Paté',
            emoji: '🍞',
            query: 'Paté'
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/pantry.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PANTRY_CATEGORY",
    ()=>PANTRY_CATEGORY
]);
const PANTRY_CATEGORY = {
    id: 'pantry',
    label: 'Rebost',
    emoji: '🥫',
    gradient: 'from-amber-900/20 to-yellow-900/20 border-amber-800/30',
    subcategories: [
        // Bàsics
        {
            id: 'oil',
            label: 'Oli Oliva',
            emoji: '🫒',
            query: 'Oli oliva verge'
        },
        {
            id: 'sunflower',
            label: 'Oli Gira-sol',
            emoji: '🌻',
            query: 'Oli gira-sol'
        },
        {
            id: 'pasta',
            label: 'Pasta',
            emoji: '🍝',
            query: 'Pasta'
        },
        {
            id: 'rice',
            label: 'Arròs',
            emoji: '🍚',
            query: 'Arròs'
        },
        {
            id: 'legumes',
            label: 'Llegums',
            emoji: '🫘',
            query: 'Cigrons cuits'
        },
        {
            id: 'sauce',
            label: 'Tomàquet/Salses',
            emoji: '🥫',
            query: 'Tomàquet fregit'
        },
        // Pa i Esmorzar
        {
            id: 'bread',
            label: 'Pa',
            emoji: '🥖',
            query: 'Pa barra'
        },
        {
            id: 'sliced_bread',
            label: 'Pa Motlle',
            emoji: '🍞',
            query: 'Pa motlle'
        },
        {
            id: 'cookies',
            label: 'Galetes',
            emoji: '🍪',
            query: 'Galetes'
        },
        {
            id: 'cereals',
            label: 'Cereals',
            emoji: '🥣',
            query: 'Cereals esmorzar'
        },
        {
            id: 'coffee',
            label: 'Cafè',
            emoji: '☕',
            query: 'Cafè molt'
        },
        {
            id: 'cocoa',
            label: 'Cacau',
            emoji: '🍫',
            query: 'Cacau pols'
        },
        // Conserves
        {
            id: 'tuna_can',
            label: 'Tonyina',
            emoji: '🐟',
            query: 'Tonyina oli'
        },
        {
            id: 'olives',
            label: 'Olives',
            emoji: '🫒',
            query: 'Olives'
        },
        {
            id: 'soup',
            label: 'Brou/Sopes',
            emoji: '🍲',
            query: 'Brou pollastre'
        },
        // Condiments
        {
            id: 'salt',
            label: 'Sal/Espècies',
            emoji: '🧂',
            query: 'Sal cuina'
        },
        {
            id: 'sugar',
            label: 'Sucre',
            emoji: '🍬',
            query: 'Sucre'
        },
        {
            id: 'sauces',
            label: 'Maionesa/Kètxup',
            emoji: '🌭',
            query: 'Maionesa'
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/frozen.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FROZEN_CATEGORY",
    ()=>FROZEN_CATEGORY
]);
const FROZEN_CATEGORY = {
    id: 'frozen',
    label: 'Congelats',
    emoji: '❄️',
    gradient: 'from-cyan-900/20 to-sky-900/20 border-cyan-800/30',
    subcategories: [
        {
            id: 'pizza',
            label: 'Pizza',
            emoji: '🍕',
            query: 'Pizza'
        },
        {
            id: 'veggies',
            label: 'Verdura',
            emoji: '🥦',
            query: 'Verdura congelada'
        },
        {
            id: 'chips',
            label: 'Patates Fregir',
            emoji: '🍟',
            query: 'Patates pre-fregides'
        },
        {
            id: 'fish',
            label: 'Peix/Marisc',
            emoji: '🐟',
            query: 'Peix congelat'
        },
        {
            id: 'croquettes',
            label: 'Croquetes',
            emoji: '🥟',
            query: 'Croquetes'
        },
        {
            id: 'icecream',
            label: 'Gelats',
            emoji: '🍦',
            query: 'Gelat'
        },
        {
            id: 'meals',
            label: 'Plats Preparats',
            emoji: '🥘',
            query: 'Lassanya congelada'
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/drinks.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DRINKS_CATEGORY",
    ()=>DRINKS_CATEGORY
]);
const DRINKS_CATEGORY = {
    id: 'drinks',
    label: 'Begudes',
    emoji: '🧃',
    gradient: 'from-purple-900/20 to-indigo-900/20 border-purple-800/30',
    subcategories: [
        {
            id: 'water',
            label: 'Aigua',
            emoji: '💧',
            query: 'Aigua mineral'
        },
        {
            id: 'soda',
            label: 'Refrescos',
            emoji: '🥤',
            query: 'Refresc'
        },
        {
            id: 'cola',
            label: 'Cola',
            emoji: '🥤',
            query: 'Refresc cola'
        },
        {
            id: 'beer',
            label: 'Cervesa',
            emoji: '🍺',
            query: 'Cervesa'
        },
        {
            id: 'wine',
            label: 'Vi',
            emoji: '🍷',
            query: 'Vi negre'
        },
        {
            id: 'juice',
            label: 'Sucs',
            emoji: '🍊',
            query: 'Suc'
        },
        {
            id: 'alcohol',
            label: 'Licors',
            emoji: '🥃',
            query: 'Ginebra'
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/dietary.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DIETARY_CATEGORY",
    ()=>DIETARY_CATEGORY
]);
const DIETARY_CATEGORY = {
    id: 'dietary',
    label: 'Dietes i Bio',
    emoji: '🌿',
    gradient: 'from-teal-900/30 to-green-800/30 border-teal-500/40',
    subcategories: [
        {
            id: 'eco',
            label: 'Ecològic',
            emoji: '🌱',
            query: 'Ecològic'
        },
        {
            id: 'gluten_free',
            label: 'Sense Gluten',
            emoji: '🌾',
            query: 'Sense gluten'
        },
        {
            id: 'lactose_free',
            label: 'Sense Lactosa',
            emoji: '🥛',
            query: 'Sense lactosa'
        },
        {
            id: 'vegan',
            label: 'Vegà',
            emoji: '🥬',
            query: 'Vegetal'
        },
        {
            id: 'protein',
            label: 'Proteïna +',
            emoji: '💪',
            query: 'Proteïna'
        },
        {
            id: 'diet',
            label: 'Dietètic',
            emoji: '📉',
            query: 'Integral'
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/household.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HOUSEHOLD_CATEGORY",
    ()=>HOUSEHOLD_CATEGORY
]);
const HOUSEHOLD_CATEGORY = {
    id: 'household',
    label: 'Llar i Higiene',
    emoji: '🧹',
    gradient: 'from-gray-800 to-slate-800 border-slate-600',
    subcategories: [
        // Neteja Llar
        {
            id: 'detergent',
            label: 'Detergent Roba',
            emoji: '👕',
            query: 'Detergent roba'
        },
        {
            id: 'softener',
            label: 'Suavitzant',
            emoji: '🌸',
            query: 'Suavitzant'
        },
        {
            id: 'dishwasher',
            label: 'Rentavaixelles',
            emoji: '🍽️',
            query: 'Rentavaixelles'
        },
        {
            id: 'cleaning',
            label: 'Netejadors',
            emoji: '🧼',
            query: 'Netejador llar'
        },
        {
            id: 'paper',
            label: 'Paper WC/Cuina',
            emoji: '🧻',
            query: 'Paper higiènic'
        },
        // Higiene Personal
        {
            id: 'shower',
            label: 'Gel/Xampú',
            emoji: '🚿',
            query: 'Gel bany'
        },
        {
            id: 'dental',
            label: 'Dental',
            emoji: '🦷',
            query: 'Pasta dents'
        },
        {
            id: 'deo',
            label: 'Desodorant',
            emoji: '🧴',
            query: 'Desodorant'
        },
        // Nadons
        {
            id: 'baby_food',
            label: 'Menjar Nadó',
            emoji: '👶',
            query: 'Potet'
        },
        {
            id: 'diapers',
            label: 'Bolquers',
            emoji: '👶',
            query: 'Bolquers'
        },
        // Mascotes
        {
            id: 'cat',
            label: 'Gats',
            emoji: '🐱',
            query: 'Menjar gat'
        },
        {
            id: 'dog',
            label: 'Gossos',
            emoji: '🐶',
            query: 'Menjar gos'
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/types.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/lib/taxonomy/types.ts
__turbopack_context__.s([]);
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/taxonamy/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FOOD_TAXONOMY",
    ()=>FOOD_TAXONOMY
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$fruit$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/fruit.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$vegetables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/vegetables.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$meat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/meat.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$fish$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/fish.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$dairy$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/dairy.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$charcuterie$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/charcuterie.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$pantry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/pantry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$frozen$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/frozen.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$drinks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/drinks.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$dietary$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/dietary.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$household$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/household.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/taxonamy/types.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
const FOOD_TAXONOMY = [
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$fruit$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FRUIT_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$vegetables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VEGETABLES_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$meat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MEAT_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$fish$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FISH_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$dairy$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAIRY_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$charcuterie$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CHARCUTERIE_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$pantry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PANTRY_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$frozen$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FROZEN_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$drinks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DRINKS_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$dietary$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DIETARY_CATEGORY"],
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$household$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HOUSEHOLD_CATEGORY"]
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/editor/ingredients/useProductLinker.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useProductLinker",
    ()=>useProductLinker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$04d964__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:04d964 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/taxonamy/index.ts [app-client] (ecmascript) <locals>"); // Check path spelling!
var _s = __turbopack_context__.k.signature();
;
;
;
function useProductLinker(ingredients, isOpen) {
    _s();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [matches, setMatches] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [selectedProducts, setSelectedProducts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    // 1. EFECTE D'INICIALITZACIÓ (Quan s'obre el modal)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useProductLinker.useEffect": ()=>{
            if (isOpen) {
                // A. Pre-carreguem les seleccions existents
                const existingSelections = {};
                ingredients.forEach({
                    "useProductLinker.useEffect": (ing)=>{
                        if (ing.linkedProductId && ing.referencePrice) {
                            // Reconstruïm un objecte mínim de producte per marcar-lo com a seleccionat
                            // ✅ FIX: Afegim 'tags: []' i altres camps obligatoris per satisfer TypeScript
                            existingSelections[ing.id] = {
                                id: ing.linkedProductId,
                                name: ing.name,
                                price: ing.referencePrice,
                                image: ing.linkedProductImage || '',
                                emoji: ing.emoji || '📦',
                                source: 'bonpreu',
                                tags: [] // Camp obligatori
                            }; // Cast com a ProductResult si falten opcionals
                        }
                    }
                }["useProductLinker.useEffect"]);
                setSelectedProducts(existingSelections);
                // B. Llancem la cerca
                loadMatches();
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["useProductLinker.useEffect"], [
        isOpen
    ]);
    const findTaxonomyMatch = (name)=>{
        const lowerName = name.toLowerCase();
        for (const cat of __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$taxonamy$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["FOOD_TAXONOMY"]){
            for (const sub of cat.subcategories){
                if (sub.label.toLowerCase() === lowerName) return sub;
                if (lowerName.includes(sub.label.toLowerCase())) return sub;
                if (sub.label.toLowerCase().includes(lowerName)) return sub;
            }
        }
        return null;
    };
    const loadMatches = async ()=>{
        setLoading(true);
        const newMatches = {};
        const promises = ingredients.map(async (ing)=>{
            let foundProducts = [];
            try {
                // 1. TAXONOMIA
                const taxMatch = findTaxonomyMatch(ing.name);
                if (taxMatch) {
                    const queries = Array.isArray(taxMatch.query) ? taxMatch.query : [
                        taxMatch.query
                    ];
                    const responses = await Promise.all(queries.map((q)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$04d964__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["searchProductsAction"])(q)));
                    let rawResults = responses.filter((r)=>r.success && r.data).flatMap((r)=>r.data || []);
                    if (taxMatch.exclude) {
                        rawResults = rawResults.filter((p)=>{
                            const lowerName = p.name.toLowerCase();
                            return !taxMatch.exclude.some((bad)=>lowerName.includes(bad.toLowerCase()));
                        });
                    }
                    // Eliminar duplicats
                    foundProducts = Array.from(new Map(rawResults.map((item)=>[
                            item.id,
                            item
                        ])).values());
                } else {
                    // 2. NOM EXACTE
                    const resDirect = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$04d964__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["searchProductsAction"])(ing.name);
                    if (resDirect.data) foundProducts = resDirect.data;
                    // 3. FALLBACK (Primera paraula)
                    if (foundProducts.length === 0 && ing.name.includes(' ')) {
                        const firstWord = ing.name.split(' ')[0];
                        if (firstWord.length > 2) {
                            const resFallback = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$04d964__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["searchProductsAction"])(firstWord);
                            if (resFallback.data) {
                                // Afegim als resultats existents (o els reemplacem si estava buit)
                                foundProducts = resFallback.data;
                            }
                        }
                    }
                }
                if (foundProducts.length > 0) {
                    newMatches[ing.id] = foundProducts.slice(0, 10);
                }
            } catch (error) {
                console.error(error);
            }
        });
        await Promise.all(promises);
        setMatches((prev)=>({
                ...prev,
                ...newMatches
            }));
        setLoading(false);
    };
    const selectProduct = (ingredientId, product)=>{
        setSelectedProducts((prev)=>({
                ...prev,
                [ingredientId]: product
            }));
    };
    const applyChanges = (originalIngredients)=>{
        return originalIngredients.map((ing)=>{
            const selected = selectedProducts[ing.id];
            if (!selected) return ing;
            return {
                ...ing,
                linkedProductId: selected.id,
                linkedProductImage: selected.image,
                referencePrice: selected.price,
                estimatedCost: selected.price
            };
        });
    };
    const totalCost = Object.values(selectedProducts).reduce((acc, p)=>acc + (p?.price || 0), 0);
    return {
        loading,
        matches,
        selectedProducts,
        selectProduct,
        applyChanges,
        totalCost
    };
}
_s(useProductLinker, "LMh8+kdRk4axg8qEDIlWdvsqKnI=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductLinkerModal",
    ()=>ProductLinkerModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$ingredients$2f$useProductLinker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/editor/ingredients/useProductLinker.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Link$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/link.js [app-client] (ecmascript) <export default as Link>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/circle-alert.js [app-client] (ecmascript) <export default as AlertCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function ProductLinkerModal({ isOpen, onClose, ingredients, onUpdateIngredients }) {
    _s();
    const { loading, matches, selectedProducts, selectProduct, applyChanges, totalCost } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$ingredients$2f$useProductLinker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProductLinker"])(ingredients, isOpen);
    const handleConfirm = ()=>{
        const updated = applyChanges(ingredients);
        onUpdateIngredients(updated);
        onClose();
    };
    if (!isOpen || typeof document === 'undefined') return null;
    const linkedCount = Object.keys(selectedProducts).length;
    const totalIngredients = ingredients.length;
    const progress = Math.round(linkedCount / totalIngredients * 100);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[9999] flex items-center justify-center p-4 sm:p-6 isolate",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 bg-slate-950/80 backdrop-blur-sm transition-opacity",
                onClick: onClose
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                lineNumber: 32,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative bg-slate-900 w-full max-w-4xl h-[85vh] rounded-3xl border border-slate-800 flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "shrink-0 px-6 py-4 border-b border-slate-800 bg-slate-950 flex justify-between items-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-xl font-black text-white flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-2xl",
                                                children: "🪄"
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                lineNumber: 43,
                                                columnNumber: 16
                                            }, this),
                                            " Càlcul de Costos"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                        lineNumber: 42,
                                        columnNumber: 14
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-slate-400 mt-0.5",
                                        children: [
                                            "Connectant amb ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-yellow-500 font-bold",
                                                children: "Bonpreu"
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                lineNumber: 46,
                                                columnNumber: 31
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                        lineNumber: 45,
                                        columnNumber: 14
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                lineNumber: 41,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onClose,
                                className: "p-2 bg-slate-800 rounded-full text-slate-400 hover:bg-slate-700 hover:text-white transition-colors",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                    size: 20
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                    lineNumber: 50,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                lineNumber: 49,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                        lineNumber: 40,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 overflow-y-auto p-4 sm:p-6 space-y-8 custom-scrollbar",
                        children: loading && Object.keys(matches).length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-full flex flex-col items-center justify-center text-slate-500 gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                    className: "w-10 h-10 animate-spin text-purple-500"
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                    lineNumber: 59,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "animate-pulse",
                                    children: "Buscant preus al supermercat..."
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                    lineNumber: 60,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                            lineNumber: 58,
                            columnNumber: 14
                        }, this) : ingredients.map((ing)=>{
                            const productOptions = matches[ing.id] || [];
                            const selected = selectedProducts[ing.id];
                            const isLinked = !!ing.linkedProductId || !!selected;
                            const hasOptions = productOptions.length > 0;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative pl-4 border-l-2 border-slate-800 hover:border-slate-700 transition-colors py-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: `absolute -left-[9px] top-1.5 w-4 h-4 rounded-full border-2 transition-colors ${isLinked ? 'bg-emerald-500 border-emerald-500' : 'bg-slate-900 border-slate-600'}`
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                        lineNumber: 71,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-3 mb-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-2xl",
                                                children: ing.emoji || '🥗'
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                lineNumber: 75,
                                                columnNumber: 24
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                        className: "text-white font-bold text-lg leading-tight",
                                                        children: ing.name
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                        lineNumber: 77,
                                                        columnNumber: 27
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs text-purple-300 font-mono",
                                                        children: [
                                                            ing.quantity,
                                                            " ",
                                                            ing.unit
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                        lineNumber: 78,
                                                        columnNumber: 27
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                lineNumber: 76,
                                                columnNumber: 24
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                        lineNumber: 74,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "pl-2",
                                        children: !hasOptions && !loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "bg-slate-800/50 rounded-xl p-3 flex items-center gap-3 text-slate-400 border border-dashed border-slate-700 text-sm",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__["AlertCircle"], {
                                                    size: 16
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                    lineNumber: 88,
                                                    columnNumber: 30
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: [
                                                        'No hem trobat "',
                                                        ing.name,
                                                        '". Prova de simplificar el nom.'
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                    lineNumber: 89,
                                                    columnNumber: 30
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                            lineNumber: 87,
                                            columnNumber: 27
                                        }, this) : // ✅ TORNEM A L'SCROLL HORITZONTAL (snap-x)
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex gap-3 overflow-x-auto pb-4 pt-1 px-1 scrollbar-thin scrollbar-thumb-slate-700 snap-x",
                                            children: productOptions.map((prod)=>{
                                                const isSelected = selected?.id === prod.id;
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>selectProduct(ing.id, prod),
                                                    className: `
                                       relative flex-none w-36 snap-start text-left group transition-all duration-200
                                       border rounded-xl overflow-hidden flex flex-col
                                       ${isSelected ? 'bg-emerald-900/10 border-emerald-500 ring-2 ring-emerald-500/50 shadow-lg scale-[1.02]' : 'bg-slate-900 border-slate-700 hover:border-slate-500 hover:bg-slate-800'}
                                    `,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "h-24 w-full bg-white p-2 flex items-center justify-center relative shrink-0",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                                    src: prod.image,
                                                                    className: "h-full object-contain mix-blend-multiply",
                                                                    alt: ""
                                                                }, void 0, false, {
                                                                    fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                                    lineNumber: 112,
                                                                    columnNumber: 41
                                                                }, this),
                                                                isSelected && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "absolute top-1 right-1 bg-emerald-500 text-white p-0.5 rounded-full shadow-md animate-in zoom-in",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                                                        size: 10,
                                                                        strokeWidth: 4
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                                        lineNumber: 115,
                                                                        columnNumber: 47
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                                    lineNumber: 114,
                                                                    columnNumber: 44
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                            lineNumber: 110,
                                                            columnNumber: 38
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "p-2.5 flex flex-col justify-between flex-1 min-h-[70px]",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: `text-[10px] font-medium leading-tight line-clamp-2 mb-2 ${isSelected ? 'text-emerald-300' : 'text-slate-300'}`,
                                                                    children: prod.name
                                                                }, void 0, false, {
                                                                    fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                                    lineNumber: 122,
                                                                    columnNumber: 41
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center justify-between mt-auto",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-[9px] text-slate-500",
                                                                            children: prod.quantityAmount ? `${prod.quantityAmount}${prod.quantityUnit}` : 'Unitat'
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                                            lineNumber: 126,
                                                                            columnNumber: 44
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "font-mono font-black text-xs text-white bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800",
                                                                            children: [
                                                                                prod.price,
                                                                                "€"
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                                            lineNumber: 129,
                                                                            columnNumber: 44
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                                    lineNumber: 125,
                                                                    columnNumber: 41
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                            lineNumber: 121,
                                                            columnNumber: 38
                                                        }, this)
                                                    ]
                                                }, prod.id, true, {
                                                    fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                    lineNumber: 97,
                                                    columnNumber: 35
                                                }, this);
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                            lineNumber: 93,
                                            columnNumber: 27
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                        lineNumber: 85,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, ing.id, true, {
                                fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                lineNumber: 70,
                                columnNumber: 19
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                        lineNumber: 55,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "shrink-0 bg-slate-950 border-t border-slate-800 p-4 sm:p-6 pb-8 sm:pb-6",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1 max-w-xs hidden sm:block",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex justify-between text-xs font-bold text-slate-400 mb-1.5 uppercase",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: "Progrés"
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                    lineNumber: 151,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: [
                                                        linkedCount,
                                                        " / ",
                                                        totalIngredients
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                    lineNumber: 152,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                            lineNumber: 150,
                                            columnNumber: 18
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-1.5 bg-slate-800 rounded-full overflow-hidden",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "h-full bg-linear-to-r from-purple-500 to-emerald-500 transition-all duration-500 ease-out",
                                                style: {
                                                    width: `${progress}%`
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                lineNumber: 155,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                            lineNumber: 154,
                                            columnNumber: 18
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                    lineNumber: 149,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center justify-between sm:justify-end gap-4 w-full sm:w-auto",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-right",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "block text-[9px] text-slate-400 font-bold uppercase tracking-wider",
                                                    children: "Total"
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                    lineNumber: 164,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "block text-2xl font-black text-emerald-400 font-mono leading-none",
                                                    children: [
                                                        totalCost.toFixed(2),
                                                        "€"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                    lineNumber: 165,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                            lineNumber: 163,
                                            columnNumber: 18
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: handleConfirm,
                                            className: "bg-white hover:bg-slate-200 text-slate-900 font-black py-3 px-6 rounded-xl shadow-lg shadow-white/5 active:scale-95 transition-all flex items-center gap-2 text-sm",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Link$3e$__["Link"], {
                                                    size: 16,
                                                    strokeWidth: 2.5
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                                    lineNumber: 174,
                                                    columnNumber: 20
                                                }, this),
                                                "Aplicar"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                            lineNumber: 170,
                                            columnNumber: 18
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                                    lineNumber: 162,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                            lineNumber: 148,
                            columnNumber: 12
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                        lineNumber: 147,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
                lineNumber: 37,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this), document.body);
}
_s(ProductLinkerModal, "dnqqNwkHCCH6Ns4HQP6WPNUS/A8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$ingredients$2f$useProductLinker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProductLinker"]
    ];
});
_c = ProductLinkerModal;
var _c;
__turbopack_context__.k.register(_c, "ProductLinkerModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/editor/IngredientsManager.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IngredientsManager",
    ()=>IngredientsManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$ingredients$2f$useIngredientsManager$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/ingredients/useIngredientsManager.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$ingredients$2f$IngredientActionSheet$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/ingredients/IngredientActionSheet.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$ingredients$2f$IngredientTools$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/ingredients/IngredientTools.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$ingredients$2f$IngredientDock$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/ingredients/IngredientDock.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$ingredients$2f$ProductLinkerModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/editor/ingredients/ProductLinkerModal.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// src/components/recipes/IngredientsManager.tsx
'use client';
;
;
;
;
;
;
function IngredientsManager({ data, update, inventory, labels, searchInputId, ingredientsListId }) {
    _s();
    const { query, setQuery, selectedCategory, setSelectedCategory, activeItem, setActiveItem, qty, setQty, filteredPresets, quickAdd, closeSelection, confirmAdd, removeIngredient } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$ingredients$2f$useIngredientsManager$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIngredientsManager"])(data, update);
    const [isLinkerOpen, setIsLinkerOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // ✅ SOLUCIÓ TYPESCRIPT: Tot coincideix amb la interfície Ingredient
    const handleUpdateIngredients = (updated)=>{
        update({
            ...data,
            ingredients: updated
        });
    };
    // ✅ SOLUCIÓ SUMA: Forcem Number() per evitar errors de tipus string
    const recipeTotalCost = data.ingredients.reduce((acc, ing)=>{
        const cost = Number(ing.estimatedCost) || 0;
        return acc + cost;
    }, 0);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$ingredients$2f$IngredientActionSheet$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IngredientActionSheet"], {
                activeItem: activeItem,
                qty: qty,
                setQty: setQty,
                updateItemUnit: (u)=>activeItem && setActiveItem({
                        ...activeItem,
                        unit: u
                    }),
                onClose: closeSelection,
                onConfirm: confirmAdd
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/IngredientsManager.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$ingredients$2f$ProductLinkerModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProductLinkerModal"], {
                isOpen: isLinkerOpen,
                onClose: ()=>setIsLinkerOpen(false),
                ingredients: data.ingredients,
                onUpdateIngredients: handleUpdateIngredients
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/IngredientsManager.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col h-full w-full relative overflow-hidden bg-slate-950",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        id: searchInputId,
                        className: "shrink-0 z-10 bg-slate-900 border-b border-slate-800",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$ingredients$2f$IngredientTools$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SearchHeader"], {
                            query: query,
                            setQuery: setQuery,
                            selectedCategory: selectedCategory,
                            setSelectedCategory: setSelectedCategory,
                            labels: labels,
                            categories: Array.from(new Set(filteredPresets.map((p)=>p.category)))
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/editor/IngredientsManager.tsx",
                            lineNumber: 72,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/editor/IngredientsManager.tsx",
                        lineNumber: 71,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 overflow-hidden relative",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$ingredients$2f$IngredientTools$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CalculatorGrid"], {
                            presets: filteredPresets,
                            inventory: inventory,
                            currentIngredients: data.ingredients,
                            onQuickAdd: quickAdd,
                            emptyLabel: labels.empty_search
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/editor/IngredientsManager.tsx",
                            lineNumber: 83,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/editor/IngredientsManager.tsx",
                        lineNumber: 82,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        id: ingredientsListId,
                        className: "absolute bottom-0 left-0 right-0 z-30 pointer-events-none",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "pointer-events-auto relative",
                            children: [
                                recipeTotalCost > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute right-4 -top-14 bg-slate-900/90 backdrop-blur border border-emerald-500/50 text-emerald-400 px-4 py-2 rounded-xl shadow-xl flex flex-col items-end z-40 animate-in slide-in-from-bottom-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-[9px] font-bold uppercase tracking-wider text-slate-400",
                                            children: "Total Recepta"
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/editor/IngredientsManager.tsx",
                                            lineNumber: 96,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xl font-black font-mono leading-none",
                                            children: [
                                                recipeTotalCost.toFixed(2),
                                                "€"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/features/recipes/components/editor/IngredientsManager.tsx",
                                            lineNumber: 97,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/features/recipes/components/editor/IngredientsManager.tsx",
                                    lineNumber: 95,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$ingredients$2f$IngredientDock$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IngredientDock"], {
                                    ingredients: data.ingredients,
                                    onRemove: removeIngredient,
                                    labels: {
                                        title: labels.basket_title,
                                        empty: labels.basket_empty
                                    },
                                    onOpenLinker: ()=>setIsLinkerOpen(true)
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/editor/IngredientsManager.tsx",
                                    lineNumber: 101,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/features/recipes/components/editor/IngredientsManager.tsx",
                            lineNumber: 93,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/editor/IngredientsManager.tsx",
                        lineNumber: 92,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/editor/IngredientsManager.tsx",
                lineNumber: 70,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(IngredientsManager, "Q5M1ovy82yR+zP6VjmGpozjxIpI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$ingredients$2f$useIngredientsManager$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIngredientsManager"]
    ];
});
_c = IngredientsManager;
var _c;
__turbopack_context__.k.register(_c, "IngredientsManager");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/editor/steps/useStepsManager.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useStepsManager",
    ()=>useStepsManager
]);
// src/components/recipes/editor/steps/useStepsManager.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
function useStepsManager(data, update) {
    _s();
    const [currentStepText, setCurrentStepText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [editingId, setEditingId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null); // ✅ Nou estat
    const textareaRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const listEndRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Aquesta funció ara serveix per AFEGIR o ACTUALITZAR
    const saveStep = ()=>{
        if (!currentStepText.trim()) return;
        // CAS 1: ESTEM EDITANT UN PAS EXISTENT
        if (editingId) {
            const updatedSteps = data.steps.map((step)=>step.id === editingId ? {
                    ...step,
                    content: currentStepText.trim()
                } : step);
            update({
                ...data,
                steps: updatedSteps
            });
            setEditingId(null); // Sortim del mode edició
        } else {
            const newStep = {
                id: crypto.randomUUID(),
                content: currentStepText.trim()
            };
            update({
                ...data,
                steps: [
                    ...data.steps,
                    newStep
                ]
            });
            // Scroll automàtic només si afegim un nou pas
            setTimeout(()=>{
                listEndRef.current?.scrollIntoView({
                    behavior: 'smooth'
                });
            }, 100);
        }
        setCurrentStepText('');
        // Tornar el focus
        setTimeout(()=>{
            textareaRef.current?.focus();
        }, 100);
    };
    const removeStep = (id)=>{
        update({
            ...data,
            steps: data.steps.filter((s)=>s.id !== id)
        });
        // Si estàvem editant aquest pas, cancelem l'edició
        if (editingId === id) {
            setEditingId(null);
            setCurrentStepText('');
        }
    };
    const handleReorder = (newOrder)=>{
        update({
            ...data,
            steps: newOrder
        });
    };
    // ✅ Nova funció: Carregar un pas per editar-lo
    const startEditing = (step)=>{
        setEditingId(step.id);
        setCurrentStepText(step.content);
        // En mòbil, potser voldràs canviar la vista aquí, però això ho gestiona el Builder
        setTimeout(()=>{
            textareaRef.current?.focus();
        }, 50);
    };
    // ✅ Cancel·lar edició
    const cancelEditing = ()=>{
        setEditingId(null);
        setCurrentStepText('');
    };
    return {
        currentStepText,
        setCurrentStepText,
        editingId,
        startEditing,
        cancelEditing,
        saveStep,
        textareaRef,
        listEndRef,
        removeStep,
        handleReorder
    };
}
_s(useStepsManager, "7CUREnH/z1zBptwQDuD1nU/I71Q=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useSpeechToText.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useSpeechToText",
    ()=>useSpeechToText
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
function useSpeechToText() {
    _s();
    const [isListening, setIsListening] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // ✅ transcript: Només tindrà el resultat FINAL (per guardar-ho)
    const [transcript, setTranscript] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    // ✅ interimTranscript: Tindrà el text "en viu" (per mostrar-ho)
    const [interimTranscript, setInterimTranscript] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const recognitionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useSpeechToText.useEffect": ()=>{
            const win = window;
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            const SpeechRecognitionConstructor = win.SpeechRecognition || win.webkitSpeechRecognition;
            if (!SpeechRecognitionConstructor) return;
            const recognition = new SpeechRecognitionConstructor();
            recognition.continuous = true;
            recognition.interimResults = true; // Això permet veure el text mentre parles
            recognition.lang = 'ca-ES';
            recognition.onstart = ({
                "useSpeechToText.useEffect": ()=>setIsListening(true)
            })["useSpeechToText.useEffect"];
            recognition.onend = ({
                "useSpeechToText.useEffect": ()=>{
                    setIsListening(false);
                    setInterimTranscript(''); // Netegem el text fantasma en acabar
                }
            })["useSpeechToText.useEffect"];
            recognition.onerror = ({
                "useSpeechToText.useEffect": (event)=>{
                    if (event.error === 'no-speech') {
                        setIsListening(false);
                        return;
                    }
                    console.warn("Error micro:", event.error);
                    setIsListening(false);
                }
            })["useSpeechToText.useEffect"];
            recognition.onresult = ({
                "useSpeechToText.useEffect": (event)=>{
                    let finalStr = '';
                    let interimStr = '';
                    for(let i = event.resultIndex; i < event.results.length; i++){
                        const result = event.results[i];
                        if (result.isFinal) {
                            finalStr += result[0].transcript;
                        } else {
                            interimStr += result[0].transcript;
                        }
                    }
                    // Si tenim text final, l'enviem al transcript principal
                    if (finalStr) {
                        setTranscript(finalStr);
                        setInterimTranscript(''); // Reset del parcial
                    } else {
                        // Si no, actualitzem el parcial perquè es vegi a l'input
                        setInterimTranscript(interimStr);
                    }
                }
            })["useSpeechToText.useEffect"];
            recognitionRef.current = recognition;
            return ({
                "useSpeechToText.useEffect": ()=>{
                    if (recognitionRef.current) recognitionRef.current.stop();
                }
            })["useSpeechToText.useEffect"];
        }
    }["useSpeechToText.useEffect"], []);
    const startListening = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useSpeechToText.useCallback[startListening]": ()=>{
            if (recognitionRef.current && !isListening) {
                try {
                    recognitionRef.current.start();
                } catch (e) {
                    console.error(e);
                }
            }
        }
    }["useSpeechToText.useCallback[startListening]"], [
        isListening
    ]);
    const stopListening = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useSpeechToText.useCallback[stopListening]": ()=>{
            if (recognitionRef.current) recognitionRef.current.stop();
        }
    }["useSpeechToText.useCallback[stopListening]"], []);
    const clearTranscript = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useSpeechToText.useCallback[clearTranscript]": ()=>setTranscript('')
    }["useSpeechToText.useCallback[clearTranscript]"], []);
    // ✅ Retornem també l'interimTranscript
    return {
        isListening,
        transcript,
        interimTranscript,
        startListening,
        stopListening,
        clearTranscript
    };
}
_s(useSpeechToText, "OQIWM7MexlRcO1iZNX84zQaz4Q0=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SuggestionChips",
    ()=>SuggestionChips
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$basket$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingBasket$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/shopping-basket.js [app-client] (ecmascript) <export default as ShoppingBasket>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function SuggestionChips({ ingredients, prepTimeMinutes, onInsert }) {
    _s();
    const [imgErrors, setImgErrors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "shrink-0 p-3 bg-slate-900/50 border-b border-slate-800 max-h-40 overflow-y-auto custom-scrollbar",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-wrap gap-2 items-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: ()=>onInsert(`⏰ ${prepTimeMinutes} min`),
                    className: "group flex items-center gap-2 px-3 py-1.5 bg-slate-800/50 hover:bg-purple-900/20 rounded-xl border border-slate-700 hover:border-purple-500/50 transition-all active:scale-95 h-[42px]",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-8 h-8 rounded-lg bg-slate-900 flex items-center justify-center border border-slate-700 group-hover:border-purple-500/30",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-base",
                                children: "⏰"
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
                                lineNumber: 31,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
                            lineNumber: 30,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col items-start",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-[9px] text-slate-400 uppercase font-bold tracking-wider",
                                    children: "Temps"
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
                                    lineNumber: 34,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-xs font-mono font-bold text-purple-200 group-hover:text-white leading-none",
                                    children: [
                                        prepTimeMinutes,
                                        "m"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
                                    lineNumber: 35,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
                            lineNumber: 33,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
                    lineNumber: 26,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-px h-8 bg-slate-800 mx-1"
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
                    lineNumber: 41,
                    columnNumber: 9
                }, this),
                ingredients.map((ing, i)=>{
                    // ✅ CAST SEGUR A ExtendedIngredient
                    const extendedIng = ing;
                    const imageUrl = extendedIng.image || extendedIng.linkedProductImage;
                    const hasImage = !!imageUrl && !imgErrors[ing.id];
                    const displayEmoji = ing.emoji || '📦';
                    const safeKey = ing.id || `ing-fallback-${i}`;
                    const cardStyle = hasImage ? 'bg-slate-800/80 border-emerald-500/30 hover:border-emerald-500/60 hover:bg-slate-800' : 'bg-slate-800 border-slate-700 hover:border-indigo-500/50 hover:bg-slate-700/80';
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>onInsert(`[${ing.name}]`),
                        className: `group relative flex items-center gap-2 pl-1.5 pr-3 py-1.5 rounded-xl border transition-all active:scale-95 h-[42px] ${cardStyle}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-8 h-8 rounded-lg bg-white flex items-center justify-center overflow-hidden shrink-0 shadow-sm ring-1 ring-black/10",
                                children: hasImage ? /* eslint-disable-next-line @next/next/no-img-element */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: imageUrl,
                                    alt: ing.name,
                                    className: "w-full h-full object-contain p-0.5",
                                    onError: ()=>setImgErrors((prev)=>({
                                                ...prev,
                                                [ing.id]: true
                                            }))
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
                                    lineNumber: 66,
                                    columnNumber: 19
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-lg leading-none",
                                    children: displayEmoji
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
                                    lineNumber: 73,
                                    columnNumber: 19
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
                                lineNumber: 63,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col items-start min-w-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs font-bold text-slate-200 truncate max-w-[100px] leading-tight",
                                        children: ing.name
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
                                        lineNumber: 78,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[9px] text-slate-400 font-mono leading-none mt-0.5",
                                        children: [
                                            ing.quantity,
                                            " ",
                                            ing.unit
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
                                        lineNumber: 81,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
                                lineNumber: 77,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                size: 12,
                                className: "text-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity -ml-1"
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
                                lineNumber: 86,
                                columnNumber: 15
                            }, this)
                        ]
                    }, safeKey, true, {
                        fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
                        lineNumber: 58,
                        columnNumber: 13
                    }, this);
                }),
                ingredients.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2 text-slate-500 italic py-2 px-2 bg-slate-900/30 rounded-lg border border-dashed border-slate-800",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$basket$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingBasket$3e$__["ShoppingBasket"], {
                            size: 14
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
                            lineNumber: 94,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-xs",
                            children: "Afegeix productes..."
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
                            lineNumber: 95,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
                    lineNumber: 93,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
            lineNumber: 23,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
}
_s(SuggestionChips, "R20EcWWBNwJsDkE2j/sCmYHby/4=");
_c = SuggestionChips;
var _c;
__turbopack_context__.k.register(_c, "SuggestionChips");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/editor/steps/input/InputHeader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InputHeader",
    ()=>InputHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mic$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/mic.js [app-client] (ecmascript) <export default as Mic>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mic$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MicOff$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/mic-off.js [app-client] (ecmascript) <export default as MicOff>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowDown$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/arrow-down.js [app-client] (ecmascript) <export default as ArrowDown>");
'use client';
;
;
;
function InputHeader({ isEditing, isListening, hasContent, labels, onSave, onCancel, onToggleSpeech }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "p-4 pb-2 shrink-0 flex justify-between items-center bg-slate-900/20",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    className: `text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-colors ${isEditing ? 'text-purple-400' : 'text-slate-500'}`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-lg",
                            children: isEditing ? '✏️' : '✍️'
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/editor/steps/input/InputHeader.tsx",
                            lineNumber: 21,
                            columnNumber: 11
                        }, this),
                        isEditing ? 'Editant Pas...' : labels.title
                    ]
                }, void 0, true, {
                    fileName: "[project]/features/recipes/components/editor/steps/input/InputHeader.tsx",
                    lineNumber: 20,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/steps/input/InputHeader.tsx",
                lineNumber: 19,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-2",
                children: [
                    isEditing && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
                        initial: {
                            scale: 0
                        },
                        animate: {
                            scale: 1
                        },
                        exit: {
                            scale: 0
                        },
                        onClick: onCancel,
                        className: "w-8 h-8 flex items-center justify-center rounded-lg bg-slate-800 text-slate-400 border border-slate-700 hover:bg-red-900/30 hover:text-red-400 hover:border-red-500/50 transition-colors",
                        title: "Cancel·lar edició",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                            size: 16,
                            strokeWidth: 3
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/editor/steps/input/InputHeader.tsx",
                            lineNumber: 35,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/editor/steps/input/InputHeader.tsx",
                        lineNumber: 29,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onToggleSpeech,
                        className: `
            h-8 px-3 rounded-lg flex items-center gap-2 text-xs font-bold uppercase tracking-wider transition-all border
            ${isListening ? 'bg-red-500 text-white border-red-400 animate-pulse shadow-red-500/20 shadow-lg' : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700 hover:text-white'}
          `,
                        children: [
                            isListening ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mic$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MicOff$3e$__["MicOff"], {
                                size: 14
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/editor/steps/input/InputHeader.tsx",
                                lineNumber: 50,
                                columnNumber: 26
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mic$3e$__["Mic"], {
                                size: 14
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/editor/steps/input/InputHeader.tsx",
                                lineNumber: 50,
                                columnNumber: 49
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "hidden sm:inline",
                                children: isListening ? 'Stop' : 'Dictar'
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/editor/steps/input/InputHeader.tsx",
                                lineNumber: 51,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/editor/steps/input/InputHeader.tsx",
                        lineNumber: 40,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                        mode: "popLayout",
                        children: (hasContent || isEditing) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
                            initial: {
                                scale: 0
                            },
                            animate: {
                                scale: 1
                            },
                            exit: {
                                scale: 0
                            },
                            whileTap: {
                                scale: 0.9
                            },
                            onClick: onSave,
                            "data-testid": "recipe-step-save",
                            className: `
                h-8 px-3 rounded-lg flex items-center gap-2 text-xs font-bold uppercase tracking-wider transition-all border shadow-lg
                ${isEditing ? 'bg-emerald-600 text-white border-emerald-500 hover:bg-emerald-500' : 'bg-purple-600 text-white border-purple-500 hover:bg-purple-500'}
              `,
                            children: [
                                isEditing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                    size: 16,
                                    strokeWidth: 3
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/editor/steps/input/InputHeader.tsx",
                                    lineNumber: 70,
                                    columnNumber: 28
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowDown$3e$__["ArrowDown"], {
                                    size: 16,
                                    strokeWidth: 3
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/editor/steps/input/InputHeader.tsx",
                                    lineNumber: 70,
                                    columnNumber: 66
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "hidden sm:inline",
                                    children: isEditing ? 'Guardar' : 'Afegir'
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/editor/steps/input/InputHeader.tsx",
                                    lineNumber: 71,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/features/recipes/components/editor/steps/input/InputHeader.tsx",
                            lineNumber: 57,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/editor/steps/input/InputHeader.tsx",
                        lineNumber: 55,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/editor/steps/input/InputHeader.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/editor/steps/input/InputHeader.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
_c = InputHeader;
var _c;
__turbopack_context__.k.register(_c, "InputHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/editor/steps/StepsInput.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StepsInput",
    ()=>StepsInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useSpeechToText$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useSpeechToText.ts [app-client] (ecmascript)");
// Importem els sub-components
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$input$2f$SuggestionChips$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/editor/steps/input/SuggestionChips.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$input$2f$InputHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/editor/steps/input/InputHeader.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function StepsInput({ data, currentText, onChangeText, onSave, onCancel, isEditing, textareaRef, labels }) {
    _s();
    const { isListening, transcript, interimTranscript, startListening, stopListening, clearTranscript } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useSpeechToText$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSpeechToText"])();
    // Gestió de Veu
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StepsInput.useEffect": ()=>{
            if (transcript) {
                insertToken(transcript + ' ');
                clearTranscript();
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["StepsInput.useEffect"], [
        transcript
    ]);
    // Gestió de Tecles
    const handleKeyDown = (e)=>{
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            onSave();
        }
        if (e.key === 'Escape' && isEditing) {
            onCancel();
        }
    };
    // Lògica d'inserció de text (el cursor màgic)
    const insertToken = (token)=>{
        const textarea = textareaRef.current;
        if (!textarea) {
            onChangeText(currentText + (currentText ? ' ' : '') + token);
            return;
        }
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const textBefore = currentText.substring(0, start);
        const textAfter = currentText.substring(end);
        // Gestió intel·ligent d'espais
        const prefix = textBefore.length > 0 && !textBefore.endsWith(' ') && !token.startsWith(' ') ? ' ' : '';
        const suffix = textAfter.length > 0 && !textAfter.startsWith(' ') && !token.endsWith(' ') ? ' ' : '';
        const newText = `${textBefore}${prefix}${token}${suffix}${textAfter}`;
        onChangeText(newText);
        setTimeout(()=>{
            textarea.focus();
            const newCursorPos = start + prefix.length + token.length;
            textarea.setSelectionRange(newCursorPos, newCursorPos);
        }, 10);
    };
    const getDisplayValue = ()=>{
        if (isListening && interimTranscript) {
            const spacer = currentText && !currentText.endsWith(' ') ? ' ' : '';
            return currentText + spacer + interimTranscript;
        }
        return currentText;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col h-full bg-slate-950/20 relative overflow-hidden",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$input$2f$SuggestionChips$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SuggestionChips"], {
                ingredients: data.ingredients,
                // ✅ CORRECCIÓ: Convertim el valor a number per satisfer les Props del component
                prepTimeMinutes: Number(data.prepTimeMinutes) || 0,
                onInsert: insertToken
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/steps/StepsInput.tsx",
                lineNumber: 88,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$input$2f$InputHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputHeader"], {
                isEditing: isEditing,
                isListening: isListening,
                hasContent: !!currentText.trim(),
                labels: {
                    title: labels.new_step_title,
                    subtitle: labels.new_step_desc
                },
                onSave: onSave,
                onCancel: onCancel,
                onToggleSpeech: isListening ? stopListening : startListening
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/steps/StepsInput.tsx",
                lineNumber: 96,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: "tour-step-textarea",
                className: "flex-1 p-4 pt-2 relative group min-h-50 flex flex-col",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                    ref: textareaRef,
                    value: getDisplayValue(),
                    onChange: (e)=>onChangeText(e.target.value),
                    onKeyDown: handleKeyDown,
                    placeholder: isListening ? "Parla ara..." : labels.placeholder,
                    "data-testid": "recipe-step-input",
                    className: `
                    flex-1 w-full bg-slate-900 border rounded-2xl p-4 text-base text-white outline-none resize-none transition-all leading-relaxed custom-scrollbar
                    ${isListening ? 'border-red-500/50 ring-1 ring-red-500/20' : isEditing ? 'border-purple-500/50 ring-1 ring-purple-500/20 bg-purple-900/10' : 'border-slate-800 focus:border-purple-500 focus:ring-1 focus:ring-purple-500/50'}
                `
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/editor/steps/StepsInput.tsx",
                    lineNumber: 108,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/steps/StepsInput.tsx",
                lineNumber: 107,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/editor/steps/StepsInput.tsx",
        lineNumber: 85,
        columnNumber: 5
    }, this);
}
_s(StepsInput, "TxIJ5FEOSTdRB9N40U+YSjaIvLw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useSpeechToText$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSpeechToText"]
    ];
});
_c = StepsInput;
var _c;
__turbopack_context__.k.register(_c, "StepsInput");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/editor/steps/list/IngredientChip.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IngredientChip",
    ()=>IngredientChip
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/food-presets/index.ts [app-client] (ecmascript) <locals>");
'use client';
;
;
function IngredientChip({ name, ingredient }) {
    // 1. Recuperem la imatge (prioritzem la del producte vinculat)
    // Fem un cast segur per accedir a propietats opcionals
    const ingData = ingredient;
    const imageUrl = ingData?.image || ingData?.linkedProductImage;
    const hasImage = !!imageUrl;
    // 2. Recuperem l'emoji (del preset o de l'ingredient)
    const preset = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["FOOD_PRESETS"].find((p)=>p.name === name);
    const emoji = ingData?.emoji || preset?.emoji || '📦';
    // 3. Recuperem el preu i quantitat
    const price = ingData?.estimatedCost ? ingData.estimatedCost.toFixed(2) : null;
    const quantity = ingData ? `${ingData.quantity}${ingData.unit}` : '';
    console.log(`RENDER CHIP [${name}]: hasImage=${hasImage}, url=${imageUrl}`);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: `
        inline-flex items-center gap-1.5 align-middle mx-1 px-1.5 py-0.5 rounded-lg border shadow-sm select-none transition-all
        ${hasImage ? 'bg-slate-800/90 border-emerald-500/40 text-white pr-2 shadow-emerald-900/20' // Estil Premium
         : 'bg-slate-800 border-slate-700 text-emerald-100'}
      `,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "w-5 h-5 rounded bg-white flex items-center justify-center overflow-hidden shrink-0 ring-1 ring-black/10",
                children: hasImage ? /* eslint-disable-next-line @next/next/no-img-element */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                    src: imageUrl,
                    alt: name,
                    className: "w-full h-full object-contain p-0.5"
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/editor/steps/list/IngredientChip.tsx",
                    lineNumber: 49,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-xs leading-none",
                    children: emoji
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/editor/steps/list/IngredientChip.tsx",
                    lineNumber: 55,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/steps/list/IngredientChip.tsx",
                lineNumber: 46,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-xs font-bold truncate max-w-30",
                children: name
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/steps/list/IngredientChip.tsx",
                lineNumber: 60,
                columnNumber: 7
            }, this),
            quantity && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-[9px] text-slate-300 font-mono leading-none bg-slate-950/50 px-1 py-0.5 rounded border border-slate-700/50",
                children: quantity
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/steps/list/IngredientChip.tsx",
                lineNumber: 64,
                columnNumber: 9
            }, this),
            price && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-[9px] font-black text-emerald-400 bg-emerald-950/80 px-1 py-0.5 rounded leading-none border border-emerald-500/20",
                children: [
                    price,
                    "€"
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/editor/steps/list/IngredientChip.tsx",
                lineNumber: 71,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/editor/steps/list/IngredientChip.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
_c = IngredientChip;
var _c;
__turbopack_context__.k.register(_c, "IngredientChip");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/parts/CountdownTimer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CountdownTimer",
    ()=>CountdownTimer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
function CountdownTimer({ minutes }) {
    _s();
    const [timeLeft, setTimeLeft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(minutes * 60);
    const [isActive, setIsActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isFinished, setIsFinished] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CountdownTimer.useEffect": ()=>{
            let interval;
            if (isActive) {
                interval = setInterval({
                    "CountdownTimer.useEffect": ()=>{
                        setTimeLeft({
                            "CountdownTimer.useEffect": (prev)=>{
                                if (prev <= 1) {
                                    clearInterval(interval);
                                    setIsActive(false);
                                    setIsFinished(true);
                                    return 0;
                                }
                                return prev - 1;
                            }
                        }["CountdownTimer.useEffect"]);
                    }
                }["CountdownTimer.useEffect"], 1000);
            }
            return ({
                "CountdownTimer.useEffect": ()=>clearInterval(interval)
            })["CountdownTimer.useEffect"];
        }
    }["CountdownTimer.useEffect"], [
        isActive
    ]); // ✅ Dependència neta
    const toggleTimer = (e)=>{
        e.stopPropagation();
        if (isFinished) {
            setTimeLeft(minutes * 60);
            setIsFinished(false);
            setIsActive(true);
        } else {
            setIsActive(!isActive);
        }
    };
    const formatTime = (seconds)=>{
        const m = Math.floor(seconds / 60);
        const s = seconds % 60;
        return `${m}:${s < 10 ? '0' : ''}${s}`;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        onClick: toggleTimer,
        className: `
        inline-flex items-center gap-2 px-2 py-0.5 rounded-full text-[10px] font-bold font-mono transition-all ml-2 align-middle
        ${isFinished ? 'bg-red-600 text-white animate-pulse' : isActive ? 'bg-purple-600 text-white border border-purple-400' : 'bg-slate-800 text-purple-300 border border-slate-700 hover:bg-slate-700'}
      `,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: isActive ? '⏳' : isFinished ? '🔔' : '⏱️'
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/parts/CountdownTimer.tsx",
                lineNumber: 59,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: isFinished ? 'FI' : formatTime(timeLeft)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/parts/CountdownTimer.tsx",
                lineNumber: 60,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/parts/CountdownTimer.tsx",
        lineNumber: 47,
        columnNumber: 5
    }, this);
}
_s(CountdownTimer, "g8eb58TatM2rhtXmQAM/b/lI+a0=");
_c = CountdownTimer;
var _c;
__turbopack_context__.k.register(_c, "CountdownTimer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/editor/steps/list/HighlightedContent.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HighlightedContent",
    ()=>HighlightedContent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$list$2f$IngredientChip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/editor/steps/list/IngredientChip.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$parts$2f$CountdownTimer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/parts/CountdownTimer.tsx [app-client] (ecmascript)");
'use client';
;
;
;
function HighlightedContent({ content, ingredients, interactive = false }) {
    // ✅ 1. PROTECCIÓ ROBUSTA: Si no hi ha contingut o no és string, retornem null
    if (!content || typeof content !== 'string') return null;
    // Ara és segur fer .split()
    const parts = content.split(/(\[.*?\]|⏰\s*\d+\s*(?:min|minuts|minutes|s|segons)?)/g);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        className: "whitespace-pre-wrap leading-relaxed text-base text-slate-300",
        children: parts.map((part, i)=>{
            const key = `part-${i}-${part.substring(0, 5)}`;
            // CAS 1: TEMPS
            if (part.startsWith('⏰')) {
                if (interactive) {
                    const timeMatch = part.match(/(\d+)/);
                    const minutes = timeMatch ? parseInt(timeMatch[0]) : 0;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$parts$2f$CountdownTimer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CountdownTimer"], {
                        minutes: minutes
                    }, key, false, {
                        fileName: "[project]/features/recipes/components/editor/steps/list/HighlightedContent.tsx",
                        lineNumber: 30,
                        columnNumber: 24
                    }, this);
                }
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "inline-flex items-center gap-1 bg-purple-500/10 text-purple-300 px-1.5 py-0.5 rounded-md text-xs font-bold mx-1 border border-purple-500/20 align-baseline shadow-sm",
                    children: part
                }, key, false, {
                    fileName: "[project]/features/recipes/components/editor/steps/list/HighlightedContent.tsx",
                    lineNumber: 33,
                    columnNumber: 17
                }, this);
            }
            // CAS 2: INGREDIENT [Nom]
            if (part.startsWith('[') && part.endsWith(']')) {
                const cleanName = part.slice(1, -1);
                // Busquem l'ingredient complet a la llista per tenir imatge/preu
                const ingredientData = ingredients.find((ing)=>ing.name === cleanName);
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$list$2f$IngredientChip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IngredientChip"], {
                    name: cleanName,
                    ingredient: ingredientData
                }, key, false, {
                    fileName: "[project]/features/recipes/components/editor/steps/list/HighlightedContent.tsx",
                    lineNumber: 46,
                    columnNumber: 13
                }, this);
            }
            // CAS 3: Text normal
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: part
            }, key, false, {
                fileName: "[project]/features/recipes/components/editor/steps/list/HighlightedContent.tsx",
                lineNumber: 55,
                columnNumber: 16
            }, this);
        })
    }, void 0, false, {
        fileName: "[project]/features/recipes/components/editor/steps/list/HighlightedContent.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
}
_c = HighlightedContent;
var _c;
__turbopack_context__.k.register(_c, "HighlightedContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/editor/steps/StepsList.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StepsList",
    ()=>StepsList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$Reorder$2f$namespace$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Reorder$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/components/Reorder/namespace.mjs [app-client] (ecmascript) <export * as Reorder>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/trash-2.js [app-client] (ecmascript) <export default as Trash2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$grip$2d$vertical$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__GripVertical$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/grip-vertical.js [app-client] (ecmascript) <export default as GripVertical>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pencil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pencil$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/pencil.js [app-client] (ecmascript) <export default as Pencil>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$list$2d$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListChecks$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/list-checks.js [app-client] (ecmascript) <export default as ListChecks>");
// Importem el contingut renderitzat
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$list$2f$HighlightedContent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/editor/steps/list/HighlightedContent.tsx [app-client] (ecmascript)");
'use client';
;
;
;
;
function StepsList({ steps, ingredients, onReorder, onRemove, onEdit, editingId, listEndRef, labels }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col h-full overflow-hidden bg-slate-950/40 relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-4 pb-2 shrink-0 bg-slate-900/80 backdrop-blur-sm border-b border-slate-800 z-10 flex justify-between items-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    className: "text-xs font-bold uppercase text-slate-500 tracking-wider flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-lg",
                            children: "📋"
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                            lineNumber: 36,
                            columnNumber: 11
                        }, this),
                        " ",
                        labels.title,
                        " (",
                        steps.length,
                        ")"
                    ]
                }, void 0, true, {
                    fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                    lineNumber: 35,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 overflow-y-auto p-4 custom-scrollbar pb-32",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$Reorder$2f$namespace$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Reorder$3e$__["Reorder"].Group, {
                        axis: "y",
                        values: steps,
                        onReorder: onReorder,
                        className: "space-y-3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                            initial: false,
                            mode: "popLayout",
                            children: steps.map((step, index)=>{
                                const isEditing = step.id === editingId;
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$Reorder$2f$namespace$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Reorder$3e$__["Reorder"].Item, {
                                    value: step,
                                    initial: {
                                        opacity: 0,
                                        y: 20
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    exit: {
                                        opacity: 0,
                                        scale: 0.9
                                    },
                                    className: "relative flex gap-3 group touch-manipulation",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "shrink-0 flex flex-col items-center gap-1 pt-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: `
                        w-6 h-6 rounded-full border flex items-center justify-center text-[10px] font-black transition-colors shadow-sm cursor-grab active:cursor-grabbing select-none
                        ${isEditing ? 'bg-purple-600 border-purple-500 text-white scale-110 shadow-purple-500/40' : 'bg-slate-800 border-slate-700 text-slate-400 group-hover:border-purple-500 group-hover:text-purple-400'}
                      `,
                                                    children: isEditing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pencil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pencil$3e$__["Pencil"], {
                                                        size: 12
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                                                        lineNumber: 67,
                                                        columnNumber: 36
                                                    }, this) : index + 1
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                                                    lineNumber: 58,
                                                    columnNumber: 21
                                                }, this),
                                                index < steps.length - 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "w-px h-full bg-slate-800 group-hover:bg-slate-700"
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                                                    lineNumber: 70,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                                            lineNumber: 57,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            onClick: ()=>onEdit(step),
                                            className: `
                      flex-1 border rounded-xl p-3 pr-8 transition-all relative shadow-sm cursor-pointer select-none
                      ${isEditing ? 'bg-purple-900/10 border-purple-500/50 ring-1 ring-purple-500/20' : 'bg-slate-900 border-slate-800 text-slate-200 hover:border-slate-600 hover:bg-slate-800'}
                    `,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$list$2f$HighlightedContent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HighlightedContent"], {
                                                    content: step.content,
                                                    ingredients: ingredients
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                                                    lineNumber: 86,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "absolute right-2 top-2 flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$grip$2d$vertical$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__GripVertical$3e$__["GripVertical"], {
                                                            className: "text-slate-600 cursor-grab active:cursor-grabbing hover:text-slate-400",
                                                            size: 14
                                                        }, void 0, false, {
                                                            fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                                                            lineNumber: 90,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: (e)=>{
                                                                e.stopPropagation();
                                                                onRemove(step.id);
                                                            },
                                                            className: "text-slate-600 hover:text-red-400 p-0.5 transition-colors",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                                                size: 14
                                                            }, void 0, false, {
                                                                fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                                                                lineNumber: 101,
                                                                columnNumber: 25
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                                                            lineNumber: 94,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                                                    lineNumber: 89,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                                            lineNumber: 75,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, step.id, true, {
                                    fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                                    lineNumber: 48,
                                    columnNumber: 17
                                }, this);
                            })
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                            lineNumber: 43,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: listEndRef
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                        lineNumber: 111,
                        columnNumber: 9
                    }, this),
                    steps.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center py-10 opacity-30 select-none",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$list$2d$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListChecks$3e$__["ListChecks"], {
                                size: 40,
                                className: "mx-auto mb-2 text-slate-500"
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                                lineNumber: 115,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs",
                                children: labels.empty_state
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                                lineNumber: 116,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                        lineNumber: 114,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/editor/steps/StepsList.tsx",
        lineNumber: 32,
        columnNumber: 5
    }, this);
}
_c = StepsList;
var _c;
__turbopack_context__.k.register(_c, "StepsList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/editor/StepsBuilder.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StepsBuilder",
    ()=>StepsBuilder
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$useStepsManager$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/editor/steps/useStepsManager.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$StepsInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/editor/steps/StepsInput.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$StepsList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/editor/steps/StepsList.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pen$2d$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PenLine$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/pen-line.js [app-client] (ecmascript) <export default as PenLine>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/eye.js [app-client] (ecmascript) <export default as Eye>");
;
var _s = __turbopack_context__.k.signature();
// src/components/recipes/editor/StepsBuilder.tsx
'use client';
;
;
;
;
;
function StepsBuilder({ data, update, labels, textareaId, stepsListId }) {
    _s();
    const { currentStepText, setCurrentStepText, editingId, startEditing, cancelEditing, saveStep, textareaRef, listEndRef, removeStep, handleReorder } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$useStepsManager$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStepsManager"])(data, update);
    const [mobileView, setMobileView] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('edit');
    // Wrapper per canviar de vista automàticament al mòbil quan editem
    const handleEditClick = (step)=>{
        startEditing(step);
        setMobileView('edit'); // 👈 Màgia UX
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "h-full flex flex-col lg:grid lg:grid-cols-2 lg:divide-x divide-slate-800 relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "lg:hidden shrink-0 flex p-1 bg-slate-900 border-b border-slate-800",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setMobileView('edit'),
                        className: `flex-1 py-2 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all ${mobileView === 'edit' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-500 hover:text-slate-300'}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pen$2d$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PenLine$3e$__["PenLine"], {
                                size: 14
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/editor/StepsBuilder.tsx",
                                lineNumber: 57,
                                columnNumber: 11
                            }, this),
                            " Editor"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/editor/StepsBuilder.tsx",
                        lineNumber: 50,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setMobileView('preview'),
                        className: `flex-1 py-2 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all ${mobileView === 'preview' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-500 hover:text-slate-300'}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__["Eye"], {
                                size: 14
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/editor/StepsBuilder.tsx",
                                lineNumber: 66,
                                columnNumber: 11
                            }, this),
                            " Llista (",
                            data.steps.length,
                            ")"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/editor/StepsBuilder.tsx",
                        lineNumber: 59,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/editor/StepsBuilder.tsx",
                lineNumber: 49,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: textareaId,
                className: `
          flex-col h-full overflow-hidden
          ${mobileView === 'preview' ? 'hidden lg:flex' : 'flex'}
      `,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$StepsInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StepsInput"], {
                    data: data,
                    currentText: currentStepText,
                    onChangeText: setCurrentStepText,
                    onSave: saveStep,
                    onCancel: cancelEditing,
                    isEditing: !!editingId,
                    textareaRef: textareaRef,
                    labels: labels
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/editor/StepsBuilder.tsx",
                    lineNumber: 75,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/StepsBuilder.tsx",
                lineNumber: 71,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: stepsListId,
                className: `
          flex-col h-full overflow-hidden bg-slate-950/40
          ${mobileView === 'edit' ? 'hidden lg:flex' : 'flex'}
      `,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$StepsList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StepsList"], {
                    // ✅ CORRECCIÓ: Forcem que cada step tingui un id string per satisfer TS
                    steps: data.steps.map((step)=>({
                            ...step,
                            id: step.id || crypto.randomUUID() // Si no hi ha ID, en creem un de temporal
                        })),
                    ingredients: data.ingredients,
                    onReorder: handleReorder,
                    onRemove: removeStep,
                    onEdit: handleEditClick,
                    editingId: editingId,
                    listEndRef: listEndRef,
                    labels: labels
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/editor/StepsBuilder.tsx",
                    lineNumber: 93,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/StepsBuilder.tsx",
                lineNumber: 88,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/editor/StepsBuilder.tsx",
        lineNumber: 46,
        columnNumber: 5
    }, this);
}
_s(StepsBuilder, "Fy24qFBFnW+cDu7XYyeGNqXOvtY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$useStepsManager$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStepsManager"]
    ];
});
_c = StepsBuilder;
var _c;
__turbopack_context__.k.register(_c, "StepsBuilder");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/editor/MetaControls.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MetaControls",
    ()=>MetaControls
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Minus$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/minus.js [app-client] (ecmascript) <export default as Minus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/tag.js [app-client] (ecmascript) <export default as Tag>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function getTitleEmoji(name) {
    const n = name.toLowerCase();
    if (!n) return '✨';
    if (n.includes('pizza')) return '🍕';
    if (n.includes('pasta') || n.includes('macarru')) return '🍝';
    if (n.includes('burger')) return '🍔';
    if (n.includes('amanida') || n.includes('enciam') || n.includes('salad')) return '🥗';
    if (n.includes('pollastre')) return '🍗';
    if (n.includes('arròs') || n.includes('paella')) return '🥘';
    if (n.includes('sushi')) return '🍣';
    if (n.includes('pastís') || n.includes('xocolata') || n.includes('cake')) return '🍰';
    if (n.includes('taco') || n.includes('fajita')) return '🌮';
    if (n.includes('peix') || n.includes('dorada')) return '🐟';
    if (n.includes('sopa') || n.includes('brou')) return '🥣';
    if (n.includes('entrepà') || n.includes('bocata')) return '🥪';
    return '🥘';
}
function MetaControls({ data, update, hasError, titleInputId, prepTimeId, tagsContainerId }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const labels = t.create_recipe.meta;
    const tagsDict = labels.tags;
    const titleEmoji = getTitleEmoji(data.name);
    const textareaRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const TAGS = [
        {
            id: 'quick',
            label: tagsDict.quick,
            emoji: '⚡',
            color: 'text-yellow-400 border-yellow-500/30 bg-yellow-900/20'
        },
        {
            id: 'healthy',
            label: tagsDict.healthy,
            emoji: '💚',
            color: 'text-emerald-400 border-emerald-500/30 bg-emerald-900/20'
        },
        {
            id: 'vegan',
            label: tagsDict.vegan,
            emoji: '🌱',
            color: 'text-green-400 border-green-500/30 bg-green-900/20'
        },
        {
            id: 'vegetarian',
            label: tagsDict.vegetarian,
            emoji: '🥗',
            color: 'text-lime-400 border-lime-500/30 bg-lime-900/20'
        },
        {
            id: 'gluten-free',
            label: tagsDict.gluten_free,
            emoji: '🌾',
            color: 'text-amber-400 border-amber-500/30 bg-amber-900/20'
        },
        {
            id: 'dairy-free',
            label: tagsDict.dairy_free,
            emoji: '🥛',
            color: 'text-blue-300 border-blue-500/30 bg-blue-900/20'
        },
        {
            id: 'dessert',
            label: tagsDict.dessert,
            emoji: '🍰',
            color: 'text-pink-400 border-pink-500/30 bg-pink-900/20'
        },
        {
            id: 'spicy',
            label: 'Picant',
            emoji: '🌶️',
            color: 'text-red-400 border-red-500/30 bg-red-900/20'
        }
    ];
    const TIME_PRESETS = [
        15,
        30,
        45,
        60,
        90
    ];
    const toggleTag = (id)=>{
        update({
            ...data,
            dietaryTags: data.dietaryTags.includes(id) ? data.dietaryTags.filter((t)=>t !== id) : [
                ...data.dietaryTags,
                id
            ]
        });
    };
    const adjustTime = (delta)=>{
        // Convertim data.prepTimeMinutes a Number abans de sumar
        const currentTime = Number(data.prepTimeMinutes) || 0;
        update({
            ...data,
            prepTimeMinutes: Math.max(0, currentTime + delta)
        });
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "MetaControls.useEffect": ()=>{
            if (textareaRef.current) {
                textareaRef.current.style.height = 'auto';
                textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
            }
        }
    }["MetaControls.useEffect"], [
        data.name
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col gap-8 pb-32",
        children: [
            " ",
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "relative pt-2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col sm:flex-row sm:items-start gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-center sm:justify-start",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                                mode: "wait",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                    initial: {
                                        scale: 0.5,
                                        rotate: -20,
                                        opacity: 0
                                    },
                                    animate: {
                                        scale: 1,
                                        rotate: 0,
                                        opacity: 1
                                    },
                                    exit: {
                                        scale: 0.5,
                                        rotate: 20,
                                        opacity: 0
                                    },
                                    className: "text-6xl sm:text-7xl filter drop-shadow-2xl p-2 bg-slate-900/50 rounded-3xl border border-slate-800",
                                    children: titleEmoji
                                }, titleEmoji, false, {
                                    fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                    lineNumber: 102,
                                    columnNumber: 22
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                lineNumber: 101,
                                columnNumber: 19
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                            lineNumber: 100,
                            columnNumber: 16
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-1 min-w-0 text-center sm:text-left",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-xs font-bold text-slate-500 uppercase tracking-widest mb-2 block",
                                    children: "Nom de la Recepta"
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                    lineNumber: 115,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                    id: titleInputId,
                                    "data-testid": "recipe-title-input",
                                    ref: textareaRef,
                                    rows: 1,
                                    value: data.name,
                                    onChange: (e)=>update({
                                            ...data,
                                            name: e.target.value
                                        }),
                                    placeholder: labels.placeholder_name,
                                    className: `
                    w-full bg-transparent text-3xl sm:text-5xl font-black text-white placeholder:text-slate-800 outline-none resize-none overflow-hidden leading-tight border-b-2 transition-colors text-center sm:text-left
                    ${hasError ? 'border-red-500/50 placeholder:text-red-900/50' : 'border-transparent focus:border-slate-800'}
                `,
                                    style: {
                                        fieldSizing: 'content'
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                    lineNumber: 116,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                            lineNumber: 114,
                            columnNumber: 16
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                    lineNumber: 98,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                lineNumber: 97,
                columnNumber: 10
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "space-y-3",
                id: prepTimeId,
                children: [
                    " ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2 text-slate-400 mb-2 px-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"], {
                                size: 16,
                                className: "text-purple-400"
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                lineNumber: 137,
                                columnNumber: 16
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xs font-bold uppercase tracking-wider",
                                children: "Temps de Preparació"
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                lineNumber: 138,
                                columnNumber: 16
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                        lineNumber: 136,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-slate-900/50 p-4 rounded-3xl border border-slate-800 flex flex-col gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between bg-slate-950 p-2 rounded-2xl border border-slate-800",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>adjustTime(-5),
                                        className: "w-12 h-12 flex items-center justify-center bg-slate-800 hover:bg-slate-700 text-slate-400 rounded-xl active:scale-95 transition-all",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Minus$3e$__["Minus"], {
                                            size: 20
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                            lineNumber: 145,
                                            columnNumber: 22
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                        lineNumber: 144,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-col items-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-3xl font-black text-white font-mono",
                                                children: data.prepTimeMinutes
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                                lineNumber: 149,
                                                columnNumber: 22
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[10px] text-slate-500 font-bold uppercase",
                                                children: "minuts"
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                                lineNumber: 150,
                                                columnNumber: 22
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                        lineNumber: 148,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>adjustTime(5),
                                        className: "w-12 h-12 flex items-center justify-center bg-slate-800 hover:bg-slate-700 text-white rounded-xl active:scale-95 transition-all shadow-lg shadow-purple-500/10",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                            size: 20
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                            lineNumber: 154,
                                            columnNumber: 22
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                        lineNumber: 153,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                lineNumber: 143,
                                columnNumber: 16
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-5 gap-2",
                                children: TIME_PRESETS.map((t)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>update({
                                                ...data,
                                                prepTimeMinutes: t
                                            }),
                                        className: `
                        py-2 rounded-xl text-xs font-bold border transition-all
                        ${data.prepTimeMinutes === t ? 'bg-purple-600 border-purple-500 text-white shadow-lg shadow-purple-500/20' : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-slate-300'}
                     `,
                                        children: t
                                    }, t, false, {
                                        fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                        lineNumber: 161,
                                        columnNumber: 22
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                lineNumber: 159,
                                columnNumber: 16
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                        lineNumber: 141,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                lineNumber: 135,
                columnNumber: 10
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "space-y-3",
                id: tagsContainerId,
                children: [
                    " ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2 text-slate-400 mb-2 px-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__["Tag"], {
                                size: 16,
                                className: "text-emerald-400"
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                lineNumber: 182,
                                columnNumber: 16
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xs font-bold uppercase tracking-wider",
                                children: "Etiquetes"
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                lineNumber: 183,
                                columnNumber: 16
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                        lineNumber: 181,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-2",
                        children: TAGS.map((tag)=>{
                            const isActive = data.dietaryTags.includes(tag.id);
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>toggleTag(tag.id),
                                className: `
                        relative flex items-center gap-3 px-4 py-3 rounded-2xl border transition-all text-left overflow-hidden active:scale-95
                        ${isActive ? `bg-slate-900 border-slate-700 ${tag.color.split(' ')[0]} shadow-lg` : 'bg-slate-900/30 border-slate-800 text-slate-500 hover:bg-slate-900'}
                     `,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-2xl",
                                        children: tag.emoji
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                        lineNumber: 201,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `text-xs font-bold uppercase tracking-wide ${isActive ? 'text-white' : 'text-slate-500'}`,
                                        children: tag.label
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                        lineNumber: 202,
                                        columnNumber: 25
                                    }, this),
                                    isActive && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                        layoutId: `active-tag-${tag.id}`,
                                        className: `absolute inset-0 border-2 rounded-2xl opacity-20 ${tag.color.split(' ')[1]}`
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                        lineNumber: 207,
                                        columnNumber: 28
                                    }, this)
                                ]
                            }, tag.id, true, {
                                fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                                lineNumber: 190,
                                columnNumber: 22
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                        lineNumber: 186,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
                lineNumber: 180,
                columnNumber: 10
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/editor/MetaControls.tsx",
        lineNumber: 94,
        columnNumber: 7
    }, this);
}
_s(MetaControls, "0dBUcVLFlxmwBze9wUn4o6Hgphw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = MetaControls;
var _c;
__turbopack_context__.k.register(_c, "MetaControls");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/onboarding/OnboardingContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OnboardingProvider",
    ()=>OnboardingProvider,
    "useOnboarding",
    ()=>useOnboarding
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
const OnboardingContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function OnboardingProvider({ children }) {
    _s();
    const [isActive, setIsActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [currentStepIndex, setCurrentStepIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [steps, setSteps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // Guardem quin tour estem fent per poder marcar-lo com a vist
    const [currentTourId, setCurrentTourId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const startTour = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OnboardingProvider.useCallback[startTour]": (tourId, newSteps, options = {})=>{
            if ("TURBOPACK compile-time truthy", 1) return;
            //TURBOPACK unreachable
            ;
            // Generem una clau única per aquest tour (ex: triatu_tour_seen_profile-setup)
            const storageKey = undefined;
            const hasSeen = undefined;
        }
    }["OnboardingProvider.useCallback[startTour]"], []);
    // ✅ Aquesta funció tanca el tour i GUANDA LA PREFERÈNCIA
    const finishTour = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OnboardingProvider.useCallback[finishTour]": ()=>{
            setIsActive(false);
            if (currentTourId) {
                // Guardem al navegador que aquest tour ja s'ha fet (o tancat)
                localStorage.setItem(`triatu_tour_seen_${currentTourId}`, 'true');
                console.log(`✅ [Onboarding] Tour '${currentTourId}' marcat com a vist.`);
            }
            // Resetegem per netejar
            setCurrentTourId('');
            setSteps([]);
            setCurrentStepIndex(0);
        }
    }["OnboardingProvider.useCallback[finishTour]"], [
        currentTourId
    ]);
    const nextStep = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OnboardingProvider.useCallback[nextStep]": ()=>{
            setCurrentStepIndex({
                "OnboardingProvider.useCallback[nextStep]": (prev)=>{
                    if (prev < steps.length - 1) {
                        return prev + 1;
                    } else {
                        finishTour(); // Si és l'últim pas, acabem i guardem
                        return prev;
                    }
                }
            }["OnboardingProvider.useCallback[nextStep]"]);
        }
    }["OnboardingProvider.useCallback[nextStep]"], [
        steps.length,
        finishTour
    ]);
    const prevStep = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OnboardingProvider.useCallback[prevStep]": ()=>{
            setCurrentStepIndex({
                "OnboardingProvider.useCallback[prevStep]": (prev)=>prev > 0 ? prev - 1 : prev
            }["OnboardingProvider.useCallback[prevStep]"]);
        }
    }["OnboardingProvider.useCallback[prevStep]"], []);
    // ✅ QUAN FEM CLICK A LA 'X'
    const skipTour = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OnboardingProvider.useCallback[skipTour]": ()=>{
            // Cridem a finishTour(), així que TAMBÉ ES GUARDA al localStorage
            finishTour();
        }
    }["OnboardingProvider.useCallback[skipTour]"], [
        finishTour
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OnboardingContext.Provider, {
        value: {
            isActive,
            currentStepIndex,
            steps,
            startTour,
            nextStep,
            prevStep,
            skipTour,
            finishTour
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/components/onboarding/OnboardingContext.tsx",
        lineNumber: 87,
        columnNumber: 5
    }, this);
}
_s(OnboardingProvider, "LwYR2QbA25DdOIzx6bjCxxgWgng=");
_c = OnboardingProvider;
function useOnboarding() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(OnboardingContext);
    if (!context) {
        throw new Error('useOnboarding must be used within an OnboardingProvider');
    }
    return context;
}
_s1(useOnboarding, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "OnboardingProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/onboarding/TourTrigger.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TourTrigger",
    ()=>TourTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$question$2d$mark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__HelpCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/circle-question-mark.js [app-client] (ecmascript) <export default as HelpCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/onboarding/OnboardingContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function TourTrigger({ steps, className, tourId }) {
    _s();
    const { startTour } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
        whileHover: {
            scale: 1.1,
            rotate: 10
        },
        whileTap: {
            scale: 0.9
        },
        onClick: ()=>{
            // ✅ { force: true } ignora el localStorage i l'activa igualment
            startTour(tourId, steps, {
                force: true
            }); // ✅ Passem l'ID
        },
        className: `
        flex items-center justify-center w-10 h-10 rounded-full 
        bg-slate-800 border border-slate-700 text-slate-400 
        hover:text-purple-400 hover:border-purple-500/50 hover:bg-slate-800/80
        transition-all shadow-lg z-50
        ${className}
      `,
        title: "Repetir la Guia 🆘",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$question$2d$mark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__HelpCircle$3e$__["HelpCircle"], {
            size: 20
        }, void 0, false, {
            fileName: "[project]/components/onboarding/TourTrigger.tsx",
            lineNumber: 34,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/onboarding/TourTrigger.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
}
_s(TourTrigger, "UeKKQgLVCaRaRTAKbwquCHh9TY8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"]
    ];
});
_c = TourTrigger;
var _c;
__turbopack_context__.k.register(_c, "TourTrigger");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:2d7a82 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "saveRecipeAction",
    ()=>$$RSC_SERVER_ACTION_0
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"40ffcc09c13a24ff1fda9dc93b16548415ffc7f4d3":"saveRecipeAction"},"app/actions/recipe-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40ffcc09c13a24ff1fda9dc93b16548415ffc7f4d3", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "saveRecipeAction");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vcmVjaXBlLWFjdGlvbnMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQVJYSVU6IGFwcC9hY3Rpb25zL3JlY2lwZS1hY3Rpb25zLnRzXHJcbid1c2Ugc2VydmVyJ1xyXG5cclxuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSAnQC9hZGFwdGVycy9zdXBhYmFzZS9zZXJ2ZXInO1xyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gJ25leHQvY2FjaGUnO1xyXG4vLyDinIUgRklYOiBJbXBvcnRlbSBlbCByZXBvc2l0b3JpIHF1ZSBmYWx0YXZhXHJcbmltcG9ydCB7IFN1cGFiYXNlUmVjaXBlUmVwb3NpdG9yeSB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2UvU3VwYWJhc2VSZWNpcGVSZXBvc2l0b3J5JztcclxuaW1wb3J0IHsgY29udGFpbmVyIH0gZnJvbSAnQC9zZXJ2aWNlcy9jb250YWluZXInO1xyXG5pbXBvcnQgeyBFbW9qaU1hdGNoZXJTZXJ2aWNlIH0gZnJvbSAnQC9jb3JlL2FwcGxpY2F0aW9uL3NlcnZpY2VzL0Vtb2ppTWF0Y2hlclNlcnZpY2UnOyAvLyDinIUgSW1wb3J0ZW0gZWwgTWF0Y2hlclxyXG5pbXBvcnQgeyBHZW5lcmF0ZVJlY2lwZVNjaGVtYSwgTWF0ZXJpYWxpemVSZWNpcGVTY2hlbWEgfSBmcm9tICdAL2NvcmUvYXBwbGljYXRpb24vc2NoZW1hcy9pbnB1dFNjaGVtYXMnO1xyXG5pbXBvcnQgeyBTdXBhYmFzZVJhdGVMaW1pdGVyIH0gZnJvbSAnQC9hZGFwdGVycy9zdXBhYmFzZS9TdXBhYmFzZVJhdGVMaW1pdGVyJztcclxuaW1wb3J0IHsgU3VwYWJhc2VTZWN1cml0eUxvZ2dlciB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2UvU3VwYWJhc2VTZWN1cml0eUxvZ2dlcic7XHJcbmltcG9ydCB7IGRlYnVnLCBlcnJvciBhcyBsb2dFcnJvciB9IGZyb20gJ0AvbGliL2xvZ2dlcic7XHJcblxyXG4vLyDinIUgRklYOiBEZWZpbmljacOzIHJvYnVzdGEgZGUgbGEgcmVzcG9zdGFcclxuZXhwb3J0IHR5cGUgQWN0aW9uUmVzcG9uc2UgPSB7XHJcbiAgICBzdWNjZXNzOiBib29sZWFuO1xyXG4gICAgcmVjaXBlSWQ/OiBzdHJpbmc7XHJcbiAgICBlcnJvcj86IHN0cmluZzsgLy8gSW1wb3J0YW50IHF1ZSBzaWd1aSBvcGNpb25hbCAoPylcclxufTtcclxuXHJcbi8vIFRpcHVzIHVuaWZpY2F0IHF1ZSBjb2JyZWl4aSBlbCBxdWUgdmUgZGUgbCdFZGl0b3IgaSBlbCBxdWUgdmUgZGUgbGEgSUFcclxuZXhwb3J0IGludGVyZmFjZSBTYXZlUmVjaXBlSW5wdXQge1xyXG4gIGlkPzogc3RyaW5nO1xyXG4gIG5hbWU6IHN0cmluZztcclxuICBwcmVwVGltZU1pbnV0ZXM6IG51bWJlciB8IHN0cmluZztcclxuICBcclxuICBpbmdyZWRpZW50czoge1xyXG4gICAgaWQ/OiBzdHJpbmc7XHJcbiAgICBuYW1lOiBzdHJpbmc7XHJcbiAgICBxdWFudGl0eTogbnVtYmVyO1xyXG4gICAgdW5pdDogc3RyaW5nO1xyXG4gICAgZW1vamk/OiBzdHJpbmc7XHJcbiAgICBlc3RpbWF0ZWRDb3N0PzogbnVtYmVyIHwgc3RyaW5nO1xyXG4gICAgbGlua2VkUHJvZHVjdElkPzogc3RyaW5nIHwgbnVsbDtcclxuICAgIGxpbmtlZFByb2R1Y3RJbWFnZT86IHN0cmluZyB8IG51bGw7XHJcbiAgfVtdO1xyXG4gIHN0ZXBzOiAoc3RyaW5nIHwgeyBpZDogc3RyaW5nOyBjb250ZW50OiBzdHJpbmcgfSlbXTtcclxuICB0YWdzPzogc3RyaW5nW107XHJcbiAgZGlldGFyeVRhZ3M/OiBzdHJpbmdbXTtcclxuICBpc0FpR2VuZXJhdGVkPzogYm9vbGVhbjtcclxufVxyXG5cclxuLy8gLS0tIEFDQ0nDkyBQUklOQ0lQQUw6IFNBVkUgLS0tXHJcbi8vIEFxdWVzdGEgY29udMOpIHRvdGEgbGEgbMOyZ2ljYSBcImludGVswrdsaWdlbnRcIiAocHJldXMsIGltYXRnZXMsIGVtb2ppcy4uLilcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNhdmVSZWNpcGVBY3Rpb24oZGF0YTogU2F2ZVJlY2lwZUlucHV0KTogUHJvbWlzZTxBY3Rpb25SZXNwb25zZT4ge1xyXG4gIGRlYnVnKCdbU0FWRSBBQ1RJT05dIHNhdmVSZWNpcGVBY3Rpb24nKTtcclxuXHJcbiAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICBpZiAoIXVzZXIpIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9O1xyXG5cclxuICB0cnkge1xyXG4gICAgbGV0IGF1dGhvck5hbWUgPSBcIlhlZiBBbsOybmltXCI7XHJcbiAgICBjb25zdCB7IGRhdGE6IHByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3ByZWZlcmVuY2VfcHJvZmlsZXMnKS5zZWxlY3QoJ3VzZXJuYW1lJykuZXEoJ3VzZXJfaWQnLCB1c2VyLmlkKS5zaW5nbGUoKTtcclxuICAgIGlmIChwcm9maWxlPy51c2VybmFtZSkgYXV0aG9yTmFtZSA9IHByb2ZpbGUudXNlcm5hbWU7XHJcblxyXG4gICAgLy8gMS4gQ8OgbGN1bCBkZSBjb3N0IHRvdGFsIChST0JVU1QpXHJcbiAgICBjb25zdCB0b3RhbENvc3QgPSBkYXRhLmluZ3JlZGllbnRzLnJlZHVjZSgoYWNjLCBpbmcpID0+IHtcclxuICAgICAgbGV0IGNvc3RWYWwgPSBpbmcuZXN0aW1hdGVkQ29zdDtcclxuICAgICAgaWYgKHR5cGVvZiBjb3N0VmFsID09PSAnc3RyaW5nJykgY29zdFZhbCA9IHBhcnNlRmxvYXQoY29zdFZhbCk7XHJcbiAgICAgIGNvbnN0IGNvc3QgPSBOdW1iZXIoY29zdFZhbCkgfHwgMDtcclxuICAgICAgcmV0dXJuIGFjYyArIGNvc3Q7XHJcbiAgICB9LCAwKTtcclxuXHJcbiAgICBsZXQgaXNBaUdlbmVyYXRlZCA9ICEhZGF0YS5pc0FpR2VuZXJhdGVkO1xyXG4gICAgaWYgKCFpc0FpR2VuZXJhdGVkICYmIGRhdGEuaWQpIHtcclxuICAgICAgY29uc3QgeyBkYXRhOiBvbGRSZWNpcGUgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3NhdmVkX3JlY2lwZXMnKS5zZWxlY3QoJ2lzX2FpX2dlbmVyYXRlZCcpLmVxKCdpZCcsIGRhdGEuaWQpLnNpbmdsZSgpO1xyXG4gICAgICBpZiAob2xkUmVjaXBlKSBpc0FpR2VuZXJhdGVkID0gb2xkUmVjaXBlLmlzX2FpX2dlbmVyYXRlZDtcclxuICAgIH1cclxuXHJcbiAgICAvLyAyLiBQUk9DRVNTQVIgSU5HUkVESUVOVFMgKyBJTUFUR0VTXHJcbiAgICBjb25zdCBpbmdyZWRpZW50c1BheWxvYWQgPSBhd2FpdCBQcm9taXNlLmFsbChkYXRhLmluZ3JlZGllbnRzLm1hcChhc3luYyAoaW5nKSA9PiB7XHJcbiAgICAgIGxldCBmaW5hbElkID0gaW5nLmlkO1xyXG4gICAgICBsZXQgZmluYWxFbW9qaSA9IGluZy5lbW9qaTtcclxuICAgICAgY29uc3QgZmluYWxOYW1lID0gaW5nLm5hbWU7XHJcbiAgICAgIGNvbnN0IGxpbmtlZFByb2R1Y3RJZCA9IGluZy5saW5rZWRQcm9kdWN0SWQ7XHJcbiAgICAgIGxldCBsaW5rZWRQcm9kdWN0SW1hZ2UgPSBpbmcubGlua2VkUHJvZHVjdEltYWdlO1xyXG4gICAgICBjb25zdCBlc3RpbWF0ZWRDb3N0ID0gaW5nLmVzdGltYXRlZENvc3QgPyBOdW1iZXIoaW5nLmVzdGltYXRlZENvc3QpIDogMDtcclxuXHJcbiAgICAgIGNvbnN0IGhhc0xpbmsgPSB0eXBlb2YgbGlua2VkUHJvZHVjdElkID09PSAnc3RyaW5nJyAmJiBsaW5rZWRQcm9kdWN0SWQubGVuZ3RoID4gMDtcclxuXHJcbiAgICAgIGlmIChoYXNMaW5rKSB7XHJcbiAgICAgICAgLy8gLi4uIChMw7JnaWNhIGRlIHJlY3VwZXJhY2nDsyBkJ2ltYXRnZXMgaWd1YWwgcXVlIHRlbmllcykgLi4uXHJcbiAgICAgICAgaWYgKCFsaW5rZWRQcm9kdWN0SW1hZ2UpIHtcclxuICAgICAgICAgIGNvbnN0IHsgZGF0YTogcHJvZHVjdCB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgncHJvZHVjdF9jYXRhbG9nJykuc2VsZWN0KCdpbWFnZV91cmwnKS5lcSgnaWQnLCBsaW5rZWRQcm9kdWN0SWQpLnNpbmdsZSgpO1xyXG4gICAgICAgICAgaWYgKHByb2R1Y3Q/LmltYWdlX3VybCkgbGlua2VkUHJvZHVjdEltYWdlID0gcHJvZHVjdC5pbWFnZV91cmw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghZmluYWxJZCB8fCBmaW5hbElkLmxlbmd0aCA8IDUpIGZpbmFsSWQgPSBsaW5rZWRQcm9kdWN0SWQhO1xyXG4gICAgICAgIGlmICghZmluYWxFbW9qaSB8fCBmaW5hbEVtb2ppID09PSAn8J+lmCcpIGZpbmFsRW1vamkgPSAn8J+Tpic7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gTWF0Y2hlciBkJ2Vtb2ppc1xyXG4gICAgICAgIGNvbnN0IGNsZWFuTmFtZSA9IGZpbmFsTmFtZS5yZXBsYWNlKC9cXGIoQk9OUFJFVXxQQVRDSEVGfC4uLilcXGIvZ2ksIFwiXCIpLnRyaW0oKTtcclxuICAgICAgICBjb25zdCBwcmVzZXQgPSBFbW9qaU1hdGNoZXJTZXJ2aWNlLm1hdGNoKGNsZWFuTmFtZSk7XHJcbiAgICAgICAgaWYgKHByZXNldCkge1xyXG4gICAgICAgICAgZmluYWxJZCA9IHByZXNldC5pZDtcclxuICAgICAgICAgIGZpbmFsRW1vamkgPSBwcmVzZXQuZW1vamk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGlmICghZmluYWxFbW9qaSkgZmluYWxFbW9qaSA9ICfwn6WYJztcclxuICAgICAgICAgIGlmICghZmluYWxJZCkgZmluYWxJZCA9IGNyeXB0by5yYW5kb21VVUlEKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIGlkOiBmaW5hbElkLFxyXG4gICAgICAgIG5hbWU6IGZpbmFsTmFtZSxcclxuICAgICAgICBxdWFudGl0eTogaW5nLnF1YW50aXR5LFxyXG4gICAgICAgIHVuaXQ6IGluZy51bml0LFxyXG4gICAgICAgIGVtb2ppOiBmaW5hbEVtb2ppLFxyXG4gICAgICAgIGxpbmtlZFByb2R1Y3RJZDogaGFzTGluayA/IGxpbmtlZFByb2R1Y3RJZCA6IG51bGwsXHJcbiAgICAgICAgbGlua2VkUHJvZHVjdEltYWdlOiBoYXNMaW5rID8gbGlua2VkUHJvZHVjdEltYWdlIDogbnVsbCxcclxuICAgICAgICBlc3RpbWF0ZWRDb3N0XHJcbiAgICAgIH07XHJcbiAgICB9KSk7XHJcblxyXG4gICAgLy8gMy4gUFJPQ0VTU0FSIFBBU1NPU1xyXG4gICAgY29uc3Qgc3RlcHNEYXRhID0gZGF0YS5zdGVwcy5tYXAocyA9PiB7XHJcbiAgICAgIGlmICh0eXBlb2YgcyA9PT0gJ3N0cmluZycpIHJldHVybiB7IGlkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLCBjb250ZW50OiBzIH07XHJcbiAgICAgIHJldHVybiB7IGlkOiBzLmlkIHx8IGNyeXB0by5yYW5kb21VVUlEKCksIGNvbnRlbnQ6IHMuY29udGVudCB8fCBcIlwiIH07XHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyA0LiBQQVlMT0FEIEJEXHJcbiAgICBjb25zdCByZWNpcGVQYXlsb2FkID0ge1xyXG4gICAgICB1c2VyX2lkOiB1c2VyLmlkLFxyXG4gICAgICBuYW1lOiBkYXRhLm5hbWUsXHJcbiAgICAgIGF1dGhvcl9uYW1lOiBhdXRob3JOYW1lLFxyXG4gICAgICBwcmVwX3RpbWVfbWludXRlczogTnVtYmVyKGRhdGEucHJlcFRpbWVNaW51dGVzKSB8fCAwLFxyXG4gICAgICBpbmdyZWRpZW50czogaW5ncmVkaWVudHNQYXlsb2FkLFxyXG4gICAgICBzdGVwczogc3RlcHNEYXRhLFxyXG4gICAgICB0YWdzOiBkYXRhLnRhZ3MgfHwgW10sXHJcbiAgICAgIGRpZXRhcnlfdGFnczogZGF0YS5kaWV0YXJ5VGFncyB8fCBbXSxcclxuICAgICAgZXN0aW1hdGVkX2Nvc3Q6IHRvdGFsQ29zdCxcclxuICAgICAgaXNfcHVibGljOiBmYWxzZSwgLy8gUGVyIGRlZmVjdGUgcHJpdmFkYSBxdWFuIGVzIGd1YXJkYVxyXG4gICAgICBpc19haV9nZW5lcmF0ZWQ6IGlzQWlHZW5lcmF0ZWQsXHJcbiAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCB0YWJsZSA9IHN1cGFiYXNlLmZyb20oJ3NhdmVkX3JlY2lwZXMnKTtcclxuICAgIGxldCByZXN1bHRJZDogc3RyaW5nO1xyXG5cclxuICAgIGlmIChkYXRhLmlkKSB7XHJcbiAgICAgIC8vIC4uLiBMw7JnaWNhIGQnVXBkYXRlIGV4aXN0ZW50IC4uLlxyXG4gICAgICAvLyAoU2ltcGxpZmljYWRhIGFxdcOtIHBlciBicmV2ZXRhdCwgY29waWEgbGEgdGV2YSBsw7JnaWNhIGQndXBkYXRlKVxyXG4gICAgICBjb25zdCB7IGRhdGE6IHVwZGF0ZWQsIGVycm9yIH0gPSBhd2FpdCB0YWJsZS51cHNlcnQoeyAuLi5yZWNpcGVQYXlsb2FkLCBpZDogZGF0YS5pZCB9KS5zZWxlY3QoJ2lkJykuc2luZ2xlKCk7XHJcbiAgICAgIGlmIChlcnJvcikgdGhyb3cgZXJyb3I7XHJcbiAgICAgIHJlc3VsdElkID0gdXBkYXRlZC5pZDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnN0IHsgZGF0YTogaW5zZXJ0ZWQsIGVycm9yIH0gPSBhd2FpdCB0YWJsZS5pbnNlcnQocmVjaXBlUGF5bG9hZCkuc2VsZWN0KCdpZCcpLnNpbmdsZSgpO1xyXG4gICAgICBpZiAoZXJyb3IpIHRocm93IGVycm9yO1xyXG4gICAgICByZXN1bHRJZCA9IGluc2VydGVkLmlkO1xyXG4gICAgfVxyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvcmVjaXBlcycpO1xyXG4gICAgaWYgKHJlc3VsdElkKSByZXZhbGlkYXRlUGF0aChgL3JlY2lwZXMvJHtyZXN1bHRJZH1gKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIHJlY2lwZUlkOiByZXN1bHRJZCB9O1xyXG5cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ3NhdmVSZWNpcGVBY3Rpb24gZmFpbGVkJywgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkVycm9yIGludGVybi5cIiB9O1xyXG4gIH1cclxufVxyXG4vLyBBY2Npw7MgcGVyIEZhdm9yaXRzIChOZWNlc3NpdGEgZWwgUmVwb3NpdG9yaSlcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHRvZ2dsZUZhdm9yaXRlQWN0aW9uKHJlY2lwZUlkOiBzdHJpbmcpIHtcclxuICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0gfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpO1xyXG5cclxuICBpZiAoIXVzZXIpIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9O1xyXG5cclxuICAvLyBBcmEgc8OtIHF1ZSB0ZW5pbSBsJ2ltcG9ydCBhIGRhbHRcclxuICBjb25zdCByZXBvID0gbmV3IFN1cGFiYXNlUmVjaXBlUmVwb3NpdG9yeSgpO1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgaXNGYXYgPSBhd2FpdCByZXBvLnRvZ2dsZUZhdm9yaXRlKHVzZXIuaWQsIHJlY2lwZUlkKTtcclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL3JlY2lwZXMnKTtcclxuICAgIHJldmFsaWRhdGVQYXRoKGAvcmVjaXBlcy8ke3JlY2lwZUlkfWApO1xyXG5cclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGlzRmF2b3JpdGU6IGlzRmF2IH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGxvZ0Vycm9yKCdFcnJvciB1cGRhdGluZyBmYXZvcml0ZScsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciB1cGRhdGluZyBmYXZvcml0ZVwiIH07XHJcbiAgfVxyXG5cclxuXHJcbn1cclxuLy8g4pyFIEFxdWVzdGEgYWNjacOzIHN1YnN0aXR1ZWl4IGxhIGzDsmdpY2EgY29tcGxleGEgcXVlIHRlbmllcyBhYmFucy5cclxuLy8gQXJhIGZhIHNlcnZpciBsJ2VzdHJhdMOoZ2lhIEjDrWJyaWRhIChCRCArIElBKSBxdWUgaGVtIGRlZmluaXQgYWwgU2VydmljZS5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlTWVudUFjdGlvbihcclxuICB1c2VySWQ6IHN0cmluZyxcclxuICBkaXNoTmFtZTogc3RyaW5nLFxyXG4gIG1vZGU6ICdGQVRFJyB8ICdDSEVGJyxcclxuICBlbmVyZ3k6IG51bWJlciA9IDUwLFxyXG4gIHRpbWU6IG51bWJlciA9IDMwLFxyXG4gIGxhbmc6IHN0cmluZyA9ICdjYSdcclxuKSB7XHJcbiAgZGVidWcoJ1tBQ1RJT05dIGdlbmVyYXRlTWVudUFjdGlvbicpO1xyXG5cclxuICAvLyAxLiBWQUxJREFDScOTIChab2QpXHJcbiAgY29uc3QgdmFsaWRhdGlvbiA9IEdlbmVyYXRlUmVjaXBlU2NoZW1hLnNhZmVQYXJzZSh7IHVzZXJJZCwgZGlzaE5hbWUsIGxhbmcgfSk7XHJcbiAgaWYgKCF2YWxpZGF0aW9uLnN1Y2Nlc3MpIHtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogdmFsaWRhdGlvbi5lcnJvci5pc3N1ZXNbMF0ubWVzc2FnZSB9O1xyXG4gIH1cclxuXHJcbiAgLy8gMi4gU0VHVVJFVEFUIChSYXRlIExpbWl0KVxyXG4gIGNvbnN0IGxpbWl0ZXIgPSBuZXcgU3VwYWJhc2VSYXRlTGltaXRlcigpO1xyXG4gIGNvbnN0IGxvZ2dlciA9IG5ldyBTdXBhYmFzZVNlY3VyaXR5TG9nZ2VyKCk7XHJcblxyXG4gIGNvbnN0IGNhblByb2NlZWQgPSBhd2FpdCBsaW1pdGVyLmNoZWNrKGBnZW46JHt1c2VySWR9YCwgMjAsIDM2MDApOyAvLyA1IGNvcHMvaG9yYVxyXG4gIGlmICghY2FuUHJvY2VlZCkge1xyXG4gICAgYXdhaXQgbG9nZ2VyLmxvZygnV0FSTicsICdSQVRFX0xJTUlUJywgdXNlcklkLCB7IGFjdGlvbjogJ2dlbmVyYXRlX21lbnUnIH0pO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkzDrW1pdCBzdXBlcmF0LiBFc3BlcmEgdW5hIGVzdG9uYS5cIiB9O1xyXG4gIH1cclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCBzZXJ2aWNlID0gY29udGFpbmVyLmdldEdlbmVyYXRlTWVudVNlcnZpY2Uoc3VwYWJhc2UpO1xyXG5cclxuICAgIC8vIEVYRUNVVEVNIEVMIFNFUlZFSSAoTCdPcmNoZXN0cmF0b3IgZGVjaWRlaXggaW50ZXJuYW1lbnQpXHJcbiAgICBjb25zdCByZWNpcGVzID0gYXdhaXQgc2VydmljZS5leGVjdXRlKFxyXG4gICAgICB1c2VySWQsXHJcbiAgICAgIG1vZGUsXHJcbiAgICAgIGRpc2hOYW1lLFxyXG4gICAgICBlbmVyZ3ksXHJcbiAgICAgIHRpbWUsXHJcbiAgICAgIGxhbmdcclxuICAgICk7XHJcblxyXG4gICAgLy8gQ09OVkVSU0nDkyBBIFBSSU1JVElWRVNcclxuICAgIC8vIDEuIENvbnZlcnRpbSBhIHByaW1pdGl2ZXMgKGFpeMOyIGphIGhvIGZhcylcclxuICAgIGNvbnN0IHBsYWluUmVjaXBlcyA9IHJlY2lwZXMubWFwKHIgPT4gci50b1ByaW1pdGl2ZXMoKSk7XHJcblxyXG4gICAgLy8gMi4g4pqg77iPIEFTU0VHVVJBJ1QgUVVFIGVzdGltYXRlZENvc3QgRVhJU1RFSVggQVFVw40g4pqg77iPXHJcbiAgICAvLyBTaSBwbGFpblJlY2lwZXNbMF0uZXN0aW1hdGVkQ29zdCDDqXMgdW5kZWZpbmVkLCBKU09OLnN0cmluZ2lmeSBsJ2VzYm9ycmFyw6AhXHJcbiAgICBpZiAocGxhaW5SZWNpcGVzLmxlbmd0aCA+IDAgJiYgcGxhaW5SZWNpcGVzWzBdLmVzdGltYXRlZENvc3QgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICBsb2dFcnJvcihcIuKaoO+4jyBBTEVSVEE6IGVzdGltYXRlZENvc3Qgw6lzIHVuZGVmaW5lZCBhYmFucyBkJ2VudmlhciBhbCBjbGllbnQhXCIpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIDMuIFNhbml0aXR6YWNpw7NcclxuICAgIGNvbnN0IGNsZWFuUmVjaXBlcyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkocGxhaW5SZWNpcGVzKSk7XHJcblxyXG4gICAgZGVidWcoJ1tBQ1RJT05dIGdlbmVyYXRlTWVudUFjdGlvbiBkb25lJyk7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogdHJ1ZSxcclxuICAgICAgcmVjaXBlczogY2xlYW5SZWNpcGVzXHJcbiAgICB9O1xyXG5cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ+KdjCBbQUNUSU9OIEVSUk9SXTonLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRXJyb3IgZ2VuZXJhbnQgZWwgbWVuw7ouXCIgfTtcclxuICB9XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1hdGVyaWFsaXplUmVjaXBlQWN0aW9uKHJhd0FpUmVjaXBlOiB1bmtub3duKTogUHJvbWlzZTxBY3Rpb25SZXNwb25zZT4ge1xyXG4gIGNvbnN0IHBhcnNlZCA9IE1hdGVyaWFsaXplUmVjaXBlU2NoZW1hLnNhZmVQYXJzZShyYXdBaVJlY2lwZSk7XHJcbiAgaWYgKCFwYXJzZWQuc3VjY2Vzcykge1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBwYXJzZWQuZXJyb3IuaXNzdWVzWzBdLm1lc3NhZ2UgfTtcclxuICB9XHJcblxyXG4gIGNvbnN0IHJlY2lwZURhdGEgPSBwYXJzZWQuZGF0YTtcclxuICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG5cclxuICAvLyDwn5SNIDEuIFBBUyBERSBERURVUExJQ0FDScOTOiBCdXNxdWVtIHNpIGphIGV4aXN0ZWl4XHJcbiAgdHJ5IHtcclxuICAgICAgY29uc3QgeyBkYXRhOiBleGlzdGluZyB9ID0gYXdhaXQgc3VwYWJhc2VcclxuICAgICAgICAgIC5mcm9tKCdzYXZlZF9yZWNpcGVzJylcclxuICAgICAgICAgIC5zZWxlY3QoJ2lkJylcclxuICAgICAgICAgIC5lcSgnbmFtZScsIHJlY2lwZURhdGEubmFtZSkgLy8gTWF0ZWl4IG5vbVxyXG4gICAgICAgICAgLmVxKCdpc19haV9nZW5lcmF0ZWQnLCB0cnVlKSAvLyBRdWUgc2lndWkgZGUgbGEgSUFcclxuICAgICAgICAgIC5lcSgnaXNfcHVibGljJywgdHJ1ZSkgLy8gUXVlIHNpZ3VpIGNvbXBhcnRpZGFcclxuICAgICAgICAgIC5saW1pdCgxKVxyXG4gICAgICAgICAgLnNpbmdsZSgpO1xyXG5cclxuICAgICAgaWYgKGV4aXN0aW5nKSB7XHJcbiAgICAgICAgICBkZWJ1ZygnW0FDVElPTl0gZGVkdXBsaWNhdGUgaGl0Jyk7XHJcbiAgICAgICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCByZWNpcGVJZDogZXhpc3RpbmcuaWQgfTtcclxuICAgICAgfVxyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgbG9nRXJyb3IoJ01hdGVyaWFsaXplUmVjaXBlQWN0aW9uIGVycm9yJywgZXJyKTtcclxuICAgICAgLy8gSWdub3JlbSBlcnJvcnMgZGUgY29uc3VsdGEgKGV4OiBubyB0cm9iYXQpLCBzZWd1aW0gZW5kYXZhbnQgcGVyIGNyZWFyLWxhXHJcbiAgfVxyXG5cclxuICAvLyDwn4yKIDIuIEZMVVggRCdFTlJJUVVJTUVOVCAoSWd1YWwgcXVlIHRlbmllcylcclxuICAvLyBTaSBubyBleGlzdGVpeCwgbCdoZW0gZGUgY3JlYXIgaSBlbnJpcXVpclxyXG4gIGNvbnN0IGVucmljaGVkSW5ncmVkaWVudHMgPSBhd2FpdCBQcm9taXNlLmFsbCgocmVjaXBlRGF0YS5pbmdyZWRpZW50cyB8fCBbXSkubWFwKGFzeW5jIChpbmcpID0+IHtcclxuICAgICAgbGV0IGxpbmtlZFByb2R1Y3RJZCA9IGluZy5saW5rZWRQcm9kdWN0SWQ7XHJcbiAgICAgIGxldCBsaW5rZWRQcm9kdWN0SW1hZ2UgPSBpbmcubGlua2VkUHJvZHVjdEltYWdlO1xyXG4gICAgICBsZXQgZXN0aW1hdGVkQ29zdCA9IGluZy5lc3RpbWF0ZWRDb3N0O1xyXG5cclxuICAgICAgaWYgKCFsaW5rZWRQcm9kdWN0SWQgfHwgIWxpbmtlZFByb2R1Y3RJbWFnZSkge1xyXG4gICAgICAgICAgY29uc3QgeyBkYXRhOiBtYXRjaCB9ID0gYXdhaXQgc3VwYWJhc2VcclxuICAgICAgICAgICAgICAuZnJvbSgncHJvZHVjdF9jYXRhbG9nJylcclxuICAgICAgICAgICAgICAuc2VsZWN0KCdpZCwgaW1hZ2VfdXJsLCBwcmljZScpXHJcbiAgICAgICAgICAgICAgLmlsaWtlKCduYW1lJywgYCUke2luZy5uYW1lfSVgKVxyXG4gICAgICAgICAgICAgIC5saW1pdCgxKVxyXG4gICAgICAgICAgICAgIC5zaW5nbGUoKTtcclxuXHJcbiAgICAgICAgICBpZiAobWF0Y2gpIHtcclxuICAgICAgICAgICAgICBsaW5rZWRQcm9kdWN0SWQgPSBtYXRjaC5pZDtcclxuICAgICAgICAgICAgICBsaW5rZWRQcm9kdWN0SW1hZ2UgPSBtYXRjaC5pbWFnZV91cmw7XHJcbiAgICAgICAgICAgICAgaWYgKCFlc3RpbWF0ZWRDb3N0ICYmIG1hdGNoLnByaWNlKSBlc3RpbWF0ZWRDb3N0ID0gbWF0Y2gucHJpY2U7IFxyXG4gICAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgbmFtZTogaW5nLm5hbWUsXHJcbiAgICAgICAgICBxdWFudGl0eTogaW5nLnF1YW50aXR5LFxyXG4gICAgICAgICAgdW5pdDogaW5nLnVuaXQsXHJcbiAgICAgICAgICBlbW9qaTogaW5nLmVtb2ppLFxyXG4gICAgICAgICAgZXN0aW1hdGVkQ29zdDogZXN0aW1hdGVkQ29zdCxcclxuICAgICAgICAgIGxpbmtlZFByb2R1Y3RJZDogbGlua2VkUHJvZHVjdElkLFxyXG4gICAgICAgICAgbGlua2VkUHJvZHVjdEltYWdlOiBsaW5rZWRQcm9kdWN0SW1hZ2UsXHJcbiAgICAgIH07XHJcbiAgfSkpO1xyXG5cclxuICAvLyDwn5K+IDMuIFBSRVBBUkFSIFBFUiBHVUFSREFSXHJcbiAgY29uc3QgaW5wdXQ6IFNhdmVSZWNpcGVJbnB1dCA9IHtcclxuICAgIG5hbWU6IHJlY2lwZURhdGEubmFtZSxcclxuICAgIHByZXBUaW1lTWludXRlczogcmVjaXBlRGF0YS5wcmVwVGltZU1pbnV0ZXMgfHwgMzAsXHJcbiAgICB0YWdzOiByZWNpcGVEYXRhLnRhZ3MgfHwgW10sXHJcbiAgICBkaWV0YXJ5VGFnczogcmVjaXBlRGF0YS5kaWV0YXJ5VGFncyB8fCBbXSxcclxuICAgIGlzQWlHZW5lcmF0ZWQ6IHRydWUsXHJcbiAgICBzdGVwczogcmVjaXBlRGF0YS5zdGVwcyB8fCBbXSxcclxuICAgIGluZ3JlZGllbnRzOiBlbnJpY2hlZEluZ3JlZGllbnRzXHJcbiAgfTtcclxuXHJcbiAgLy8g8J+UpSBUUlVDIEZJTkFMOiBHdWFyZGVtIGNvbSBhIFDDmkJMSUNBP1xyXG4gIC8vIFPDrSwgcGVycXXDqCBzaSB1biBhbHRyZSB1c3VhcmkgZGUgbGEgc2FsYSBmYSBjbGljLCB2b2xlbSBxdWUgdHJvYmkgYXF1ZXN0YSByZWNlcHRhIChQYXMgMSlcclxuICAvLyBpIG5vIGVuIGNyZcOvIHVuYSBkZSBub3ZhLlxyXG4gIC8vIE1vZGlmaXF1ZW0gc2F2ZVJlY2lwZUFjdGlvbiBwZXJxdcOoIGFjY2VwdGkgJ2lzUHVibGljJyBvIGhvIGZvcmNlbSBhIGxhIGzDsmdpY2EgZGUgc2F2ZS5cclxuICBcclxuICAvLyBPcGNpw7MgQTogU2kgc2F2ZVJlY2lwZUFjdGlvbiBhY2NlcHRhIGlzUHVibGljIGFsIGlucHV0LCBwYXNzYS1sJ2hpLlxyXG4gIC8vIE9wY2nDsyBCIChIYWNrIHLDoHBpZCk6IFNhdmVSZWNpcGVBY3Rpb24gcGVyIGRlZmVjdGUgbGVzIGZhIHByaXZhZGVzLiBcclxuICAvLyBQZXLDsiBjb20gcXVlIHJldG9ybmEgbCdJRCwgcG9kZW0gZmVyIHVuIHVwZGF0ZSByw6BwaWQgYXF1w60gcGVyIGZlci1sYSBww7pibGljYS5cclxuICBcclxuICBjb25zdCBzYXZlUmVzdWx0ID0gYXdhaXQgc2F2ZVJlY2lwZUFjdGlvbihpbnB1dCk7XHJcblxyXG4gIGlmIChzYXZlUmVzdWx0LnN1Y2Nlc3MgJiYgc2F2ZVJlc3VsdC5yZWNpcGVJZCkge1xyXG4gICAgICAvLyBMYSBmZW0gcMO6YmxpY2EgcGVycXXDqCBsYSB0cm9iaW4gZWxzIGFsdHJlcyBjb21wYW55cyBkZSBsYSBzYWxhXHJcbiAgICAgIGF3YWl0IHN1cGFiYXNlXHJcbiAgICAgICAgICAuZnJvbSgnc2F2ZWRfcmVjaXBlcycpXHJcbiAgICAgICAgICAudXBkYXRlKHsgaXNfcHVibGljOiB0cnVlIH0pXHJcbiAgICAgICAgICAuZXEoJ2lkJywgc2F2ZVJlc3VsdC5yZWNpcGVJZCk7XHJcbiAgICAgICAgICBcclxuICAgICAgZGVidWcoJ1tBQ1RJT05dIHJlY2lwZSBzaGFyZWQnKTtcclxuICB9XHJcblxyXG4gIHJldHVybiBzYXZlUmVzdWx0O1xyXG59XHJcblxyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6ImtTQTZDc0IsNkxBQUEifQ==
}),
"[project]/features/recipes/components/editor/useRecipeForm.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useRecipeForm",
    ()=>useRecipeForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/navigation.js [app-client] (ecmascript)");
// import { toast } from 'sonner'; 
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$2d7a82__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:2d7a82 [app-client] (ecmascript) <text/javascript>");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
// ✅ 1. AFEGIM EL MAPA DE TRADUCCIÓ (Anglès UI -> Català DB)
const DB_TAGS_MAPPING = {
    // Dietes
    'vegan': 'vegà',
    'vegetarian': 'vegetarià',
    'gluten-free': 'sense gluten',
    'dairy-free': 'sense lactosa',
    'healthy': 'sa',
    // Tipus de plat
    'breakfast': 'esmorzar',
    'lunch': 'dinar',
    'dinner': 'sopar',
    'snack': 'snack',
    'dessert': 'postres',
    // Característiques
    'quick': 'ràpid',
    'spicy': 'picant',
    'traditional': 'tradicional',
    'fresh': 'fresc',
    'winter': 'hivern',
    'summer': 'estiu',
    'meat': 'carn',
    'fish': 'peix',
    'pasta': 'pasta',
    'rice': 'arròs'
};
function useRecipeForm(labels, setActiveTab, initialData// ✅ Paràmetre nou per a edició
) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // ESTAT NOU: Control del Modal
    const [feedback, setFeedback] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        isOpen: false,
        type: 'error',
        title: '',
        message: ''
    });
    // Errors visuals 
    const [errors, setErrors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        name: false,
        ingredients: false,
        steps: false
    });
    // ✅ INICIALITZACIÓ DE L'ESTAT (Create vs Edit)
    // Si tenim initialData (Edició), l'ussem. Si no, valors per defecte (Creació).
    // ✅ CORRECCIÓ 1: Afegim 'tags' als valors per defecte
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialData || {
        name: '',
        prepTimeMinutes: 30,
        ingredients: [],
        steps: [],
        dietaryTags: [],
        tags: [],
        description: '',
        servings: 2,
        difficulty: 'medium'
    });
    const closeFeedback = ()=>setFeedback((prev)=>({
                ...prev,
                isOpen: false
            }));
    const handleSave = async ()=>{
        setErrors({
            name: false,
            ingredients: false,
            steps: false
        });
        // VALIDACIONS AMB TRADUCCIÓ DINÀMICA
        if (!data.name.trim()) {
            setErrors((prev)=>({
                    ...prev,
                    name: true
                }));
            setFeedback({
                isOpen: true,
                type: 'error',
                title: labels.errors.title_missing,
                message: labels.errors.title_missing_desc
            });
            return;
        }
        if (data.ingredients.length === 0) {
            setErrors((prev)=>({
                    ...prev,
                    ingredients: true
                }));
            setActiveTab('ingredients');
            setFeedback({
                isOpen: true,
                type: 'error',
                title: labels.errors.ingredients_missing,
                message: labels.errors.ingredients_missing_desc
            });
            return;
        }
        if (data.steps.length === 0) {
            setErrors((prev)=>({
                    ...prev,
                    steps: true
                }));
            setActiveTab('steps');
            setFeedback({
                isOpen: true,
                type: 'error',
                title: labels.errors.steps_missing,
                message: labels.errors.steps_missing_desc
            });
            return;
        }
        // ✅ 2. PREPARAR DADES: TRADUCCIÓ DE TAGS
        // ✅ CORRECCIÓ 2: Mantenir la integritat del tipus al crear el payload
        const translatedTags = data.dietaryTags.map((tag)=>DB_TAGS_MAPPING[tag] || tag);
        const payload = {
            ...data,
            dietaryTags: translatedTags
        };
        setLoading(true);
        // ✅ CRIDA A LA NOVA ACCIÓ CENTRALITZADA
        // Si estem editant, assegura't que l'acció (saveRecipeAction) gestioni l'Update si rep un ID,
        // o crea una updateRecipeAction separada. Per ara mantenim la lògica original.
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$2d7a82__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["saveRecipeAction"])(payload);
        setLoading(false);
        if (result.success) {
            router.push(`/recipes/${result.recipeId}`);
        } else {
            setFeedback({
                isOpen: true,
                type: 'error',
                title: labels.toasts.error_title,
                message: result.error || "Hi ha hagut un error inesperat."
            });
        }
    };
    return {
        data,
        setData,
        loading,
        errors,
        handleSave,
        feedback,
        closeFeedback
    };
}
_s(useRecipeForm, "Mx7t9yEhC+qwvdFekmoVsd7HJ7w=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/FeedbackModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FeedbackModal",
    ()=>FeedbackModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/circle-alert.js [app-client] (ecmascript) <export default as AlertCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/circle-check-big.js [app-client] (ecmascript) <export default as CheckCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
'use client';
;
;
;
function FeedbackModal({ isOpen, onClose, type, title, message }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
        children: isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    exit: {
                        opacity: 0
                    },
                    onClick: onClose,
                    className: "fixed inset-0 bg-black/60 backdrop-blur-sm z-9999"
                }, void 0, false, {
                    fileName: "[project]/components/ui/FeedbackModal.tsx",
                    lineNumber: 20,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        opacity: 0,
                        scale: 0.95,
                        y: 20
                    },
                    animate: {
                        opacity: 1,
                        scale: 1,
                        y: 0
                    },
                    exit: {
                        opacity: 0,
                        scale: 0.95,
                        y: 20
                    },
                    className: "fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-10000 w-full max-w-sm px-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `relative overflow-hidden rounded-2xl border p-6 shadow-2xl ${type === 'error' ? 'bg-zinc-900 border-red-500/30 text-red-100' : 'bg-zinc-900 border-emerald-500/30 text-emerald-100'}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onClose,
                                className: "absolute right-4 top-4 p-1 rounded-full hover:bg-white/10 transition-colors",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                    size: 18
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/FeedbackModal.tsx",
                                    lineNumber: 39,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/ui/FeedbackModal.tsx",
                                lineNumber: 38,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col items-center text-center gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: `p-3 rounded-full mb-1 ${type === 'error' ? 'bg-red-500/20 text-red-400' : 'bg-emerald-500/20 text-emerald-400'}`,
                                        children: type === 'error' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__["AlertCircle"], {
                                            size: 32
                                        }, void 0, false, {
                                            fileName: "[project]/components/ui/FeedbackModal.tsx",
                                            lineNumber: 44,
                                            columnNumber: 39
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"], {
                                            size: 32
                                        }, void 0, false, {
                                            fileName: "[project]/components/ui/FeedbackModal.tsx",
                                            lineNumber: 44,
                                            columnNumber: 67
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/ui/FeedbackModal.tsx",
                                        lineNumber: 43,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-lg font-bold",
                                        children: title
                                    }, void 0, false, {
                                        fileName: "[project]/components/ui/FeedbackModal.tsx",
                                        lineNumber: 46,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm opacity-90 leading-relaxed",
                                        children: message
                                    }, void 0, false, {
                                        fileName: "[project]/components/ui/FeedbackModal.tsx",
                                        lineNumber: 47,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: onClose,
                                        className: `mt-4 w-full py-2.5 rounded-xl font-bold text-sm transition-transform active:scale-95 ${type === 'error' ? 'bg-red-600 hover:bg-red-500 text-white shadow-lg shadow-red-900/20' : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-900/20'}`,
                                        children: "Entesos"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ui/FeedbackModal.tsx",
                                        lineNumber: 48,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ui/FeedbackModal.tsx",
                                lineNumber: 42,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ui/FeedbackModal.tsx",
                        lineNumber: 33,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/ui/FeedbackModal.tsx",
                    lineNumber: 27,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true)
    }, void 0, false, {
        fileName: "[project]/components/ui/FeedbackModal.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
}
_c = FeedbackModal;
var _c;
__turbopack_context__.k.register(_c, "FeedbackModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/editor/editor/EditorTabs.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EditorTabs",
    ()=>EditorTabs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chef$2d$hat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChefHat$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/chef-hat.js [app-client] (ecmascript) <export default as ChefHat>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$list$2d$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListChecks$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/list-checks.js [app-client] (ecmascript) <export default as ListChecks>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings2$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/settings-2.js [app-client] (ecmascript) <export default as Settings2>");
'use client';
;
;
;
function EditorTabs({ activeTab, onChange, errors, counts }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "shrink-0 px-4 py-2 bg-slate-950 border-b border-slate-900 z-40",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            id: "tour-tabs",
            className: "flex bg-slate-900/50 p-1 rounded-xl border border-slate-800/50 relative max-w-lg mx-auto",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    layoutId: "activeTab",
                    className: "absolute inset-y-1 rounded-lg bg-slate-800 shadow-sm",
                    initial: false,
                    animate: {
                        left: activeTab === 'meta' ? '1%' : activeTab === 'ingredients' ? '34%' : '67%',
                        width: '32%'
                    },
                    transition: {
                        type: "spring",
                        stiffness: 300,
                        damping: 30
                    }
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/editor/editor/EditorTabs.tsx",
                    lineNumber: 19,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TabButton, {
                    active: activeTab === 'meta',
                    onClick: ()=>onChange('meta'),
                    error: errors.name,
                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings2$3e$__["Settings2"], {
                        size: 16
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/editor/editor/EditorTabs.tsx",
                        lineNumber: 33,
                        columnNumber: 17
                    }, void 0),
                    label: "Info",
                    testId: "recipe-tab-meta"
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/editor/editor/EditorTabs.tsx",
                    lineNumber: 29,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TabButton, {
                    active: activeTab === 'ingredients',
                    onClick: ()=>onChange('ingredients'),
                    error: errors.ingredients,
                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chef$2d$hat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChefHat$3e$__["ChefHat"], {
                        size: 16
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/editor/editor/EditorTabs.tsx",
                        lineNumber: 41,
                        columnNumber: 17
                    }, void 0),
                    label: "Ingredients",
                    count: counts.ingredients,
                    testId: "recipe-tab-ingredients"
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/editor/editor/EditorTabs.tsx",
                    lineNumber: 37,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TabButton, {
                    active: activeTab === 'steps',
                    onClick: ()=>onChange('steps'),
                    error: errors.steps,
                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$list$2d$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListChecks$3e$__["ListChecks"], {
                        size: 16
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/editor/editor/EditorTabs.tsx",
                        lineNumber: 50,
                        columnNumber: 17
                    }, void 0),
                    label: "Passos",
                    count: counts.steps,
                    testId: "recipe-tab-steps"
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/editor/editor/EditorTabs.tsx",
                    lineNumber: 46,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/features/recipes/components/editor/editor/EditorTabs.tsx",
            lineNumber: 18,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/features/recipes/components/editor/editor/EditorTabs.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
}
_c = EditorTabs;
function TabButton({ active, onClick, error, icon, label, count, testId }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        onClick: onClick,
        "data-testid": testId,
        className: `relative z-10 flex-1 py-2.5 text-xs font-bold uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-2 ${error ? 'text-red-400 animate-pulse' : active ? 'text-white' : 'text-slate-500 hover:text-slate-300'}`,
        children: [
            icon,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "hidden sm:inline",
                children: label
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/editor/EditorTabs.tsx",
                lineNumber: 72,
                columnNumber: 7
            }, this),
            count !== undefined && count > 0 && !error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "bg-purple-600 text-white text-[9px] px-1.5 py-0.5 rounded-full min-w-[18px] text-center ml-1",
                children: count
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/editor/EditorTabs.tsx",
                lineNumber: 73,
                columnNumber: 54
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/editor/editor/EditorTabs.tsx",
        lineNumber: 66,
        columnNumber: 5
    }, this);
}
_c1 = TabButton;
var _c, _c1;
__turbopack_context__.k.register(_c, "EditorTabs");
__turbopack_context__.k.register(_c1, "TabButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/editor/editor/utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getEditorTourSteps",
    ()=>getEditorTourSteps,
    "mapRecipeToFormData",
    ()=>mapRecipeToFormData
]);
function mapRecipeToFormData(recipe) {
    if (!recipe) {
        console.log("?? [Editor Mapper] No recipe provided");
        return undefined;
    }
    console.log("?? [Editor Mapper] Ingredients entrant:", recipe.ingredients);
    console.log("?? [Editor Mapper] Steps entrant:", recipe.steps);
    return {
        id: recipe.id,
        name: recipe.name,
        prepTimeMinutes: recipe.prepTimeMinutes,
        dietaryTags: recipe.dietaryTags || [],
        tags: recipe.tags || [],
        description: "",
        servings: 2,
        difficulty: 'medium',
        ingredients: recipe.ingredients.map((ing)=>{
            const i = ing;
            const foundImage = i.image || i.productImage || i.linkedProductImage || undefined;
            return {
                id: crypto.randomUUID(),
                name: i.name,
                quantity: i.quantity,
                unit: i.unit,
                emoji: i.emoji,
                image: foundImage,
                linkedProductImage: foundImage,
                estimatedCost: i.estimatedCost || 0,
                linkedProductId: i.linkedProductId
            };
        }),
        steps: recipe.steps.map((s)=>({
                id: crypto.randomUUID(),
                content: s || ""
            }))
    };
}
function getEditorTourSteps(t) {
    return [
        {
            targetId: 'tour-recipe-title',
            title: t.onboarding.editor.step1_title,
            description: t.onboarding.editor.step1_desc,
            requiredTab: 'meta'
        },
        {
            targetId: 'tour-prep-time',
            title: t.onboarding.editor.step2_title,
            description: t.onboarding.editor.step2_desc,
            requiredTab: 'meta'
        },
        {
            targetId: 'tour-dietary-tags',
            title: t.onboarding.editor.step3_title,
            description: t.onboarding.editor.step3_desc,
            requiredTab: 'meta'
        },
        {
            targetId: 'tour-ing-input',
            title: t.onboarding.editor.step4_title,
            description: t.onboarding.editor.step4_desc,
            requiredTab: 'ingredients'
        },
        {
            targetId: 'tour-ing-list',
            title: t.onboarding.editor.step5_title,
            description: t.onboarding.editor.step5_desc,
            requiredTab: 'ingredients'
        },
        {
            targetId: 'tour-step-textarea',
            title: t.onboarding.editor.step6_title,
            description: t.onboarding.editor.step6_desc,
            requiredTab: 'steps'
        },
        {
            targetId: 'tour-step-chips',
            title: t.onboarding.editor.step7_title,
            description: t.onboarding.editor.step7_desc,
            requiredTab: 'steps'
        },
        {
            targetId: 'tour-save-btn',
            title: t.onboarding.editor.step8_title,
            description: t.onboarding.editor.step8_desc
        }
    ];
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/BackButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BackButton",
    ()=>BackButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/navigation.js [app-client] (ecmascript)"); // 👈 Importem el router
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function BackButton({ href, label = "Tornar", className = "", preferReferrer = false, fallbackHref }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const storageKey = ("TURBOPACK compile-time truthy", 1) ? `back-origin:${window.location.pathname}` : "TURBOPACK unreachable";
    // Definim els estils comuns per no repetir codi
    const buttonStyles = `
    flex items-center justify-center gap-2 
    bg-slate-800 hover:bg-slate-700 
    text-white 
    border border-slate-700 hover:border-purple-500/50
    transition-colors shadow-lg
    cursor-pointer
    
    /* MÒBIL: Rodó i petit */
    w-10 h-10 rounded-full
    
    /* ESCRIPTORI: Allargat i amb text */
    sm:w-auto sm:h-auto sm:px-4 sm:py-2 sm:rounded-full
    
    ${className}
  `;
    // Contingut visual del botó (Icona + Text)
    const content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-xl sm:text-lg leading-none pb-1 sm:pb-0",
                children: "🔙"
            }, void 0, false, {
                fileName: "[project]/components/ui/BackButton.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "hidden sm:inline text-xs font-bold uppercase tracking-wide",
                children: label
            }, void 0, false, {
                fileName: "[project]/components/ui/BackButton.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
    // CAS 1: Si tenim una ruta específica (href), fem servir Link (millor per SEO i prefetching)
    if (href) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: href,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                whileHover: {
                    scale: 1.05
                },
                whileTap: {
                    scale: 0.95
                },
                className: buttonStyles,
                children: content
            }, void 0, false, {
                fileName: "[project]/components/ui/BackButton.tsx",
                lineNumber: 58,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/ui/BackButton.tsx",
            lineNumber: 57,
            columnNumber: 7
        }, this);
    }
    // CAS 2: Si volem tornar a l'origen (fora d'aquesta ruta), usem el referrer guardat
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
        type: "button",
        onClick: ()=>{
            if (preferReferrer && ("TURBOPACK compile-time value", "object") !== "undefined" && storageKey) {
                const storedOrigin = sessionStorage.getItem(storageKey);
                if (storedOrigin) {
                    router.push(storedOrigin);
                    return;
                }
                if (fallbackHref) {
                    router.push(fallbackHref);
                    return;
                }
            }
            router.back();
        },
        whileHover: {
            scale: 1.05
        },
        whileTap: {
            scale: 0.95
        },
        className: buttonStyles,
        children: content
    }, void 0, false, {
        fileName: "[project]/components/ui/BackButton.tsx",
        lineNumber: 72,
        columnNumber: 5
    }, this);
}
_s(BackButton, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = BackButton;
var _c;
__turbopack_context__.k.register(_c, "BackButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/editor/editor/EditorHeader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EditorHeader",
    ()=>EditorHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$BackButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/BackButton.tsx [app-client] (ecmascript)");
'use client';
;
;
function EditorHeader({ title, isEditing, onExit, onTitleClick }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "shrink-0 px-4 py-3 bg-slate-950 flex items-center justify-between border-b border-slate-900",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                onClick: onExit,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$BackButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BackButton"], {}, void 0, false, {
                    fileName: "[project]/features/recipes/components/editor/editor/EditorHeader.tsx",
                    lineNumber: 16,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/editor/EditorHeader.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-slate-200 font-bold text-lg cursor-pointer",
                onClick: onTitleClick,
                children: title || (isEditing ? "Editant Recepta" : "Nova Recepta")
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/editor/EditorHeader.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-10"
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/editor/EditorHeader.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/editor/editor/EditorHeader.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
_c = EditorHeader;
var _c;
__turbopack_context__.k.register(_c, "EditorHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:1089db [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deleteRecipeAction",
    ()=>$$RSC_SERVER_ACTION_0
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"4021cac189a81baaf5b58ebf9a4ebd135509ffa670":"deleteRecipeAction"},"app/actions/delete-recipe.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("4021cac189a81baaf5b58ebf9a4ebd135509ffa670", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "deleteRecipeAction");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vZGVsZXRlLXJlY2lwZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvYXBwL2FjdGlvbnMvZGVsZXRlLXJlY2lwZS50c1xyXG4ndXNlIHNlcnZlcidcclxuXHJcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2Uvc2VydmVyJztcclxuaW1wb3J0IHsgY29udGFpbmVyIH0gZnJvbSAnQC9zZXJ2aWNlcy9jb250YWluZXInO1xyXG5pbXBvcnQgeyByZWRpcmVjdCB9IGZyb20gJ25leHQvbmF2aWdhdGlvbic7XHJcbmltcG9ydCB7IHJldmFsaWRhdGVQYXRoIH0gZnJvbSAnbmV4dC9jYWNoZSc7XHJcbmltcG9ydCB7IGVycm9yIGFzIGxvZ0Vycm9yIH0gZnJvbSAnQC9saWIvbG9nZ2VyJztcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVSZWNpcGVBY3Rpb24ocmVjaXBlSWQ6IHN0cmluZykge1xyXG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgXHJcbiAgLy8gMS4gQXV0ZW50aWNhY2nDs1xyXG4gIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0gfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpO1xyXG4gIGlmICghdXNlcikge1xyXG4gICAgcmV0dXJuIHsgZXJyb3I6IFwiSGFzIGQnaW5pY2lhciBzZXNzacOzIHBlciBlbGltaW5hciByZWNlcHRlcy5cIiB9O1xyXG4gIH1cclxuXHJcbiAgdHJ5IHtcclxuICAgIC8vIDIuIEV4ZWN1Y2nDsyBkZWwgRG9taW5pXHJcbiAgICBjb25zdCBkZWxldGVSZWNpcGUgPSBjb250YWluZXIuZ2V0RGVsZXRlUmVjaXBlKCk7XHJcbiAgICBhd2FpdCBkZWxldGVSZWNpcGUuZXhlY3V0ZShyZWNpcGVJZCwgdXNlci5pZCk7XHJcblxyXG4gICAgLy8gMy4gUmV2YWxpZGFjacOzXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL3JlY2lwZXMnKTtcclxuICAgIHJldmFsaWRhdGVQYXRoKGAvcmVjaXBlcy8ke3JlY2lwZUlkfWApO1xyXG4gICAgXHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGxvZ0Vycm9yKCdFcnJvciBkZWxldGluZyByZWNpcGU6JywgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHsgZXJyb3I6ICdObyBzXFwnaGEgcG9ndXQgZWxpbWluYXIgbGEgcmVjZXB0YS4nIH07XHJcbiAgfVxyXG5cclxuICAvLyA0LiBSZWRpcmVjdCAoZm9yYSBkZWwgdHJ5LWNhdGNoIHBlcnF1w6ggbGxlbsOnYSB1bmEgZXhjZXBjacOzIGludGVybmEgZGUgTmV4dC5qcylcclxuICByZWRpcmVjdCgnL3JlY2lwZXMnKTtcclxufSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoibVNBU3NCLCtMQUFBIn0=
}),
"[project]/features/recipes/components/editor/RecipeEditor.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RecipeEditor",
    ()=>RecipeEditor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$IngredientsManager$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/editor/IngredientsManager.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$StepsBuilder$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/editor/StepsBuilder.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$MetaControls$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/editor/MetaControls.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Save$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/save.js [app-client] (ecmascript) <export default as Save>"); // Importem icona Trash2
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/trash-2.js [app-client] (ecmascript) <export default as Trash2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/onboarding/OnboardingContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$TourTrigger$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/onboarding/TourTrigger.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$useRecipeForm$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/editor/useRecipeForm.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$FeedbackModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/FeedbackModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$editor$2f$EditorTabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/editor/editor/EditorTabs.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$editor$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/editor/editor/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$editor$2f$EditorHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/editor/editor/EditorHeader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$1089db__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:1089db [app-client] (ecmascript) <text/javascript>"); // Importem l'acció
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function RecipeEditor({ userInventory, initialRecipe }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [activeTab, setActiveTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('meta');
    // 1. DATA MAPPING (Extret a utils)
    const initialFormData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "RecipeEditor.useMemo[initialFormData]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$editor$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mapRecipeToFormData"])(initialRecipe)
    }["RecipeEditor.useMemo[initialFormData]"], [
        initialRecipe
    ]);
    const [isPendingDelete, startDeleteTransition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransition"])();
    // 2. FORM LOGIC
    const { data, setData, loading, errors, handleSave, feedback, closeFeedback } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$useRecipeForm$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRecipeForm"])(t.create_recipe, setActiveTab, initialFormData);
    // 3. ONBOARDING LOGIC
    const { startTour, currentStepIndex, isActive, steps: activeSteps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"])();
    const onboardingSteps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "RecipeEditor.useMemo[onboardingSteps]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$editor$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getEditorTourSteps"])(t)
    }["RecipeEditor.useMemo[onboardingSteps]"], [
        t
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RecipeEditor.useEffect": ()=>{
            if (initialRecipe) return;
            const timer = setTimeout({
                "RecipeEditor.useEffect.timer": ()=>startTour('recipe-editor', onboardingSteps)
            }["RecipeEditor.useEffect.timer"], 800);
            return ({
                "RecipeEditor.useEffect": ()=>clearTimeout(timer)
            })["RecipeEditor.useEffect"];
        }
    }["RecipeEditor.useEffect"], [
        startTour,
        onboardingSteps,
        initialRecipe
    ]);
    // Sincronització de Tabs amb el Tour
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RecipeEditor.useEffect": ()=>{
            if (!isActive) return;
            const currentStep = activeSteps[currentStepIndex];
            if (currentStep?.requiredTab && activeTab !== currentStep.requiredTab) {
                const timer = setTimeout({
                    "RecipeEditor.useEffect.timer": ()=>setActiveTab(currentStep.requiredTab)
                }["RecipeEditor.useEffect.timer"], 0);
                return ({
                    "RecipeEditor.useEffect": ()=>clearTimeout(timer)
                })["RecipeEditor.useEffect"];
            }
        }
    }["RecipeEditor.useEffect"], [
        currentStepIndex,
        isActive,
        activeSteps,
        activeTab
    ]);
    // 4. HANDLERS
    const handleExit = ()=>{
        if (confirm("Vols sortir sense guardar els canvis?")) router.back();
    };
    // 5. LABELS (Mapeig segur)
    const safeIngredientsLabels = {
        ...t.create_recipe.ingredients,
        title: t.create_recipe.ingredients.title || "Ingredients",
        basket_title: "La teva Cistella",
        basket_empty: "Encara no has afegit ingredients"
    };
    const safeStepsLabels = {
        ...t.create_recipe.steps,
        title: "Passos"
    };
    // NOU HANDLER: Gestió de l'eliminació
    const handleDelete = async ()=>{
        if (!initialRecipe?.id) return;
        // UX: Confirmació nativa (Simple i efectiva per accions destructives)
        // En el futur es pot canviar per un Modal de UI si es vol més estil.
        const confirmed = window.confirm("Estàs segur que vols eliminar aquesta recepta? Aquesta acció no es pot desfer.");
        if (confirmed) {
            startDeleteTransition(async ()=>{
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$1089db__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["deleteRecipeAction"])(initialRecipe.id);
                if (result?.error) {
                    // Si falla, mostrem feedback utilitzant el sistema existent
                    // Nota: necessitaràs exposar 'setFeedback' des de useRecipeForm o similar
                    alert(result.error); // Fallback si no tenim accés al setFeedback des d'aquí fàcilment
                }
            });
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col h-full w-full bg-slate-950 overflow-hidden relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$FeedbackModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeedbackModal"], {
                isOpen: feedback.isOpen,
                onClose: closeFeedback,
                type: feedback.type,
                title: feedback.title,
                message: feedback.message
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                lineNumber: 97,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute top-4 right-4 z-50",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$TourTrigger$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TourTrigger"], {
                    tourId: "recipe-editor",
                    steps: onboardingSteps
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                    lineNumber: 106,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                lineNumber: 105,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative z-50",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$editor$2f$EditorHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EditorHeader"], {
                        title: data.name,
                        isEditing: !!initialRecipe,
                        onExit: handleExit,
                        onTitleClick: ()=>setActiveTab('meta')
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                        lineNumber: 113,
                        columnNumber: 9
                    }, this),
                    initialRecipe && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleDelete,
                        disabled: isPendingDelete || loading,
                        "data-testid": "recipe-delete-button",
                        className: "absolute top-4 right-16 p-2 text-slate-400 hover:text-red-500 hover:bg-red-500/10 rounded-full transition-colors",
                        title: "Eliminar recepta",
                        children: isPendingDelete ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "animate-spin",
                            children: "⏳"
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                            lineNumber: 128,
                            columnNumber: 32
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                            className: "w-5 h-5"
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                            lineNumber: 128,
                            columnNumber: 74
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                        lineNumber: 121,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                lineNumber: 112,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$editor$2f$EditorTabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EditorTabs"], {
                activeTab: activeTab,
                onChange: setActiveTab,
                errors: {
                    name: errors.name,
                    ingredients: errors.ingredients,
                    steps: errors.steps
                },
                counts: {
                    ingredients: data.ingredients.length,
                    steps: data.steps.length
                }
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                lineNumber: 133,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 overflow-hidden relative w-full p-2 sm:p-4 md:p-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    id: "tour-content-area",
                    className: "h-full w-full bg-slate-900/30 border border-slate-800/50 rounded-3xl overflow-hidden relative backdrop-blur-sm shadow-inner",
                    children: [
                        activeTab === 'meta' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-full overflow-y-auto p-4 animate-in fade-in zoom-in-95 scrollbar-thin scrollbar-thumb-slate-800",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "max-w-2xl mx-auto space-y-6 pt-4 pb-20",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$MetaControls$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MetaControls"], {
                                    data: data,
                                    update: setData,
                                    hasError: errors.name,
                                    titleInputId: "tour-recipe-title",
                                    prepTimeId: "tour-prep-time",
                                    tagsContainerId: "tour-dietary-tags"
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                                    lineNumber: 147,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                                lineNumber: 146,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                            lineNumber: 145,
                            columnNumber: 13
                        }, this),
                        activeTab === 'ingredients' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$IngredientsManager$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IngredientsManager"], {
                            data: data,
                            update: setData,
                            inventory: userInventory,
                            labels: safeIngredientsLabels,
                            searchInputId: "tour-ing-input",
                            ingredientsListId: "tour-ing-list"
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                            lineNumber: 160,
                            columnNumber: 13
                        }, this),
                        activeTab === 'steps' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$StepsBuilder$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StepsBuilder"], {
                            data: data,
                            update: setData,
                            labels: safeStepsLabels,
                            textareaId: "tour-step-textarea",
                            stepsListId: "tour-step-chips"
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                            lineNumber: 171,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                    lineNumber: 142,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                lineNumber: 141,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute bottom-6 right-6 z-60",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
                    id: "tour-save-btn",
                    whileHover: {
                        scale: 1.1
                    },
                    whileTap: {
                        scale: 0.9
                    },
                    onClick: handleSave,
                    disabled: loading,
                    "data-testid": "recipe-save-button",
                    className: `w-14 h-14 md:w-16 md:h-16 rounded-full shadow-[0_0_40px_-10px_rgba(168,85,247,0.6)] flex items-center justify-center ring-4 transition-all ${loading ? 'bg-slate-800 cursor-wait ring-slate-700' : 'bg-linear-to-r from-purple-600 to-pink-600 hover:shadow-purple-500/40 cursor-pointer ring-slate-950/80'}`,
                    children: loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "animate-spin text-2xl",
                        children: "⏳"
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                        lineNumber: 191,
                        columnNumber: 22
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Save$3e$__["Save"], {
                        className: "w-6 h-6 md:w-7 md:h-7 text-white stroke-[2.5px]"
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                        lineNumber: 191,
                        columnNumber: 73
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                    lineNumber: 184,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
                lineNumber: 183,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/editor/RecipeEditor.tsx",
        lineNumber: 96,
        columnNumber: 5
    }, this);
}
_s(RecipeEditor, "dpA+oZK+LFAz2eMZYVl1S7mkiVQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransition"],
        __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$useRecipeForm$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRecipeForm"],
        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$onboarding$2f$OnboardingContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnboarding"]
    ];
});
_c = RecipeEditor;
var _c;
__turbopack_context__.k.register(_c, "RecipeEditor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_f7ab49bf._.js.map