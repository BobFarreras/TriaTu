(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_e7042ce5._.js",
  "static/chunks/node_modules__pnpm_80d85044._.js"
],
    source: "dynamic"
});
