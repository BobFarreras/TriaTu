(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/features/recipes/components/parts/RecipeHeader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RecipeHeader",
    ()=>RecipeHeader,
    "getEmoji",
    ()=>getEmoji
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/tag.js [app-client] (ecmascript) <export default as Tag>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$euro$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Euro$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/euro.js [app-client] (ecmascript) <export default as Euro>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/user.js [app-client] (ecmascript) <export default as User>");
'use client';
;
;
const getEmoji = (name)=>{
    const n = name.toLowerCase();
    if (n.includes('pizza')) return '🍕';
    if (n.includes('pasta')) return '🍝';
    if (n.includes('burger')) return '🍔';
    if (n.includes('amanida')) return '🥗';
    if (n.includes('postre') || n.includes('pastís')) return '🍰';
    if (n.includes('arròs')) return '🥘';
    if (n.includes('peix')) return '🐟';
    if (n.includes('pollastre')) return '🍗';
    return '🍲';
};
function RecipeHeader({ name, prepTime, tags, estimatedCost, authorName }) {
    const emoji = getEmoji(name);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative mb-8",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute top-0 left-0 w-32 h-32 bg-purple-500/20 rounded-full blur-3xl -z-10"
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/parts/RecipeHeader.tsx",
                lineNumber: 32,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col md:flex-row gap-6 items-start md:items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-7xl md:text-8xl drop-shadow-2xl animate-bounce-slow select-none grayscale-[0.2]",
                        children: emoji
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/parts/RecipeHeader.tsx",
                        lineNumber: 36,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 space-y-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-3xl md:text-5xl font-black text-white leading-tight tracking-tight",
                                children: name
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/parts/RecipeHeader.tsx",
                                lineNumber: 41,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-wrap items-center gap-3",
                                children: [
                                    prepTime && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "flex items-center gap-1.5 bg-slate-900/80 border border-slate-700 px-3 py-1.5 rounded-full text-sm font-bold text-slate-300",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"], {
                                                size: 14,
                                                className: "text-purple-400"
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/parts/RecipeHeader.tsx",
                                                lineNumber: 50,
                                                columnNumber: 17
                                            }, this),
                                            prepTime,
                                            " min"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/recipes/components/parts/RecipeHeader.tsx",
                                        lineNumber: 49,
                                        columnNumber: 15
                                    }, this),
                                    estimatedCost && estimatedCost > 0.5 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "flex items-center gap-1.5 bg-emerald-950/30 border border-emerald-500/30 px-3 py-1.5 rounded-full text-sm font-bold text-emerald-400",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$euro$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Euro$3e$__["Euro"], {
                                                size: 14
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/parts/RecipeHeader.tsx",
                                                lineNumber: 58,
                                                columnNumber: 17
                                            }, this),
                                            estimatedCost.toFixed(2),
                                            "€"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/recipes/components/parts/RecipeHeader.tsx",
                                        lineNumber: 57,
                                        columnNumber: 15
                                    }, this),
                                    authorName && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "flex items-center gap-1.5 bg-slate-800/50 border border-slate-700 px-3 py-1.5 rounded-full text-xs font-bold text-slate-400",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__["User"], {
                                                size: 12
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/parts/RecipeHeader.tsx",
                                                lineNumber: 66,
                                                columnNumber: 17
                                            }, this),
                                            authorName
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/recipes/components/parts/RecipeHeader.tsx",
                                        lineNumber: 65,
                                        columnNumber: 15
                                    }, this),
                                    tags.map((tag)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "flex items-center gap-1 bg-purple-900/20 border border-purple-500/30 px-3 py-1.5 rounded-full text-xs font-bold text-purple-300 uppercase tracking-wide",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__["Tag"], {
                                                    size: 10
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/parts/RecipeHeader.tsx",
                                                    lineNumber: 74,
                                                    columnNumber: 17
                                                }, this),
                                                " ",
                                                tag
                                            ]
                                        }, tag, true, {
                                            fileName: "[project]/features/recipes/components/parts/RecipeHeader.tsx",
                                            lineNumber: 73,
                                            columnNumber: 15
                                        }, this))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/recipes/components/parts/RecipeHeader.tsx",
                                lineNumber: 46,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/parts/RecipeHeader.tsx",
                        lineNumber: 40,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/parts/RecipeHeader.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/parts/RecipeHeader.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, this);
}
_c = RecipeHeader;
var _c;
__turbopack_context__.k.register(_c, "RecipeHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:a546e9 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "toggleIngredientStockAction",
    ()=>$$RSC_SERVER_ACTION_0
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"7c383b53a4b3fa87e0ad1e08f13a8b0378ba0c5ddc":"toggleIngredientStockAction"},"app/actions/inventory-quick-update.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("7c383b53a4b3fa87e0ad1e08f13a8b0378ba0c5ddc", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "toggleIngredientStockAction");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vaW52ZW50b3J5LXF1aWNrLXVwZGF0ZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBBUlhJVTogc3JjL2FwcC9hY3Rpb25zL2ludmVudG9yeS1xdWljay11cGRhdGUudHNcclxuJ3VzZSBzZXJ2ZXInO1xyXG5cclxuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSAnQC9hZGFwdGVycy9zdXBhYmFzZS9zZXJ2ZXInO1xyXG5pbXBvcnQgeyBjb250YWluZXIgfSBmcm9tICdAL3NlcnZpY2VzL2NvbnRhaW5lcic7XHJcbmltcG9ydCB7IHJldmFsaWRhdGVQYXRoIH0gZnJvbSAnbmV4dC9jYWNoZSc7XHJcbmltcG9ydCB7IFN0b3JhZ2VMb2NhdGlvbiB9IGZyb20gJ0AvY29yZS9kb21haW4vZW50aXRpZXMvU3RvcmFnZUxvY2F0aW9uJzsgLy8g4pyFIE5lY2Vzc2FyaSBwZXIgcmVjcmVhclxyXG5pbXBvcnQgeyBGT09EX1BSRVNFVFMgfSBmcm9tICdAL2xpYi9mb29kLXByZXNldHMnOyAvLyDinIUgTmVjZXNzYXJpIHBlciBjYWxjdWxhciBkYXRhL2Vtb2ppXHJcbmltcG9ydCB7IGVycm9yIGFzIGxvZ0Vycm9yIH0gZnJvbSAnQC9saWIvbG9nZ2VyJztcclxuXHJcbi8vIC0tLSBIRUxQRVI6IENvbnZlcnNpw7MgZCdVbml0YXRzIC0tLVxyXG5mdW5jdGlvbiBub3JtYWxpemVRdWFudGl0eShxdHk6IG51bWJlciwgdW5pdDogc3RyaW5nKTogeyB2YWw6IG51bWJlcjsgYmFzZTogc3RyaW5nIH0ge1xyXG4gIGNvbnN0IHUgPSB1bml0LnRvTG93ZXJDYXNlKCkudHJpbSgpO1xyXG4gIGlmICh1ID09PSAna2cnIHx8IHUgPT09ICdraWxvZ3JhbScpIHJldHVybiB7IHZhbDogcXR5ICogMTAwMCwgYmFzZTogJ2cnIH07XHJcbiAgaWYgKHUgPT09ICdnJyB8fCB1ID09PSAnZ3JhbScgfHwgdSA9PT0gJ2dyJykgcmV0dXJuIHsgdmFsOiBxdHksIGJhc2U6ICdnJyB9O1xyXG4gIGlmICh1ID09PSAnbCcgfHwgdSA9PT0gJ2xpdHJlJyB8fCB1ID09PSAnbGl0cmVzJykgcmV0dXJuIHsgdmFsOiBxdHkgKiAxMDAwLCBiYXNlOiAnbWwnIH07XHJcbiAgaWYgKHUgPT09ICdtbCcgfHwgdSA9PT0gJ2NsJykgcmV0dXJuIHsgdmFsOiBxdHksIGJhc2U6ICdtbCcgfTtcclxuICByZXR1cm4geyB2YWw6IHF0eSwgYmFzZTogJ3V0JyB9O1xyXG59XHJcblxyXG4vLyAtLS0gSEVMUEVSOiBDYWxjdWxhciBEYXRhIGkgRW1vamkgKER1cGxpY2F0IHBlciBzZWd1cmV0YXQgbyBtb3VyZSBhIEAvbGliL3V0aWxzKSAtLS1cclxuZnVuY3Rpb24gZ2V0U21hcnREZXRhaWxzKG5hbWU6IHN0cmluZykge1xyXG4gICAgY29uc3QgcHJlc2V0ID0gRk9PRF9QUkVTRVRTLmZpbmQocCA9PiBwLm5hbWUudG9Mb3dlckNhc2UoKSA9PT0gbmFtZS50b0xvd2VyQ2FzZSgpKTtcclxuICAgIGNvbnN0IGVtb2ppID0gcHJlc2V0Py5lbW9qaSB8fCAn8J+Tpic7XHJcbiAgICBsZXQgZXhwaXJ5RGF0ZTogRGF0ZSB8IHVuZGVmaW5lZCA9IHVuZGVmaW5lZDtcclxuICAgIFxyXG4gICAgaWYgKHByZXNldCkge1xyXG4gICAgICAgIGV4cGlyeURhdGUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgIGV4cGlyeURhdGUuc2V0RGF0ZShleHBpcnlEYXRlLmdldERhdGUoKSArIHByZXNldC5leHBpcmF0aW9uRGF5cyk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4geyBlbW9qaSwgZXhwaXJ5RGF0ZSB9O1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdG9nZ2xlSW5ncmVkaWVudFN0b2NrQWN0aW9uKFxyXG4gIHVzZXJJZDogc3RyaW5nLFxyXG4gIGluZ3JlZGllbnROYW1lOiBzdHJpbmcsXHJcbiAgcXVhbnRpdHlSZXF1aXJlZDogbnVtYmVyLFxyXG4gIGFjdGlvbjogJ0NPTlNVTUUnIHwgJ1JFU1RPUkUnLFxyXG4gIHVuaXRSZXF1aXJlZDogc3RyaW5nID0gJ3V0J1xyXG4pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICAgIGNvbnN0IGludmVudG9yeVJlcG8gPSBjb250YWluZXIuZ2V0SW52ZW50b3J5UmVwbyhzdXBhYmFzZSk7XHJcblxyXG4gICAgLy8gMS4gQnVzcXVlbSBsJ8OtdGVtIChDYXNlIGluc2Vuc2l0aXZlKVxyXG4gICAgY29uc3QgYWxsSXRlbXMgPSBhd2FpdCBpbnZlbnRvcnlSZXBvLmZpbmRCeUNvbnRleHQodXNlcklkKTtcclxuICAgIGNvbnN0IGl0ZW0gPSBhbGxJdGVtcy5maW5kKGkgPT4gXHJcbiAgICAgICAgaS5uYW1lLnRvTG93ZXJDYXNlKCkgPT09IGluZ3JlZGllbnROYW1lLnRvTG93ZXJDYXNlKCkgfHwgLy8gUHJpb3JpdHplbSBtYXRjaCBleGFjdGVcclxuICAgICAgICBpLm5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbmdyZWRpZW50TmFtZS50b0xvd2VyQ2FzZSgpKSB8fCBcclxuICAgICAgICBpbmdyZWRpZW50TmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGkubmFtZS50b0xvd2VyQ2FzZSgpKVxyXG4gICAgKTtcclxuXHJcbiAgICAvLyDinYwgQ0FTOiBMJ0lURU0gTk8gRVhJU1RFSVhcclxuICAgIGlmICghaXRlbSkge1xyXG4gICAgICAgIGlmIChhY3Rpb24gPT09ICdDT05TVU1FJykge1xyXG4gICAgICAgICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGBObyB0ZW5zICR7aW5ncmVkaWVudE5hbWV9IGEgbCdpbnZlbnRhcmkuYCB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICAvLyDinIUgU09MVUNJw5MgTcOAR0lDQTogU0kgw4lTIFJFU1RPUkUsIEVMIFJFLUNSRUVNIVxyXG4gICAgICAgIGlmIChhY3Rpb24gPT09ICdSRVNUT1JFJykge1xyXG4gICAgICAgICAgICBjb25zdCB7IGVtb2ppLCBleHBpcnlEYXRlIH0gPSBnZXRTbWFydERldGFpbHMoaW5ncmVkaWVudE5hbWUpO1xyXG4gICAgICAgICAgICBjb25zdCBhZGRJdGVtVXNlQ2FzZSA9IGNvbnRhaW5lci5nZXRBZGRJdGVtKHN1cGFiYXNlKTtcclxuXHJcbiAgICAgICAgICAgIGF3YWl0IGFkZEl0ZW1Vc2VDYXNlLmV4ZWN1dGUoe1xyXG4gICAgICAgICAgICAgICAgdXNlcklkLFxyXG4gICAgICAgICAgICAgICAgbmFtZTogaW5ncmVkaWVudE5hbWUsXHJcbiAgICAgICAgICAgICAgICBxdWFudGl0eTogcXVhbnRpdHlSZXF1aXJlZCwgLy8gUmVzdGF1cmVtIGV4YWN0YW1lbnQgZWwgcXVlIGRlbWFuYSBsYSByZWNlcHRhXHJcbiAgICAgICAgICAgICAgICB1bml0OiB1bml0UmVxdWlyZWQsICAgICAgICAgLy8gQW1iIGxhIHVuaXRhdCBkZSBsYSByZWNlcHRhXHJcbiAgICAgICAgICAgICAgICBsb2NhdGlvbjogU3RvcmFnZUxvY2F0aW9uLlBBTlRSWSwgLy8gUGVyIGRlZmVjdGVcclxuICAgICAgICAgICAgICAgIGVtb2ppOiBlbW9qaSxcclxuICAgICAgICAgICAgICAgIGV4cGlyeURhdGU6IGV4cGlyeURhdGUsXHJcbiAgICAgICAgICAgICAgICBhZGRlZEF0OiBuZXcgRGF0ZSgpXHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgcmV2YWxpZGF0ZVBhdGgoJy9pbnZlbnRvcnknKTtcclxuICAgICAgICAgICAgcmV2YWxpZGF0ZVBhdGgoYC9yZWNpcGVzYCk7XHJcbiAgICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIG5ld1F1YW50aXR5OiBxdWFudGl0eVJlcXVpcmVkLCB1bml0OiB1bml0UmVxdWlyZWQsIHN0YXR1czogJ1JFU1RPUkVEX0NSRUFURUQnIH07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIC0tLSBTaSBsJ2l0ZW0gZXhpc3RlaXgsIGNvbnRpbnVlbSBhbWIgbGEgbMOyZ2ljYSBub3JtYWwgLS0tXHJcblxyXG4gICAgLy8gMi4gTMOSR0lDQSBERSBDT05WRVJTScOTIEkgQ8OATENVTFxyXG4gICAgLy8gTm90YTogU2kgYWNhYmVtIGRlIGNyZWFyIGwnaXRlbSBhIGRhbHQsIGphIGhlbSByZXRvcm5hdCwgYWl4w60gcXVlIGFxdcOtICdpdGVtJyDDqXMgc2VndXIuXHJcbiAgICBjb25zdCBjdXJyZW50ID0gbm9ybWFsaXplUXVhbnRpdHkoaXRlbSEucXVhbnRpdHksIGl0ZW0hLnVuaXQpO1xyXG4gICAgY29uc3QgcmVxdWlyZWQgPSBub3JtYWxpemVRdWFudGl0eShxdWFudGl0eVJlcXVpcmVkLCB1bml0UmVxdWlyZWQpO1xyXG5cclxuICAgIGxldCBuZXdCYXNlUXVhbnRpdHkgPSAwO1xyXG5cclxuICAgIGlmIChhY3Rpb24gPT09ICdDT05TVU1FJykge1xyXG4gICAgICAgIGlmIChjdXJyZW50LmJhc2UgIT09IHJlcXVpcmVkLmJhc2UgJiYgY3VycmVudC5iYXNlICE9PSAndXQnKSB7XHJcbiAgICAgICAgICAgICBjb25zb2xlLndhcm4oYFVuaXRhdHMgaW5jb21wYXRpYmxlczogJHtpdGVtIS51bml0fSB2cyAke3VuaXRSZXF1aXJlZH1gKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbmV3QmFzZVF1YW50aXR5ID0gY3VycmVudC52YWwgLSByZXF1aXJlZC52YWw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIC8vIFJFU1RPUkUgKFN1bWVtKVxyXG4gICAgICAgIG5ld0Jhc2VRdWFudGl0eSA9IGN1cnJlbnQudmFsICsgcmVxdWlyZWQudmFsO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIDMuIFJFQ09OVkVSU0nDkyBBIExBIFVOSVRBVCBERSBMJ1VTVUFSSVxyXG4gICAgbGV0IGZpbmFsUXVhbnRpdHkgPSBuZXdCYXNlUXVhbnRpdHk7XHJcbiAgICBpZiAoaXRlbSEudW5pdC50b0xvd2VyQ2FzZSgpID09PSAna2cnICYmIGN1cnJlbnQuYmFzZSA9PT0gJ2cnKSBmaW5hbFF1YW50aXR5ID0gbmV3QmFzZVF1YW50aXR5IC8gMTAwMDtcclxuICAgIGlmIChpdGVtIS51bml0LnRvTG93ZXJDYXNlKCkgPT09ICdsJyAmJiBjdXJyZW50LmJhc2UgPT09ICdtbCcpIGZpbmFsUXVhbnRpdHkgPSBuZXdCYXNlUXVhbnRpdHkgLyAxMDAwO1xyXG4gICAgXHJcbiAgICBmaW5hbFF1YW50aXR5ID0gTnVtYmVyKGZpbmFsUXVhbnRpdHkudG9GaXhlZCgzKSk7XHJcblxyXG4gICAgLy8gNC4gRVhFQ1VUQVIgQUNUVUFMSVRaQUNJw5NcclxuICAgIGlmIChmaW5hbFF1YW50aXR5IDw9IDApIHtcclxuICAgICAgICAvLyBERUxFVEVcclxuICAgICAgICBjb25zdCBkZWxldGVVc2VDYXNlID0gY29udGFpbmVyLmdldERlbGV0ZUl0ZW0oc3VwYWJhc2UpO1xyXG4gICAgICAgIGF3YWl0IGRlbGV0ZVVzZUNhc2UuZXhlY3V0ZShpdGVtIS5pZCk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgcmV2YWxpZGF0ZVBhdGgoJy9pbnZlbnRvcnknKTtcclxuICAgICAgICByZXZhbGlkYXRlUGF0aChgL3JlY2lwZXNgKTtcclxuICAgICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCBuZXdRdWFudGl0eTogMCwgdW5pdDogaXRlbSEudW5pdCwgc3RhdHVzOiAnREVMRVRFRCcgfTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gVVBEQVRFXHJcbiAgICAgICAgY29uc3QgdXBkYXRlVXNlQ2FzZSA9IGNvbnRhaW5lci5nZXRVcGRhdGVJdGVtKHN1cGFiYXNlKTtcclxuICAgICAgICBhd2FpdCB1cGRhdGVVc2VDYXNlLmV4ZWN1dGUoe1xyXG4gICAgICAgICAgICAuLi5pdGVtIS5wcm9wcyxcclxuICAgICAgICAgICAgcXVhbnRpdHk6IGZpbmFsUXVhbnRpdHksXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldmFsaWRhdGVQYXRoKCcvaW52ZW50b3J5Jyk7XHJcbiAgICAgICAgcmV2YWxpZGF0ZVBhdGgoYC9yZWNpcGVzYCk7XHJcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgbmV3UXVhbnRpdHk6IGZpbmFsUXVhbnRpdHksIHVuaXQ6IGl0ZW0hLnVuaXQsIHN0YXR1czogJ1VQREFURUQnIH07XHJcbiAgICB9XHJcblxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBsb2dFcnJvcihcIkVycm9yIGVuIHRvZ2dsZUluZ3JlZGllbnQ6XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciBhY3R1YWxpdHphbnQgbCdlc3RvYy5cIiB9O1xyXG4gIH1cclxufVxyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6InFUQWlDc0Isd01BQUEifQ==
}),
"[project]/lib/utils/emojiUtils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getIngredientEmoji",
    ()=>getIngredientEmoji,
    "getMainEmoji",
    ()=>getMainEmoji
]);
// Diccionari ràpid per ingredients individuals
const EMOJI_MAP = {
    // Verdures
    tomaquet: '🍅',
    tomato: '🍅',
    patata: '🥔',
    potato: '🥔',
    ceba: '🧅',
    onion: '🧅',
    all: '🧄',
    garlic: '🧄',
    pastanaga: '🥕',
    carrot: '🥕',
    enciam: '🥬',
    lettuce: '🥬',
    brocoli: '🥦',
    broccoli: '🥦',
    pebrot: '🫑',
    pepper: '🫑',
    alberginia: '🍆',
    eggplant: '🍆',
    bolet: '🍄',
    xampinyo: '🍄',
    mushroom: '🍄',
    // Fruites
    llimona: '🍋',
    lemon: '🍋',
    poma: '🍎',
    apple: '🍎',
    platan: '🍌',
    banana: '🍌',
    maduixa: '🍓',
    strawberry: '🍓',
    // Proteïnes
    pollastre: '🍗',
    chicken: '🍗',
    carn: '🥩',
    vedella: '🥩',
    meat: '🥩',
    beef: '🥩',
    porc: '🥓',
    pork: '🥓',
    pernil: '🥓',
    bacon: '🥓',
    peix: '🐟',
    fish: '🐟',
    gamba: '🦐',
    shrimp: '🦐',
    ou: '🥚',
    egg: '🥚',
    // Làctics & Altres
    llet: '🥛',
    milk: '🥛',
    formatge: '🧀',
    cheese: '🧀',
    mantega: '🧈',
    butter: '🧈',
    oli: '🫒',
    oil: '🫒',
    pa: '🥖',
    bread: '🥖',
    arros: '🍚',
    rice: '🍚',
    pasta: '🍝',
    espagueti: '🍝',
    macarrons: '🍝',
    // Condiments
    sal: '🧂',
    salt: '🧂',
    pebre: '🌶️',
    sucre: '🍬',
    sugar: '🍬',
    aigua: '💧',
    water: '💧',
    xocolata: '🍫',
    chocolate: '🍫'
};
// Helper per treure accents i passar a minúscules (ex: "Arròs" -> "arros")
const normalizeText = (text)=>text.toLowerCase().trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
function getIngredientEmoji(name) {
    if (!name) return '🥗';
    const normalized = normalizeText(name);
    // A. Cerca directa
    if (EMOJI_MAP[normalized]) return EMOJI_MAP[normalized];
    // B. Cerca parcial
    for (const [key, emoji] of Object.entries(EMOJI_MAP)){
        if (normalized.includes(key)) return emoji;
    }
    // C. Fallbacks genèrics
    if (normalized.includes('carn') || normalized.includes('filet')) return '🥩';
    if (normalized.includes('verdura') || normalized.includes('fulla')) return '🥬';
    if (normalized.includes('fruita')) return '🍎';
    if (normalized.includes('salsa')) return '🥣';
    if (normalized.includes('especia') || normalized.includes('herba')) return '🌿';
    if (normalized.includes('farina') || normalized.includes('masa')) return '🌾';
    return '🥗'; // Default
}
function getMainEmoji(name, tags = []) {
    const normalizedName = normalizeText(name);
    const normalizedTags = tags.map((t)=>normalizeText(t));
    // Unim tot el text per buscar paraules clau
    const context = [
        normalizedName,
        ...normalizedTags
    ].join(' ');
    // --- NIVELL 1: PLATS ESPECÍFICS (Prioritat Màxima) ---
    if (context.includes('pizza')) return '🍕';
    if (context.includes('hamburg') || context.includes('burger')) return '🍔';
    if (context.includes('sushi') || context.includes('maki') || context.includes('nigiri')) return '🍣';
    if (context.includes('taco') || context.includes('mexic') || context.includes('fajita')) return '🌮';
    if (context.includes('burrito') || context.includes('durum')) return '🌯';
    if (context.includes('hot dog') || context.includes('frankfurt')) return '🌭';
    if (context.includes('crispetes') || context.includes('pop corn')) return '🍿';
    if (context.includes('patates fregides') || context.includes('braves')) return '🍟';
    if (context.includes('ramen') || context.includes('fideus xinesos')) return '🍜';
    // --- NIVELL 2: POSTRES I DOLÇOS ---
    // Fruita (IMPORTANT: Abans que "postres" genèric)
    if (context.includes('macedonia') || context.includes('fruita')) return '🍉';
    if (context.includes('maduix')) return '🍓';
    if (context.includes('poma')) return '🍎';
    if (context.includes('platan')) return '🍌';
    if (context.includes('llimona') || context.includes('sorbet')) return '🍋';
    if (context.includes('cirer')) return '🍒';
    // Dolços
    if (context.includes('xocolata') || context.includes('brownie') || context.includes('coulant')) return '🍫';
    if (context.includes('pastis') || context.includes('cake') || context.includes('tarta') || context.includes('tiramisu')) return '🍰';
    if (context.includes('gelat') || context.includes('ice cream')) return '🍦';
    if (context.includes('galetes') || context.includes('cookies')) return '🍪';
    if (context.includes('donut')) return '🍩';
    if (context.includes('croissant')) return '🥐';
    if (context.includes('pancake') || context.includes('crep')) return '🥞';
    if (context.includes('flam') || context.includes('crema catalana') || context.includes('pudding')) return '🍮';
    // Tag genèric de postres
    if (context.includes('postres') || context.includes('dessert') || context.includes('dolc')) return '🧁';
    // --- NIVELL 3: PLATS PRINCIPALS ---
    // Arrossos i Pasta
    if (context.includes('paella') || context.includes('arros')) return '🥘';
    if (context.includes('pasta') || context.includes('spaghetti') || context.includes('macarron') || context.includes('lasanya')) return '🍝';
    if (context.includes('fideu')) return '🍜';
    // Sopes i Cremes
    if (context.includes('sopa') || context.includes('crema') || context.includes('brou') || context.includes('escudella')) return '🥣';
    // Amanides
    if (context.includes('amanida') || context.includes('salad') || context.includes('cesar')) return '🥗';
    // Entrepans
    if (context.includes('entrepa') || context.includes('sandvitx') || context.includes('bikini')) return '🥪';
    // Ous
    if (context.includes('ou') || context.includes('truita') || context.includes('tortilla')) return '🍳';
    // --- NIVELL 4: BEGUDES ---
    if (context.includes('batut') || context.includes('smoothie')) return '🥤';
    if (context.includes('cafe') || context.includes('coffee')) return '☕';
    if (context.includes('cocktail') || context.includes('mojito')) return '🍹';
    if (context.includes('cervesa') || context.includes('beer')) return '🍺';
    if (context.includes('vi ') || context.includes('wine')) return '🍷';
    // --- NIVELL 5: INGREDIENT PRINCIPAL ---
    if (context.includes('pollastre') || context.includes('chicken') || context.includes('gall d')) return '🍗';
    if (context.includes('vedella') || context.includes('carn') || context.includes('steak') || context.includes('meat')) return '🥩';
    if (context.includes('porc') || context.includes('bacon') || context.includes('pernil')) return '🥓';
    if (context.includes('peix') || context.includes('fish') || context.includes('salmo') || context.includes('bacalla') || context.includes('orada')) return '🐟';
    if (context.includes('gamba') || context.includes('marisc') || context.includes('musclo')) return '🦐';
    if (context.includes('formatge') || context.includes('cheese')) return '🧀';
    // --- NIVELL 6: DIETES ---
    if (context.includes('vega') || context.includes('vegan')) return '🌱';
    if (context.includes('vegetaria')) return '🥦';
    return '🍽️';
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:633fec [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addToShoppingListAction",
    ()=>$$RSC_SERVER_ACTION_0
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"7f90f029d2592ccc3fc2c5b053e08bb834cfdaedc2":"addToShoppingListAction"},"app/actions/shopping-list-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("7f90f029d2592ccc3fc2c5b053e08bb834cfdaedc2", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "addToShoppingListAction");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vc2hvcHBpbmctbGlzdC1hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc2VydmVyJztcclxuXHJcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2Uvc2VydmVyJztcclxuaW1wb3J0IHsgY29udGFpbmVyIH0gZnJvbSAnQC9zZXJ2aWNlcy9jb250YWluZXInO1xyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gJ25leHQvY2FjaGUnO1xyXG5pbXBvcnQgeyBkZWJ1ZywgZXJyb3IgYXMgbG9nRXJyb3IgfSBmcm9tICdAL2xpYi9sb2dnZXInO1xyXG5pbXBvcnQgeyB6IH0gZnJvbSAnem9kJztcclxuXHJcbmNvbnN0IEFkZEl0ZW1TY2hlbWEgPSB6Lm9iamVjdCh7XHJcbiAgbmFtZTogei5zdHJpbmcoKS5taW4oMSksXHJcbiAgcXVhbnRpdHk6IHoubnVtYmVyKCkucG9zaXRpdmUoKSxcclxuICB1bml0OiB6LnN0cmluZygpLFxyXG4gIGVtb2ppOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgcHJvZHVjdElkOiB6LnN0cmluZygpLm9wdGlvbmFsKCkubnVsbGFibGUoKSxcclxuICBwcm9kdWN0SW1hZ2U6IHouc3RyaW5nKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpLFxyXG4gIGVzdGltYXRlZENvc3Q6IHoubnVtYmVyKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpLFxyXG4gIHJvb21JZDogei5zdHJpbmcoKS51dWlkKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpXHJcbn0pO1xyXG4vLyDinIUgU2NoZW1hIHBlciB2YWxpZGFjacOzIG1hc3NpdmFcclxuY29uc3QgQmF0Y2hJdGVtU2NoZW1hID0gei5vYmplY3Qoe1xyXG4gIGl0ZW1zOiB6LmFycmF5KEFkZEl0ZW1TY2hlbWEpLFxyXG4gIHJvb21JZDogei5zdHJpbmcoKS51dWlkKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpXHJcbn0pO1xyXG5jb25zdCBUb2dnbGVJdGVtU2NoZW1hID0gei5vYmplY3Qoe1xyXG4gIGl0ZW1JZDogei5zdHJpbmcoKS51dWlkKCksXHJcbiAgaXNDaGVja2VkOiB6LmJvb2xlYW4oKVxyXG59KTtcclxuY29uc3QgUm9vbUlkU2NoZW1hID0gei5zdHJpbmcoKS51dWlkKCkub3B0aW9uYWwoKS5udWxsYWJsZSgpO1xyXG4vLyAxLiBBREQgSVRFTVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYWRkVG9TaG9wcGluZ0xpc3RBY3Rpb24oXHJcbiAgICBuYW1lOiBzdHJpbmcsIFxyXG4gICAgcXVhbnRpdHk6IG51bWJlciwgXHJcbiAgICB1bml0OiBzdHJpbmcsIFxyXG4gICAgZW1vamk/OiBzdHJpbmcsIFxyXG4gICAgcHJvZHVjdElkPzogc3RyaW5nLFxyXG4gICAgcHJvZHVjdEltYWdlPzogc3RyaW5nLFxyXG4gICAgZXN0aW1hdGVkQ29zdD86IG51bWJlcixcclxuICAgIHJvb21JZD86IHN0cmluZyB8IG51bGxcclxuKSB7XHJcbiAgdHJ5IHtcclxuICAgIGRlYnVnKCdbQUNUSU9OXSBhZGRUb1Nob3BwaW5nTGlzdCBzdGFydCcpO1xyXG5cclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICAgIGlmICghdXNlcikgdGhyb3cgbmV3IEVycm9yKFwiVW5hdXRob3JpemVkXCIpO1xyXG5cclxuICAgIGNvbnN0IHZhbGlkYXRpb24gPSBBZGRJdGVtU2NoZW1hLnNhZmVQYXJzZSh7IFxyXG4gICAgICAgIG5hbWUsIHF1YW50aXR5LCB1bml0LCBlbW9qaSwgcHJvZHVjdElkLCBwcm9kdWN0SW1hZ2UsIGVzdGltYXRlZENvc3QsIHJvb21JZFxyXG4gICAgfSk7XHJcbiAgICBcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSB7XHJcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkRhZGVzIGludsOgbGlkZXNcIiB9O1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHVzZUNhc2UgPSBjb250YWluZXIuZ2V0QWRkVG9TaG9wcGluZ0xpc3Qoc3VwYWJhc2UpO1xyXG4gICAgXHJcbiAgICBhd2FpdCB1c2VDYXNlLmV4ZWN1dGUoXHJcbiAgICAgICAgdXNlci5pZCwgXHJcbiAgICAgICAgdmFsaWRhdGlvbi5kYXRhLm5hbWUsIFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5xdWFudGl0eSwgXHJcbiAgICAgICAgdmFsaWRhdGlvbi5kYXRhLnVuaXQsXHJcbiAgICAgICAgdmFsaWRhdGlvbi5kYXRhLmVtb2ppLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5wcm9kdWN0SWQgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5wcm9kdWN0SW1hZ2UgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5lc3RpbWF0ZWRDb3N0IHx8IHVuZGVmaW5lZCxcclxuICAgICAgICB2YWxpZGF0aW9uLmRhdGEucm9vbUlkIHx8IHVuZGVmaW5lZFxyXG4gICAgKTtcclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL3Nob3BwaW5nLWxpc3QnKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxuXHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGxvZ0Vycm9yKCdhZGRUb1Nob3BwaW5nTGlzdCBmYWlsZWQnLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiTm8gcydoYSBwb2d1dCBhZmVnaXIgYSBsYSBsbGlzdGEuXCIgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIDIuIFRPR0dMRSBJVEVNXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB0b2dnbGVTaG9wcGluZ0l0ZW1BY3Rpb24oaXRlbUlkOiBzdHJpbmcsIGlzQ2hlY2tlZDogYm9vbGVhbikge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB2YWxpZGF0aW9uID0gVG9nZ2xlSXRlbVNjaGVtYS5zYWZlUGFyc2UoeyBpdGVtSWQsIGlzQ2hlY2tlZCB9KTtcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRGFkZXMgaW52w6BsaWRlc1wiIH07XHJcblxyXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICAgIGNvbnN0IHJlcG8gPSBjb250YWluZXIuZ2V0U2hvcHBpbmdMaXN0UmVwbyhzdXBhYmFzZSk7IFxyXG4gICAgYXdhaXQgcmVwby50b2dnbGVDaGVjayh2YWxpZGF0aW9uLmRhdGEuaXRlbUlkLCB2YWxpZGF0aW9uLmRhdGEuaXNDaGVja2VkKTtcclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL3Nob3BwaW5nLWxpc3QnKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ3RvZ2dsZVNob3BwaW5nSXRlbSBmYWlsZWQnLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRXJyb3IgYWN0dWFsaXR6YW50XCIgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIDMuIENPTVBMRVRFIFNFU1NJT05cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNvbXBsZXRlU2hvcHBpbmdTZXNzaW9uQWN0aW9uKHJvb21JZD86IHN0cmluZyB8IG51bGwpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgdmFsaWRhdGlvbiA9IFJvb21JZFNjaGVtYS5zYWZlUGFyc2Uocm9vbUlkKTtcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRGFkZXMgaW52w6BsaWRlc1wiIH07XHJcblxyXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICAgIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0gfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpO1xyXG4gICAgaWYgKCF1c2VyKSB0aHJvdyBuZXcgRXJyb3IoJ1VuYXV0aG9yaXplZCcpO1xyXG5cclxuICAgIGNvbnN0IHVzZUNhc2UgPSBjb250YWluZXIuZ2V0Q29tcGxldGVTaG9wcGluZ1Nlc3Npb24oc3VwYWJhc2UpO1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdXNlQ2FzZS5leGVjdXRlKHVzZXIuaWQsIHZhbGlkYXRpb24uZGF0YSB8fCB1bmRlZmluZWQpO1xyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvc2hvcHBpbmctbGlzdCcpO1xyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9pbnZlbnRvcnknKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGNvdW50OiByZXN1bHQuYWRkZWQgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoXCJFcnJvciBjb21wbGV0aW5nIHNob3BwaW5nIHNlc3Npb246XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciBmaW5hbGl0emFudCBsYSBjb21wcmFcIiB9O1xyXG4gIH1cclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYWRkQmF0Y2hUb1Nob3BwaW5nTGlzdEFjdGlvbihpdGVtczogei5pbmZlcjx0eXBlb2YgQWRkSXRlbVNjaGVtYT5bXSwgcm9vbUlkPzogc3RyaW5nIHwgbnVsbCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgICBpZiAoIXVzZXIpIHRocm93IG5ldyBFcnJvcihcIlVuYXV0aG9yaXplZFwiKTtcclxuXHJcbiAgICAvLyBWYWxpZGFyIGRhZGVzXHJcbiAgICBjb25zdCB2YWxpZGF0aW9uID0gQmF0Y2hJdGVtU2NoZW1hLnNhZmVQYXJzZSh7IGl0ZW1zLCByb29tSWQgfSk7XHJcbiAgICBpZiAoIXZhbGlkYXRpb24uc3VjY2VzcykgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkRhZGVzIGludsOgbGlkZXNcIiB9O1xyXG5cclxuICAgIGNvbnN0IHVzZUNhc2UgPSBjb250YWluZXIuZ2V0QWRkVG9TaG9wcGluZ0xpc3Qoc3VwYWJhc2UpO1xyXG5cclxuICAgIC8vIEV4ZWN1dGFyIGVuIHBhcmFswrdsZWwgKG8gcG9kcmllcyBmZXIgdW4gbG9vcCBzZXF1ZW5jaWFsIHNpIHZvbHMgZ2FyYW50aXIgb3JkcmUpXHJcbiAgICBhd2FpdCBQcm9taXNlLmFsbChpdGVtcy5tYXAoaXRlbSA9PiBcclxuICAgICAgdXNlQ2FzZS5leGVjdXRlKFxyXG4gICAgICAgIHVzZXIuaWQsXHJcbiAgICAgICAgaXRlbS5uYW1lLFxyXG4gICAgICAgIGl0ZW0ucXVhbnRpdHksXHJcbiAgICAgICAgaXRlbS51bml0LFxyXG4gICAgICAgIGl0ZW0uZW1vamksXHJcbiAgICAgICAgaXRlbS5wcm9kdWN0SWQgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIGl0ZW0ucHJvZHVjdEltYWdlIHx8IHVuZGVmaW5lZCxcclxuICAgICAgICBpdGVtLmVzdGltYXRlZENvc3QgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIHZhbGlkYXRpb24uZGF0YS5yb29tSWQgfHwgdW5kZWZpbmVkXHJcbiAgICAgIClcclxuICAgICkpO1xyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvc2hvcHBpbmctbGlzdCcpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG5cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoXCJFcnJvciBhZGRpbmcgYmF0Y2g6XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciBndWFyZGFudCBwcm9kdWN0ZXNcIiB9O1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNob3BwaW5nTGlzdERhdGFBY3Rpb24ocm9vbUlkPzogc3RyaW5nIHwgbnVsbCkge1xyXG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgaWYgKCF1c2VyKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGlvbiA9IFJvb21JZFNjaGVtYS5zYWZlUGFyc2Uocm9vbUlkKTtcclxuICBpZiAoIXZhbGlkYXRpb24uc3VjY2VzcykgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkRhZGVzIGludsOgbGlkZXNcIiB9O1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgZ2V0U2hvcHBpbmdMaXN0ID0gY29udGFpbmVyLmdldEdldFNob3BwaW5nTGlzdChzdXBhYmFzZSk7XHJcbiAgICBjb25zdCBnZXRIaXN0b3J5ID0gY29udGFpbmVyLmdldEdldFNob3BwaW5nSGlzdG9yeShzdXBhYmFzZSk7XHJcblxyXG4gICAgY29uc3QgW2l0ZW1zLCBoaXN0b3J5XSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgZ2V0U2hvcHBpbmdMaXN0LmV4ZWN1dGUodXNlci5pZCwgdmFsaWRhdGlvbi5kYXRhIHx8IHVuZGVmaW5lZCksXHJcbiAgICAgIGdldEhpc3RvcnkuZXhlY3V0ZSh1c2VyLmlkLCB2YWxpZGF0aW9uLmRhdGEgfHwgdW5kZWZpbmVkKSxcclxuICAgIF0pO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IHRydWUsXHJcbiAgICAgIGRhdGE6IHtcclxuICAgICAgICBpdGVtczogbWFwSXRlbXNUb1ZpZXdNb2RlbChpdGVtcyksXHJcbiAgICAgICAgaGlzdG9yeTogbWFwSGlzdG9yeVRvVmlld01vZGVsKGhpc3RvcnkpLFxyXG4gICAgICB9LFxyXG4gICAgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ2dldFNob3BwaW5nTGlzdERhdGFBY3Rpb24gZmFpbGVkJywgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIk5vIHMnaGEgcG9ndXQgY2FycmVnYXIgbGEgbGxpc3RhLlwiIH07XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBtYXBJdGVtc1RvVmlld01vZGVsKGl0ZW1zOiBpbXBvcnQoJ0AvY29yZS9kb21haW4vZW50aXRpZXMvU2hvcHBpbmdMaXN0SXRlbScpLlNob3BwaW5nTGlzdEl0ZW1bXSkge1xyXG4gIHJldHVybiBpdGVtcy5tYXAoKGkpID0+ICh7XHJcbiAgICBpZDogaS5wcm9wcy5pZCxcclxuICAgIG5hbWU6IGkucHJvcHMubmFtZSxcclxuICAgIHF1YW50aXR5OiBpLnByb3BzLnF1YW50aXR5LFxyXG4gICAgdW5pdDogaS5wcm9wcy51bml0LFxyXG4gICAgaXNDaGVja2VkOiBpLnByb3BzLmlzQ2hlY2tlZCxcclxuICAgIGVtb2ppOiBpLnByb3BzLmVtb2ppLFxyXG4gICAgcHJvZHVjdElkOiBpLnByb3BzLnByb2R1Y3RJZCA/PyB1bmRlZmluZWQsXHJcbiAgICBwcm9kdWN0SW1hZ2U6IGkucHJvcHMucHJvZHVjdEltYWdlID8/IHVuZGVmaW5lZCxcclxuICAgIGVzdGltYXRlZENvc3Q6IGkucHJvcHMuZXN0aW1hdGVkQ29zdCA/PyB1bmRlZmluZWRcclxuICB9KSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIG1hcEhpc3RvcnlUb1ZpZXdNb2RlbChoaXN0b3J5OiBpbXBvcnQoJ0AvY29yZS9kb21haW4vZW50aXRpZXMvU2hvcHBpbmdTZXNzaW9uJykuU2hvcHBpbmdTZXNzaW9uW10pIHtcclxuICByZXR1cm4gaGlzdG9yeS5tYXAoKGgpID0+ICh7XHJcbiAgICBpZDogaC5wcm9wcy5pZCxcclxuICAgIGNyZWF0ZWRBdDogaC5wcm9wcy5jcmVhdGVkQXQsXHJcbiAgICB0b3RhbENvc3Q6IGgucHJvcHMudG90YWxDb3N0LFxyXG4gICAgaXRlbUNvdW50OiBoLnByb3BzLml0ZW1Db3VudCxcclxuICAgIGl0ZW1zU25hcHNob3Q6IGgucHJvcHMuaXRlbXNTbmFwc2hvdFxyXG4gIH0pKTtcclxufVxyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6ImdUQTZCc0Isb01BQUEifQ==
}),
"[project]/app/actions/data:419f81 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "quickAddInventoryAction",
    ()=>$$RSC_SERVER_ACTION_6
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"7eb2211045aedb326ee2742860ff1fe351fe40e05c":"quickAddInventoryAction"},"app/actions/inventory.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("7eb2211045aedb326ee2742860ff1fe351fe40e05c", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "quickAddInventoryAction");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vaW52ZW50b3J5LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEFSWElVOiBzcmMvYXBwL2FjdGlvbnMvaW52ZW50b3J5LnRzXHJcbid1c2Ugc2VydmVyJztcclxuXHJcbmltcG9ydCB7IHogfSBmcm9tICd6b2QnO1xyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gJ25leHQvY2FjaGUnO1xyXG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tICdAL2FkYXB0ZXJzL3N1cGFiYXNlL3NlcnZlcic7XHJcbmltcG9ydCB7IGNvbnRhaW5lciB9IGZyb20gJ0Avc2VydmljZXMvY29udGFpbmVyJztcclxuaW1wb3J0IHsgU3RvcmFnZUxvY2F0aW9uIH0gZnJvbSAnQC9jb3JlL2RvbWFpbi9lbnRpdGllcy9TdG9yYWdlTG9jYXRpb24nO1xyXG5pbXBvcnQgeyBJbnZlbnRvcnlJdGVtIH0gZnJvbSAnQC9jb3JlL2RvbWFpbi9lbnRpdGllcy9JbnZlbnRvcnlJdGVtJzsgLy8gQXNzZWd1cmEndCBxdWUgbCdFbnRpdHkgamEgdMOpIHJvb21JZCBhbCBjb25zdHJ1Y3RvciFcclxuaW1wb3J0IHsgRk9PRF9QUkVTRVRTIH0gZnJvbSAnQC9saWIvZm9vZC1wcmVzZXRzJztcclxuaW1wb3J0IHsgRXhwaXJ5U2FmZXR5U2VydmljZSB9IGZyb20gJ0AvY29yZS9hcHBsaWNhdGlvbi9zZXJ2aWNlcy9FeHBpcnlTYWZldHlTZXJ2aWNlJztcclxuaW1wb3J0IHsgRW1vamlNYXRjaGVyU2VydmljZSB9IGZyb20gJ0AvY29yZS9hcHBsaWNhdGlvbi9zZXJ2aWNlcy9FbW9qaU1hdGNoZXJTZXJ2aWNlJztcclxuaW1wb3J0IHsgZXJyb3IgYXMgbG9nRXJyb3IgfSBmcm9tICdAL2xpYi9sb2dnZXInO1xyXG5pbXBvcnQge1xyXG4gIEludmVudG9yeUl0ZW1TY2hlbWEsXHJcbiAgQ29uc3VtZUl0ZW1TY2hlbWEsXHJcbn0gZnJvbSAnQC9jb3JlL2FwcGxpY2F0aW9uL3NjaGVtYXMvaW5wdXRTY2hlbWFzJztcclxuXHJcbi8vIERlZmluaW0gcXXDqCByZXRvcm5lbSBhIGxhIFVJIChTZXJpYWxpdHphYmxlLCBzZW5zZSBjbGFzc2VzKVxyXG5leHBvcnQgaW50ZXJmYWNlIFByb2R1Y3RSZXN1bHQge1xyXG4gIGlkOiBzdHJpbmc7XHJcbiAgbmFtZTogc3RyaW5nO1xyXG4gIHByaWNlOiBudW1iZXI7XHJcbiAgaW1hZ2U6IHN0cmluZztcclxuICBzb3VyY2U6IHN0cmluZztcclxuICBlbW9qaTogc3RyaW5nO1xyXG4gIHRhZ3M6IHN0cmluZ1tdO1xyXG4gIHF1YW50aXR5QW1vdW50PzogbnVtYmVyO1xyXG4gIHF1YW50aXR5VW5pdD86IHN0cmluZztcclxufVxyXG5cclxuLy8gLS0tIEhFTFBFUlMgLS0tXHJcbmZ1bmN0aW9uIGNhbGN1bGF0ZUV4cGlyeURhdGUobmFtZTogc3RyaW5nLCBlbW9qaT86IHN0cmluZyk6IERhdGUgfCB1bmRlZmluZWQge1xyXG4gIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XHJcbiAgY29uc3QgcHJlc2V0ID0gRk9PRF9QUkVTRVRTLmZpbmQocCA9PlxyXG4gICAgcC5uYW1lLnRvTG93ZXJDYXNlKCkgPT09IG5hbWUudG9Mb3dlckNhc2UoKSB8fFxyXG4gICAgKGVtb2ppICYmIHAuZW1vamkgPT09IGVtb2ppKVxyXG4gICk7XHJcbiAgaWYgKHByZXNldCkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gbmV3IERhdGUoKTtcclxuICAgIHJlc3VsdC5zZXREYXRlKG5vdy5nZXREYXRlKCkgKyBwcmVzZXQuZXhwaXJhdGlvbkRheXMpO1xyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxuICB9XHJcbiAgcmV0dXJuIHVuZGVmaW5lZDtcclxufVxyXG5cclxuLy8gQWN0dWFsaXR6ZW0gbCdzY2hlbWEgcGVyIGFjY2VwdGFyIHJvb21JZFxyXG5jb25zdCBCYXRjaEludmVudG9yeVNjaGVtYSA9IHouYXJyYXkoSW52ZW50b3J5SXRlbVNjaGVtYS5vbWl0KHsgdXNlcklkOiB0cnVlIH0pLmV4dGVuZCh7IHJvb21JZDogei5zdHJpbmcoKS5vcHRpb25hbCgpIH0pKTtcclxuXHJcbmZ1bmN0aW9uIGdldFpvZEVycm9yKGVycm9yOiB6LlpvZEVycm9yPHVua25vd24+KTogc3RyaW5nIHsgcmV0dXJuIGVycm9yLmlzc3Vlc1swXT8ubWVzc2FnZSB8fCBcIkRhZGVzIGludsOgbGlkZXNcIjsgfVxyXG5mdW5jdGlvbiBnZXRFcnJvck1lc3NhZ2UoZXJyb3I6IHVua25vd24pOiBzdHJpbmcgeyByZXR1cm4gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBTdHJpbmcoZXJyb3IpOyB9XHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gMC4gR0VUIElOVkVOVE9SWSAoTk9WQSBBQ0NJw5MgUEVSIExMSVNUQVIpXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SW52ZW50b3J5QWN0aW9uKHJvb21JZD86IHN0cmluZykge1xyXG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgaWYgKCF1c2VyKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfTtcclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlcG8gPSBjb250YWluZXIuZ2V0SW52ZW50b3J5UmVwbyhzdXBhYmFzZSk7XHJcbiAgICAvLyBDcmlkZW0gYWwgbm91IG3DqHRvZGUgZGVsIHJlcG8gcXVlIHZhbSBjcmVhciBhbCBwYXMgYW50ZXJpb3JcclxuICAgIGNvbnN0IGl0ZW1zID0gYXdhaXQgcmVwby5maW5kQnlDb250ZXh0KHVzZXIuaWQsIHJvb21JZCk7XHJcblxyXG4gICAgLy8gU2VyaWFsaXR6ZW0gZGF0ZXMgcGVyIGFsIGNsaWVudFxyXG4gICAgY29uc3Qgc2VyaWFsaXplZCA9IGl0ZW1zLm1hcChpID0+ICh7XHJcbiAgICAgIC4uLmkudG9QcmltaXRpdmVzKCksXHJcbiAgICAgIGV4cGlyeURhdGU6IGkuZXhwaXJ5RGF0ZSA/IGkuZXhwaXJ5RGF0ZS50b0lTT1N0cmluZygpIDogbnVsbCxcclxuICAgICAgYWRkZWRBdDogaS5hZGRlZEF0LnRvSVNPU3RyaW5nKCksXHJcbiAgICAgIHJvb21JZDogaS5yb29tSWQgfHwgdW5kZWZpbmVkXHJcbiAgICB9KSk7XHJcblxyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgZGF0YTogc2VyaWFsaXplZCB9O1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldEVycm9yTWVzc2FnZShlcnJvcikgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAxLiBBREQgSVRFTSAoQW1iIHN1cG9ydCBSb29tKVxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFkZEl0ZW1BY3Rpb24oZm9ybURhdGE6IEZvcm1EYXRhKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICAgIGlmICghdXNlcikgdGhyb3cgbmV3IEVycm9yKCdVbmF1dGhvcml6ZWQnKTtcclxuXHJcbiAgICBjb25zdCBuYW1lID0gU3RyaW5nKGZvcm1EYXRhLmdldCgnbmFtZScpIHx8ICdQcm9kdWN0ZScpO1xyXG4gICAgbGV0IGVtb2ppID0gZm9ybURhdGEuZ2V0KCdlbW9qaScpPy50b1N0cmluZygpIHx8ICfwn5OmJztcclxuICAgIGNvbnN0IHJvb21JZCA9IGZvcm1EYXRhLmdldCgncm9vbUlkJyk/LnRvU3RyaW5nKCkgfHwgdW5kZWZpbmVkOyAvLyA8LS0tIExMRUdJTSBFTCBDT05URVhUXHJcblxyXG4gICAgLy8gRU5SSVFVSU1FTlQgRU1PSklcclxuICAgIGlmIChlbW9qaSA9PT0gJ/Cfk6YnIHx8IGVtb2ppID09PSAn8J+bkicpIHtcclxuICAgICAgY29uc3QgYmV0dGVyRW1vamkgPSBFbW9qaU1hdGNoZXJTZXJ2aWNlLmdldEVtb2ppKG5hbWUpO1xyXG4gICAgICBpZiAoYmV0dGVyRW1vamkgIT09ICfwn5OmJykgZW1vamkgPSBiZXR0ZXJFbW9qaTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBsb2NhdGlvbiA9IFN0cmluZyhmb3JtRGF0YS5nZXQoJ2xvY2F0aW9uJykgfHwgJ1BBTlRSWScpO1xyXG4gICAgbGV0IGV4cGlyeVN0cmluZyA9IGZvcm1EYXRhLmdldCgnZXhwaXJ5RGF0ZScpPy50b1N0cmluZygpO1xyXG5cclxuICAgIC8vIFNFR1VSRVRBVCBEQVRBXHJcbiAgICBpZiAoIWV4cGlyeVN0cmluZyB8fCBleHBpcnlTdHJpbmcgPT09ICdudWxsJyB8fCBleHBpcnlTdHJpbmcgPT09ICd1bmRlZmluZWQnIHx8IGV4cGlyeVN0cmluZyA9PT0gJycpIHtcclxuICAgICAgY29uc3Qgc2FmZURhdGVZTUQgPSBFeHBpcnlTYWZldHlTZXJ2aWNlLmFwcGx5U2FmZXR5UnVsZXMobmFtZSwgbG9jYXRpb24sIHVuZGVmaW5lZCk7XHJcbiAgICAgIGV4cGlyeVN0cmluZyA9IG5ldyBEYXRlKHNhZmVEYXRlWU1EKS50b0lTT1N0cmluZygpO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHJhd0RhdGEgPSB7XHJcbiAgICAgIHVzZXJJZDogdXNlci5pZCxcclxuICAgICAgbmFtZTogbmFtZSxcclxuICAgICAgcXVhbnRpdHk6IE51bWJlcihmb3JtRGF0YS5nZXQoJ3F1YW50aXR5JykpLFxyXG4gICAgICB1bml0OiBmb3JtRGF0YS5nZXQoJ3VuaXQnKSxcclxuICAgICAgbG9jYXRpb246IGxvY2F0aW9uLFxyXG4gICAgICBleHBpcnlEYXRlOiBleHBpcnlTdHJpbmcsXHJcbiAgICAgIGVtb2ppOiBlbW9qaSxcclxuICAgICAgcHJvZHVjdElkOiBmb3JtRGF0YS5nZXQoJ3Byb2R1Y3RJZCcpICYmIGZvcm1EYXRhLmdldCgncHJvZHVjdElkJykgIT09ICdudWxsJ1xyXG4gICAgICAgID8gU3RyaW5nKGZvcm1EYXRhLmdldCgncHJvZHVjdElkJykpXHJcbiAgICAgICAgOiBudWxsLFxyXG4gICAgICByb29tSWQ6IHJvb21JZCAvLyA8LS0tIFBBU1NFTSBFTCBST09NIElEIEFMIFZBTElEQVRPUlxyXG4gICAgfTtcclxuXHJcbiAgICAvLyBOZWNlc3NpdGVtIGVzdGVuZHJlIGwnc2NoZW1hIGJhc2UgcGVyIGFjY2VwdGFyIHJvb21JZCBzaSBubyBobyBmYVxyXG4gICAgY29uc3QgdmFsaWRhdGlvbiA9IEludmVudG9yeUl0ZW1TY2hlbWEuZXh0ZW5kKHsgcm9vbUlkOiB6LnN0cmluZygpLm9wdGlvbmFsKCkgfSkuc2FmZVBhcnNlKHJhd0RhdGEpO1xyXG5cclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSB7XHJcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZ2V0Wm9kRXJyb3IodmFsaWRhdGlvbi5lcnJvcikgfTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBmaW5hbERhdGEgPSB2YWxpZGF0aW9uLmRhdGE7XHJcbiAgICBjb25zdCBmaW5hbEV4cGlyeURhdGUgPSBmaW5hbERhdGEuZXhwaXJ5RGF0ZSA/IG5ldyBEYXRlKGZpbmFsRGF0YS5leHBpcnlEYXRlKSA6IHVuZGVmaW5lZDtcclxuXHJcbiAgICAvLyBVU0VNIEVMIFJFUE8gRElSRUNUQU1FTlQgKE8gVXNlQ2FzZSBhY3R1YWxpdHphdClcclxuICAgIC8vIFBlciBzaW1wbGlmaWNhciBpIGV2aXRhciB0b2NhciAxMCBhcnhpdXMgZGUgVXNlQ2FzZSwgYXF1w60gY3JpZGFyZW0gYWwgUmVwbyxcclxuICAgIC8vIGphIHF1ZSBBZGRJdGVtVXNlQ2FzZSBwb3RzZXIgbm8gZXNwZXJhIHJvb21JZC5cclxuICAgIC8vIEwnaWRlYWwgc2VyaWEgYWN0dWFsaXR6YXIgQWRkSXRlbVVzZUNhc2UsIHBlcsOyIGNvbSBxdWUgZWwgUmVwbyBqYSDDqXMgbGxlc3Q6XHJcbiAgICBjb25zdCByZXBvID0gY29udGFpbmVyLmdldEludmVudG9yeVJlcG8oc3VwYWJhc2UpO1xyXG5cclxuICAgIGNvbnN0IG5ld0l0ZW0gPSBJbnZlbnRvcnlJdGVtLmNyZWF0ZSh7XHJcbiAgICAgIGlkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxyXG4gICAgICB1c2VySWQ6IHVzZXIuaWQsXHJcbiAgICAgIHJvb21JZDogZmluYWxEYXRhLnJvb21JZCB8fCBudWxsLCAvLyA8LS0tIEFRVUkgRVMgR1VBUkRBIExBIE1BQUdJQVxyXG4gICAgICBuYW1lOiBTdHJpbmcoZmluYWxEYXRhLm5hbWUpLFxyXG4gICAgICBxdWFudGl0eTogTnVtYmVyKGZpbmFsRGF0YS5xdWFudGl0eSksXHJcbiAgICAgIHVuaXQ6IFN0cmluZyhmaW5hbERhdGEudW5pdCksXHJcbiAgICAgIGxvY2F0aW9uOiBmaW5hbERhdGEubG9jYXRpb24gYXMgU3RvcmFnZUxvY2F0aW9uLFxyXG4gICAgICBleHBpcnlEYXRlOiBmaW5hbEV4cGlyeURhdGUsXHJcbiAgICAgIGVtb2ppOiBTdHJpbmcoZmluYWxEYXRhLmVtb2ppKSxcclxuICAgICAgYWRkZWRBdDogbmV3IERhdGUoKSxcclxuICAgICAgcHJvZHVjdElkOiBmaW5hbERhdGEucHJvZHVjdElkXHJcbiAgICB9KTtcclxuXHJcbiAgICBhd2FpdCByZXBvLnNhdmUobmV3SXRlbSk7XHJcblxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvaW52ZW50b3J5Jyk7XHJcbiAgICBpZiAocm9vbUlkKSByZXZhbGlkYXRlUGF0aChgL3Jvb21zLyR7cm9vbUlkfWApOyAvLyBSZXZhbGlkYXIgc2FsYSBzaSBjYWxcclxuXHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcblxyXG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XHJcbiAgICBsb2dFcnJvcihcIvCfkqUgRXJyb3IgZmF0YWwgYSBhZGRJdGVtQWN0aW9uOlwiLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldEVycm9yTWVzc2FnZShlcnJvcikgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAyLiBDT05TVU1FIElURU0gKFNlbnNlIGNhbnZpcywgbCdJRCDDqXMgw7puaWMpXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY29uc3VtZUl0ZW1BY3Rpb24oaXRlbUlkOiBzdHJpbmcsIGFtb3VudDogbnVtYmVyKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHZhbGlkYXRpb24gPSBDb25zdW1lSXRlbVNjaGVtYS5zYWZlUGFyc2UoeyBpdGVtSWQsIGFtb3VudCB9KTtcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldFpvZEVycm9yKHZhbGlkYXRpb24uZXJyb3IpIH07XHJcblxyXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICAgIGNvbnN0IHVzZUNhc2UgPSBjb250YWluZXIuZ2V0Q29uc3VtZUl0ZW0oc3VwYWJhc2UpO1xyXG4gICAgLy8gRWwgVXNlQ2FzZSBub23DqXMgbmVjZXNzaXRhIGwnSUQuIEVsIFJlcG8gdHJvYmFyw6AgbCdpdGVtIHNpZ3VpIGRlIHNhbGEgbyB1c3VhcmkuXHJcbiAgICBhd2FpdCB1c2VDYXNlLmV4ZWN1dGUodmFsaWRhdGlvbi5kYXRhLml0ZW1JZCwgdmFsaWRhdGlvbi5kYXRhLmFtb3VudCk7XHJcblxyXG4gICAgLy8g4pyFIEFGRUdFSVggQUlYw5IgQUwgRklOQUwgREUgVE9UOlxyXG4gICAgLy8gQWl4w7Igb2JsaWdhIGEgTmV4dC5qcyBhIHJlZnJlc2NhciBsZXMgZGFkZXMgZGUgbGEgcnV0YSAvaW52ZW50b3J5IGF1dG9tw6B0aWNhbWVudFxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9pbnZlbnRvcnknKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxuICB9IGNhdGNoIChlcnJvcjogdW5rbm93bikge1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBnZXRFcnJvck1lc3NhZ2UoZXJyb3IpIH07XHJcbiAgfVxyXG59XHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gMy4gVVBEQVRFIElURU1cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbmludGVyZmFjZSBVcGRhdGVJdGVtRFRPIHsgaWQ6IHN0cmluZzsgbmFtZTogc3RyaW5nOyBxdWFudGl0eTogbnVtYmVyOyB1bml0OiBzdHJpbmc7IGVtb2ppOiBzdHJpbmc7IGV4cGlyeURhdGU/OiBEYXRlIHwgbnVsbDsgbG9jYXRpb24/OiBzdHJpbmc7IHJvb21JZD86IHN0cmluZzsgfVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUl0ZW1BY3Rpb24oaXRlbTogVXBkYXRlSXRlbURUTykge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgICBpZiAoIXVzZXIpIHRocm93IG5ldyBFcnJvcignVW5hdXRob3JpemVkJyk7XHJcblxyXG4gICAgaWYgKCFpdGVtLmlkIHx8ICFpdGVtLm5hbWUpIHRocm93IG5ldyBFcnJvcihcIkRhZGVzIGluY29tcGxldGVzXCIpO1xyXG5cclxuICAgIGNvbnN0IHJlcG8gPSBjb250YWluZXIuZ2V0SW52ZW50b3J5UmVwbyhzdXBhYmFzZSk7XHJcblxyXG4gICAgLy8gUmVjdXBlcmVtIGwnaXRlbSBvcmlnaW5hbCBwZXIgbm8gcGVyZHJlIGVsIHJvb21JZFxyXG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCByZXBvLmZpbmRCeUlkKGl0ZW0uaWQpO1xyXG4gICAgaWYgKCFleGlzdGluZykgdGhyb3cgbmV3IEVycm9yKFwiSXRlbSBub3QgZm91bmRcIik7XHJcblxyXG4gICAgLy8gQ3JlZW0gbGEgbm92YSB2ZXJzacOzIChJbW11dGFibGUpXHJcbiAgICBjb25zdCB1cGRhdGVkID0gSW52ZW50b3J5SXRlbS5jcmVhdGUoe1xyXG4gICAgICAuLi5leGlzdGluZy50b1ByaW1pdGl2ZXMoKSwgLy8gTWFudGVuaW0gZGFkZXMgdmVsbGVzIChjb20gYWRkZWRBdCwgcm9vbUlkLCB1c2VySWQpXHJcbiAgICAgIG5hbWU6IGl0ZW0ubmFtZSxcclxuICAgICAgZW1vamk6IGl0ZW0uZW1vamkgfHwgJ/Cfk6YnLFxyXG4gICAgICBxdWFudGl0eTogaXRlbS5xdWFudGl0eSxcclxuICAgICAgdW5pdDogaXRlbS51bml0LFxyXG4gICAgICBsb2NhdGlvbjogKGl0ZW0ubG9jYXRpb24gYXMgU3RvcmFnZUxvY2F0aW9uKSB8fCBTdG9yYWdlTG9jYXRpb24uUEFOVFJZLFxyXG4gICAgICBleHBpcnlEYXRlOiBpdGVtLmV4cGlyeURhdGUgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAvLyByb29tSWQgZXMgbWFudMOpIGRlIGwnb3JpZ2luYWwgYSB0b1ByaW1pdGl2ZXMoKSwgbyBlbCBwb3RzIGZvcsOnYXIgc2kgdm9sZ3Vlc3NpcyBtb3VyZSdsXHJcbiAgICB9KTtcclxuXHJcbiAgICBhd2FpdCByZXBvLnNhdmUodXBkYXRlZCk7XHJcblxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvaW52ZW50b3J5Jyk7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcbiAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZ2V0RXJyb3JNZXNzYWdlKGVycm9yKSB9O1xyXG4gIH1cclxufVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIDQuIERFTEVURSBJVEVNIChJZ3VhbClcclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVJdGVtQWN0aW9uKGl0ZW1JZDogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGlmICghaXRlbUlkKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiSUQgaW52w6BsaWRcIiB9O1xyXG5cclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICAvLyBBcXXDrSBwb2Ryw61lbSB1c2FyIGVsIFJlcG8gZGlyZWN0YW1lbnQgdGFtYsOpXHJcbiAgICBjb25zdCB1c2VDYXNlID0gY29udGFpbmVyLmdldERlbGV0ZUl0ZW0oc3VwYWJhc2UpO1xyXG4gICAgYXdhaXQgdXNlQ2FzZS5leGVjdXRlKGl0ZW1JZCk7XHJcblxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvaW52ZW50b3J5Jyk7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcbiAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZ2V0RXJyb3JNZXNzYWdlKGVycm9yKSB9O1xyXG4gIH1cclxufVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIDUuIEJVTEsgQUREIElURU1TXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYWRkQmF0Y2hJdGVtc0FjdGlvbihpdGVtczogei5pbmZlcjx0eXBlb2YgQmF0Y2hJbnZlbnRvcnlTY2hlbWE+KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICAgIGlmICghdXNlcikgdGhyb3cgbmV3IEVycm9yKCdVbmF1dGhvcml6ZWQnKTtcclxuXHJcbiAgICBjb25zdCB2YWxpZGF0aW9uID0gQmF0Y2hJbnZlbnRvcnlTY2hlbWEuc2FmZVBhcnNlKGl0ZW1zKTtcclxuICAgIGlmICghdmFsaWRhdGlvbi5zdWNjZXNzKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldFpvZEVycm9yKHZhbGlkYXRpb24uZXJyb3IpIH07XHJcblxyXG4gICAgY29uc3QgcmVwbyA9IGNvbnRhaW5lci5nZXRJbnZlbnRvcnlSZXBvKHN1cGFiYXNlKTtcclxuXHJcbiAgICBjb25zdCBlbnRpdGllcyA9IHZhbGlkYXRpb24uZGF0YS5tYXAoZCA9PiB7XHJcbiAgICAgIGxldCBmaW5hbERhdGUgPSBkLmV4cGlyeURhdGUgPyBuZXcgRGF0ZShkLmV4cGlyeURhdGUpIDogdW5kZWZpbmVkO1xyXG4gICAgICBpZiAoIWZpbmFsRGF0ZSkge1xyXG4gICAgICAgIGZpbmFsRGF0ZSA9IGNhbGN1bGF0ZUV4cGlyeURhdGUoZC5uYW1lLCBkLmVtb2ppKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIEludmVudG9yeUl0ZW0uY3JlYXRlKHtcclxuICAgICAgICBpZDogY3J5cHRvLnJhbmRvbVVVSUQoKSxcclxuICAgICAgICB1c2VySWQ6IHVzZXIuaWQsXHJcbiAgICAgICAgcm9vbUlkOiBkLnJvb21JZCB8fCBudWxsLCAvLyA8LS0tIEFRVUkgVEFNQsOJXHJcbiAgICAgICAgbmFtZTogZC5uYW1lLFxyXG4gICAgICAgIHF1YW50aXR5OiBkLnF1YW50aXR5LFxyXG4gICAgICAgIHVuaXQ6IGQudW5pdCxcclxuICAgICAgICBsb2NhdGlvbjogZC5sb2NhdGlvbiBhcyBTdG9yYWdlTG9jYXRpb24sXHJcbiAgICAgICAgZXhwaXJ5RGF0ZTogZmluYWxEYXRlLFxyXG4gICAgICAgIGVtb2ppOiBkLmVtb2ppIHx8ICfwn5OmJyxcclxuICAgICAgICBhZGRlZEF0OiBuZXcgRGF0ZSgpLFxyXG4gICAgICAgIHByb2R1Y3RJZDogZC5wcm9kdWN0SWRcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBhd2FpdCByZXBvLnNhdmVCYXRjaChlbnRpdGllcyk7XHJcblxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvaW52ZW50b3J5Jyk7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcblxyXG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XHJcbiAgICBsb2dFcnJvcignRXJyb3IgaW4gYWRkQmF0Y2hJdGVtc0FjdGlvbjonLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldEVycm9yTWVzc2FnZShlcnJvcikgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyA2LiBRVUlDSyBBRERcclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBxdWlja0FkZEludmVudG9yeUFjdGlvbihcclxuICBuYW1lOiBzdHJpbmcsXHJcbiAgcXVhbnRpdHk6IG51bWJlcixcclxuICB1bml0OiBzdHJpbmcsXHJcbiAgZW1vamk/OiBzdHJpbmcsXHJcbiAgcHJvZHVjdElkPzogc3RyaW5nLFxyXG4gIHJvb21JZD86IHN0cmluZyAvLyA8LS0tIE5PVSBQQVLDgE1FVFJFXHJcbikge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcbiAgICBpZiAoIXVzZXIpIHRocm93IG5ldyBFcnJvcihcIlVuYXV0aG9yaXplZFwiKTtcclxuXHJcbiAgICBjb25zdCBleHBpcnlZTUQgPSBFeHBpcnlTYWZldHlTZXJ2aWNlLmFwcGx5U2FmZXR5UnVsZXMobmFtZSwgJ1BBTlRSWScsIHVuZGVmaW5lZCk7XHJcbiAgICBjb25zdCBleHBpcnlEYXRlID0gbmV3IERhdGUoZXhwaXJ5WU1EKTtcclxuXHJcbiAgICBjb25zdCByZXBvID0gY29udGFpbmVyLmdldEludmVudG9yeVJlcG8oc3VwYWJhc2UpO1xyXG5cclxuICAgIGNvbnN0IG5ld0l0ZW0gPSBJbnZlbnRvcnlJdGVtLmNyZWF0ZSh7XHJcbiAgICAgIGlkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxyXG4gICAgICB1c2VySWQ6IHVzZXIuaWQsXHJcbiAgICAgIHJvb21JZDogcm9vbUlkIHx8IG51bGwsIC8vIDwtLS0gR1VBUkRFTVxyXG4gICAgICBuYW1lOiBuYW1lLFxyXG4gICAgICBxdWFudGl0eTogcXVhbnRpdHksXHJcbiAgICAgIHVuaXQ6IHVuaXQsXHJcbiAgICAgIGxvY2F0aW9uOiBTdG9yYWdlTG9jYXRpb24uUEFOVFJZLFxyXG4gICAgICBleHBpcnlEYXRlOiBleHBpcnlEYXRlLFxyXG4gICAgICBlbW9qaTogZW1vamkgfHwgJ/Cfk6YnLFxyXG4gICAgICBhZGRlZEF0OiBuZXcgRGF0ZSgpLFxyXG4gICAgICBwcm9kdWN0SWQ6IHByb2R1Y3RJZCB8fCBudWxsXHJcbiAgICB9KTtcclxuXHJcbiAgICBhd2FpdCByZXBvLnNhdmUobmV3SXRlbSk7XHJcblxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvaW52ZW50b3J5Jyk7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcblxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBsb2dFcnJvcihcIkVycm9yIHF1aWNrIGFkZGluZyB0byBpbnZlbnRvcnk6XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciBhZmVnaW50IGEgbCdpbnZlbnRhcmkuXCIgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyA3LiBTRUFSQ0ggKElndWFsLCBubyBkZXDDqG4gZGUgbGEgc2FsYSlcclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZWFyY2hQcm9kdWN0c0FjdGlvbihxdWVyeTogc3RyaW5nKTogUHJvbWlzZTx7IHN1Y2Nlc3M6IGJvb2xlYW4sIGRhdGE/OiBQcm9kdWN0UmVzdWx0W10sIGVycm9yPzogc3RyaW5nIH0+IHtcclxuICBpZiAoIXF1ZXJ5IHx8IHF1ZXJ5Lmxlbmd0aCA8IDMpIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGRhdGE6IFtdIH07XHJcblxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gICAgY29uc3Qgc2VhcmNoZXIgPSBjb250YWluZXIuZ2V0U2VhcmNoQW5kQ2FjaGVQcm9kdWN0cyhzdXBhYmFzZSk7XHJcbiAgICBjb25zdCBwcm9kdWN0cyA9IGF3YWl0IHNlYXJjaGVyLmV4ZWN1dGUocXVlcnkpO1xyXG5cclxuICAgIGNvbnN0IHNlcmlhbGl6ZWQgPSBwcm9kdWN0cy5tYXAocCA9PiAoe1xyXG4gICAgICBpZDogcC5wcm9wcy5pZCxcclxuICAgICAgbmFtZTogcC5wcm9wcy5uYW1lLFxyXG4gICAgICBwcmljZTogcC5wcm9wcy5wcmljZSxcclxuICAgICAgaW1hZ2U6IHAucHJvcHMuaW1hZ2UsXHJcbiAgICAgIHNvdXJjZTogcC5wcm9wcy5zb3VyY2UsXHJcbiAgICAgIGVtb2ppOiBwLnByb3BzLmVtb2ppLFxyXG4gICAgICB0YWdzOiBwLnByb3BzLnRhZ3NcclxuICAgIH0pKTtcclxuXHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCBkYXRhOiBzZXJpYWxpemVkIH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGxvZ0Vycm9yKFwiRXJyb3IgY2VyY2FudCBwcm9kdWN0ZXM6XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJObyBzJ2hhIHBvZ3V0IGNvbXBsZXRhciBsYSBjZXJjYS5cIiB9O1xyXG4gIH1cclxufVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIDguIERFTEVURSBCQVRDSCAoSWd1YWwpXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlQmF0Y2hJdGVtc0FjdGlvbihpZHM6IHN0cmluZ1tdKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICAgIGlmICghdXNlcikgdGhyb3cgbmV3IEVycm9yKCdVbmF1dGhvcml6ZWQnKTtcclxuXHJcbiAgICBjb25zdCByZXBvID0gY29udGFpbmVyLmdldEludmVudG9yeVJlcG8oc3VwYWJhc2UpO1xyXG4gICAgYXdhaXQgcmVwby5iYXRjaERlbGV0ZShpZHMpO1xyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvZGFzaGJvYXJkL2ludmVudG9yeScpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGdldEVycm9yTWVzc2FnZShlcnJvcikgfTtcclxuICB9XHJcbn1cclxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJvU0FzU3NCLG9NQUFBIn0=
}),
"[project]/features/recipes/components/MissingIngredientDialog.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MissingIngredientDialog",
    ()=>MissingIngredientDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$633fec__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:633fec [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$419f81__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:419f81 [app-client] (ecmascript) <text/javascript>"); // Aquesta és la que farem servir
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/sonner@2.0.7_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function MissingIngredientDialog({ isOpen, ingredient, onClose, onSuccess }) {
    _s();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    if (!isOpen || !ingredient) return null;
    // Lògica per mostrar imatge o emoji
    const imageUrl = ingredient.image || ingredient.linkedProductImage;
    const hasImage = !!imageUrl;
    const handleAddToList = async ()=>{
        setLoading('list');
        // ✅ Passem totes les dades rellevants
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$633fec__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["addToShoppingListAction"])(ingredient.name, ingredient.quantity, ingredient.unit, ingredient.emoji, ingredient.linkedProductId, ingredient.linkedProductImage, ingredient.estimatedCost // ✅ Preu
        );
        if (result.success) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success(`📝 Afegit a la llista: ${ingredient.name}`);
            onClose();
        } else {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Error afegint a la llista");
        }
        setLoading(null);
    };
    const handleAddToInventory = async ()=>{
        setLoading('inventory');
        // ✅ CRIDEM A L'ACCIÓ RÀPIDA AMB DADES RIQUES
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$419f81__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["quickAddInventoryAction"])(ingredient.name, ingredient.quantity, ingredient.unit, ingredient.emoji, ingredient.linkedProductId // ✅ Passem l'ID del producte si existeix
        );
        if (result.success) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success(`📦 Afegit al rebost: ${ingredient.name}`);
            onClose();
            onSuccess();
        } else {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(result.error || "Error afegint a l'inventari");
        }
        setLoading(null);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
        children: isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed inset-0 z-[100] flex items-center justify-center p-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    exit: {
                        opacity: 0
                    },
                    onClick: onClose,
                    className: "absolute inset-0 bg-slate-950/80 backdrop-blur-sm"
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                    lineNumber: 87,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        scale: 0.95,
                        opacity: 0,
                        y: 10
                    },
                    animate: {
                        scale: 1,
                        opacity: 1,
                        y: 0
                    },
                    exit: {
                        scale: 0.95,
                        opacity: 0,
                        y: 10
                    },
                    className: "relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-gradient-to-r from-purple-900/40 to-slate-900 p-6 text-center border-b border-slate-800",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mb-3 flex justify-center",
                                    children: hasImage ? /* eslint-disable-next-line @next/next/no-img-element */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: imageUrl,
                                        alt: ingredient.name,
                                        className: "w-16 h-16 object-contain bg-white rounded-xl p-1 shadow-lg"
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                        lineNumber: 104,
                                        columnNumber: 19
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-4xl",
                                        children: ingredient.emoji || '⚠️'
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                        lineNumber: 106,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                    lineNumber: 101,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-xl font-bold text-white",
                                    children: "Et falta ingredient!"
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                    lineNumber: 109,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-slate-400 text-sm mt-1",
                                    children: ingredient.name
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                    lineNumber: 110,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                            lineNumber: 100,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-6 space-y-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs uppercase tracking-wider text-slate-500 font-bold mb-4",
                                    children: "Què vols fer?"
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                    lineNumber: 115,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleAddToList,
                                    disabled: loading !== null,
                                    className: "w-full flex items-center justify-between p-4 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-emerald-500/50 transition-all group",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-2xl bg-slate-900 p-2 rounded-lg group-hover:scale-110 transition-transform",
                                                    children: "📝"
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                                    lineNumber: 123,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-left",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "font-bold text-slate-200",
                                                            children: "Afegir a la Llista"
                                                        }, void 0, false, {
                                                            fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                                            lineNumber: 125,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-xs text-slate-400",
                                                            children: "Per comprar-ho més tard"
                                                        }, void 0, false, {
                                                            fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                                            lineNumber: 126,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                                    lineNumber: 124,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                            lineNumber: 122,
                                            columnNumber: 17
                                        }, this),
                                        loading === 'list' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "animate-spin",
                                            children: "⏳"
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                            lineNumber: 129,
                                            columnNumber: 40
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                    lineNumber: 117,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleAddToInventory,
                                    disabled: loading !== null,
                                    className: "w-full flex items-center justify-between p-4 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-purple-500/50 transition-all group",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-2xl bg-slate-900 p-2 rounded-lg group-hover:scale-110 transition-transform",
                                                    children: "📦"
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                                    lineNumber: 138,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-left",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "font-bold text-slate-200",
                                                            children: "Ja en tinc (Afegir stock)"
                                                        }, void 0, false, {
                                                            fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                                            lineNumber: 140,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-xs text-slate-400",
                                                            children: "L'afegeix al rebost immediatament"
                                                        }, void 0, false, {
                                                            fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                                            lineNumber: 141,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                                    lineNumber: 139,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                            lineNumber: 137,
                                            columnNumber: 17
                                        }, this),
                                        loading === 'inventory' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "animate-spin",
                                            children: "⏳"
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                            lineNumber: 144,
                                            columnNumber: 45
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                    lineNumber: 132,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                            lineNumber: 114,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-4 bg-slate-950 border-t border-slate-800 text-center",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onClose,
                                className: "text-sm text-slate-500 hover:text-white transition-colors",
                                children: "Cancel·lar operació"
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                                lineNumber: 149,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                            lineNumber: 148,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
                    lineNumber: 93,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
            lineNumber: 86,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/features/recipes/components/MissingIngredientDialog.tsx",
        lineNumber: 84,
        columnNumber: 5
    }, this);
}
_s(MissingIngredientDialog, "GB86ilDv2e+FWPZKEI6FKzMMZ1c=");
_c = MissingIngredientDialog;
var _c;
__turbopack_context__.k.register(_c, "MissingIngredientDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/parts/IngredientsPanel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IngredientsPanel",
    ()=>IngredientsPanel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$a546e9__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:a546e9 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/sonner@2.0.7_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2f$emojiUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils/emojiUtils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$MissingIngredientDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/MissingIngredientDialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
function IngredientsPanel({ ingredients, inventory, userId }) {
    _s();
    const [localInventory, setLocalInventory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(inventory);
    const [loadingItems, setLoadingItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    const [checkedItems, setCheckedItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    const [missingIngredient, setMissingIngredient] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isExpanded, setIsExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "IngredientsPanel.useEffect": ()=>{
            setLocalInventory(inventory);
        }
    }["IngredientsPanel.useEffect"], [
        inventory
    ]);
    const handleToggleItem = async (index, ing)=>{
        if (loadingItems.has(index)) return;
        const isChecking = !checkedItems.has(index);
        const action = isChecking ? 'CONSUME' : 'RESTORE';
        setLoadingItems((prev)=>{
            const n = new Set(prev);
            n.add(index);
            return n;
        });
        const currentEmoji = ing.emoji || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2f$emojiUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIngredientEmoji"])(ing.name);
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$a546e9__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["toggleIngredientStockAction"])(userId, ing.name, ing.quantity, action, ing.unit);
        setLoadingItems((prev)=>{
            const n = new Set(prev);
            n.delete(index);
            return n;
        });
        if (result.success && result.newQuantity !== undefined) {
            setCheckedItems((prev)=>{
                const next = new Set(prev);
                if (isChecking) next.add(index);
                else next.delete(index);
                return next;
            });
            setLocalInventory((prev)=>prev.map((item)=>{
                    if (item.name.toLowerCase().includes(ing.name.toLowerCase()) || ing.name.toLowerCase().includes(item.name.toLowerCase())) {
                        return {
                            ...item,
                            quantity: result.newQuantity
                        };
                    }
                    return item;
                }));
            if (isChecking) __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success(`Restat: ${ing.quantity}${ing.unit}`);
            else __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].info(`Restaurat: ${ing.name}`);
        } else {
            console.warn("⚠️ Stock Error:", result.error);
            const isMissingError = result.error?.includes("No tens") || result.error?.includes("no existeix");
            if (isMissingError && isChecking) {
                // ✅ CORRECCIÓ: Eliminem 'as any' perquè la interfície ja ho suporta
                const modalIng = {
                    name: ing.name,
                    quantity: ing.quantity,
                    unit: ing.unit,
                    emoji: currentEmoji,
                    // Accés directe i tipat
                    linkedProductId: ing.linkedProductId || '',
                    linkedProductImage: ing.linkedProductImage || ing.image,
                    estimatedCost: ing.estimatedCost
                };
                console.log("🛠️ [CLIENT] Obrint modal amb:", modalIng);
                setMissingIngredient(modalIng);
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(result.error || "Error desconegut");
            }
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-slate-900/50 border-r border-slate-800 flex flex-col h-full rounded-bl-3xl overflow-hidden",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$MissingIngredientDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MissingIngredientDialog"], {
                isOpen: !!missingIngredient,
                ingredient: missingIngredient,
                onClose: ()=>setMissingIngredient(null),
                onSuccess: ()=>console.log("Ingredient gestionat")
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                lineNumber: 106,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>setIsExpanded(!isExpanded),
                className: "p-4 border-b border-slate-800/50 bg-slate-900/80 hover:bg-slate-800 flex justify-between items-center w-full transition-colors",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "font-black text-white flex items-center gap-2 text-sm uppercase tracking-wider",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "🛒"
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                        lineNumber: 120,
                                        columnNumber: 25
                                    }, this),
                                    " Cistella"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                lineNumber: 119,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[10px] font-bold text-slate-400 bg-slate-950 px-2 py-0.5 rounded-full border border-slate-800",
                                children: [
                                    checkedItems.size,
                                    "/",
                                    ingredients.length
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                lineNumber: 122,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                        lineNumber: 118,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                        className: `text-slate-400 transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`,
                        size: 20
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                        lineNumber: 127,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                lineNumber: 114,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                initial: false,
                children: isExpanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        height: 0,
                        opacity: 0
                    },
                    animate: {
                        height: 'auto',
                        opacity: 1
                    },
                    exit: {
                        height: 0,
                        opacity: 0
                    },
                    transition: {
                        duration: 0.3,
                        ease: 'easeInOut'
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 overflow-y-auto p-2 space-y-1 custom-scrollbar",
                        children: ingredients.map((ing, i)=>{
                            const stockItem = localInventory.find((item)=>item.name.toLowerCase().includes(ing.name.toLowerCase()) || ing.name.toLowerCase().includes(item.name.toLowerCase()));
                            const isChecked = checkedItems.has(i);
                            const isLoading = loadingItems.has(i);
                            const emoji = ing.emoji || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2f$emojiUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIngredientEmoji"])(ing.name);
                            const imageUrl = ing.image || ing.linkedProductImage;
                            const hasImage = !!imageUrl;
                            const price = ing.estimatedCost;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                onClick: ()=>handleToggleItem(i, ing),
                                className: `
                                        group relative flex items-center justify-between p-2 rounded-xl cursor-pointer transition-all duration-200 border select-none
                                        ${isChecked ? 'bg-slate-900/50 border-slate-800 opacity-50' : 'bg-slate-800 border-slate-700 hover:bg-slate-700 hover:border-emerald-500/50'}
                                    `,
                                children: [
                                    isLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute inset-0 bg-slate-900/60 z-20 flex items-center justify-center rounded-xl backdrop-blur-[1px]",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "animate-spin text-white text-xs",
                                            children: "⏳"
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                            lineNumber: 171,
                                            columnNumber: 49
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                        lineNumber: 170,
                                        columnNumber: 45
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-3 overflow-hidden",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `
                                        w-8 h-8 rounded-lg flex items-center justify-center overflow-hidden shrink-0 ring-1 ring-black/10 transition-colors
                                        ${isChecked ? 'bg-emerald-900/20' : 'bg-white'}
                                    `,
                                                children: isChecked ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-emerald-500 font-bold",
                                                    children: "✓"
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                                    lineNumber: 182,
                                                    columnNumber: 53
                                                }, this) : hasImage ? /* eslint-disable-next-line @next/next/no-img-element */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                    src: imageUrl,
                                                    alt: ing.name,
                                                    className: "w-full h-full object-contain p-0.5"
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                                    lineNumber: 185,
                                                    columnNumber: 53
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-lg leading-none",
                                                    children: emoji
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                                    lineNumber: 187,
                                                    columnNumber: 53
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                                lineNumber: 177,
                                                columnNumber: 45
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-col min-w-0",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `text-sm truncate font-bold ${isChecked ? 'line-through text-slate-600' : 'text-slate-200'}`,
                                                        children: ing.name
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                                        lineNumber: 192,
                                                        columnNumber: 49
                                                    }, this),
                                                    price && !isChecked && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-[9px] font-mono text-emerald-400 leading-none",
                                                        children: [
                                                            price.toFixed(2),
                                                            "€"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                                        lineNumber: 196,
                                                        columnNumber: 53
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                                lineNumber: 191,
                                                columnNumber: 45
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                        lineNumber: 176,
                                        columnNumber: 41
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 pl-2 shrink-0",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs font-bold text-purple-300 bg-purple-500/10 px-1.5 py-0.5 rounded-md",
                                                children: [
                                                    ing.quantity,
                                                    ing.unit
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                                lineNumber: 205,
                                                columnNumber: 45
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-slate-600 text-[10px] font-light",
                                                children: "/"
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                                lineNumber: 208,
                                                columnNumber: 45
                                            }, this),
                                            stockItem ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `text-xs font-bold px-1.5 py-0.5 rounded-md ${stockItem.quantity > 0 ? 'text-emerald-400 bg-emerald-500/10' : 'text-red-400 bg-red-500/10'}`,
                                                children: [
                                                    stockItem.quantity,
                                                    stockItem.unit
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                                lineNumber: 210,
                                                columnNumber: 49
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[10px] font-bold text-red-400 bg-red-500/10 px-1.5 py-0.5 rounded-md",
                                                children: "0"
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                                lineNumber: 214,
                                                columnNumber: 49
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                        lineNumber: 204,
                                        columnNumber: 41
                                    }, this)
                                ]
                            }, i, true, {
                                fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                                lineNumber: 157,
                                columnNumber: 37
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                        lineNumber: 142,
                        columnNumber: 25
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                    lineNumber: 136,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
                lineNumber: 134,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/parts/IngredientsPanel.tsx",
        lineNumber: 105,
        columnNumber: 9
    }, this);
}
_s(IngredientsPanel, "9ChtMkyObasgf6mUrqZzBC0WRvg=");
_c = IngredientsPanel;
var _c;
__turbopack_context__.k.register(_c, "IngredientsPanel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/core/domain/entities/StorageLocation.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/domain/inventory/StorageLocation.ts
__turbopack_context__.s([
    "StorageLocation",
    ()=>StorageLocation
]);
var StorageLocation = /*#__PURE__*/ function(StorageLocation) {
    StorageLocation["FRIDGE"] = "FRIDGE";
    StorageLocation["FREEZER"] = "FREEZER";
    StorageLocation["PANTRY"] = "PANTRY"; // Revost
    return StorageLocation;
}({});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/types.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/lib/food-presets/types.ts
__turbopack_context__.s([
    "DAYS",
    ()=>DAYS
]);
const DAYS = {
    FRESH_MEAT: 4,
    FRESH_FISH: 3,
    FRUIT: 14,
    BERRIES: 7,
    CITRUS: 30,
    VEGGIE: 12,
    ROOTS: 45,
    LEAFY: 7,
    DAIRY: 60,
    CHEESE: 30,
    PANTRY: 180,
    LONG_PANTRY: 665,
    FROZEN: 365,
    BAKERY: 3
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/fruit.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FRUIT_PRESETS",
    ()=>FRUIT_PRESETS
]);
// src/lib/food-presets/fruit.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/domain/entities/StorageLocation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/types.ts [app-client] (ecmascript)");
;
;
const FRUIT_PRESETS = [
    {
        id: 'f1',
        emoji: '🍎',
        name: 'Poma vermella',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRUIT
    },
    {
        id: 'f2',
        emoji: '🍏',
        name: 'Poma verda',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRUIT
    },
    {
        id: 'f3',
        emoji: '🍎',
        name: 'Poma groga',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRUIT
    },
    {
        id: 'f4',
        emoji: '🍌',
        name: 'Plàtan',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'f5',
        emoji: '🍌',
        name: 'Plàtan mascle',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'f6',
        emoji: '🍐',
        name: 'Pera conference',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRUIT
    },
    {
        id: 'f7',
        emoji: '🍐',
        name: 'Pera blanquilla',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRUIT
    },
    {
        id: 'f8',
        emoji: '🍊',
        name: 'Taronja',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].CITRUS
    },
    {
        id: 'f9',
        emoji: '🍊',
        name: 'Mandarina',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].CITRUS
    },
    {
        id: 'f10',
        emoji: '🍋',
        name: 'Llimona',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].CITRUS
    },
    {
        id: 'f11',
        emoji: '🍋',
        name: 'Llima',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].CITRUS
    },
    {
        id: 'f12',
        emoji: '🍊',
        name: 'Aranja',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].CITRUS
    },
    {
        id: 'f13',
        emoji: '🍓',
        name: 'Maduixa',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].BERRIES
    },
    {
        id: 'f14',
        emoji: '🫐',
        name: 'Nabius',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].BERRIES
    },
    {
        id: 'f15',
        emoji: '🍒',
        name: 'Cireres',
        category: '🍎 Fruita',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.2,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].BERRIES
    },
    {
        id: 'f16',
        emoji: '🍇',
        name: 'Raïm blanc',
        category: '🍎 Fruita',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.1,
        expirationDays: 10
    },
    {
        id: 'f17',
        emoji: '🍇',
        name: 'Raïm negre',
        category: '🍎 Fruita',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.1,
        expirationDays: 10
    },
    {
        id: 'f18',
        emoji: '🍑',
        name: 'Préssec',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'f19',
        emoji: '🍑',
        name: 'Nectarina',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'f20',
        emoji: '🍑',
        name: 'Paraguaià',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'f21',
        emoji: '🍒',
        name: 'Pruna',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'f22',
        emoji: '🍒',
        name: 'Albercoc',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'f23',
        emoji: '🥝',
        name: 'Kiwi verd',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    },
    {
        id: 'f24',
        emoji: '🥝',
        name: 'Kiwi groc',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    },
    {
        id: 'f25',
        emoji: '🍍',
        name: 'Pinya',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'f26',
        emoji: '🥭',
        name: 'Mango',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'f27',
        emoji: '🍈',
        name: 'Meló',
        category: '🍎 Fruita',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: 10
    },
    {
        id: 'f28',
        emoji: '🍉',
        name: 'Síndria',
        category: '🍎 Fruita',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: 10
    },
    {
        id: 'f29',
        emoji: '🥥',
        name: 'Coco',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 20
    },
    {
        id: 'f30',
        emoji: '🍎',
        name: 'Codony',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 30
    },
    {
        id: 'f31',
        emoji: '🍎',
        name: 'Figa',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    {
        id: 'f32',
        emoji: '🍌',
        name: 'Dàtil fresc',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 30
    },
    // Fruits tropicals
    {
        id: 'f33',
        emoji: '🍍',
        name: 'Papaia',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'f34',
        emoji: '🥭',
        name: 'Guaiaba',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'f35',
        emoji: '🍌',
        name: 'Plàtan vermell',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 7
    },
    // Fruits del bosc (més)
    {
        id: 'f36',
        emoji: '🫐',
        name: 'Gerds',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].BERRIES
    },
    {
        id: 'f37',
        emoji: '🫐',
        name: 'Mores',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].BERRIES
    },
    {
        id: 'f38',
        emoji: '🍓',
        name: 'Fruita del bosc barrejada',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 250,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    // Fruits secs / deshidratats
    {
        id: 'f39',
        emoji: '🍇',
        name: 'Panses',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'f40',
        emoji: '🍑',
        name: 'Albercocs secs',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'f41',
        emoji: '🍎',
        name: 'Poma deshidratada',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 50,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    // Altres comuns
    {
        id: 'f42',
        emoji: '🍐',
        name: 'Caqui',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'f43',
        emoji: '🍊',
        name: 'Clementina',
        category: '🍎 Fruita',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].CITRUS
    },
    {
        id: 'f44',
        emoji: '🍋',
        name: 'Kumquat',
        category: '🍎 Fruita',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 250,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].CITRUS
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/vegetables.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VEGETABLE_PRESETS",
    ()=>VEGETABLE_PRESETS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/domain/entities/StorageLocation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/types.ts [app-client] (ecmascript)");
;
;
const VEGETABLE_PRESETS = [
    // 🥕 Arrels i tubercles
    {
        id: 'v1',
        emoji: '🥕',
        name: 'Pastanaga',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].ROOTS
    },
    {
        id: 'v2',
        emoji: '🥔',
        name: 'Patata',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].ROOTS
    },
    {
        id: 'v31',
        emoji: '🍠',
        name: 'Moniato',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].ROOTS
    },
    {
        id: 'v33',
        emoji: '🥔',
        name: 'Yuca',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].ROOTS
    },
    {
        id: 'v24',
        emoji: '🫚',
        name: 'Nap',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    },
    {
        id: 'v25',
        emoji: '🥕',
        name: 'Remolatxa',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: 14
    },
    // 🧅 Bulbs i aromàtiques
    {
        id: 'v3',
        emoji: '🧅',
        name: 'Ceba blanca',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].ROOTS
    },
    {
        id: 'v4',
        emoji: '🧅',
        name: 'Ceba morada',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].ROOTS
    },
    {
        id: 'v35',
        emoji: '🧅',
        name: 'Ceba tendra',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'v5',
        emoji: '🧄',
        name: 'All',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].ROOTS
    },
    {
        id: 'v36',
        emoji: '🧄',
        name: 'All tendre',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'v37',
        emoji: '🧅',
        name: 'Escalunya',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].ROOTS
    },
    {
        id: 'v23',
        emoji: '🫚',
        name: 'Gingebre',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 50,
        expirationDays: 30
    },
    {
        id: 'v34',
        emoji: '🫚',
        name: 'Cúrcuma fresca',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 50,
        expirationDays: 30
    },
    // 🍅 Fruita-verdura / mediterrànies
    {
        id: 'v6',
        emoji: '🍅',
        name: 'Tomàquet madur',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: 7
    },
    {
        id: 'v7',
        emoji: '🍅',
        name: 'Tomàquet cherry',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 250,
        expirationDays: 10
    },
    {
        id: 'v43',
        emoji: '🍅',
        name: 'Tomàquet pera',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: 7
    },
    {
        id: 'v44',
        emoji: '🍅',
        name: 'Tomàquet cor de bou',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: 6
    },
    {
        id: 'v15',
        emoji: '🍆',
        name: 'Albergínia',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'v19',
        emoji: '🥒',
        name: 'Carbassó',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'v9',
        emoji: '🥒',
        name: 'Cogombre',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'v45',
        emoji: '🌶️',
        name: 'Bitxo',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 50,
        expirationDays: 14
    },
    {
        id: 'v16',
        emoji: '🌶️',
        name: 'Pebrot verd',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    },
    {
        id: 'v17',
        emoji: '🌶️',
        name: 'Pebrot vermell',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    },
    {
        id: 'v18',
        emoji: '🌶️',
        name: 'Pebrot groc',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    },
    // 🥬 Fulles
    {
        id: 'v10',
        emoji: '🥬',
        name: 'Enciam iceberg',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    },
    {
        id: 'v11',
        emoji: '🥬',
        name: 'Enciam romà',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LEAFY
    },
    {
        id: 'v12',
        emoji: '🥬',
        name: 'Enciam fulla de roure',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LEAFY
    },
    {
        id: 'v13',
        emoji: '🥬',
        name: 'Espinacs frescos',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 5
    },
    {
        id: 'v14',
        emoji: '🥬',
        name: 'Rúcula',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 50,
        expirationDays: 5
    },
    {
        id: 'v38',
        emoji: '🥬',
        name: 'Bledes',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 250,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LEAFY
    },
    {
        id: 'v39',
        emoji: '🥬',
        name: 'Canonges',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 5
    },
    {
        id: 'v40',
        emoji: '🥬',
        name: 'Endívia',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    // 🥦 Crucíferes
    {
        id: 'v8',
        emoji: '🥦',
        name: 'Bròquil',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'v20',
        emoji: '🥦',
        name: 'Coliflor',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'v21',
        emoji: '🥬',
        name: 'Col verda',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    },
    {
        id: 'v22',
        emoji: '🥬',
        name: 'Col llombarda',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    },
    {
        id: 'v41',
        emoji: '🥦',
        name: 'Cols de Brussel·les',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 500,
        expirationDays: 10
    },
    {
        id: 'v42',
        emoji: '🥦',
        name: 'Romanesco',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    // 🍄 Fongs
    {
        id: 'v29',
        emoji: '🍄',
        name: 'Xampinyons',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 250,
        expirationDays: 5
    },
    {
        id: 'v30',
        emoji: '🍄',
        name: 'Bolets variats',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 250,
        expirationDays: 5
    },
    // 🫘 Llegums i vegetals proteics
    {
        id: 'v28',
        emoji: '🫘',
        name: 'Mongetes verdes',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: 7
    },
    {
        id: 'v26',
        emoji: '🌽',
        name: 'Blat de moro',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    {
        id: 'v49',
        emoji: '🫘',
        name: 'Faves fresques',
        category: '🥦 Verdura',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: 7
    },
    {
        id: 'v27',
        emoji: '🫛',
        name: 'Pèsols',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 250,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'v50',
        emoji: '🫛',
        name: 'Edamame',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 400,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    // 🌍 Asiàtics / internacionals
    {
        id: 'v46',
        emoji: '🥬',
        name: 'Pak choi',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'v47',
        emoji: '🥬',
        name: 'Col xinesa',
        category: '🥦 Verdura',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'v48',
        emoji: '🎋',
        name: 'Brot de bambú',
        category: '🥦 Verdura',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 400,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/protein.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PROTEIN_PRESETS",
    ()=>PROTEIN_PRESETS
]);
// src/lib/food-presets/protein.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/domain/entities/StorageLocation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/types.ts [app-client] (ecmascript)");
;
;
const PROTEIN_PRESETS = [
    {
        id: 'p1',
        emoji: '🍗',
        name: 'Pollastre sencer',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p2',
        emoji: '🍗',
        name: 'Pit de pollastre',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p3',
        emoji: '🍗',
        name: 'Cuixes de pollastre',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p11',
        emoji: '🍗',
        name: 'Aletes de pollastre',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p12',
        emoji: '🥩',
        name: 'Vedella fresca',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_MEAT
    },
    {
        id: 'p13',
        emoji: '🥩',
        name: 'Vedella picada',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p14',
        emoji: '🥩',
        name: 'Entrecot de vedella',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_MEAT
    },
    {
        id: 'p15',
        emoji: '🥩',
        name: 'Filet de vedella',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.3,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_MEAT
    },
    {
        id: 'p16',
        emoji: '🐖',
        name: 'Llom de porc',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_MEAT
    },
    {
        id: 'p17',
        emoji: '🐖',
        name: 'Costelles de porc',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p18',
        emoji: '🐖',
        name: 'Carn picada de porc',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p19',
        emoji: '🥓',
        name: 'Bacon',
        category: '🥩 Proteïna',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 200,
        expirationDays: 30
    },
    {
        id: 'p20',
        emoji: '🐑',
        name: 'Xai (cuixa)',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p21',
        emoji: '🐑',
        name: 'Costelles de xai',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p22',
        emoji: '🐟',
        name: 'Lluç',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.3,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_FISH
    },
    {
        id: 'p23',
        emoji: '🐟',
        name: 'Bacallà fresc',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.3,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_FISH
    },
    {
        id: 'p25',
        emoji: '🐟',
        name: 'Orada',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.3,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_FISH
    },
    {
        id: 'p26',
        emoji: '🐟',
        name: 'Llobarro',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.3,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_FISH
    },
    {
        id: 'p29',
        emoji: '🐟',
        name: 'Salmó fresc',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.2,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_FISH
    },
    {
        id: 'p30',
        emoji: '🐟',
        name: 'Salmó congelat',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p32',
        emoji: '🦐',
        name: 'Gambes',
        category: '🥩 Proteïna',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 250,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p38',
        emoji: '🥚',
        name: 'Ous',
        category: '🥩 Proteïna',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 6,
        expirationDays: 21
    },
    {
        id: 'p41',
        emoji: '🌱',
        name: 'Tofu',
        category: '🥩 Proteïna',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    // 🍗 Aus extra
    {
        id: 'p42',
        emoji: '🦃',
        name: 'Gall dindi (pit)',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p43',
        emoji: '🦃',
        name: 'Gall dindi picat',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p44',
        emoji: '🍗',
        name: 'Conill',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    // 🥩 Vedella / boví extra
    {
        id: 'p45',
        emoji: '🥩',
        name: 'Hamburgueses de vedella',
        category: '🥩 Proteïna',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 2,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p46',
        emoji: '🥩',
        name: 'Estofat de vedella',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_MEAT
    },
    {
        id: 'p47',
        emoji: '🥩',
        name: 'Costella de vedella',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    // 🐖 Porc extra
    {
        id: 'p48',
        emoji: '🐖',
        name: 'Botifarra',
        category: '🥩 Proteïna',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 2,
        expirationDays: 10
    },
    {
        id: 'p49',
        emoji: '🐖',
        name: 'Salsitxes',
        category: '🥩 Proteïna',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 4,
        expirationDays: 10
    },
    {
        id: 'p50',
        emoji: '🐖',
        name: 'Pernil dolç',
        category: '🥩 Proteïna',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 150,
        expirationDays: 15
    },
    {
        id: 'p51',
        emoji: '🥓',
        name: 'Xoriço',
        category: '🥩 Proteïna',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 150,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'p52',
        emoji: '🥓',
        name: 'Fuet',
        category: '🥩 Proteïna',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 150,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    // 🐟 Peix extra
    {
        id: 'p53',
        emoji: '🐟',
        name: 'Tonyina fresca',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.3,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_FISH
    },
    {
        id: 'p54',
        emoji: '🐟',
        name: 'Tonyina en conserva',
        category: '🥩 Proteïna',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 200,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'p55',
        emoji: '🐟',
        name: 'Sardines',
        category: '🥩 Proteïna',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 300,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_FISH
    },
    {
        id: 'p56',
        emoji: '🐟',
        name: 'Seitons',
        category: '🥩 Proteïna',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 300,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_FISH
    },
    {
        id: 'p57',
        emoji: '🐟',
        name: 'Verat',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.3,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FRESH_FISH
    },
    // 🦐 Marisc extra
    {
        id: 'p58',
        emoji: '🦑',
        name: 'Calamars',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p59',
        emoji: '🦑',
        name: 'Pop',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 'p60',
        emoji: '🦐',
        name: 'Musclos',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 2
    },
    {
        id: 'p61',
        emoji: '🦐',
        name: 'Escamarlans',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    // 🥚 Ous i derivats
    {
        id: 'p62',
        emoji: '🥚',
        name: 'Clares d’ou',
        category: '🥩 Proteïna',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.5,
        expirationDays: 5
    },
    // 🌱 Proteïna vegetal
    {
        id: 'p63',
        emoji: '🌱',
        name: 'Tempeh',
        category: '🥩 Proteïna',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'p64',
        emoji: '🌱',
        name: 'Seitan',
        category: '🥩 Proteïna',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'p65',
        emoji: '🌱',
        name: 'Proteïna vegetal texturitzada',
        category: '🥩 Proteïna',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 250,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    // 🏋️‍♂️ Fitness / complements
    {
        id: 'p66',
        emoji: '🥤',
        name: 'Batuts de proteïna',
        category: '🥩 Proteïna',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: 180
    },
    {
        id: 'p67',
        emoji: '💊',
        name: 'Proteïna en pols',
        category: '🥩 Proteïna',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: 365
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/dairy.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DAIRY_PRESETS",
    ()=>DAIRY_PRESETS
]);
// src/lib/food-presets/dairy.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/domain/entities/StorageLocation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/types.ts [app-client] (ecmascript)");
;
;
const DAIRY_PRESETS = [
    {
        id: 'l1',
        emoji: '🥛',
        name: 'Llet sencera',
        category: '🥛 Lactic',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    {
        id: 'l2',
        emoji: '🥛',
        name: 'Llet semi',
        category: '🥛 Lactic',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    {
        id: 'l3',
        emoji: '🥛',
        name: 'Llet desnatada',
        category: '🥛 Lactic',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    {
        id: 'l4',
        emoji: '🥛',
        name: 'Llet sense lactosa',
        category: '🥛 Lactic',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    {
        id: 'l5',
        emoji: '🧀',
        name: 'Formatge curat',
        category: '🥛 Lactic',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 60
    },
    {
        id: 'l6',
        emoji: '🧀',
        name: 'Formatge semicurat',
        category: '🥛 Lactic',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 45
    },
    {
        id: 'l7',
        emoji: '🧀',
        name: 'Formatge tendre',
        category: '🥛 Lactic',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 10
    },
    {
        id: 'l8',
        emoji: '🧀',
        name: 'Formatge ratllat',
        category: '🥛 Lactic',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 14
    },
    {
        id: 'l9',
        emoji: '🧀',
        name: 'Mozzarella',
        category: '🥛 Lactic',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 10
    },
    {
        id: 'l10',
        emoji: '🧀',
        name: 'Formatge parmesà',
        category: '🥛 Lactic',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 90
    },
    {
        id: 'l11',
        emoji: '🧀',
        name: 'Formatge fresc',
        category: '🥛 Lactic',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    {
        id: 'l12',
        emoji: '🧀',
        name: 'Formatge blau',
        category: '🥛 Lactic',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 20
    },
    {
        id: 'l13',
        emoji: '🥣',
        name: 'Iogurt natural',
        category: '🥛 Lactic',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 20
    },
    {
        id: 'l14',
        emoji: '🥣',
        name: 'Iogurt grec',
        category: '🥛 Lactic',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 20
    },
    {
        id: 'l15',
        emoji: '🥣',
        name: 'Iogurt de maduixa',
        category: '🥛 Lactic',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 20
    },
    {
        id: 'l16',
        emoji: '🍮',
        name: 'Flam',
        category: '🥛 Lactic',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 20
    },
    {
        id: 'l17',
        emoji: '🍮',
        name: 'Natilles',
        category: '🥛 Lactic',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 20
    },
    {
        id: 'l18',
        emoji: '🧈',
        name: 'Mantega',
        category: '🥛 Lactic',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 100,
        expirationDays: 90
    },
    {
        id: 'l19',
        emoji: '🧴',
        name: 'Nata per cuinar',
        category: '🥛 Lactic',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 200,
        expirationDays: 30
    },
    {
        id: 'l20',
        emoji: '🍦',
        name: 'Gelat',
        category: '🥛 Lactic',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/cereals.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CEREAL_PRESETS",
    ()=>CEREAL_PRESETS
]);
// src/lib/food-presets/dairy.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/domain/entities/StorageLocation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/types.ts [app-client] (ecmascript)");
;
;
const CEREAL_PRESETS = [
    // 🥖 CEREALS
    {
        id: 'c1',
        emoji: '🍞',
        name: 'Pa blanc',
        category: '🥖 Cereals',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].BAKERY
    },
    {
        id: 'c2',
        emoji: '🍞',
        name: 'Pa integral',
        category: '🥖 Cereals',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].BAKERY
    },
    {
        id: 'c3',
        emoji: '🍝',
        name: 'Pasta espagueti',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    {
        id: 'c4',
        emoji: '🍝',
        name: 'Pasta macarrons',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    {
        id: 'c5',
        emoji: '🍚',
        name: 'Arròs blanc',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    // Pa i brioixeria
    {
        id: 'c6',
        emoji: '🥖',
        name: 'Barra de pa',
        category: '🥖 Cereals',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].BAKERY
    },
    {
        id: 'c7',
        emoji: '🥐',
        name: 'Croissant',
        category: '🥖 Cereals',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].BAKERY
    },
    {
        id: 'c8',
        emoji: '🥯',
        name: 'Bagel',
        category: '🥖 Cereals',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 5
    },
    {
        id: 'c9',
        emoji: '🍞',
        name: 'Pa de motlle',
        category: '🥖 Cereals',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 10
    },
    // Pasta i derivats
    {
        id: 'c10',
        emoji: '🍝',
        name: 'Pasta fusilli',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    {
        id: 'c11',
        emoji: '🍝',
        name: 'Pasta penne',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    {
        id: 'c12',
        emoji: '🍜',
        name: 'Fideus',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    // Arròs i grans
    {
        id: 'c13',
        emoji: '🍚',
        name: 'Arròs integral',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    {
        id: 'c14',
        emoji: '🍚',
        name: 'Arròs basmati',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    {
        id: 'c15',
        emoji: '🍚',
        name: 'Arròs jazmín',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    {
        id: 'c16',
        emoji: '🌾',
        name: 'Cuscús',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    {
        id: 'c17',
        emoji: '🌾',
        name: 'Quinoa',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].PANTRY
    },
    // Esmorzar
    {
        id: 'c18',
        emoji: '🥣',
        name: 'Cereals d’esmorzar',
        category: '🥖 Cereals',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 250,
        expirationDays: 90
    },
    {
        id: 'c19',
        emoji: '🥣',
        name: 'Flocs de civada',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: 90
    },
    {
        id: 'c20',
        emoji: '🥣',
        name: 'Muesli',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: 90
    },
    // Farines
    {
        id: 'c21',
        emoji: '🌾',
        name: 'Farina de blat',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 180
    },
    {
        id: 'c22',
        emoji: '🌾',
        name: 'Farina integral',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 180
    },
    {
        id: 'c23',
        emoji: '🌾',
        name: 'Farina de civada',
        category: '🥖 Cereals',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 180
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/drinks.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DRINK_PRESETS",
    ()=>DRINK_PRESETS
]);
// src/lib/food-presets/drinks.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/domain/entities/StorageLocation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/types.ts [app-client] (ecmascript)");
;
;
const DRINK_PRESETS = [
    // 🥤 BEGUDA
    {
        id: 'b1',
        emoji: '💧',
        name: 'Aigua',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'b2',
        emoji: '☕',
        name: 'Cafè mòlt',
        category: '🥤 Beguda',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 250,
        expirationDays: 180
    },
    {
        id: 'b3',
        emoji: '🍵',
        name: 'Te',
        category: '🥤 Beguda',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 20,
        expirationDays: 365
    },
    {
        id: 'b4',
        emoji: '🥤',
        name: 'Refresc cola',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 180
    },
    // Begudes fredes
    {
        id: 'b5',
        emoji: '🥤',
        name: 'Refresc taronja',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 180
    },
    {
        id: 'b6',
        emoji: '🥤',
        name: 'Refresc llimona',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 180
    },
    {
        id: 'b7',
        emoji: '🧃',
        name: 'Suc de taronja',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'b8',
        emoji: '🧃',
        name: 'Suc de poma',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    // Begudes calentes
    {
        id: 'b9',
        emoji: '☕',
        name: 'Cafè en gra',
        category: '🥤 Beguda',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 250,
        expirationDays: 180
    },
    {
        id: 'b10',
        emoji: '☕',
        name: 'Cafè soluble',
        category: '🥤 Beguda',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 200,
        expirationDays: 365
    },
    {
        id: 'b11',
        emoji: '🍵',
        name: 'Infusions',
        category: '🥤 Beguda',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 20,
        expirationDays: 365
    },
    // Altres
    {
        id: 'b12',
        emoji: '🥛',
        name: 'Beguda vegetal de civada',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'b13',
        emoji: '🥛',
        name: 'Beguda vegetal d’ametlla',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'b14',
        emoji: '🍺',
        name: 'Cervesa',
        category: '🥤 Beguda',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 180
    },
    {
        id: 'b15',
        emoji: '🍷',
        name: 'Vi',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.75,
        expirationDays: 365
    },
    {
        id: 'b16',
        emoji: '🥂',
        name: 'Vi blanc',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.75,
        expirationDays: 365
    },
    {
        id: 'b17',
        emoji: '🍾',
        name: 'Cava',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 0.75,
        expirationDays: 365
    },
    {
        id: 'b18',
        emoji: '🥃',
        name: 'Vermut',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 365
    },
    {
        id: 'b19',
        emoji: '🥤',
        name: 'Tònica',
        category: '🥤 Beguda',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 180
    },
    // 🧃 Més sucs
    {
        id: 'b20',
        emoji: '🧃',
        name: 'Suc de pinya',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'b21',
        emoji: '🧃',
        name: 'Suc de préssec',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'b22',
        emoji: '🧃',
        name: 'Suc multifruites',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    // ⚡ Begudes energètiques / esportives
    {
        id: 'b23',
        emoji: '⚡',
        name: 'Beguda energètica',
        category: '🥤 Beguda',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 365
    },
    {
        id: 'b24',
        emoji: '🥤',
        name: 'Beguda isotònica',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 180
    },
    // 🌱 Begudes vegetals (més)
    {
        id: 'b25',
        emoji: '🥛',
        name: 'Beguda vegetal de soja',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'b26',
        emoji: '🥛',
        name: 'Beguda vegetal d’arròs',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    {
        id: 'b27',
        emoji: '🥛',
        name: 'Beguda vegetal de coco',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 7
    },
    // 🍷 Alcohols habituals
    {
        id: 'b28',
        emoji: '🍷',
        name: 'Vi negre',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.75,
        expirationDays: 365
    },
    {
        id: 'b29',
        emoji: '🥃',
        name: 'Ginebra',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.7,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'b30',
        emoji: '🥃',
        name: 'Rom',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.7,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'b31',
        emoji: '🥃',
        name: 'Vodka',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.7,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    // 🍹 Altres
    {
        id: 'b32',
        emoji: '🍹',
        name: 'Sangria',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    {
        id: 'b33',
        emoji: '🍶',
        name: 'Sake',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.75,
        expirationDays: 365
    },
    {
        id: 'b34',
        emoji: '🫖',
        name: 'Te matcha',
        category: '🥤 Beguda',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 50,
        expirationDays: 180
    },
    {
        id: 'b35',
        emoji: '🍵',
        name: 'Kombutxa',
        category: '🥤 Beguda',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 14
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/snacks.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SNACK_PRESETS",
    ()=>SNACK_PRESETS
]);
// src/lib/food-presets/snacks.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/domain/entities/StorageLocation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/types.ts [app-client] (ecmascript)");
;
;
const SNACK_PRESETS = [
    {
        id: 's1',
        emoji: '🍪',
        name: 'Galetes',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    {
        id: 's2',
        emoji: '🍫',
        name: 'Xocolata negra',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 365
    },
    {
        id: 's3',
        emoji: '🍿',
        name: 'Crispetes',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 180
    },
    {
        id: 's4',
        emoji: '🥜',
        name: 'Ametlles',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    // Dolços
    {
        id: 's5',
        emoji: '🍫',
        name: 'Xocolata amb llet',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 365
    },
    {
        id: 's6',
        emoji: '🍫',
        name: 'Xocolata blanca',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 365
    },
    {
        id: 's7',
        emoji: '🍬',
        name: 'Caramels',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 365
    },
    {
        id: 's8',
        emoji: '🍭',
        name: 'Pirulís',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 365
    },
    {
        id: 's9',
        emoji: '🧁',
        name: 'Magdalena',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 7
    },
    {
        id: 's10',
        emoji: '🍩',
        name: 'Dònut',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 3
    },
    // Salats
    {
        id: 's11',
        emoji: '🥨',
        name: 'Bastonets salats',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    {
        id: 's12',
        emoji: '🥨',
        name: 'Pretzels',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    {
        id: 's13',
        emoji: '🍟',
        name: 'Patates fregides',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    {
        id: 's14',
        emoji: '🌮',
        name: 'Nachos',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    // Fruits secs i llavors
    {
        id: 's15',
        emoji: '🥜',
        name: 'Avellanes',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    {
        id: 's16',
        emoji: '🥜',
        name: 'Nous',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    {
        id: 's17',
        emoji: '🥜',
        name: 'Anacards',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    {
        id: 's18',
        emoji: '🌰',
        name: 'Cacauets',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    {
        id: 's19',
        emoji: '🌻',
        name: 'Pipes de gira-sol',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    // Altres
    {
        id: 's20',
        emoji: '🍪',
        name: 'Galetes salades',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    {
        id: 's21',
        emoji: '🍪',
        name: 'Crackers',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    {
        id: 's22',
        emoji: '🍫',
        name: 'Barretes de cereals',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 90
    },
    {
        id: 's23',
        emoji: '🍯',
        name: 'Mel',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 250,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    // 🍫 Dolços extra / rebosteria
    {
        id: 's24',
        emoji: '🍰',
        name: 'Pastís envasat',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 10
    },
    {
        id: 's25',
        emoji: '🥧',
        name: 'Tarta dolça',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    {
        id: 's26',
        emoji: '🍪',
        name: 'Cookies amb xips de xocolata',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 14
    },
    {
        id: 's27',
        emoji: '🍩',
        name: 'Croissant',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 3
    },
    {
        id: 's28',
        emoji: '🥐',
        name: 'Croissant farcit',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 3
    },
    // 🍿 Salats extra
    {
        id: 's29',
        emoji: '🧀',
        name: 'Snacks de formatge',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    {
        id: 's30',
        emoji: '🥓',
        name: 'Snacks de bacon',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 60
    },
    {
        id: 's31',
        emoji: '🍘',
        name: 'Crackers d’arròs',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 120
    },
    {
        id: 's32',
        emoji: '🍘',
        name: 'Galetes d’arròs',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 120
    },
    {
        id: 's33',
        emoji: '🥠',
        name: 'Snacks asiàtics',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 120
    },
    // 🥜 Fruits secs premium / saludables
    {
        id: 's34',
        emoji: '🥜',
        name: 'Festucs',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    {
        id: 's35',
        emoji: '🥜',
        name: 'Ametlles torrades',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    {
        id: 's36',
        emoji: '🌰',
        name: 'Nous pecanes',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    {
        id: 's37',
        emoji: '🥥',
        name: 'Xips de coco',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    // 🧃 Healthy / fitness
    {
        id: 's38',
        emoji: '🍎',
        name: 'Fruita deshidratada',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 180
    },
    {
        id: 's39',
        emoji: '🍫',
        name: 'Barreta proteica',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: 180
    },
    {
        id: 's40',
        emoji: '🫘',
        name: 'Cigrons torrats',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    {
        id: 's41',
        emoji: '🌽',
        name: 'Blat de moro torrat',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 100,
        expirationDays: 90
    },
    // ❄️ Nevera / congelador
    {
        id: 's42',
        emoji: '🍦',
        name: 'Gelat',
        category: '🍪 Snack',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 's43',
        emoji: '🧊',
        name: 'Polos de gel',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 's44',
        emoji: '🍫',
        name: 'Brownie',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 5
    },
    // 🌍 Internacionals / street food
    {
        id: 's45',
        emoji: '🥟',
        name: 'Empanadilles',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FREEZER,
        step: 6,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].FROZEN
    },
    {
        id: 's46',
        emoji: '🍙',
        name: 'Onigiri',
        category: '🍪 Snack',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 2
    },
    {
        id: 's47',
        emoji: '🥙',
        name: 'Falàfel',
        category: '🍪 Snack',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 200,
        expirationDays: 5
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/condiments.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CONDIMENT_PRESETS",
    ()=>CONDIMENT_PRESETS
]);
// src/lib/food-presets/condiments.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/domain/entities/StorageLocation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/types.ts [app-client] (ecmascript)");
;
;
const CONDIMENT_PRESETS = [
    {
        id: 'co1',
        emoji: '🫒',
        name: 'Oli d\'oliva verge',
        category: '🧂 Condiments',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co3',
        emoji: '🧂',
        name: 'Sal',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 500,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co4',
        emoji: '🧂',
        name: 'Pebre negre',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 50,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co5',
        emoji: '🍯',
        name: 'Vinagre de vi',
        category: '🧂 Condiments',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co9',
        emoji: '🍅',
        name: 'Quètxup',
        category: '🧂 Condiments',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 180
    },
    {
        id: 'co10',
        emoji: '🥚',
        name: 'Maionesa',
        category: '🧂 Condiments',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 30
    },
    {
        id: 'co15',
        emoji: '🥘',
        name: 'Tomàquet fregit',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 400,
        expirationDays: 180
    },
    // 🌿 Olis i vinagres
    {
        id: 'co16',
        emoji: '🫒',
        name: 'Oli de gira-sol',
        category: '🧂 Condiments',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co17',
        emoji: '🫒',
        name: 'Oli de coco',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 500,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co18',
        emoji: '🍯',
        name: 'Vinagre de poma',
        category: '🧂 Condiments',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co19',
        emoji: '🍯',
        name: 'Vinagre balsàmic',
        category: '🧂 Condiments',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 0.5,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    // 🧂 Espècies bàsiques
    {
        id: 'co20',
        emoji: '🌶️',
        name: 'Pebre blanc',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 50,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co21',
        emoji: '🌶️',
        name: 'Pebre vermell dolç',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 50,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co22',
        emoji: '🌶️',
        name: 'Pebre vermell picant',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 50,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co23',
        emoji: '🧄',
        name: 'All en pols',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 50,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co24',
        emoji: '🧅',
        name: 'Ceba en pols',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 50,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    // 🌿 Herbes aromàtiques
    {
        id: 'co25',
        emoji: '🌿',
        name: 'Orenga',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 20,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co26',
        emoji: '🌿',
        name: 'Alfàbrega seca',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 20,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co27',
        emoji: '🌿',
        name: 'Farigola',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 20,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co28',
        emoji: '🌿',
        name: 'Romaní',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 20,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    // 🥫 Salses
    {
        id: 'co29',
        emoji: '🥫',
        name: 'Mostassa',
        category: '🧂 Condiments',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 180
    },
    {
        id: 'co30',
        emoji: '🥫',
        name: 'Salsa barbacoa',
        category: '🧂 Condiments',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 180
    },
    {
        id: 'co31',
        emoji: '🥫',
        name: 'Salsa de soja',
        category: '🧂 Condiments',
        defaultUnit: 'l',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 250,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co32',
        emoji: '🌶️',
        name: 'Salsa picant',
        category: '🧂 Condiments',
        defaultUnit: 'ut',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].FRIDGE,
        step: 1,
        expirationDays: 365
    },
    // 🍯 Altres
    {
        id: 'co33',
        emoji: '🍯',
        name: 'Sucre blanc',
        category: '🧂 Condiments',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co34',
        emoji: '🍯',
        name: 'Sucre morè',
        category: '🧂 Condiments',
        defaultUnit: 'kg',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 1,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    },
    {
        id: 'co35',
        emoji: '🍯',
        name: 'Mel',
        category: '🧂 Condiments',
        defaultUnit: 'g',
        defaultLoc: __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$domain$2f$entities$2f$StorageLocation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StorageLocation"].PANTRY,
        step: 250,
        expirationDays: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAYS"].LONG_PANTRY
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/food-presets/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// src/lib/food-presets/index.ts
__turbopack_context__.s([
    "FOOD_PRESETS",
    ()=>FOOD_PRESETS,
    "PRESET_CATEGORIES",
    ()=>PRESET_CATEGORIES
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$fruit$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/fruit.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$vegetables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/vegetables.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$protein$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/protein.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$dairy$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/dairy.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$cereals$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/cereals.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$drinks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/drinks.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$snacks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/snacks.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$condiments$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/condiments.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/food-presets/types.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
const FOOD_PRESETS = [
    ...__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$fruit$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FRUIT_PRESETS"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$vegetables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VEGETABLE_PRESETS"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$protein$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROTEIN_PRESETS"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$dairy$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DAIRY_PRESETS"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$cereals$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CEREAL_PRESETS"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$drinks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DRINK_PRESETS"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$snacks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SNACK_PRESETS"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$condiments$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CONDIMENT_PRESETS"]
];
const PRESET_CATEGORIES = Array.from(new Set(FOOD_PRESETS.map((p)=>p.category)));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/editor/steps/list/IngredientChip.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IngredientChip",
    ()=>IngredientChip
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/food-presets/index.ts [app-client] (ecmascript) <locals>");
'use client';
;
;
function IngredientChip({ name, ingredient }) {
    // 1. Recuperem la imatge (prioritzem la del producte vinculat)
    // Fem un cast segur per accedir a propietats opcionals
    const ingData = ingredient;
    const imageUrl = ingData?.image || ingData?.linkedProductImage;
    const hasImage = !!imageUrl;
    // 2. Recuperem l'emoji (del preset o de l'ingredient)
    const preset = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$food$2d$presets$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["FOOD_PRESETS"].find((p)=>p.name === name);
    const emoji = ingData?.emoji || preset?.emoji || '📦';
    // 3. Recuperem el preu i quantitat
    const price = ingData?.estimatedCost ? ingData.estimatedCost.toFixed(2) : null;
    const quantity = ingData ? `${ingData.quantity}${ingData.unit}` : '';
    console.log(`RENDER CHIP [${name}]: hasImage=${hasImage}, url=${imageUrl}`);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: `
        inline-flex items-center gap-1.5 align-middle mx-1 px-1.5 py-0.5 rounded-lg border shadow-sm select-none transition-all
        ${hasImage ? 'bg-slate-800/90 border-emerald-500/40 text-white pr-2 shadow-emerald-900/20' // Estil Premium
         : 'bg-slate-800 border-slate-700 text-emerald-100'}
      `,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "w-5 h-5 rounded bg-white flex items-center justify-center overflow-hidden shrink-0 ring-1 ring-black/10",
                children: hasImage ? /* eslint-disable-next-line @next/next/no-img-element */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                    src: imageUrl,
                    alt: name,
                    className: "w-full h-full object-contain p-0.5"
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/editor/steps/list/IngredientChip.tsx",
                    lineNumber: 49,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-xs leading-none",
                    children: emoji
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/editor/steps/list/IngredientChip.tsx",
                    lineNumber: 55,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/steps/list/IngredientChip.tsx",
                lineNumber: 46,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-xs font-bold truncate max-w-30",
                children: name
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/steps/list/IngredientChip.tsx",
                lineNumber: 60,
                columnNumber: 7
            }, this),
            quantity && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-[9px] text-slate-300 font-mono leading-none bg-slate-950/50 px-1 py-0.5 rounded border border-slate-700/50",
                children: quantity
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/editor/steps/list/IngredientChip.tsx",
                lineNumber: 64,
                columnNumber: 9
            }, this),
            price && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-[9px] font-black text-emerald-400 bg-emerald-950/80 px-1 py-0.5 rounded leading-none border border-emerald-500/20",
                children: [
                    price,
                    "€"
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/editor/steps/list/IngredientChip.tsx",
                lineNumber: 71,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/editor/steps/list/IngredientChip.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
_c = IngredientChip;
var _c;
__turbopack_context__.k.register(_c, "IngredientChip");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/parts/CountdownTimer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CountdownTimer",
    ()=>CountdownTimer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
function CountdownTimer({ minutes }) {
    _s();
    const [timeLeft, setTimeLeft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(minutes * 60);
    const [isActive, setIsActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isFinished, setIsFinished] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CountdownTimer.useEffect": ()=>{
            let interval;
            if (isActive) {
                interval = setInterval({
                    "CountdownTimer.useEffect": ()=>{
                        setTimeLeft({
                            "CountdownTimer.useEffect": (prev)=>{
                                if (prev <= 1) {
                                    clearInterval(interval);
                                    setIsActive(false);
                                    setIsFinished(true);
                                    return 0;
                                }
                                return prev - 1;
                            }
                        }["CountdownTimer.useEffect"]);
                    }
                }["CountdownTimer.useEffect"], 1000);
            }
            return ({
                "CountdownTimer.useEffect": ()=>clearInterval(interval)
            })["CountdownTimer.useEffect"];
        }
    }["CountdownTimer.useEffect"], [
        isActive
    ]); // ✅ Dependència neta
    const toggleTimer = (e)=>{
        e.stopPropagation();
        if (isFinished) {
            setTimeLeft(minutes * 60);
            setIsFinished(false);
            setIsActive(true);
        } else {
            setIsActive(!isActive);
        }
    };
    const formatTime = (seconds)=>{
        const m = Math.floor(seconds / 60);
        const s = seconds % 60;
        return `${m}:${s < 10 ? '0' : ''}${s}`;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        onClick: toggleTimer,
        className: `
        inline-flex items-center gap-2 px-2 py-0.5 rounded-full text-[10px] font-bold font-mono transition-all ml-2 align-middle
        ${isFinished ? 'bg-red-600 text-white animate-pulse' : isActive ? 'bg-purple-600 text-white border border-purple-400' : 'bg-slate-800 text-purple-300 border border-slate-700 hover:bg-slate-700'}
      `,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: isActive ? '⏳' : isFinished ? '🔔' : '⏱️'
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/parts/CountdownTimer.tsx",
                lineNumber: 59,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: isFinished ? 'FI' : formatTime(timeLeft)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/parts/CountdownTimer.tsx",
                lineNumber: 60,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/parts/CountdownTimer.tsx",
        lineNumber: 47,
        columnNumber: 5
    }, this);
}
_s(CountdownTimer, "g8eb58TatM2rhtXmQAM/b/lI+a0=");
_c = CountdownTimer;
var _c;
__turbopack_context__.k.register(_c, "CountdownTimer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/editor/steps/list/HighlightedContent.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HighlightedContent",
    ()=>HighlightedContent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$list$2f$IngredientChip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/editor/steps/list/IngredientChip.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$parts$2f$CountdownTimer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/parts/CountdownTimer.tsx [app-client] (ecmascript)");
'use client';
;
;
;
function HighlightedContent({ content, ingredients, interactive = false }) {
    // ✅ 1. PROTECCIÓ ROBUSTA: Si no hi ha contingut o no és string, retornem null
    if (!content || typeof content !== 'string') return null;
    // Ara és segur fer .split()
    const parts = content.split(/(\[.*?\]|⏰\s*\d+\s*(?:min|minuts|minutes|s|segons)?)/g);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        className: "whitespace-pre-wrap leading-relaxed text-base text-slate-300",
        children: parts.map((part, i)=>{
            const key = `part-${i}-${part.substring(0, 5)}`;
            // CAS 1: TEMPS
            if (part.startsWith('⏰')) {
                if (interactive) {
                    const timeMatch = part.match(/(\d+)/);
                    const minutes = timeMatch ? parseInt(timeMatch[0]) : 0;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$parts$2f$CountdownTimer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CountdownTimer"], {
                        minutes: minutes
                    }, key, false, {
                        fileName: "[project]/features/recipes/components/editor/steps/list/HighlightedContent.tsx",
                        lineNumber: 30,
                        columnNumber: 24
                    }, this);
                }
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "inline-flex items-center gap-1 bg-purple-500/10 text-purple-300 px-1.5 py-0.5 rounded-md text-xs font-bold mx-1 border border-purple-500/20 align-baseline shadow-sm",
                    children: part
                }, key, false, {
                    fileName: "[project]/features/recipes/components/editor/steps/list/HighlightedContent.tsx",
                    lineNumber: 33,
                    columnNumber: 17
                }, this);
            }
            // CAS 2: INGREDIENT [Nom]
            if (part.startsWith('[') && part.endsWith(']')) {
                const cleanName = part.slice(1, -1);
                // Busquem l'ingredient complet a la llista per tenir imatge/preu
                const ingredientData = ingredients.find((ing)=>ing.name === cleanName);
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$list$2f$IngredientChip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IngredientChip"], {
                    name: cleanName,
                    ingredient: ingredientData
                }, key, false, {
                    fileName: "[project]/features/recipes/components/editor/steps/list/HighlightedContent.tsx",
                    lineNumber: 46,
                    columnNumber: 13
                }, this);
            }
            // CAS 3: Text normal
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: part
            }, key, false, {
                fileName: "[project]/features/recipes/components/editor/steps/list/HighlightedContent.tsx",
                lineNumber: 55,
                columnNumber: 16
            }, this);
        })
    }, void 0, false, {
        fileName: "[project]/features/recipes/components/editor/steps/list/HighlightedContent.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
}
_c = HighlightedContent;
var _c;
__turbopack_context__.k.register(_c, "HighlightedContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/parts/StepsPanel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StepsPanel",
    ()=>StepsPanel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/circle-check.js [app-client] (ecmascript) <export default as CheckCircle2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$list$2f$HighlightedContent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/editor/steps/list/HighlightedContent.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function StepsPanel({ steps, ingredients }) {
    _s();
    const [completedSteps, setCompletedSteps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [isExpanded, setIsExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const toggleStep = (index)=>{
        const next = new Set(completedSteps);
        if (next.has(index)) next.delete(index);
        else next.add(index);
        setCompletedSteps(next);
    };
    const normalizedSteps = steps.map((s)=>{
        if (typeof s === 'string') return s;
        return s.content || "";
    });
    const safeIngredients = ingredients.map((ing, i)=>({
            id: ing.id || `temp-id-${i}`,
            name: ing.name,
            quantity: ing.quantity,
            unit: ing.unit,
            emoji: ing.emoji || '🥘',
            image: ing.image,
            linkedProductImage: ing.linkedProductImage,
            estimatedCost: ing.estimatedCost,
            linkedProductId: ing.linkedProductId || undefined
        }));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-slate-900/50 rounded-3xl border border-slate-800 shadow-xl overflow-hidden",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>setIsExpanded(!isExpanded),
                className: "w-full flex justify-between items-center p-5 md:p-6 bg-slate-900/30 hover:bg-slate-900/50 transition-colors border-b border-slate-800/50",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg md:text-xl font-black text-white flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-2xl",
                                        children: "👨‍🍳"
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                                        lineNumber: 54,
                                        columnNumber: 25
                                    }, this),
                                    " ",
                                    t.community.steps.title
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                                lineNumber: 53,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[10px] font-bold bg-slate-950 text-slate-400 px-3 py-1 rounded-full border border-slate-800 uppercase tracking-wider",
                                children: [
                                    completedSteps.size,
                                    "/",
                                    steps.length
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                                lineNumber: 56,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                        lineNumber: 52,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                        className: `text-slate-400 transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`,
                        size: 20
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                        lineNumber: 61,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                lineNumber: 48,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                initial: false,
                children: isExpanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        height: 0,
                        opacity: 0
                    },
                    animate: {
                        height: 'auto',
                        opacity: 1
                    },
                    exit: {
                        height: 0,
                        opacity: 0
                    },
                    transition: {
                        duration: 0.3,
                        ease: 'easeInOut'
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-4 md:p-6 relative space-y-4 md:space-y-6 pb-8 md:pb-12",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute left-[27px] md:left-[35px] top-6 bottom-10 w-0.5 bg-slate-800/50 -z-10"
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                                lineNumber: 78,
                                columnNumber: 29
                            }, this),
                            normalizedSteps.length > 0 ? normalizedSteps.map((stepText, i)=>{
                                const isDone = completedSteps.has(i);
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                    layout: true,
                                    initial: {
                                        opacity: 0,
                                        y: 10
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        delay: i * 0.05
                                    },
                                    onClick: ()=>toggleStep(i),
                                    className: `
                                            relative flex gap-4 md:gap-6 group select-none cursor-pointer
                                            ${isDone ? 'opacity-50 grayscale' : 'opacity-100'}
                                        `,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "shrink-0 pt-1 relative z-10",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `
                                                w-8 h-8 md:w-10 md:h-10 rounded-full border-4 flex items-center justify-center text-xs md:text-sm font-bold shadow-xl transition-all duration-300
                                                ${isDone ? 'bg-emerald-500 border-slate-950 text-white scale-90' : 'bg-slate-900 border-slate-950 text-slate-400 group-hover:border-purple-500 group-hover:text-white'}
                                            `,
                                                children: isDone ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__["CheckCircle2"], {
                                                    size: 18
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                                                    lineNumber: 105,
                                                    columnNumber: 59
                                                }, this) : i + 1
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                                                lineNumber: 98,
                                                columnNumber: 45
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                                            lineNumber: 97,
                                            columnNumber: 41
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: `
                                            flex-1 p-4 md:p-5 rounded-2xl border transition-all duration-300 relative
                                            ${isDone ? 'bg-transparent border-transparent text-slate-600' : 'bg-slate-900/60 border-slate-800/50 text-slate-200 shadow-lg backdrop-blur-sm group-hover:border-purple-500/30 group-hover:bg-slate-900/80'}
                                        `,
                                            children: [
                                                !isDone && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "absolute top-0 right-0 w-20 h-20 bg-purple-500/5 rounded-full blur-2xl -translate-y-1/2 translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity"
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                                                    lineNumber: 117,
                                                    columnNumber: 57
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: `text-base md:text-lg leading-relaxed ${isDone ? 'line-through decoration-slate-700' : ''}`,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$editor$2f$steps$2f$list$2f$HighlightedContent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HighlightedContent"], {
                                                        content: stepText,
                                                        ingredients: safeIngredients,
                                                        interactive: true
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                                                        lineNumber: 121,
                                                        columnNumber: 49
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                                                    lineNumber: 119,
                                                    columnNumber: 45
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                                            lineNumber: 110,
                                            columnNumber: 41
                                        }, this)
                                    ]
                                }, i, true, {
                                    fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                                    lineNumber: 84,
                                    columnNumber: 37
                                }, this);
                            }) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center py-10 opacity-50 border-2 border-dashed border-slate-800 rounded-3xl",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: t.community.steps.empty
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                                    lineNumber: 132,
                                    columnNumber: 37
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                                lineNumber: 131,
                                columnNumber: 33
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                        lineNumber: 76,
                        columnNumber: 25
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                    lineNumber: 70,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
                lineNumber: 68,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/parts/StepsPanel.tsx",
        lineNumber: 46,
        columnNumber: 9
    }, this);
}
_s(StepsPanel, "N5n4Ewt/MAgLmOwCP5XKLQaTwio=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = StepsPanel;
var _c;
__turbopack_context__.k.register(_c, "StepsPanel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/BackButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BackButton",
    ()=>BackButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/navigation.js [app-client] (ecmascript)"); // 👈 Importem el router
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function BackButton({ href, label = "Tornar", className = "", preferReferrer = false, fallbackHref }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const storageKey = ("TURBOPACK compile-time truthy", 1) ? `back-origin:${window.location.pathname}` : "TURBOPACK unreachable";
    // Definim els estils comuns per no repetir codi
    const buttonStyles = `
    flex items-center justify-center gap-2 
    bg-slate-800 hover:bg-slate-700 
    text-white 
    border border-slate-700 hover:border-purple-500/50
    transition-colors shadow-lg
    cursor-pointer
    
    /* MÒBIL: Rodó i petit */
    w-10 h-10 rounded-full
    
    /* ESCRIPTORI: Allargat i amb text */
    sm:w-auto sm:h-auto sm:px-4 sm:py-2 sm:rounded-full
    
    ${className}
  `;
    // Contingut visual del botó (Icona + Text)
    const content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-xl sm:text-lg leading-none pb-1 sm:pb-0",
                children: "🔙"
            }, void 0, false, {
                fileName: "[project]/components/ui/BackButton.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "hidden sm:inline text-xs font-bold uppercase tracking-wide",
                children: label
            }, void 0, false, {
                fileName: "[project]/components/ui/BackButton.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
    // CAS 1: Si tenim una ruta específica (href), fem servir Link (millor per SEO i prefetching)
    if (href) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: href,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                whileHover: {
                    scale: 1.05
                },
                whileTap: {
                    scale: 0.95
                },
                className: buttonStyles,
                children: content
            }, void 0, false, {
                fileName: "[project]/components/ui/BackButton.tsx",
                lineNumber: 58,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/ui/BackButton.tsx",
            lineNumber: 57,
            columnNumber: 7
        }, this);
    }
    // CAS 2: Si volem tornar a l'origen (fora d'aquesta ruta), usem el referrer guardat
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
        type: "button",
        onClick: ()=>{
            if (preferReferrer && ("TURBOPACK compile-time value", "object") !== "undefined" && storageKey) {
                const storedOrigin = sessionStorage.getItem(storageKey);
                if (storedOrigin) {
                    router.push(storedOrigin);
                    return;
                }
                if (fallbackHref) {
                    router.push(fallbackHref);
                    return;
                }
            }
            router.back();
        },
        whileHover: {
            scale: 1.05
        },
        whileTap: {
            scale: 0.95
        },
        className: buttonStyles,
        children: content
    }, void 0, false, {
        fileName: "[project]/components/ui/BackButton.tsx",
        lineNumber: 72,
        columnNumber: 5
    }, this);
}
_s(BackButton, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = BackButton;
var _c;
__turbopack_context__.k.register(_c, "BackButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:0c6092 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "toggleFavoriteAction",
    ()=>$$RSC_SERVER_ACTION_1
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"40c53fa8401d5e6dda60b51c1e9e408ee2b365c0dc":"toggleFavoriteAction"},"app/actions/recipe-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40c53fa8401d5e6dda60b51c1e9e408ee2b365c0dc", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "toggleFavoriteAction");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vcmVjaXBlLWFjdGlvbnMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQVJYSVU6IGFwcC9hY3Rpb25zL3JlY2lwZS1hY3Rpb25zLnRzXHJcbid1c2Ugc2VydmVyJ1xyXG5cclxuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSAnQC9hZGFwdGVycy9zdXBhYmFzZS9zZXJ2ZXInO1xyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gJ25leHQvY2FjaGUnO1xyXG4vLyDinIUgRklYOiBJbXBvcnRlbSBlbCByZXBvc2l0b3JpIHF1ZSBmYWx0YXZhXHJcbmltcG9ydCB7IFN1cGFiYXNlUmVjaXBlUmVwb3NpdG9yeSB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2UvU3VwYWJhc2VSZWNpcGVSZXBvc2l0b3J5JztcclxuaW1wb3J0IHsgY29udGFpbmVyIH0gZnJvbSAnQC9zZXJ2aWNlcy9jb250YWluZXInO1xyXG5pbXBvcnQgeyBFbW9qaU1hdGNoZXJTZXJ2aWNlIH0gZnJvbSAnQC9jb3JlL2FwcGxpY2F0aW9uL3NlcnZpY2VzL0Vtb2ppTWF0Y2hlclNlcnZpY2UnOyAvLyDinIUgSW1wb3J0ZW0gZWwgTWF0Y2hlclxyXG5pbXBvcnQgeyBHZW5lcmF0ZVJlY2lwZVNjaGVtYSwgTWF0ZXJpYWxpemVSZWNpcGVTY2hlbWEgfSBmcm9tICdAL2NvcmUvYXBwbGljYXRpb24vc2NoZW1hcy9pbnB1dFNjaGVtYXMnO1xyXG5pbXBvcnQgeyBTdXBhYmFzZVJhdGVMaW1pdGVyIH0gZnJvbSAnQC9hZGFwdGVycy9zdXBhYmFzZS9TdXBhYmFzZVJhdGVMaW1pdGVyJztcclxuaW1wb3J0IHsgU3VwYWJhc2VTZWN1cml0eUxvZ2dlciB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2UvU3VwYWJhc2VTZWN1cml0eUxvZ2dlcic7XHJcbmltcG9ydCB7IGRlYnVnLCBlcnJvciBhcyBsb2dFcnJvciB9IGZyb20gJ0AvbGliL2xvZ2dlcic7XHJcblxyXG4vLyDinIUgRklYOiBEZWZpbmljacOzIHJvYnVzdGEgZGUgbGEgcmVzcG9zdGFcclxuZXhwb3J0IHR5cGUgQWN0aW9uUmVzcG9uc2UgPSB7XHJcbiAgICBzdWNjZXNzOiBib29sZWFuO1xyXG4gICAgcmVjaXBlSWQ/OiBzdHJpbmc7XHJcbiAgICBlcnJvcj86IHN0cmluZzsgLy8gSW1wb3J0YW50IHF1ZSBzaWd1aSBvcGNpb25hbCAoPylcclxufTtcclxuXHJcbi8vIFRpcHVzIHVuaWZpY2F0IHF1ZSBjb2JyZWl4aSBlbCBxdWUgdmUgZGUgbCdFZGl0b3IgaSBlbCBxdWUgdmUgZGUgbGEgSUFcclxuZXhwb3J0IGludGVyZmFjZSBTYXZlUmVjaXBlSW5wdXQge1xyXG4gIGlkPzogc3RyaW5nO1xyXG4gIG5hbWU6IHN0cmluZztcclxuICBwcmVwVGltZU1pbnV0ZXM6IG51bWJlciB8IHN0cmluZztcclxuICBcclxuICBpbmdyZWRpZW50czoge1xyXG4gICAgaWQ/OiBzdHJpbmc7XHJcbiAgICBuYW1lOiBzdHJpbmc7XHJcbiAgICBxdWFudGl0eTogbnVtYmVyO1xyXG4gICAgdW5pdDogc3RyaW5nO1xyXG4gICAgZW1vamk/OiBzdHJpbmc7XHJcbiAgICBlc3RpbWF0ZWRDb3N0PzogbnVtYmVyIHwgc3RyaW5nO1xyXG4gICAgbGlua2VkUHJvZHVjdElkPzogc3RyaW5nIHwgbnVsbDtcclxuICAgIGxpbmtlZFByb2R1Y3RJbWFnZT86IHN0cmluZyB8IG51bGw7XHJcbiAgfVtdO1xyXG4gIHN0ZXBzOiAoc3RyaW5nIHwgeyBpZDogc3RyaW5nOyBjb250ZW50OiBzdHJpbmcgfSlbXTtcclxuICB0YWdzPzogc3RyaW5nW107XHJcbiAgZGlldGFyeVRhZ3M/OiBzdHJpbmdbXTtcclxuICBpc0FpR2VuZXJhdGVkPzogYm9vbGVhbjtcclxufVxyXG5cclxuLy8gLS0tIEFDQ0nDkyBQUklOQ0lQQUw6IFNBVkUgLS0tXHJcbi8vIEFxdWVzdGEgY29udMOpIHRvdGEgbGEgbMOyZ2ljYSBcImludGVswrdsaWdlbnRcIiAocHJldXMsIGltYXRnZXMsIGVtb2ppcy4uLilcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNhdmVSZWNpcGVBY3Rpb24oZGF0YTogU2F2ZVJlY2lwZUlucHV0KTogUHJvbWlzZTxBY3Rpb25SZXNwb25zZT4ge1xyXG4gIGRlYnVnKCdbU0FWRSBBQ1RJT05dIHNhdmVSZWNpcGVBY3Rpb24nKTtcclxuXHJcbiAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICBpZiAoIXVzZXIpIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9O1xyXG5cclxuICB0cnkge1xyXG4gICAgbGV0IGF1dGhvck5hbWUgPSBcIlhlZiBBbsOybmltXCI7XHJcbiAgICBjb25zdCB7IGRhdGE6IHByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3ByZWZlcmVuY2VfcHJvZmlsZXMnKS5zZWxlY3QoJ3VzZXJuYW1lJykuZXEoJ3VzZXJfaWQnLCB1c2VyLmlkKS5zaW5nbGUoKTtcclxuICAgIGlmIChwcm9maWxlPy51c2VybmFtZSkgYXV0aG9yTmFtZSA9IHByb2ZpbGUudXNlcm5hbWU7XHJcblxyXG4gICAgLy8gMS4gQ8OgbGN1bCBkZSBjb3N0IHRvdGFsIChST0JVU1QpXHJcbiAgICBjb25zdCB0b3RhbENvc3QgPSBkYXRhLmluZ3JlZGllbnRzLnJlZHVjZSgoYWNjLCBpbmcpID0+IHtcclxuICAgICAgbGV0IGNvc3RWYWwgPSBpbmcuZXN0aW1hdGVkQ29zdDtcclxuICAgICAgaWYgKHR5cGVvZiBjb3N0VmFsID09PSAnc3RyaW5nJykgY29zdFZhbCA9IHBhcnNlRmxvYXQoY29zdFZhbCk7XHJcbiAgICAgIGNvbnN0IGNvc3QgPSBOdW1iZXIoY29zdFZhbCkgfHwgMDtcclxuICAgICAgcmV0dXJuIGFjYyArIGNvc3Q7XHJcbiAgICB9LCAwKTtcclxuXHJcbiAgICBsZXQgaXNBaUdlbmVyYXRlZCA9ICEhZGF0YS5pc0FpR2VuZXJhdGVkO1xyXG4gICAgaWYgKCFpc0FpR2VuZXJhdGVkICYmIGRhdGEuaWQpIHtcclxuICAgICAgY29uc3QgeyBkYXRhOiBvbGRSZWNpcGUgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3NhdmVkX3JlY2lwZXMnKS5zZWxlY3QoJ2lzX2FpX2dlbmVyYXRlZCcpLmVxKCdpZCcsIGRhdGEuaWQpLnNpbmdsZSgpO1xyXG4gICAgICBpZiAob2xkUmVjaXBlKSBpc0FpR2VuZXJhdGVkID0gb2xkUmVjaXBlLmlzX2FpX2dlbmVyYXRlZDtcclxuICAgIH1cclxuXHJcbiAgICAvLyAyLiBQUk9DRVNTQVIgSU5HUkVESUVOVFMgKyBJTUFUR0VTXHJcbiAgICBjb25zdCBpbmdyZWRpZW50c1BheWxvYWQgPSBhd2FpdCBQcm9taXNlLmFsbChkYXRhLmluZ3JlZGllbnRzLm1hcChhc3luYyAoaW5nKSA9PiB7XHJcbiAgICAgIGxldCBmaW5hbElkID0gaW5nLmlkO1xyXG4gICAgICBsZXQgZmluYWxFbW9qaSA9IGluZy5lbW9qaTtcclxuICAgICAgY29uc3QgZmluYWxOYW1lID0gaW5nLm5hbWU7XHJcbiAgICAgIGNvbnN0IGxpbmtlZFByb2R1Y3RJZCA9IGluZy5saW5rZWRQcm9kdWN0SWQ7XHJcbiAgICAgIGxldCBsaW5rZWRQcm9kdWN0SW1hZ2UgPSBpbmcubGlua2VkUHJvZHVjdEltYWdlO1xyXG4gICAgICBjb25zdCBlc3RpbWF0ZWRDb3N0ID0gaW5nLmVzdGltYXRlZENvc3QgPyBOdW1iZXIoaW5nLmVzdGltYXRlZENvc3QpIDogMDtcclxuXHJcbiAgICAgIGNvbnN0IGhhc0xpbmsgPSB0eXBlb2YgbGlua2VkUHJvZHVjdElkID09PSAnc3RyaW5nJyAmJiBsaW5rZWRQcm9kdWN0SWQubGVuZ3RoID4gMDtcclxuXHJcbiAgICAgIGlmIChoYXNMaW5rKSB7XHJcbiAgICAgICAgLy8gLi4uIChMw7JnaWNhIGRlIHJlY3VwZXJhY2nDsyBkJ2ltYXRnZXMgaWd1YWwgcXVlIHRlbmllcykgLi4uXHJcbiAgICAgICAgaWYgKCFsaW5rZWRQcm9kdWN0SW1hZ2UpIHtcclxuICAgICAgICAgIGNvbnN0IHsgZGF0YTogcHJvZHVjdCB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgncHJvZHVjdF9jYXRhbG9nJykuc2VsZWN0KCdpbWFnZV91cmwnKS5lcSgnaWQnLCBsaW5rZWRQcm9kdWN0SWQpLnNpbmdsZSgpO1xyXG4gICAgICAgICAgaWYgKHByb2R1Y3Q/LmltYWdlX3VybCkgbGlua2VkUHJvZHVjdEltYWdlID0gcHJvZHVjdC5pbWFnZV91cmw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghZmluYWxJZCB8fCBmaW5hbElkLmxlbmd0aCA8IDUpIGZpbmFsSWQgPSBsaW5rZWRQcm9kdWN0SWQhO1xyXG4gICAgICAgIGlmICghZmluYWxFbW9qaSB8fCBmaW5hbEVtb2ppID09PSAn8J+lmCcpIGZpbmFsRW1vamkgPSAn8J+Tpic7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gTWF0Y2hlciBkJ2Vtb2ppc1xyXG4gICAgICAgIGNvbnN0IGNsZWFuTmFtZSA9IGZpbmFsTmFtZS5yZXBsYWNlKC9cXGIoQk9OUFJFVXxQQVRDSEVGfC4uLilcXGIvZ2ksIFwiXCIpLnRyaW0oKTtcclxuICAgICAgICBjb25zdCBwcmVzZXQgPSBFbW9qaU1hdGNoZXJTZXJ2aWNlLm1hdGNoKGNsZWFuTmFtZSk7XHJcbiAgICAgICAgaWYgKHByZXNldCkge1xyXG4gICAgICAgICAgZmluYWxJZCA9IHByZXNldC5pZDtcclxuICAgICAgICAgIGZpbmFsRW1vamkgPSBwcmVzZXQuZW1vamk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGlmICghZmluYWxFbW9qaSkgZmluYWxFbW9qaSA9ICfwn6WYJztcclxuICAgICAgICAgIGlmICghZmluYWxJZCkgZmluYWxJZCA9IGNyeXB0by5yYW5kb21VVUlEKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIGlkOiBmaW5hbElkLFxyXG4gICAgICAgIG5hbWU6IGZpbmFsTmFtZSxcclxuICAgICAgICBxdWFudGl0eTogaW5nLnF1YW50aXR5LFxyXG4gICAgICAgIHVuaXQ6IGluZy51bml0LFxyXG4gICAgICAgIGVtb2ppOiBmaW5hbEVtb2ppLFxyXG4gICAgICAgIGxpbmtlZFByb2R1Y3RJZDogaGFzTGluayA/IGxpbmtlZFByb2R1Y3RJZCA6IG51bGwsXHJcbiAgICAgICAgbGlua2VkUHJvZHVjdEltYWdlOiBoYXNMaW5rID8gbGlua2VkUHJvZHVjdEltYWdlIDogbnVsbCxcclxuICAgICAgICBlc3RpbWF0ZWRDb3N0XHJcbiAgICAgIH07XHJcbiAgICB9KSk7XHJcblxyXG4gICAgLy8gMy4gUFJPQ0VTU0FSIFBBU1NPU1xyXG4gICAgY29uc3Qgc3RlcHNEYXRhID0gZGF0YS5zdGVwcy5tYXAocyA9PiB7XHJcbiAgICAgIGlmICh0eXBlb2YgcyA9PT0gJ3N0cmluZycpIHJldHVybiB7IGlkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLCBjb250ZW50OiBzIH07XHJcbiAgICAgIHJldHVybiB7IGlkOiBzLmlkIHx8IGNyeXB0by5yYW5kb21VVUlEKCksIGNvbnRlbnQ6IHMuY29udGVudCB8fCBcIlwiIH07XHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyA0LiBQQVlMT0FEIEJEXHJcbiAgICBjb25zdCByZWNpcGVQYXlsb2FkID0ge1xyXG4gICAgICB1c2VyX2lkOiB1c2VyLmlkLFxyXG4gICAgICBuYW1lOiBkYXRhLm5hbWUsXHJcbiAgICAgIGF1dGhvcl9uYW1lOiBhdXRob3JOYW1lLFxyXG4gICAgICBwcmVwX3RpbWVfbWludXRlczogTnVtYmVyKGRhdGEucHJlcFRpbWVNaW51dGVzKSB8fCAwLFxyXG4gICAgICBpbmdyZWRpZW50czogaW5ncmVkaWVudHNQYXlsb2FkLFxyXG4gICAgICBzdGVwczogc3RlcHNEYXRhLFxyXG4gICAgICB0YWdzOiBkYXRhLnRhZ3MgfHwgW10sXHJcbiAgICAgIGRpZXRhcnlfdGFnczogZGF0YS5kaWV0YXJ5VGFncyB8fCBbXSxcclxuICAgICAgZXN0aW1hdGVkX2Nvc3Q6IHRvdGFsQ29zdCxcclxuICAgICAgaXNfcHVibGljOiBmYWxzZSwgLy8gUGVyIGRlZmVjdGUgcHJpdmFkYSBxdWFuIGVzIGd1YXJkYVxyXG4gICAgICBpc19haV9nZW5lcmF0ZWQ6IGlzQWlHZW5lcmF0ZWQsXHJcbiAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCB0YWJsZSA9IHN1cGFiYXNlLmZyb20oJ3NhdmVkX3JlY2lwZXMnKTtcclxuICAgIGxldCByZXN1bHRJZDogc3RyaW5nO1xyXG5cclxuICAgIGlmIChkYXRhLmlkKSB7XHJcbiAgICAgIC8vIC4uLiBMw7JnaWNhIGQnVXBkYXRlIGV4aXN0ZW50IC4uLlxyXG4gICAgICAvLyAoU2ltcGxpZmljYWRhIGFxdcOtIHBlciBicmV2ZXRhdCwgY29waWEgbGEgdGV2YSBsw7JnaWNhIGQndXBkYXRlKVxyXG4gICAgICBjb25zdCB7IGRhdGE6IHVwZGF0ZWQsIGVycm9yIH0gPSBhd2FpdCB0YWJsZS51cHNlcnQoeyAuLi5yZWNpcGVQYXlsb2FkLCBpZDogZGF0YS5pZCB9KS5zZWxlY3QoJ2lkJykuc2luZ2xlKCk7XHJcbiAgICAgIGlmIChlcnJvcikgdGhyb3cgZXJyb3I7XHJcbiAgICAgIHJlc3VsdElkID0gdXBkYXRlZC5pZDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnN0IHsgZGF0YTogaW5zZXJ0ZWQsIGVycm9yIH0gPSBhd2FpdCB0YWJsZS5pbnNlcnQocmVjaXBlUGF5bG9hZCkuc2VsZWN0KCdpZCcpLnNpbmdsZSgpO1xyXG4gICAgICBpZiAoZXJyb3IpIHRocm93IGVycm9yO1xyXG4gICAgICByZXN1bHRJZCA9IGluc2VydGVkLmlkO1xyXG4gICAgfVxyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvcmVjaXBlcycpO1xyXG4gICAgaWYgKHJlc3VsdElkKSByZXZhbGlkYXRlUGF0aChgL3JlY2lwZXMvJHtyZXN1bHRJZH1gKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIHJlY2lwZUlkOiByZXN1bHRJZCB9O1xyXG5cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ3NhdmVSZWNpcGVBY3Rpb24gZmFpbGVkJywgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkVycm9yIGludGVybi5cIiB9O1xyXG4gIH1cclxufVxyXG4vLyBBY2Npw7MgcGVyIEZhdm9yaXRzIChOZWNlc3NpdGEgZWwgUmVwb3NpdG9yaSlcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHRvZ2dsZUZhdm9yaXRlQWN0aW9uKHJlY2lwZUlkOiBzdHJpbmcpIHtcclxuICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0gfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpO1xyXG5cclxuICBpZiAoIXVzZXIpIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9O1xyXG5cclxuICAvLyBBcmEgc8OtIHF1ZSB0ZW5pbSBsJ2ltcG9ydCBhIGRhbHRcclxuICBjb25zdCByZXBvID0gbmV3IFN1cGFiYXNlUmVjaXBlUmVwb3NpdG9yeSgpO1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgaXNGYXYgPSBhd2FpdCByZXBvLnRvZ2dsZUZhdm9yaXRlKHVzZXIuaWQsIHJlY2lwZUlkKTtcclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL3JlY2lwZXMnKTtcclxuICAgIHJldmFsaWRhdGVQYXRoKGAvcmVjaXBlcy8ke3JlY2lwZUlkfWApO1xyXG5cclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGlzRmF2b3JpdGU6IGlzRmF2IH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGxvZ0Vycm9yKCdFcnJvciB1cGRhdGluZyBmYXZvcml0ZScsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciB1cGRhdGluZyBmYXZvcml0ZVwiIH07XHJcbiAgfVxyXG5cclxuXHJcbn1cclxuLy8g4pyFIEFxdWVzdGEgYWNjacOzIHN1YnN0aXR1ZWl4IGxhIGzDsmdpY2EgY29tcGxleGEgcXVlIHRlbmllcyBhYmFucy5cclxuLy8gQXJhIGZhIHNlcnZpciBsJ2VzdHJhdMOoZ2lhIEjDrWJyaWRhIChCRCArIElBKSBxdWUgaGVtIGRlZmluaXQgYWwgU2VydmljZS5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlTWVudUFjdGlvbihcclxuICB1c2VySWQ6IHN0cmluZyxcclxuICBkaXNoTmFtZTogc3RyaW5nLFxyXG4gIG1vZGU6ICdGQVRFJyB8ICdDSEVGJyxcclxuICBlbmVyZ3k6IG51bWJlciA9IDUwLFxyXG4gIHRpbWU6IG51bWJlciA9IDMwLFxyXG4gIGxhbmc6IHN0cmluZyA9ICdjYSdcclxuKSB7XHJcbiAgZGVidWcoJ1tBQ1RJT05dIGdlbmVyYXRlTWVudUFjdGlvbicpO1xyXG5cclxuICAvLyAxLiBWQUxJREFDScOTIChab2QpXHJcbiAgY29uc3QgdmFsaWRhdGlvbiA9IEdlbmVyYXRlUmVjaXBlU2NoZW1hLnNhZmVQYXJzZSh7IHVzZXJJZCwgZGlzaE5hbWUsIGxhbmcgfSk7XHJcbiAgaWYgKCF2YWxpZGF0aW9uLnN1Y2Nlc3MpIHtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogdmFsaWRhdGlvbi5lcnJvci5pc3N1ZXNbMF0ubWVzc2FnZSB9O1xyXG4gIH1cclxuXHJcbiAgLy8gMi4gU0VHVVJFVEFUIChSYXRlIExpbWl0KVxyXG4gIGNvbnN0IGxpbWl0ZXIgPSBuZXcgU3VwYWJhc2VSYXRlTGltaXRlcigpO1xyXG4gIGNvbnN0IGxvZ2dlciA9IG5ldyBTdXBhYmFzZVNlY3VyaXR5TG9nZ2VyKCk7XHJcblxyXG4gIGNvbnN0IGNhblByb2NlZWQgPSBhd2FpdCBsaW1pdGVyLmNoZWNrKGBnZW46JHt1c2VySWR9YCwgMjAsIDM2MDApOyAvLyA1IGNvcHMvaG9yYVxyXG4gIGlmICghY2FuUHJvY2VlZCkge1xyXG4gICAgYXdhaXQgbG9nZ2VyLmxvZygnV0FSTicsICdSQVRFX0xJTUlUJywgdXNlcklkLCB7IGFjdGlvbjogJ2dlbmVyYXRlX21lbnUnIH0pO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkzDrW1pdCBzdXBlcmF0LiBFc3BlcmEgdW5hIGVzdG9uYS5cIiB9O1xyXG4gIH1cclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCBzZXJ2aWNlID0gY29udGFpbmVyLmdldEdlbmVyYXRlTWVudVNlcnZpY2Uoc3VwYWJhc2UpO1xyXG5cclxuICAgIC8vIEVYRUNVVEVNIEVMIFNFUlZFSSAoTCdPcmNoZXN0cmF0b3IgZGVjaWRlaXggaW50ZXJuYW1lbnQpXHJcbiAgICBjb25zdCByZWNpcGVzID0gYXdhaXQgc2VydmljZS5leGVjdXRlKFxyXG4gICAgICB1c2VySWQsXHJcbiAgICAgIG1vZGUsXHJcbiAgICAgIGRpc2hOYW1lLFxyXG4gICAgICBlbmVyZ3ksXHJcbiAgICAgIHRpbWUsXHJcbiAgICAgIGxhbmdcclxuICAgICk7XHJcblxyXG4gICAgLy8gQ09OVkVSU0nDkyBBIFBSSU1JVElWRVNcclxuICAgIC8vIDEuIENvbnZlcnRpbSBhIHByaW1pdGl2ZXMgKGFpeMOyIGphIGhvIGZhcylcclxuICAgIGNvbnN0IHBsYWluUmVjaXBlcyA9IHJlY2lwZXMubWFwKHIgPT4gci50b1ByaW1pdGl2ZXMoKSk7XHJcblxyXG4gICAgLy8gMi4g4pqg77iPIEFTU0VHVVJBJ1QgUVVFIGVzdGltYXRlZENvc3QgRVhJU1RFSVggQVFVw40g4pqg77iPXHJcbiAgICAvLyBTaSBwbGFpblJlY2lwZXNbMF0uZXN0aW1hdGVkQ29zdCDDqXMgdW5kZWZpbmVkLCBKU09OLnN0cmluZ2lmeSBsJ2VzYm9ycmFyw6AhXHJcbiAgICBpZiAocGxhaW5SZWNpcGVzLmxlbmd0aCA+IDAgJiYgcGxhaW5SZWNpcGVzWzBdLmVzdGltYXRlZENvc3QgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICBsb2dFcnJvcihcIuKaoO+4jyBBTEVSVEE6IGVzdGltYXRlZENvc3Qgw6lzIHVuZGVmaW5lZCBhYmFucyBkJ2VudmlhciBhbCBjbGllbnQhXCIpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIDMuIFNhbml0aXR6YWNpw7NcclxuICAgIGNvbnN0IGNsZWFuUmVjaXBlcyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkocGxhaW5SZWNpcGVzKSk7XHJcblxyXG4gICAgZGVidWcoJ1tBQ1RJT05dIGdlbmVyYXRlTWVudUFjdGlvbiBkb25lJyk7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogdHJ1ZSxcclxuICAgICAgcmVjaXBlczogY2xlYW5SZWNpcGVzXHJcbiAgICB9O1xyXG5cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ+KdjCBbQUNUSU9OIEVSUk9SXTonLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRXJyb3IgZ2VuZXJhbnQgZWwgbWVuw7ouXCIgfTtcclxuICB9XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1hdGVyaWFsaXplUmVjaXBlQWN0aW9uKHJhd0FpUmVjaXBlOiB1bmtub3duKTogUHJvbWlzZTxBY3Rpb25SZXNwb25zZT4ge1xyXG4gIGNvbnN0IHBhcnNlZCA9IE1hdGVyaWFsaXplUmVjaXBlU2NoZW1hLnNhZmVQYXJzZShyYXdBaVJlY2lwZSk7XHJcbiAgaWYgKCFwYXJzZWQuc3VjY2Vzcykge1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBwYXJzZWQuZXJyb3IuaXNzdWVzWzBdLm1lc3NhZ2UgfTtcclxuICB9XHJcblxyXG4gIGNvbnN0IHJlY2lwZURhdGEgPSBwYXJzZWQuZGF0YTtcclxuICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG5cclxuICAvLyDwn5SNIDEuIFBBUyBERSBERURVUExJQ0FDScOTOiBCdXNxdWVtIHNpIGphIGV4aXN0ZWl4XHJcbiAgdHJ5IHtcclxuICAgICAgY29uc3QgeyBkYXRhOiBleGlzdGluZyB9ID0gYXdhaXQgc3VwYWJhc2VcclxuICAgICAgICAgIC5mcm9tKCdzYXZlZF9yZWNpcGVzJylcclxuICAgICAgICAgIC5zZWxlY3QoJ2lkJylcclxuICAgICAgICAgIC5lcSgnbmFtZScsIHJlY2lwZURhdGEubmFtZSkgLy8gTWF0ZWl4IG5vbVxyXG4gICAgICAgICAgLmVxKCdpc19haV9nZW5lcmF0ZWQnLCB0cnVlKSAvLyBRdWUgc2lndWkgZGUgbGEgSUFcclxuICAgICAgICAgIC5lcSgnaXNfcHVibGljJywgdHJ1ZSkgLy8gUXVlIHNpZ3VpIGNvbXBhcnRpZGFcclxuICAgICAgICAgIC5saW1pdCgxKVxyXG4gICAgICAgICAgLnNpbmdsZSgpO1xyXG5cclxuICAgICAgaWYgKGV4aXN0aW5nKSB7XHJcbiAgICAgICAgICBkZWJ1ZygnW0FDVElPTl0gZGVkdXBsaWNhdGUgaGl0Jyk7XHJcbiAgICAgICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCByZWNpcGVJZDogZXhpc3RpbmcuaWQgfTtcclxuICAgICAgfVxyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgbG9nRXJyb3IoJ01hdGVyaWFsaXplUmVjaXBlQWN0aW9uIGVycm9yJywgZXJyKTtcclxuICAgICAgLy8gSWdub3JlbSBlcnJvcnMgZGUgY29uc3VsdGEgKGV4OiBubyB0cm9iYXQpLCBzZWd1aW0gZW5kYXZhbnQgcGVyIGNyZWFyLWxhXHJcbiAgfVxyXG5cclxuICAvLyDwn4yKIDIuIEZMVVggRCdFTlJJUVVJTUVOVCAoSWd1YWwgcXVlIHRlbmllcylcclxuICAvLyBTaSBubyBleGlzdGVpeCwgbCdoZW0gZGUgY3JlYXIgaSBlbnJpcXVpclxyXG4gIGNvbnN0IGVucmljaGVkSW5ncmVkaWVudHMgPSBhd2FpdCBQcm9taXNlLmFsbCgocmVjaXBlRGF0YS5pbmdyZWRpZW50cyB8fCBbXSkubWFwKGFzeW5jIChpbmcpID0+IHtcclxuICAgICAgbGV0IGxpbmtlZFByb2R1Y3RJZCA9IGluZy5saW5rZWRQcm9kdWN0SWQ7XHJcbiAgICAgIGxldCBsaW5rZWRQcm9kdWN0SW1hZ2UgPSBpbmcubGlua2VkUHJvZHVjdEltYWdlO1xyXG4gICAgICBsZXQgZXN0aW1hdGVkQ29zdCA9IGluZy5lc3RpbWF0ZWRDb3N0O1xyXG5cclxuICAgICAgaWYgKCFsaW5rZWRQcm9kdWN0SWQgfHwgIWxpbmtlZFByb2R1Y3RJbWFnZSkge1xyXG4gICAgICAgICAgY29uc3QgeyBkYXRhOiBtYXRjaCB9ID0gYXdhaXQgc3VwYWJhc2VcclxuICAgICAgICAgICAgICAuZnJvbSgncHJvZHVjdF9jYXRhbG9nJylcclxuICAgICAgICAgICAgICAuc2VsZWN0KCdpZCwgaW1hZ2VfdXJsLCBwcmljZScpXHJcbiAgICAgICAgICAgICAgLmlsaWtlKCduYW1lJywgYCUke2luZy5uYW1lfSVgKVxyXG4gICAgICAgICAgICAgIC5saW1pdCgxKVxyXG4gICAgICAgICAgICAgIC5zaW5nbGUoKTtcclxuXHJcbiAgICAgICAgICBpZiAobWF0Y2gpIHtcclxuICAgICAgICAgICAgICBsaW5rZWRQcm9kdWN0SWQgPSBtYXRjaC5pZDtcclxuICAgICAgICAgICAgICBsaW5rZWRQcm9kdWN0SW1hZ2UgPSBtYXRjaC5pbWFnZV91cmw7XHJcbiAgICAgICAgICAgICAgaWYgKCFlc3RpbWF0ZWRDb3N0ICYmIG1hdGNoLnByaWNlKSBlc3RpbWF0ZWRDb3N0ID0gbWF0Y2gucHJpY2U7IFxyXG4gICAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgbmFtZTogaW5nLm5hbWUsXHJcbiAgICAgICAgICBxdWFudGl0eTogaW5nLnF1YW50aXR5LFxyXG4gICAgICAgICAgdW5pdDogaW5nLnVuaXQsXHJcbiAgICAgICAgICBlbW9qaTogaW5nLmVtb2ppLFxyXG4gICAgICAgICAgZXN0aW1hdGVkQ29zdDogZXN0aW1hdGVkQ29zdCxcclxuICAgICAgICAgIGxpbmtlZFByb2R1Y3RJZDogbGlua2VkUHJvZHVjdElkLFxyXG4gICAgICAgICAgbGlua2VkUHJvZHVjdEltYWdlOiBsaW5rZWRQcm9kdWN0SW1hZ2UsXHJcbiAgICAgIH07XHJcbiAgfSkpO1xyXG5cclxuICAvLyDwn5K+IDMuIFBSRVBBUkFSIFBFUiBHVUFSREFSXHJcbiAgY29uc3QgaW5wdXQ6IFNhdmVSZWNpcGVJbnB1dCA9IHtcclxuICAgIG5hbWU6IHJlY2lwZURhdGEubmFtZSxcclxuICAgIHByZXBUaW1lTWludXRlczogcmVjaXBlRGF0YS5wcmVwVGltZU1pbnV0ZXMgfHwgMzAsXHJcbiAgICB0YWdzOiByZWNpcGVEYXRhLnRhZ3MgfHwgW10sXHJcbiAgICBkaWV0YXJ5VGFnczogcmVjaXBlRGF0YS5kaWV0YXJ5VGFncyB8fCBbXSxcclxuICAgIGlzQWlHZW5lcmF0ZWQ6IHRydWUsXHJcbiAgICBzdGVwczogcmVjaXBlRGF0YS5zdGVwcyB8fCBbXSxcclxuICAgIGluZ3JlZGllbnRzOiBlbnJpY2hlZEluZ3JlZGllbnRzXHJcbiAgfTtcclxuXHJcbiAgLy8g8J+UpSBUUlVDIEZJTkFMOiBHdWFyZGVtIGNvbSBhIFDDmkJMSUNBP1xyXG4gIC8vIFPDrSwgcGVycXXDqCBzaSB1biBhbHRyZSB1c3VhcmkgZGUgbGEgc2FsYSBmYSBjbGljLCB2b2xlbSBxdWUgdHJvYmkgYXF1ZXN0YSByZWNlcHRhIChQYXMgMSlcclxuICAvLyBpIG5vIGVuIGNyZcOvIHVuYSBkZSBub3ZhLlxyXG4gIC8vIE1vZGlmaXF1ZW0gc2F2ZVJlY2lwZUFjdGlvbiBwZXJxdcOoIGFjY2VwdGkgJ2lzUHVibGljJyBvIGhvIGZvcmNlbSBhIGxhIGzDsmdpY2EgZGUgc2F2ZS5cclxuICBcclxuICAvLyBPcGNpw7MgQTogU2kgc2F2ZVJlY2lwZUFjdGlvbiBhY2NlcHRhIGlzUHVibGljIGFsIGlucHV0LCBwYXNzYS1sJ2hpLlxyXG4gIC8vIE9wY2nDsyBCIChIYWNrIHLDoHBpZCk6IFNhdmVSZWNpcGVBY3Rpb24gcGVyIGRlZmVjdGUgbGVzIGZhIHByaXZhZGVzLiBcclxuICAvLyBQZXLDsiBjb20gcXVlIHJldG9ybmEgbCdJRCwgcG9kZW0gZmVyIHVuIHVwZGF0ZSByw6BwaWQgYXF1w60gcGVyIGZlci1sYSBww7pibGljYS5cclxuICBcclxuICBjb25zdCBzYXZlUmVzdWx0ID0gYXdhaXQgc2F2ZVJlY2lwZUFjdGlvbihpbnB1dCk7XHJcblxyXG4gIGlmIChzYXZlUmVzdWx0LnN1Y2Nlc3MgJiYgc2F2ZVJlc3VsdC5yZWNpcGVJZCkge1xyXG4gICAgICAvLyBMYSBmZW0gcMO6YmxpY2EgcGVycXXDqCBsYSB0cm9iaW4gZWxzIGFsdHJlcyBjb21wYW55cyBkZSBsYSBzYWxhXHJcbiAgICAgIGF3YWl0IHN1cGFiYXNlXHJcbiAgICAgICAgICAuZnJvbSgnc2F2ZWRfcmVjaXBlcycpXHJcbiAgICAgICAgICAudXBkYXRlKHsgaXNfcHVibGljOiB0cnVlIH0pXHJcbiAgICAgICAgICAuZXEoJ2lkJywgc2F2ZVJlc3VsdC5yZWNpcGVJZCk7XHJcbiAgICAgICAgICBcclxuICAgICAgZGVidWcoJ1tBQ1RJT05dIHJlY2lwZSBzaGFyZWQnKTtcclxuICB9XHJcblxyXG4gIHJldHVybiBzYXZlUmVzdWx0O1xyXG59XHJcblxyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6InNTQWtLc0IsaU1BQUEifQ==
}),
"[project]/features/recipes/components/FavoriteButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FavoriteButton",
    ()=>FavoriteButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/heart.js [app-client] (ecmascript) <export default as Heart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$0c6092__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:0c6092 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/sonner@2.0.7_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// ARXIU: src/components/recipes/FavoriteButton.tsx
'use client';
;
;
;
;
;
function FavoriteButton({ recipeId, initialIsFavorite, className = "", testId }) {
    _s();
    const [isFav, setIsFav] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialIsFavorite);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleToggle = async (e)=>{
        e.preventDefault(); // Evitem obrir la recepta si estem a la card
        e.stopPropagation();
        if (isLoading) return;
        // UI Optimista (Canviem visualment JA)
        const newState = !isFav;
        setIsFav(newState);
        setIsLoading(true);
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$0c6092__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["toggleFavoriteAction"])(recipeId);
        if (!result.success) {
            // Si falla, revertim
            setIsFav(!newState);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Error guardant favorit");
        }
        setIsLoading(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
        whileTap: {
            scale: 0.8
        },
        onClick: handleToggle,
        disabled: isLoading,
        "data-testid": testId,
        className: `
                flex items-center justify-center rounded-full p-2 transition-all
                ${isFav ? 'bg-rose-500/10 text-rose-500 hover:bg-rose-500/20' : 'bg-slate-800/80 text-slate-400 hover:bg-slate-700 hover:text-white'}
                ${className}
            `,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__["Heart"], {
            size: 18,
            className: isFav ? "fill-current" : "",
            strokeWidth: 2.5
        }, void 0, false, {
            fileName: "[project]/features/recipes/components/FavoriteButton.tsx",
            lineNumber: 57,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/features/recipes/components/FavoriteButton.tsx",
        lineNumber: 44,
        columnNumber: 9
    }, this);
}
_s(FavoriteButton, "lpPFOyr0JKcZ1BL4wUu/Dl5So4A=");
_c = FavoriteButton;
var _c;
__turbopack_context__.k.register(_c, "FavoriteButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/RecipeDetailView.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RecipeDetailView",
    ()=>RecipeDetailView
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$parts$2f$RecipeHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/parts/RecipeHeader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$parts$2f$IngredientsPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/parts/IngredientsPanel.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$parts$2f$StepsPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/parts/StepsPanel.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$BackButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/BackButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$euro$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Euro$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/euro.js [app-client] (ecmascript) <export default as Euro>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/square-pen.js [app-client] (ecmascript) <export default as Edit>");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$FavoriteButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/FavoriteButton.tsx [app-client] (ecmascript)");
// src/features/recipes/components/RecipeDetailView.tsx
'use client';
;
;
;
;
;
;
;
;
;
function RecipeDetailView({ recipe, inventory, userId }) {
    // Casting segur per accedir a les metadades
    const extendedRecipe = recipe;
    const cost = extendedRecipe.estimatedCost || 0;
    const emoji = (0, __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$parts$2f$RecipeHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getEmoji"])(recipe.name);
    const isAuthor = recipe.authorId === userId;
    // 🔍 DEBUG: Això ens dirà si les dades arriben bé del servidor
    console.group("🔍 [RecipeDetailView] Debug");
    console.log("Recepta:", recipe.name);
    console.log("Ingredients (Raw):", extendedRecipe.ingredients);
    extendedRecipe.ingredients.forEach((ing, i)=>{
        if (ing.linkedProductImage) {
            console.log(`✅ Ingredient ${i} (${ing.name}) té IMATGE VINCULADA:`, ing.linkedProductImage);
        } else if (ing.image) {
            console.log(`ℹ️ Ingredient ${i} (${ing.name}) té imatge genèrica:`, ing.image);
        } else {
            console.log(`⚠️ Ingredient ${i} (${ing.name}) NO té imatge.`);
        }
    });
    console.groupEnd();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col gap-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "lg:hidden sticky top-0 z-50 bg-slate-950/80 backdrop-blur-md border-b border-slate-800 p-3 shadow-xl",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "shrink-0",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$BackButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BackButton"], {
                                className: "bg-slate-800 text-white p-2 rounded-full",
                                label: ""
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                lineNumber: 55,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                            lineNumber: 54,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-1 min-w-0 flex flex-col justify-center mr-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xl leading-none",
                                            children: emoji
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                            lineNumber: 60,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                            className: "text-sm font-black text-white truncate leading-tight",
                                            children: recipe.name
                                        }, void 0, false, {
                                            fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                            lineNumber: 61,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                    lineNumber: 59,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-3 text-[10px] text-slate-400 font-mono mt-0.5",
                                    children: [
                                        recipe.prepTimeMinutes > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "flex items-center gap-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"], {
                                                    size: 10
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                                    lineNumber: 65,
                                                    columnNumber: 67
                                                }, this),
                                                " ",
                                                recipe.prepTimeMinutes,
                                                "m"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                            lineNumber: 65,
                                            columnNumber: 25
                                        }, this),
                                        cost > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "flex items-center gap-1 text-emerald-400",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$euro$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Euro$3e$__["Euro"], {
                                                    size: 10
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                                    lineNumber: 68,
                                                    columnNumber: 84
                                                }, this),
                                                " ",
                                                cost.toFixed(2),
                                                "€"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                            lineNumber: 68,
                                            columnNumber: 25
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                    lineNumber: 63,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                            lineNumber: 58,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2 shrink-0",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$FavoriteButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FavoriteButton"], {
                                    recipeId: recipe.id,
                                    initialIsFavorite: !!recipe.isFavorite,
                                    testId: "recipe-favorite-button",
                                    className: "w-8 h-8 bg-slate-800 border border-slate-700"
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                    lineNumber: 74,
                                    columnNumber: 17
                                }, this),
                                isAuthor && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: `/recipes/${recipe.id}/edit`,
                                    "data-testid": "recipe-edit-link",
                                    className: "w-8 h-8 flex items-center justify-center rounded-full bg-purple-600/20 text-purple-400 border border-purple-500/30 hover:bg-purple-600 hover:text-white transition-colors",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__["Edit"], {
                                        size: 14
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                        lineNumber: 86,
                                        columnNumber: 25
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                    lineNumber: 81,
                                    columnNumber: 21
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                            lineNumber: 73,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                    lineNumber: 53,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                lineNumber: 52,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4 max-w-6xl",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "hidden lg:flex items-start gap-4 mb-8 relative pt-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "shrink-0 flex flex-col gap-3 sticky top-8 z-10",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$BackButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BackButton"], {
                                        label: "Tornar",
                                        className: "bg-slate-900/50 hover:bg-slate-800 border border-slate-700 text-slate-300 px-4 py-2 rounded-xl transition-all"
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                        lineNumber: 97,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 mt-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$FavoriteButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FavoriteButton"], {
                                                recipeId: recipe.id,
                                                initialIsFavorite: !!recipe.isFavorite,
                                                testId: "recipe-favorite-button",
                                                className: "w-10 h-10 bg-slate-900 border border-slate-700 hover:border-rose-500/50"
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                                lineNumber: 99,
                                                columnNumber: 21
                                            }, this),
                                            isAuthor && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: `/recipes/${recipe.id}/edit`,
                                                "data-testid": "recipe-edit-link",
                                                className: "w-10 h-10 flex items-center justify-center rounded-full bg-slate-900 text-slate-400 hover:bg-purple-600 hover:text-white transition-all border border-slate-700 hover:border-purple-500",
                                                title: "Editar Recepta",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__["Edit"], {
                                                    size: 18
                                                }, void 0, false, {
                                                    fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                                    lineNumber: 107,
                                                    columnNumber: 29
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                                lineNumber: 106,
                                                columnNumber: 25
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                        lineNumber: 98,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                lineNumber: 96,
                                columnNumber: 14
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                className: "flex-1 ml-4",
                                initial: {
                                    opacity: 0,
                                    y: -20
                                },
                                animate: {
                                    opacity: 1,
                                    y: 0
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$parts$2f$RecipeHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RecipeHeader"], {
                                    name: recipe.name,
                                    prepTime: recipe.prepTimeMinutes,
                                    tags: recipe.tags,
                                    estimatedCost: cost,
                                    authorName: extendedRecipe.authorName || "Xef Anònim"
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                    lineNumber: 114,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                lineNumber: 113,
                                columnNumber: 14
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                        lineNumber: 95,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start pb-20",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                initial: {
                                    opacity: 0,
                                    x: -20
                                },
                                animate: {
                                    opacity: 1,
                                    x: 0
                                },
                                transition: {
                                    delay: 0.2
                                },
                                className: "lg:col-span-4 lg:sticky lg:top-8 z-40",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$parts$2f$IngredientsPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IngredientsPanel"], {
                                    ingredients: extendedRecipe.ingredients,
                                    inventory: inventory,
                                    userId: userId
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                    lineNumber: 126,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                lineNumber: 125,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                initial: {
                                    opacity: 0,
                                    x: 20
                                },
                                animate: {
                                    opacity: 1,
                                    x: 0
                                },
                                transition: {
                                    delay: 0.3
                                },
                                className: "lg:col-span-8",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$parts$2f$StepsPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StepsPanel"], {
                                    steps: recipe.steps,
                                    ingredients: extendedRecipe.ingredients
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                    lineNumber: 134,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                                lineNumber: 133,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                        lineNumber: 124,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
                lineNumber: 93,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/RecipeDetailView.tsx",
        lineNumber: 50,
        columnNumber: 5
    }, this);
}
_c = RecipeDetailView;
var _c;
__turbopack_context__.k.register(_c, "RecipeDetailView");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_1b619bf1._.js.map