(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_734d2bc7._.js",
  "static/chunks/node_modules__pnpm_7d308f28._.js"
],
    source: "dynamic"
});
