(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_1b619bf1._.js",
  "static/chunks/node_modules__pnpm_feaf0f00._.js"
],
    source: "dynamic"
});
