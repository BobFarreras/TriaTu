(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_f7ab49bf._.js",
  "static/chunks/node_modules__pnpm_3669eeb2._.js"
],
    source: "dynamic"
});
