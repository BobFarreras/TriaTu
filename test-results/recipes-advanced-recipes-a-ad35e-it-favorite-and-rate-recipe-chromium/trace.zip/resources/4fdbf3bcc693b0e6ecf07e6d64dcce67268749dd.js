(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/actions/data:7faccf [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "rateRecipeAction",
    ()=>$$RSC_SERVER_ACTION_1
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"60ba277e7c0eda765900dddd4ae1807ed491019130":"rateRecipeAction"},"app/actions/community.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("60ba277e7c0eda765900dddd4ae1807ed491019130", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "rateRecipeAction");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vY29tbXVuaXR5LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9hcHAvYWN0aW9ucy9jb21tdW5pdHkudHMgKG8gb24gdGluZ3VpcyBsZXMgYWN0aW9ucylcclxuJ3VzZSBzZXJ2ZXInXHJcblxyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gJ25leHQvY2FjaGUnO1xyXG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tICdAL2FkYXB0ZXJzL3N1cGFiYXNlL3NlcnZlcic7XHJcbmltcG9ydCB7IFN1cGFiYXNlUmVjaXBlUmVwb3NpdG9yeSB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2UvU3VwYWJhc2VSZWNpcGVSZXBvc2l0b3J5JztcclxuaW1wb3J0IHsgUHVibGlzaFJlY2lwZSB9IGZyb20gJ0AvY29yZS91c2VjYXNlcy9jb21tdW5pdHkvUHVibGlzaFJlY2lwZSc7XHJcbmltcG9ydCB7IFJhdGVSZWNpcGUgfSBmcm9tICdAL2NvcmUvdXNlY2FzZXMvY29tbXVuaXR5L1JhdGVSZWNpcGUnO1xyXG5cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwdWJsaXNoUmVjaXBlQWN0aW9uKGZvcm1EYXRhOiBGb3JtRGF0YSkge1xyXG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcblxyXG4gIGlmICghdXNlcikgcmV0dXJuIHsgZXJyb3I6IFwiSGFzIGQnaW5pY2lhciBzZXNzacOzLlwiIH07XHJcblxyXG4gIGNvbnN0IG5hbWUgPSBmb3JtRGF0YS5nZXQoJ3RpdGxlJykgYXMgc3RyaW5nO1xyXG4gIGNvbnN0IGluZ3JlZGllbnRzSnNvbiA9IGZvcm1EYXRhLmdldCgnaW5ncmVkaWVudHMnKSBhcyBzdHJpbmc7XHJcbiAgY29uc3Qgc3RlcHNKc29uID0gZm9ybURhdGEuZ2V0KCdzdGVwcycpIGFzIHN0cmluZztcclxuICBjb25zdCBwcmVwVGltZSA9IGZvcm1EYXRhLmdldCgncHJlcFRpbWUnKSA/IHBhcnNlSW50KGZvcm1EYXRhLmdldCgncHJlcFRpbWUnKSBhcyBzdHJpbmcpIDogMTU7XHJcbiAgY29uc3QgZGlmZmljdWx0eSA9IGZvcm1EYXRhLmdldCgnZGlmZmljdWx0eScpIGFzIHN0cmluZzsgLy8gQWl4w7IgYW5pcsOgIGEgJ3RhZ3MnXHJcblxyXG4gIGlmICghbmFtZSB8fCAhaW5ncmVkaWVudHNKc29uIHx8ICFzdGVwc0pzb24pIHtcclxuICAgIHJldHVybiB7IGVycm9yOiBcIkZhbHRlbiBkYWRlcyBvYmxpZ2F0w7JyaWVzLlwiIH07XHJcbiAgfVxyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgaW5ncmVkaWVudHMgPSBKU09OLnBhcnNlKGluZ3JlZGllbnRzSnNvbik7XHJcbiAgICBjb25zdCBzdGVwcyA9IEpTT04ucGFyc2Uoc3RlcHNKc29uKTtcclxuXHJcbiAgICAvLyBUYWdzIGdlbmVyYWxzXHJcbiAgICBjb25zdCB0YWdzOiBzdHJpbmdbXSA9IFsnQ29tdW5pdGF0J107XHJcbiAgICBpZiAoZGlmZmljdWx0eSkgdGFncy5wdXNoKGRpZmZpY3VsdHkpO1xyXG5cclxuICAgIC8vIFRhZ3MgZGlldMOodGljcyAoc2kgZW4gdGluZ3Vlc3NpcyBhbCBmb3JtdWxhcmksIGVscyBleHRyYXVyaWVzIGFxdcOtKVxyXG4gICAgY29uc3QgZGlldGFyeVRhZ3M6IHN0cmluZ1tdID0gW107IFxyXG5cclxuICAgIGNvbnN0IHJlcG8gPSBuZXcgU3VwYWJhc2VSZWNpcGVSZXBvc2l0b3J5KCk7XHJcbiAgICBjb25zdCB1c2VDYXNlID0gbmV3IFB1Ymxpc2hSZWNpcGUocmVwbyk7XHJcbiAgICBcclxuICAgIGF3YWl0IHVzZUNhc2UuZXhlY3V0ZSh1c2VyLmlkLCB7XHJcbiAgICAgIG5hbWUsXHJcbiAgICAgIGluZ3JlZGllbnRzLFxyXG4gICAgICBzdGVwcyxcclxuICAgICAgdGFncyxcclxuICAgICAgZGlldGFyeVRhZ3MsIC8vIFBBU1NFTSBFTFMgTk9VUyBDQU1QU1xyXG4gICAgICBwcmVwVGltZU1pbnV0ZXM6IHByZXBUaW1lLCBcclxuICAgICAgaXNQdWJsaWM6IHRydWUgLy8gRGVmaW5pbSBleHBsw61jaXRhbWVudCBxdWUgw6lzIHDDumJsaWNhXHJcbiAgICB9KTtcclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL2NvbW11bml0eScpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG4gIH0gY2F0Y2ggKGU6IHVua25vd24pIHtcclxuICAgIHJldHVybiB7IGVycm9yOiBlIGluc3RhbmNlb2YgRXJyb3IgPyBlLm1lc3NhZ2UgOiBcIkVycm9yIGRlc2NvbmVndXRcIiB9O1xyXG4gIH1cclxufVxyXG4vKipcclxuICogQWNjacOzIHBlciBwdW50dWFyIHVuYSByZWNlcHRhLlxyXG4gKiBBY3R1YSBjb20gYSBDb250cm9sbGVyOiBBdXRoIC0+IFVzZUNhc2UgLT4gUmVzcG9uc2VcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByYXRlUmVjaXBlQWN0aW9uKHJlY2lwZUlkOiBzdHJpbmcsIHZhbHVlOiBudW1iZXIpIHtcclxuICAvLyAxLiBWYWxpZGFjacOzIGQnaW5mcmFlc3RydWN0dXJhIChBdXRoKVxyXG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XHJcblxyXG4gIGlmICghdXNlcikge1xyXG4gICAgcmV0dXJuIHsgZXJyb3I6IFwiSGFzIGQnaW5pY2lhciBzZXNzacOzIHBlciB2b3Rhci5cIiB9O1xyXG4gIH1cclxuXHJcbiAgLy8gMi4gVmFsaWRhY2nDsyBiw6BzaWNhIGQnaW5wdXRzIChCb3VuZGFyeSBjaGVjaylcclxuICBpZiAoIXJlY2lwZUlkIHx8IHZhbHVlIDwgMSB8fCB2YWx1ZSA+IDUpIHtcclxuICAgIHJldHVybiB7IGVycm9yOiBcIkRhZGVzIGRlIHZvdGFjacOzIGluY29ycmVjdGVzLlwiIH07XHJcbiAgfVxyXG5cclxuICB0cnkge1xyXG4gICAgLy8gMy4gSW5zdGFuY2lhY2nDsyBkZSBkZXBlbmRlbmNpZXMgKERlcGVuZGVuY3kgSW5qZWN0aW9uIG1hbnVhbClcclxuICAgIGNvbnN0IHJlcG8gPSBuZXcgU3VwYWJhc2VSZWNpcGVSZXBvc2l0b3J5KCk7XHJcbiAgICBjb25zdCB1c2VDYXNlID0gbmV3IFJhdGVSZWNpcGUocmVwbyk7XHJcblxyXG4gICAgLy8gNC4gRXhlY3VjacOzIGRlbCBDYXMgZCfDmnNcclxuICAgIGF3YWl0IHVzZUNhc2UuZXhlY3V0ZSh7XHJcbiAgICAgIHVzZXJJZDogdXNlci5pZCxcclxuICAgICAgcmVjaXBlSWQ6IHJlY2lwZUlkLFxyXG4gICAgICB2YWx1ZTogdmFsdWUsXHJcbiAgICAgIGNvbW1lbnQ6IFwiXCIgLy8gRGUgbW9tZW50IGxhIFVJIG5vIGVudmlhIGNvbWVudGFyaSwgaG8gZGVpeGVtIGJ1aXQgbyBvcGNpb25hbFxyXG4gICAgfSk7XHJcblxyXG4gICAgLy8gNS4gUmV2YWxpZGFjacOzXHJcbiAgICAvLyBJbXBvcnRhbnQ6IEFjdHVhbGl0emVtIGxhIHJ1dGEgcGVycXXDqCBlcyByZWNhbGN1bGkgbGEgbWl0amFuYSB2aXN1YWxtZW50XHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL2NvbW11bml0eScpOyBcclxuICAgIC8vIE8gc2kgdGVucyB1bmEgcMOgZ2luYSBkZSBkZXRhbGw6IHJldmFsaWRhdGVQYXRoKGAvY29tbXVuaXR5LyR7cmVjaXBlSWR9YCk7XHJcblxyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG5cclxuICB9IGNhdGNoIChlOiB1bmtub3duKSB7XHJcbiAgICAvLyA2LiBHZXN0acOzIGQnZXJyb3JzIGRlIGRvbWluaVxyXG4gICAgLy8gU2kgZWwgVXNlQ2FzZSBsbGFuw6dhIFwiTGEgcmVjZXB0YSBubyBleGlzdGVpeFwiIG8gXCJQdW50dWFjacOzIGludsOgbGlkYVwiLCBobyBjYXB0dXJlbSBhcXXDrS5cclxuICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IGUgaW5zdGFuY2VvZiBFcnJvciA/IGUubWVzc2FnZSA6IFwiRXJyb3IgYWwgZ3VhcmRhciBlbCB2b3RcIjtcclxuICAgIHJldHVybiB7IGVycm9yOiBlcnJvck1lc3NhZ2UgfTtcclxuICB9XHJcbn0iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjZSQTREc0IsNkxBQUEifQ==
}),
"[project]/features/recipes/components/StarRating.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StarRating",
    ()=>StarRating
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$7faccf__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:7faccf [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/sonner@2.0.7_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function StarRating({ recipeId, initialUserRating, average, count, testIdPrefix }) {
    _s();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [userRating, setUserRating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialUserRating || 0);
    const handleRate = async (e, value)=>{
        e.preventDefault();
        e.stopPropagation();
        if (loading) return;
        setLoading(true);
        // Optimistic UI update
        const previousRating = userRating;
        setUserRating(value);
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$7faccf__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["rateRecipeAction"])(recipeId, value);
        if (result?.error) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(result.error);
            setUserRating(previousRating);
        } else {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success('Vot guardat! ⭐');
        }
        setLoading(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-3 z-20 relative bg-black/20 px-3 py-1.5 rounded-xl border border-white/5 backdrop-blur-sm",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-1",
                children: [
                    1,
                    2,
                    3,
                    4,
                    5
                ].map((star)=>{
                    const isFilled = star <= (userRating || Math.round(average));
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
                        whileHover: {
                            scale: 1.3,
                            rotate: 10
                        },
                        whileTap: {
                            scale: 0.8
                        },
                        onClick: (e)=>handleRate(e, star),
                        disabled: loading,
                        "data-testid": testIdPrefix ? `${testIdPrefix}-star-${star}` : undefined,
                        className: `focus:outline-none text-2xl leading-none transition-colors ${isFilled ? 'text-yellow-400 drop-shadow-[0_0_5px_rgba(250,204,21,0.6)]' : 'text-slate-700 hover:text-yellow-200'}`,
                        children: "★"
                    }, star, false, {
                        fileName: "[project]/features/recipes/components/StarRating.tsx",
                        lineNumber: 48,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/StarRating.tsx",
                lineNumber: 44,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col leading-none",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-xs font-bold text-white font-mono",
                        children: average.toFixed(1)
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/StarRating.tsx",
                        lineNumber: 68,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[9px] text-slate-500",
                        children: [
                            "(",
                            count,
                            ")"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/StarRating.tsx",
                        lineNumber: 71,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/StarRating.tsx",
                lineNumber: 67,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/StarRating.tsx",
        lineNumber: 43,
        columnNumber: 5
    }, this);
}
_s(StarRating, "5vv9w27/Oqp5ZRCrYYAbPV5XKWo=");
_c = StarRating;
var _c;
__turbopack_context__.k.register(_c, "StarRating");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/utils/emojiUtils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getIngredientEmoji",
    ()=>getIngredientEmoji,
    "getMainEmoji",
    ()=>getMainEmoji
]);
// Diccionari ràpid per ingredients individuals
const EMOJI_MAP = {
    // Verdures
    tomaquet: '🍅',
    tomato: '🍅',
    patata: '🥔',
    potato: '🥔',
    ceba: '🧅',
    onion: '🧅',
    all: '🧄',
    garlic: '🧄',
    pastanaga: '🥕',
    carrot: '🥕',
    enciam: '🥬',
    lettuce: '🥬',
    brocoli: '🥦',
    broccoli: '🥦',
    pebrot: '🫑',
    pepper: '🫑',
    alberginia: '🍆',
    eggplant: '🍆',
    bolet: '🍄',
    xampinyo: '🍄',
    mushroom: '🍄',
    // Fruites
    llimona: '🍋',
    lemon: '🍋',
    poma: '🍎',
    apple: '🍎',
    platan: '🍌',
    banana: '🍌',
    maduixa: '🍓',
    strawberry: '🍓',
    // Proteïnes
    pollastre: '🍗',
    chicken: '🍗',
    carn: '🥩',
    vedella: '🥩',
    meat: '🥩',
    beef: '🥩',
    porc: '🥓',
    pork: '🥓',
    pernil: '🥓',
    bacon: '🥓',
    peix: '🐟',
    fish: '🐟',
    gamba: '🦐',
    shrimp: '🦐',
    ou: '🥚',
    egg: '🥚',
    // Làctics & Altres
    llet: '🥛',
    milk: '🥛',
    formatge: '🧀',
    cheese: '🧀',
    mantega: '🧈',
    butter: '🧈',
    oli: '🫒',
    oil: '🫒',
    pa: '🥖',
    bread: '🥖',
    arros: '🍚',
    rice: '🍚',
    pasta: '🍝',
    espagueti: '🍝',
    macarrons: '🍝',
    // Condiments
    sal: '🧂',
    salt: '🧂',
    pebre: '🌶️',
    sucre: '🍬',
    sugar: '🍬',
    aigua: '💧',
    water: '💧',
    xocolata: '🍫',
    chocolate: '🍫'
};
// Helper per treure accents i passar a minúscules (ex: "Arròs" -> "arros")
const normalizeText = (text)=>text.toLowerCase().trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
function getIngredientEmoji(name) {
    if (!name) return '🥗';
    const normalized = normalizeText(name);
    // A. Cerca directa
    if (EMOJI_MAP[normalized]) return EMOJI_MAP[normalized];
    // B. Cerca parcial
    for (const [key, emoji] of Object.entries(EMOJI_MAP)){
        if (normalized.includes(key)) return emoji;
    }
    // C. Fallbacks genèrics
    if (normalized.includes('carn') || normalized.includes('filet')) return '🥩';
    if (normalized.includes('verdura') || normalized.includes('fulla')) return '🥬';
    if (normalized.includes('fruita')) return '🍎';
    if (normalized.includes('salsa')) return '🥣';
    if (normalized.includes('especia') || normalized.includes('herba')) return '🌿';
    if (normalized.includes('farina') || normalized.includes('masa')) return '🌾';
    return '🥗'; // Default
}
function getMainEmoji(name, tags = []) {
    const normalizedName = normalizeText(name);
    const normalizedTags = tags.map((t)=>normalizeText(t));
    // Unim tot el text per buscar paraules clau
    const context = [
        normalizedName,
        ...normalizedTags
    ].join(' ');
    // --- NIVELL 1: PLATS ESPECÍFICS (Prioritat Màxima) ---
    if (context.includes('pizza')) return '🍕';
    if (context.includes('hamburg') || context.includes('burger')) return '🍔';
    if (context.includes('sushi') || context.includes('maki') || context.includes('nigiri')) return '🍣';
    if (context.includes('taco') || context.includes('mexic') || context.includes('fajita')) return '🌮';
    if (context.includes('burrito') || context.includes('durum')) return '🌯';
    if (context.includes('hot dog') || context.includes('frankfurt')) return '🌭';
    if (context.includes('crispetes') || context.includes('pop corn')) return '🍿';
    if (context.includes('patates fregides') || context.includes('braves')) return '🍟';
    if (context.includes('ramen') || context.includes('fideus xinesos')) return '🍜';
    // --- NIVELL 2: POSTRES I DOLÇOS ---
    // Fruita (IMPORTANT: Abans que "postres" genèric)
    if (context.includes('macedonia') || context.includes('fruita')) return '🍉';
    if (context.includes('maduix')) return '🍓';
    if (context.includes('poma')) return '🍎';
    if (context.includes('platan')) return '🍌';
    if (context.includes('llimona') || context.includes('sorbet')) return '🍋';
    if (context.includes('cirer')) return '🍒';
    // Dolços
    if (context.includes('xocolata') || context.includes('brownie') || context.includes('coulant')) return '🍫';
    if (context.includes('pastis') || context.includes('cake') || context.includes('tarta') || context.includes('tiramisu')) return '🍰';
    if (context.includes('gelat') || context.includes('ice cream')) return '🍦';
    if (context.includes('galetes') || context.includes('cookies')) return '🍪';
    if (context.includes('donut')) return '🍩';
    if (context.includes('croissant')) return '🥐';
    if (context.includes('pancake') || context.includes('crep')) return '🥞';
    if (context.includes('flam') || context.includes('crema catalana') || context.includes('pudding')) return '🍮';
    // Tag genèric de postres
    if (context.includes('postres') || context.includes('dessert') || context.includes('dolc')) return '🧁';
    // --- NIVELL 3: PLATS PRINCIPALS ---
    // Arrossos i Pasta
    if (context.includes('paella') || context.includes('arros')) return '🥘';
    if (context.includes('pasta') || context.includes('spaghetti') || context.includes('macarron') || context.includes('lasanya')) return '🍝';
    if (context.includes('fideu')) return '🍜';
    // Sopes i Cremes
    if (context.includes('sopa') || context.includes('crema') || context.includes('brou') || context.includes('escudella')) return '🥣';
    // Amanides
    if (context.includes('amanida') || context.includes('salad') || context.includes('cesar')) return '🥗';
    // Entrepans
    if (context.includes('entrepa') || context.includes('sandvitx') || context.includes('bikini')) return '🥪';
    // Ous
    if (context.includes('ou') || context.includes('truita') || context.includes('tortilla')) return '🍳';
    // --- NIVELL 4: BEGUDES ---
    if (context.includes('batut') || context.includes('smoothie')) return '🥤';
    if (context.includes('cafe') || context.includes('coffee')) return '☕';
    if (context.includes('cocktail') || context.includes('mojito')) return '🍹';
    if (context.includes('cervesa') || context.includes('beer')) return '🍺';
    if (context.includes('vi ') || context.includes('wine')) return '🍷';
    // --- NIVELL 5: INGREDIENT PRINCIPAL ---
    if (context.includes('pollastre') || context.includes('chicken') || context.includes('gall d')) return '🍗';
    if (context.includes('vedella') || context.includes('carn') || context.includes('steak') || context.includes('meat')) return '🥩';
    if (context.includes('porc') || context.includes('bacon') || context.includes('pernil')) return '🥓';
    if (context.includes('peix') || context.includes('fish') || context.includes('salmo') || context.includes('bacalla') || context.includes('orada')) return '🐟';
    if (context.includes('gamba') || context.includes('marisc') || context.includes('musclo')) return '🦐';
    if (context.includes('formatge') || context.includes('cheese')) return '🧀';
    // --- NIVELL 6: DIETES ---
    if (context.includes('vega') || context.includes('vegan')) return '🌱';
    if (context.includes('vegetaria')) return '🥦';
    return '🍽️';
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:0c6092 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "toggleFavoriteAction",
    ()=>$$RSC_SERVER_ACTION_1
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"40c53fa8401d5e6dda60b51c1e9e408ee2b365c0dc":"toggleFavoriteAction"},"app/actions/recipe-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40c53fa8401d5e6dda60b51c1e9e408ee2b365c0dc", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "toggleFavoriteAction");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vcmVjaXBlLWFjdGlvbnMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQVJYSVU6IGFwcC9hY3Rpb25zL3JlY2lwZS1hY3Rpb25zLnRzXHJcbid1c2Ugc2VydmVyJ1xyXG5cclxuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSAnQC9hZGFwdGVycy9zdXBhYmFzZS9zZXJ2ZXInO1xyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gJ25leHQvY2FjaGUnO1xyXG4vLyDinIUgRklYOiBJbXBvcnRlbSBlbCByZXBvc2l0b3JpIHF1ZSBmYWx0YXZhXHJcbmltcG9ydCB7IFN1cGFiYXNlUmVjaXBlUmVwb3NpdG9yeSB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2UvU3VwYWJhc2VSZWNpcGVSZXBvc2l0b3J5JztcclxuaW1wb3J0IHsgY29udGFpbmVyIH0gZnJvbSAnQC9zZXJ2aWNlcy9jb250YWluZXInO1xyXG5pbXBvcnQgeyBFbW9qaU1hdGNoZXJTZXJ2aWNlIH0gZnJvbSAnQC9jb3JlL2FwcGxpY2F0aW9uL3NlcnZpY2VzL0Vtb2ppTWF0Y2hlclNlcnZpY2UnOyAvLyDinIUgSW1wb3J0ZW0gZWwgTWF0Y2hlclxyXG5pbXBvcnQgeyBHZW5lcmF0ZVJlY2lwZVNjaGVtYSwgTWF0ZXJpYWxpemVSZWNpcGVTY2hlbWEgfSBmcm9tICdAL2NvcmUvYXBwbGljYXRpb24vc2NoZW1hcy9pbnB1dFNjaGVtYXMnO1xyXG5pbXBvcnQgeyBTdXBhYmFzZVJhdGVMaW1pdGVyIH0gZnJvbSAnQC9hZGFwdGVycy9zdXBhYmFzZS9TdXBhYmFzZVJhdGVMaW1pdGVyJztcclxuaW1wb3J0IHsgU3VwYWJhc2VTZWN1cml0eUxvZ2dlciB9IGZyb20gJ0AvYWRhcHRlcnMvc3VwYWJhc2UvU3VwYWJhc2VTZWN1cml0eUxvZ2dlcic7XHJcbmltcG9ydCB7IGRlYnVnLCBlcnJvciBhcyBsb2dFcnJvciB9IGZyb20gJ0AvbGliL2xvZ2dlcic7XHJcblxyXG4vLyDinIUgRklYOiBEZWZpbmljacOzIHJvYnVzdGEgZGUgbGEgcmVzcG9zdGFcclxuZXhwb3J0IHR5cGUgQWN0aW9uUmVzcG9uc2UgPSB7XHJcbiAgICBzdWNjZXNzOiBib29sZWFuO1xyXG4gICAgcmVjaXBlSWQ/OiBzdHJpbmc7XHJcbiAgICBlcnJvcj86IHN0cmluZzsgLy8gSW1wb3J0YW50IHF1ZSBzaWd1aSBvcGNpb25hbCAoPylcclxufTtcclxuXHJcbi8vIFRpcHVzIHVuaWZpY2F0IHF1ZSBjb2JyZWl4aSBlbCBxdWUgdmUgZGUgbCdFZGl0b3IgaSBlbCBxdWUgdmUgZGUgbGEgSUFcclxuZXhwb3J0IGludGVyZmFjZSBTYXZlUmVjaXBlSW5wdXQge1xyXG4gIGlkPzogc3RyaW5nO1xyXG4gIG5hbWU6IHN0cmluZztcclxuICBwcmVwVGltZU1pbnV0ZXM6IG51bWJlciB8IHN0cmluZztcclxuICBcclxuICBpbmdyZWRpZW50czoge1xyXG4gICAgaWQ/OiBzdHJpbmc7XHJcbiAgICBuYW1lOiBzdHJpbmc7XHJcbiAgICBxdWFudGl0eTogbnVtYmVyO1xyXG4gICAgdW5pdDogc3RyaW5nO1xyXG4gICAgZW1vamk/OiBzdHJpbmc7XHJcbiAgICBlc3RpbWF0ZWRDb3N0PzogbnVtYmVyIHwgc3RyaW5nO1xyXG4gICAgbGlua2VkUHJvZHVjdElkPzogc3RyaW5nIHwgbnVsbDtcclxuICAgIGxpbmtlZFByb2R1Y3RJbWFnZT86IHN0cmluZyB8IG51bGw7XHJcbiAgfVtdO1xyXG4gIHN0ZXBzOiAoc3RyaW5nIHwgeyBpZDogc3RyaW5nOyBjb250ZW50OiBzdHJpbmcgfSlbXTtcclxuICB0YWdzPzogc3RyaW5nW107XHJcbiAgZGlldGFyeVRhZ3M/OiBzdHJpbmdbXTtcclxuICBpc0FpR2VuZXJhdGVkPzogYm9vbGVhbjtcclxufVxyXG5cclxuLy8gLS0tIEFDQ0nDkyBQUklOQ0lQQUw6IFNBVkUgLS0tXHJcbi8vIEFxdWVzdGEgY29udMOpIHRvdGEgbGEgbMOyZ2ljYSBcImludGVswrdsaWdlbnRcIiAocHJldXMsIGltYXRnZXMsIGVtb2ppcy4uLilcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNhdmVSZWNpcGVBY3Rpb24oZGF0YTogU2F2ZVJlY2lwZUlucHV0KTogUHJvbWlzZTxBY3Rpb25SZXNwb25zZT4ge1xyXG4gIGRlYnVnKCdbU0FWRSBBQ1RJT05dIHNhdmVSZWNpcGVBY3Rpb24nKTtcclxuXHJcbiAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoKTtcclxuICBjb25zdCB7IGRhdGE6IHsgdXNlciB9IH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcclxuICBpZiAoIXVzZXIpIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9O1xyXG5cclxuICB0cnkge1xyXG4gICAgbGV0IGF1dGhvck5hbWUgPSBcIlhlZiBBbsOybmltXCI7XHJcbiAgICBjb25zdCB7IGRhdGE6IHByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3ByZWZlcmVuY2VfcHJvZmlsZXMnKS5zZWxlY3QoJ3VzZXJuYW1lJykuZXEoJ3VzZXJfaWQnLCB1c2VyLmlkKS5zaW5nbGUoKTtcclxuICAgIGlmIChwcm9maWxlPy51c2VybmFtZSkgYXV0aG9yTmFtZSA9IHByb2ZpbGUudXNlcm5hbWU7XHJcblxyXG4gICAgLy8gMS4gQ8OgbGN1bCBkZSBjb3N0IHRvdGFsIChST0JVU1QpXHJcbiAgICBjb25zdCB0b3RhbENvc3QgPSBkYXRhLmluZ3JlZGllbnRzLnJlZHVjZSgoYWNjLCBpbmcpID0+IHtcclxuICAgICAgbGV0IGNvc3RWYWwgPSBpbmcuZXN0aW1hdGVkQ29zdDtcclxuICAgICAgaWYgKHR5cGVvZiBjb3N0VmFsID09PSAnc3RyaW5nJykgY29zdFZhbCA9IHBhcnNlRmxvYXQoY29zdFZhbCk7XHJcbiAgICAgIGNvbnN0IGNvc3QgPSBOdW1iZXIoY29zdFZhbCkgfHwgMDtcclxuICAgICAgcmV0dXJuIGFjYyArIGNvc3Q7XHJcbiAgICB9LCAwKTtcclxuXHJcbiAgICBsZXQgaXNBaUdlbmVyYXRlZCA9ICEhZGF0YS5pc0FpR2VuZXJhdGVkO1xyXG4gICAgaWYgKCFpc0FpR2VuZXJhdGVkICYmIGRhdGEuaWQpIHtcclxuICAgICAgY29uc3QgeyBkYXRhOiBvbGRSZWNpcGUgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3NhdmVkX3JlY2lwZXMnKS5zZWxlY3QoJ2lzX2FpX2dlbmVyYXRlZCcpLmVxKCdpZCcsIGRhdGEuaWQpLnNpbmdsZSgpO1xyXG4gICAgICBpZiAob2xkUmVjaXBlKSBpc0FpR2VuZXJhdGVkID0gb2xkUmVjaXBlLmlzX2FpX2dlbmVyYXRlZDtcclxuICAgIH1cclxuXHJcbiAgICAvLyAyLiBQUk9DRVNTQVIgSU5HUkVESUVOVFMgKyBJTUFUR0VTXHJcbiAgICBjb25zdCBpbmdyZWRpZW50c1BheWxvYWQgPSBhd2FpdCBQcm9taXNlLmFsbChkYXRhLmluZ3JlZGllbnRzLm1hcChhc3luYyAoaW5nKSA9PiB7XHJcbiAgICAgIGxldCBmaW5hbElkID0gaW5nLmlkO1xyXG4gICAgICBsZXQgZmluYWxFbW9qaSA9IGluZy5lbW9qaTtcclxuICAgICAgY29uc3QgZmluYWxOYW1lID0gaW5nLm5hbWU7XHJcbiAgICAgIGNvbnN0IGxpbmtlZFByb2R1Y3RJZCA9IGluZy5saW5rZWRQcm9kdWN0SWQ7XHJcbiAgICAgIGxldCBsaW5rZWRQcm9kdWN0SW1hZ2UgPSBpbmcubGlua2VkUHJvZHVjdEltYWdlO1xyXG4gICAgICBjb25zdCBlc3RpbWF0ZWRDb3N0ID0gaW5nLmVzdGltYXRlZENvc3QgPyBOdW1iZXIoaW5nLmVzdGltYXRlZENvc3QpIDogMDtcclxuXHJcbiAgICAgIGNvbnN0IGhhc0xpbmsgPSB0eXBlb2YgbGlua2VkUHJvZHVjdElkID09PSAnc3RyaW5nJyAmJiBsaW5rZWRQcm9kdWN0SWQubGVuZ3RoID4gMDtcclxuXHJcbiAgICAgIGlmIChoYXNMaW5rKSB7XHJcbiAgICAgICAgLy8gLi4uIChMw7JnaWNhIGRlIHJlY3VwZXJhY2nDsyBkJ2ltYXRnZXMgaWd1YWwgcXVlIHRlbmllcykgLi4uXHJcbiAgICAgICAgaWYgKCFsaW5rZWRQcm9kdWN0SW1hZ2UpIHtcclxuICAgICAgICAgIGNvbnN0IHsgZGF0YTogcHJvZHVjdCB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgncHJvZHVjdF9jYXRhbG9nJykuc2VsZWN0KCdpbWFnZV91cmwnKS5lcSgnaWQnLCBsaW5rZWRQcm9kdWN0SWQpLnNpbmdsZSgpO1xyXG4gICAgICAgICAgaWYgKHByb2R1Y3Q/LmltYWdlX3VybCkgbGlua2VkUHJvZHVjdEltYWdlID0gcHJvZHVjdC5pbWFnZV91cmw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghZmluYWxJZCB8fCBmaW5hbElkLmxlbmd0aCA8IDUpIGZpbmFsSWQgPSBsaW5rZWRQcm9kdWN0SWQhO1xyXG4gICAgICAgIGlmICghZmluYWxFbW9qaSB8fCBmaW5hbEVtb2ppID09PSAn8J+lmCcpIGZpbmFsRW1vamkgPSAn8J+Tpic7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gTWF0Y2hlciBkJ2Vtb2ppc1xyXG4gICAgICAgIGNvbnN0IGNsZWFuTmFtZSA9IGZpbmFsTmFtZS5yZXBsYWNlKC9cXGIoQk9OUFJFVXxQQVRDSEVGfC4uLilcXGIvZ2ksIFwiXCIpLnRyaW0oKTtcclxuICAgICAgICBjb25zdCBwcmVzZXQgPSBFbW9qaU1hdGNoZXJTZXJ2aWNlLm1hdGNoKGNsZWFuTmFtZSk7XHJcbiAgICAgICAgaWYgKHByZXNldCkge1xyXG4gICAgICAgICAgZmluYWxJZCA9IHByZXNldC5pZDtcclxuICAgICAgICAgIGZpbmFsRW1vamkgPSBwcmVzZXQuZW1vamk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGlmICghZmluYWxFbW9qaSkgZmluYWxFbW9qaSA9ICfwn6WYJztcclxuICAgICAgICAgIGlmICghZmluYWxJZCkgZmluYWxJZCA9IGNyeXB0by5yYW5kb21VVUlEKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIGlkOiBmaW5hbElkLFxyXG4gICAgICAgIG5hbWU6IGZpbmFsTmFtZSxcclxuICAgICAgICBxdWFudGl0eTogaW5nLnF1YW50aXR5LFxyXG4gICAgICAgIHVuaXQ6IGluZy51bml0LFxyXG4gICAgICAgIGVtb2ppOiBmaW5hbEVtb2ppLFxyXG4gICAgICAgIGxpbmtlZFByb2R1Y3RJZDogaGFzTGluayA/IGxpbmtlZFByb2R1Y3RJZCA6IG51bGwsXHJcbiAgICAgICAgbGlua2VkUHJvZHVjdEltYWdlOiBoYXNMaW5rID8gbGlua2VkUHJvZHVjdEltYWdlIDogbnVsbCxcclxuICAgICAgICBlc3RpbWF0ZWRDb3N0XHJcbiAgICAgIH07XHJcbiAgICB9KSk7XHJcblxyXG4gICAgLy8gMy4gUFJPQ0VTU0FSIFBBU1NPU1xyXG4gICAgY29uc3Qgc3RlcHNEYXRhID0gZGF0YS5zdGVwcy5tYXAocyA9PiB7XHJcbiAgICAgIGlmICh0eXBlb2YgcyA9PT0gJ3N0cmluZycpIHJldHVybiB7IGlkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLCBjb250ZW50OiBzIH07XHJcbiAgICAgIHJldHVybiB7IGlkOiBzLmlkIHx8IGNyeXB0by5yYW5kb21VVUlEKCksIGNvbnRlbnQ6IHMuY29udGVudCB8fCBcIlwiIH07XHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyA0LiBQQVlMT0FEIEJEXHJcbiAgICBjb25zdCByZWNpcGVQYXlsb2FkID0ge1xyXG4gICAgICB1c2VyX2lkOiB1c2VyLmlkLFxyXG4gICAgICBuYW1lOiBkYXRhLm5hbWUsXHJcbiAgICAgIGF1dGhvcl9uYW1lOiBhdXRob3JOYW1lLFxyXG4gICAgICBwcmVwX3RpbWVfbWludXRlczogTnVtYmVyKGRhdGEucHJlcFRpbWVNaW51dGVzKSB8fCAwLFxyXG4gICAgICBpbmdyZWRpZW50czogaW5ncmVkaWVudHNQYXlsb2FkLFxyXG4gICAgICBzdGVwczogc3RlcHNEYXRhLFxyXG4gICAgICB0YWdzOiBkYXRhLnRhZ3MgfHwgW10sXHJcbiAgICAgIGRpZXRhcnlfdGFnczogZGF0YS5kaWV0YXJ5VGFncyB8fCBbXSxcclxuICAgICAgZXN0aW1hdGVkX2Nvc3Q6IHRvdGFsQ29zdCxcclxuICAgICAgaXNfcHVibGljOiBmYWxzZSwgLy8gUGVyIGRlZmVjdGUgcHJpdmFkYSBxdWFuIGVzIGd1YXJkYVxyXG4gICAgICBpc19haV9nZW5lcmF0ZWQ6IGlzQWlHZW5lcmF0ZWQsXHJcbiAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCB0YWJsZSA9IHN1cGFiYXNlLmZyb20oJ3NhdmVkX3JlY2lwZXMnKTtcclxuICAgIGxldCByZXN1bHRJZDogc3RyaW5nO1xyXG5cclxuICAgIGlmIChkYXRhLmlkKSB7XHJcbiAgICAgIC8vIC4uLiBMw7JnaWNhIGQnVXBkYXRlIGV4aXN0ZW50IC4uLlxyXG4gICAgICAvLyAoU2ltcGxpZmljYWRhIGFxdcOtIHBlciBicmV2ZXRhdCwgY29waWEgbGEgdGV2YSBsw7JnaWNhIGQndXBkYXRlKVxyXG4gICAgICBjb25zdCB7IGRhdGE6IHVwZGF0ZWQsIGVycm9yIH0gPSBhd2FpdCB0YWJsZS51cHNlcnQoeyAuLi5yZWNpcGVQYXlsb2FkLCBpZDogZGF0YS5pZCB9KS5zZWxlY3QoJ2lkJykuc2luZ2xlKCk7XHJcbiAgICAgIGlmIChlcnJvcikgdGhyb3cgZXJyb3I7XHJcbiAgICAgIHJlc3VsdElkID0gdXBkYXRlZC5pZDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnN0IHsgZGF0YTogaW5zZXJ0ZWQsIGVycm9yIH0gPSBhd2FpdCB0YWJsZS5pbnNlcnQocmVjaXBlUGF5bG9hZCkuc2VsZWN0KCdpZCcpLnNpbmdsZSgpO1xyXG4gICAgICBpZiAoZXJyb3IpIHRocm93IGVycm9yO1xyXG4gICAgICByZXN1bHRJZCA9IGluc2VydGVkLmlkO1xyXG4gICAgfVxyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvcmVjaXBlcycpO1xyXG4gICAgaWYgKHJlc3VsdElkKSByZXZhbGlkYXRlUGF0aChgL3JlY2lwZXMvJHtyZXN1bHRJZH1gKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIHJlY2lwZUlkOiByZXN1bHRJZCB9O1xyXG5cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ3NhdmVSZWNpcGVBY3Rpb24gZmFpbGVkJywgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkVycm9yIGludGVybi5cIiB9O1xyXG4gIH1cclxufVxyXG4vLyBBY2Npw7MgcGVyIEZhdm9yaXRzIChOZWNlc3NpdGEgZWwgUmVwb3NpdG9yaSlcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHRvZ2dsZUZhdm9yaXRlQWN0aW9uKHJlY2lwZUlkOiBzdHJpbmcpIHtcclxuICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG4gIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0gfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpO1xyXG5cclxuICBpZiAoIXVzZXIpIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9O1xyXG5cclxuICAvLyBBcmEgc8OtIHF1ZSB0ZW5pbSBsJ2ltcG9ydCBhIGRhbHRcclxuICBjb25zdCByZXBvID0gbmV3IFN1cGFiYXNlUmVjaXBlUmVwb3NpdG9yeSgpO1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgaXNGYXYgPSBhd2FpdCByZXBvLnRvZ2dsZUZhdm9yaXRlKHVzZXIuaWQsIHJlY2lwZUlkKTtcclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL3JlY2lwZXMnKTtcclxuICAgIHJldmFsaWRhdGVQYXRoKGAvcmVjaXBlcy8ke3JlY2lwZUlkfWApO1xyXG5cclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGlzRmF2b3JpdGU6IGlzRmF2IH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGxvZ0Vycm9yKCdFcnJvciB1cGRhdGluZyBmYXZvcml0ZScsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJFcnJvciB1cGRhdGluZyBmYXZvcml0ZVwiIH07XHJcbiAgfVxyXG5cclxuXHJcbn1cclxuLy8g4pyFIEFxdWVzdGEgYWNjacOzIHN1YnN0aXR1ZWl4IGxhIGzDsmdpY2EgY29tcGxleGEgcXVlIHRlbmllcyBhYmFucy5cclxuLy8gQXJhIGZhIHNlcnZpciBsJ2VzdHJhdMOoZ2lhIEjDrWJyaWRhIChCRCArIElBKSBxdWUgaGVtIGRlZmluaXQgYWwgU2VydmljZS5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlTWVudUFjdGlvbihcclxuICB1c2VySWQ6IHN0cmluZyxcclxuICBkaXNoTmFtZTogc3RyaW5nLFxyXG4gIG1vZGU6ICdGQVRFJyB8ICdDSEVGJyxcclxuICBlbmVyZ3k6IG51bWJlciA9IDUwLFxyXG4gIHRpbWU6IG51bWJlciA9IDMwLFxyXG4gIGxhbmc6IHN0cmluZyA9ICdjYSdcclxuKSB7XHJcbiAgZGVidWcoJ1tBQ1RJT05dIGdlbmVyYXRlTWVudUFjdGlvbicpO1xyXG5cclxuICAvLyAxLiBWQUxJREFDScOTIChab2QpXHJcbiAgY29uc3QgdmFsaWRhdGlvbiA9IEdlbmVyYXRlUmVjaXBlU2NoZW1hLnNhZmVQYXJzZSh7IHVzZXJJZCwgZGlzaE5hbWUsIGxhbmcgfSk7XHJcbiAgaWYgKCF2YWxpZGF0aW9uLnN1Y2Nlc3MpIHtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogdmFsaWRhdGlvbi5lcnJvci5pc3N1ZXNbMF0ubWVzc2FnZSB9O1xyXG4gIH1cclxuXHJcbiAgLy8gMi4gU0VHVVJFVEFUIChSYXRlIExpbWl0KVxyXG4gIGNvbnN0IGxpbWl0ZXIgPSBuZXcgU3VwYWJhc2VSYXRlTGltaXRlcigpO1xyXG4gIGNvbnN0IGxvZ2dlciA9IG5ldyBTdXBhYmFzZVNlY3VyaXR5TG9nZ2VyKCk7XHJcblxyXG4gIGNvbnN0IGNhblByb2NlZWQgPSBhd2FpdCBsaW1pdGVyLmNoZWNrKGBnZW46JHt1c2VySWR9YCwgMjAsIDM2MDApOyAvLyA1IGNvcHMvaG9yYVxyXG4gIGlmICghY2FuUHJvY2VlZCkge1xyXG4gICAgYXdhaXQgbG9nZ2VyLmxvZygnV0FSTicsICdSQVRFX0xJTUlUJywgdXNlcklkLCB7IGFjdGlvbjogJ2dlbmVyYXRlX21lbnUnIH0pO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkzDrW1pdCBzdXBlcmF0LiBFc3BlcmEgdW5hIGVzdG9uYS5cIiB9O1xyXG4gIH1cclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XHJcbiAgICBjb25zdCBzZXJ2aWNlID0gY29udGFpbmVyLmdldEdlbmVyYXRlTWVudVNlcnZpY2Uoc3VwYWJhc2UpO1xyXG5cclxuICAgIC8vIEVYRUNVVEVNIEVMIFNFUlZFSSAoTCdPcmNoZXN0cmF0b3IgZGVjaWRlaXggaW50ZXJuYW1lbnQpXHJcbiAgICBjb25zdCByZWNpcGVzID0gYXdhaXQgc2VydmljZS5leGVjdXRlKFxyXG4gICAgICB1c2VySWQsXHJcbiAgICAgIG1vZGUsXHJcbiAgICAgIGRpc2hOYW1lLFxyXG4gICAgICBlbmVyZ3ksXHJcbiAgICAgIHRpbWUsXHJcbiAgICAgIGxhbmdcclxuICAgICk7XHJcblxyXG4gICAgLy8gQ09OVkVSU0nDkyBBIFBSSU1JVElWRVNcclxuICAgIC8vIDEuIENvbnZlcnRpbSBhIHByaW1pdGl2ZXMgKGFpeMOyIGphIGhvIGZhcylcclxuICAgIGNvbnN0IHBsYWluUmVjaXBlcyA9IHJlY2lwZXMubWFwKHIgPT4gci50b1ByaW1pdGl2ZXMoKSk7XHJcblxyXG4gICAgLy8gMi4g4pqg77iPIEFTU0VHVVJBJ1QgUVVFIGVzdGltYXRlZENvc3QgRVhJU1RFSVggQVFVw40g4pqg77iPXHJcbiAgICAvLyBTaSBwbGFpblJlY2lwZXNbMF0uZXN0aW1hdGVkQ29zdCDDqXMgdW5kZWZpbmVkLCBKU09OLnN0cmluZ2lmeSBsJ2VzYm9ycmFyw6AhXHJcbiAgICBpZiAocGxhaW5SZWNpcGVzLmxlbmd0aCA+IDAgJiYgcGxhaW5SZWNpcGVzWzBdLmVzdGltYXRlZENvc3QgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICBsb2dFcnJvcihcIuKaoO+4jyBBTEVSVEE6IGVzdGltYXRlZENvc3Qgw6lzIHVuZGVmaW5lZCBhYmFucyBkJ2VudmlhciBhbCBjbGllbnQhXCIpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIDMuIFNhbml0aXR6YWNpw7NcclxuICAgIGNvbnN0IGNsZWFuUmVjaXBlcyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkocGxhaW5SZWNpcGVzKSk7XHJcblxyXG4gICAgZGVidWcoJ1tBQ1RJT05dIGdlbmVyYXRlTWVudUFjdGlvbiBkb25lJyk7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogdHJ1ZSxcclxuICAgICAgcmVjaXBlczogY2xlYW5SZWNpcGVzXHJcbiAgICB9O1xyXG5cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgbG9nRXJyb3IoJ+KdjCBbQUNUSU9OIEVSUk9SXTonLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRXJyb3IgZ2VuZXJhbnQgZWwgbWVuw7ouXCIgfTtcclxuICB9XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1hdGVyaWFsaXplUmVjaXBlQWN0aW9uKHJhd0FpUmVjaXBlOiB1bmtub3duKTogUHJvbWlzZTxBY3Rpb25SZXNwb25zZT4ge1xyXG4gIGNvbnN0IHBhcnNlZCA9IE1hdGVyaWFsaXplUmVjaXBlU2NoZW1hLnNhZmVQYXJzZShyYXdBaVJlY2lwZSk7XHJcbiAgaWYgKCFwYXJzZWQuc3VjY2Vzcykge1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBwYXJzZWQuZXJyb3IuaXNzdWVzWzBdLm1lc3NhZ2UgfTtcclxuICB9XHJcblxyXG4gIGNvbnN0IHJlY2lwZURhdGEgPSBwYXJzZWQuZGF0YTtcclxuICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpO1xyXG5cclxuICAvLyDwn5SNIDEuIFBBUyBERSBERURVUExJQ0FDScOTOiBCdXNxdWVtIHNpIGphIGV4aXN0ZWl4XHJcbiAgdHJ5IHtcclxuICAgICAgY29uc3QgeyBkYXRhOiBleGlzdGluZyB9ID0gYXdhaXQgc3VwYWJhc2VcclxuICAgICAgICAgIC5mcm9tKCdzYXZlZF9yZWNpcGVzJylcclxuICAgICAgICAgIC5zZWxlY3QoJ2lkJylcclxuICAgICAgICAgIC5lcSgnbmFtZScsIHJlY2lwZURhdGEubmFtZSkgLy8gTWF0ZWl4IG5vbVxyXG4gICAgICAgICAgLmVxKCdpc19haV9nZW5lcmF0ZWQnLCB0cnVlKSAvLyBRdWUgc2lndWkgZGUgbGEgSUFcclxuICAgICAgICAgIC5lcSgnaXNfcHVibGljJywgdHJ1ZSkgLy8gUXVlIHNpZ3VpIGNvbXBhcnRpZGFcclxuICAgICAgICAgIC5saW1pdCgxKVxyXG4gICAgICAgICAgLnNpbmdsZSgpO1xyXG5cclxuICAgICAgaWYgKGV4aXN0aW5nKSB7XHJcbiAgICAgICAgICBkZWJ1ZygnW0FDVElPTl0gZGVkdXBsaWNhdGUgaGl0Jyk7XHJcbiAgICAgICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCByZWNpcGVJZDogZXhpc3RpbmcuaWQgfTtcclxuICAgICAgfVxyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgbG9nRXJyb3IoJ01hdGVyaWFsaXplUmVjaXBlQWN0aW9uIGVycm9yJywgZXJyKTtcclxuICAgICAgLy8gSWdub3JlbSBlcnJvcnMgZGUgY29uc3VsdGEgKGV4OiBubyB0cm9iYXQpLCBzZWd1aW0gZW5kYXZhbnQgcGVyIGNyZWFyLWxhXHJcbiAgfVxyXG5cclxuICAvLyDwn4yKIDIuIEZMVVggRCdFTlJJUVVJTUVOVCAoSWd1YWwgcXVlIHRlbmllcylcclxuICAvLyBTaSBubyBleGlzdGVpeCwgbCdoZW0gZGUgY3JlYXIgaSBlbnJpcXVpclxyXG4gIGNvbnN0IGVucmljaGVkSW5ncmVkaWVudHMgPSBhd2FpdCBQcm9taXNlLmFsbCgocmVjaXBlRGF0YS5pbmdyZWRpZW50cyB8fCBbXSkubWFwKGFzeW5jIChpbmcpID0+IHtcclxuICAgICAgbGV0IGxpbmtlZFByb2R1Y3RJZCA9IGluZy5saW5rZWRQcm9kdWN0SWQ7XHJcbiAgICAgIGxldCBsaW5rZWRQcm9kdWN0SW1hZ2UgPSBpbmcubGlua2VkUHJvZHVjdEltYWdlO1xyXG4gICAgICBsZXQgZXN0aW1hdGVkQ29zdCA9IGluZy5lc3RpbWF0ZWRDb3N0O1xyXG5cclxuICAgICAgaWYgKCFsaW5rZWRQcm9kdWN0SWQgfHwgIWxpbmtlZFByb2R1Y3RJbWFnZSkge1xyXG4gICAgICAgICAgY29uc3QgeyBkYXRhOiBtYXRjaCB9ID0gYXdhaXQgc3VwYWJhc2VcclxuICAgICAgICAgICAgICAuZnJvbSgncHJvZHVjdF9jYXRhbG9nJylcclxuICAgICAgICAgICAgICAuc2VsZWN0KCdpZCwgaW1hZ2VfdXJsLCBwcmljZScpXHJcbiAgICAgICAgICAgICAgLmlsaWtlKCduYW1lJywgYCUke2luZy5uYW1lfSVgKVxyXG4gICAgICAgICAgICAgIC5saW1pdCgxKVxyXG4gICAgICAgICAgICAgIC5zaW5nbGUoKTtcclxuXHJcbiAgICAgICAgICBpZiAobWF0Y2gpIHtcclxuICAgICAgICAgICAgICBsaW5rZWRQcm9kdWN0SWQgPSBtYXRjaC5pZDtcclxuICAgICAgICAgICAgICBsaW5rZWRQcm9kdWN0SW1hZ2UgPSBtYXRjaC5pbWFnZV91cmw7XHJcbiAgICAgICAgICAgICAgaWYgKCFlc3RpbWF0ZWRDb3N0ICYmIG1hdGNoLnByaWNlKSBlc3RpbWF0ZWRDb3N0ID0gbWF0Y2gucHJpY2U7IFxyXG4gICAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgbmFtZTogaW5nLm5hbWUsXHJcbiAgICAgICAgICBxdWFudGl0eTogaW5nLnF1YW50aXR5LFxyXG4gICAgICAgICAgdW5pdDogaW5nLnVuaXQsXHJcbiAgICAgICAgICBlbW9qaTogaW5nLmVtb2ppLFxyXG4gICAgICAgICAgZXN0aW1hdGVkQ29zdDogZXN0aW1hdGVkQ29zdCxcclxuICAgICAgICAgIGxpbmtlZFByb2R1Y3RJZDogbGlua2VkUHJvZHVjdElkLFxyXG4gICAgICAgICAgbGlua2VkUHJvZHVjdEltYWdlOiBsaW5rZWRQcm9kdWN0SW1hZ2UsXHJcbiAgICAgIH07XHJcbiAgfSkpO1xyXG5cclxuICAvLyDwn5K+IDMuIFBSRVBBUkFSIFBFUiBHVUFSREFSXHJcbiAgY29uc3QgaW5wdXQ6IFNhdmVSZWNpcGVJbnB1dCA9IHtcclxuICAgIG5hbWU6IHJlY2lwZURhdGEubmFtZSxcclxuICAgIHByZXBUaW1lTWludXRlczogcmVjaXBlRGF0YS5wcmVwVGltZU1pbnV0ZXMgfHwgMzAsXHJcbiAgICB0YWdzOiByZWNpcGVEYXRhLnRhZ3MgfHwgW10sXHJcbiAgICBkaWV0YXJ5VGFnczogcmVjaXBlRGF0YS5kaWV0YXJ5VGFncyB8fCBbXSxcclxuICAgIGlzQWlHZW5lcmF0ZWQ6IHRydWUsXHJcbiAgICBzdGVwczogcmVjaXBlRGF0YS5zdGVwcyB8fCBbXSxcclxuICAgIGluZ3JlZGllbnRzOiBlbnJpY2hlZEluZ3JlZGllbnRzXHJcbiAgfTtcclxuXHJcbiAgLy8g8J+UpSBUUlVDIEZJTkFMOiBHdWFyZGVtIGNvbSBhIFDDmkJMSUNBP1xyXG4gIC8vIFPDrSwgcGVycXXDqCBzaSB1biBhbHRyZSB1c3VhcmkgZGUgbGEgc2FsYSBmYSBjbGljLCB2b2xlbSBxdWUgdHJvYmkgYXF1ZXN0YSByZWNlcHRhIChQYXMgMSlcclxuICAvLyBpIG5vIGVuIGNyZcOvIHVuYSBkZSBub3ZhLlxyXG4gIC8vIE1vZGlmaXF1ZW0gc2F2ZVJlY2lwZUFjdGlvbiBwZXJxdcOoIGFjY2VwdGkgJ2lzUHVibGljJyBvIGhvIGZvcmNlbSBhIGxhIGzDsmdpY2EgZGUgc2F2ZS5cclxuICBcclxuICAvLyBPcGNpw7MgQTogU2kgc2F2ZVJlY2lwZUFjdGlvbiBhY2NlcHRhIGlzUHVibGljIGFsIGlucHV0LCBwYXNzYS1sJ2hpLlxyXG4gIC8vIE9wY2nDsyBCIChIYWNrIHLDoHBpZCk6IFNhdmVSZWNpcGVBY3Rpb24gcGVyIGRlZmVjdGUgbGVzIGZhIHByaXZhZGVzLiBcclxuICAvLyBQZXLDsiBjb20gcXVlIHJldG9ybmEgbCdJRCwgcG9kZW0gZmVyIHVuIHVwZGF0ZSByw6BwaWQgYXF1w60gcGVyIGZlci1sYSBww7pibGljYS5cclxuICBcclxuICBjb25zdCBzYXZlUmVzdWx0ID0gYXdhaXQgc2F2ZVJlY2lwZUFjdGlvbihpbnB1dCk7XHJcblxyXG4gIGlmIChzYXZlUmVzdWx0LnN1Y2Nlc3MgJiYgc2F2ZVJlc3VsdC5yZWNpcGVJZCkge1xyXG4gICAgICAvLyBMYSBmZW0gcMO6YmxpY2EgcGVycXXDqCBsYSB0cm9iaW4gZWxzIGFsdHJlcyBjb21wYW55cyBkZSBsYSBzYWxhXHJcbiAgICAgIGF3YWl0IHN1cGFiYXNlXHJcbiAgICAgICAgICAuZnJvbSgnc2F2ZWRfcmVjaXBlcycpXHJcbiAgICAgICAgICAudXBkYXRlKHsgaXNfcHVibGljOiB0cnVlIH0pXHJcbiAgICAgICAgICAuZXEoJ2lkJywgc2F2ZVJlc3VsdC5yZWNpcGVJZCk7XHJcbiAgICAgICAgICBcclxuICAgICAgZGVidWcoJ1tBQ1RJT05dIHJlY2lwZSBzaGFyZWQnKTtcclxuICB9XHJcblxyXG4gIHJldHVybiBzYXZlUmVzdWx0O1xyXG59XHJcblxyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6InNTQWtLc0IsaU1BQUEifQ==
}),
"[project]/features/recipes/components/FavoriteButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FavoriteButton",
    ()=>FavoriteButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/heart.js [app-client] (ecmascript) <export default as Heart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$0c6092__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:0c6092 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/sonner@2.0.7_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// ARXIU: src/components/recipes/FavoriteButton.tsx
'use client';
;
;
;
;
;
function FavoriteButton({ recipeId, initialIsFavorite, className = "", testId }) {
    _s();
    const [isFav, setIsFav] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialIsFavorite);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleToggle = async (e)=>{
        e.preventDefault(); // Evitem obrir la recepta si estem a la card
        e.stopPropagation();
        if (isLoading) return;
        // UI Optimista (Canviem visualment JA)
        const newState = !isFav;
        setIsFav(newState);
        setIsLoading(true);
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$0c6092__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["toggleFavoriteAction"])(recipeId);
        if (!result.success) {
            // Si falla, revertim
            setIsFav(!newState);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$sonner$40$2$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Error guardant favorit");
        }
        setIsLoading(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
        whileTap: {
            scale: 0.8
        },
        onClick: handleToggle,
        disabled: isLoading,
        "data-testid": testId,
        className: `
                flex items-center justify-center rounded-full p-2 transition-all
                ${isFav ? 'bg-rose-500/10 text-rose-500 hover:bg-rose-500/20' : 'bg-slate-800/80 text-slate-400 hover:bg-slate-700 hover:text-white'}
                ${className}
            `,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__["Heart"], {
            size: 18,
            className: isFav ? "fill-current" : "",
            strokeWidth: 2.5
        }, void 0, false, {
            fileName: "[project]/features/recipes/components/FavoriteButton.tsx",
            lineNumber: 57,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/features/recipes/components/FavoriteButton.tsx",
        lineNumber: 44,
        columnNumber: 9
    }, this);
}
_s(FavoriteButton, "lpPFOyr0JKcZ1BL4wUu/Dl5So4A=");
_c = FavoriteButton;
var _c;
__turbopack_context__.k.register(_c, "FavoriteButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/RecipeCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RecipeCard",
    ()=>RecipeCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$StarRating$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/StarRating.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2f$emojiUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils/emojiUtils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/user.js [app-client] (ecmascript) <export default as User>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$coins$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Coins$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/coins.js [app-client] (ecmascript) <export default as Coins>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chef$2d$hat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChefHat$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/chef-hat.js [app-client] (ecmascript) <export default as ChefHat>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/chevron-up.js [app-client] (ecmascript) <export default as ChevronUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bot$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/bot.js [app-client] (ecmascript) <export default as Bot>");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$FavoriteButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/FavoriteButton.tsx [app-client] (ecmascript)"); // ✅ Import correcte
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
function RecipeCard({ recipe, userId, userRating }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [isExpanded, setIsExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const labels = t.create_recipe.card;
    const recipeWithTags = recipe;
    const safeTags = Array.isArray(recipeWithTags.tags) ? recipeWithTags.tags : [];
    const mainEmoji = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2f$emojiUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMainEmoji"])(recipe.name, safeTags);
    const isAuthor = recipe.authorId === userId;
    // Lògica visual de l'autor
    const isAi = recipe.isAiGenerated;
    const displayAuthorName = isAi ? "Chef IA" : isAuthor ? labels.created_by_you : recipe.authorName || labels.created_by_community;
    const toggleExpand = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setIsExpanded(!isExpanded);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].article, {
        initial: {
            opacity: 0,
            y: 10
        },
        animate: {
            opacity: 1,
            y: 0
        },
        "data-testid": `recipe-card-${recipe.id}`,
        className: `
        group relative flex flex-col bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg transition-all 
        ${isExpanded ? 'ring-1 ring-purple-500/30 bg-slate-900' : 'hover:border-purple-500/40'}
        h-fit md:h-full
      `,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: `/recipes/${recipe.id}`,
                className: "absolute inset-0 z-0",
                prefetch: false,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "sr-only",
                    children: [
                        labels.view_sr,
                        " ",
                        recipe.name
                    ]
                }, void 0, true, {
                    fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                    lineNumber: 58,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative p-4 flex gap-4 items-center bg-linear-to-br from-slate-800/50 to-slate-900 border-b border-slate-800/50 z-10 pointer-events-none",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "shrink-0 w-12 h-12 bg-slate-800 rounded-xl flex items-center justify-center text-2xl shadow-inner border border-slate-700/50",
                        children: mainEmoji
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                        lineNumber: 66,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 min-w-0 flex flex-col justify-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-base font-bold text-slate-100 leading-tight line-clamp-2 pr-12 md:pr-8",
                                children: recipe.name
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                                lineNumber: 71,
                                columnNumber: 13
                            }, this),
                            recipe.estimatedCost && recipe.estimatedCost > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1 text-emerald-400 text-xs font-mono font-bold mt-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$coins$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Coins$3e$__["Coins"], {
                                        size: 10,
                                        className: "stroke-[2.5]"
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                                        lineNumber: 76,
                                        columnNumber: 21
                                    }, this),
                                    recipe.estimatedCost.toFixed(2),
                                    "€"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                                lineNumber: 75,
                                columnNumber: 17
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-xs text-slate-600 mt-1 font-mono",
                                children: "-- €"
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                                lineNumber: 79,
                                columnNumber: 17
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                        lineNumber: 70,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-3 right-12 md:right-3 z-30 pointer-events-auto",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$FavoriteButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FavoriteButton"], {
                            recipeId: recipe.id,
                            initialIsFavorite: !!recipe.isFavorite,
                            testId: `recipe-favorite-${recipe.id}`
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                            lineNumber: 86,
                            columnNumber: 14
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                        lineNumber: 85,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: toggleExpand,
                        className: "md:hidden absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white transition-colors border border-slate-700 z-30 pointer-events-auto",
                        children: isExpanded ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
                            size: 18
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                            lineNumber: 98,
                            columnNumber: 27
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                            size: 18
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                            lineNumber: 98,
                            columnNumber: 53
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                        lineNumber: 94,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "md:hidden relative z-10 pointer-events-none",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                    children: isExpanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                        initial: {
                            height: 0,
                            opacity: 0
                        },
                        animate: {
                            height: "auto",
                            opacity: 1
                        },
                        exit: {
                            height: 0,
                            opacity: 0
                        },
                        className: "overflow-hidden bg-slate-950/30",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "pointer-events-auto",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CardContent, {
                                recipe: recipe,
                                isAuthor: isAuthor,
                                isAi: isAi ?? false,
                                displayAuthorName: displayAuthorName,
                                userRating: userRating
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                                lineNumber: 116,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                            lineNumber: 115,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                        lineNumber: 108,
                        columnNumber: 17
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                    lineNumber: 106,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                lineNumber: 105,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "hidden md:flex flex-col flex-1 bg-slate-950/30 relative z-10 pointer-events-none",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CardContent, {
                    recipe: recipe,
                    isAuthor: isAuthor,
                    isAi: isAi ?? false,
                    displayAuthorName: displayAuthorName,
                    userRating: userRating
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                    lineNumber: 133,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                lineNumber: 130,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/RecipeCard.tsx",
        lineNumber: 46,
        columnNumber: 5
    }, this);
}
_s(RecipeCard, "UW80cY9003Usbg1jBuvaGG66piM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = RecipeCard;
// --- SUBCOMPONENT ---
function CardContent({ recipe, isAuthor, isAi, displayAuthorName, userRating }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col h-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-4 flex flex-col gap-3 flex-1 relative z-10",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-wrap gap-2 content-start",
                    children: [
                        recipe.ingredients.slice(0, 4).map((ing, i)=>{
                            const hasStoredEmoji = ing.emoji && ing.emoji !== '📦';
                            const displayEmoji = hasStoredEmoji ? ing.emoji : (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2f$emojiUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIngredientEmoji"])(ing.name);
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "inline-flex items-center gap-1.5 text-[10px] font-bold bg-slate-950 text-slate-300 px-2 py-1 rounded border border-slate-800/60",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "grayscale-[0.3]",
                                        children: displayEmoji
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                                        lineNumber: 160,
                                        columnNumber: 33
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "truncate max-w-17.5",
                                        children: ing.name
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                                        lineNumber: 161,
                                        columnNumber: 33
                                    }, this)
                                ]
                            }, i, true, {
                                fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                                lineNumber: 159,
                                columnNumber: 29
                            }, this);
                        }),
                        recipe.ingredients.length > 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-[10px] font-bold text-slate-600 self-center pl-1",
                            children: [
                                "+",
                                recipe.ingredients.length - 4,
                                ".."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                            lineNumber: 166,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                    lineNumber: 154,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                lineNumber: 153,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-4 pb-4 pt-2 flex flex-col gap-3 border-t border-slate-800/50 relative z-10 mt-auto",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "flex items-center gap-1 bg-slate-900 px-2 py-1 rounded text-slate-400 border border-slate-800 text-xs font-bold",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"], {
                                        size: 12
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                                        lineNumber: 177,
                                        columnNumber: 25
                                    }, this),
                                    " ",
                                    recipe.prepTimeMinutes,
                                    "m"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                                lineNumber: 176,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "pointer-events-auto",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$StarRating$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StarRating"], {
                                    recipeId: recipe.id,
                                    average: recipe.ratingSummary?.average || 0,
                                    count: recipe.ratingSummary?.count || 0,
                                    initialUserRating: userRating || 0,
                                    testIdPrefix: `recipe-rating-${recipe.id}`
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                                    lineNumber: 181,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                                lineNumber: 180,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                        lineNumber: 175,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2 pt-2 border-t border-slate-800/50",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `p-1 rounded-full ${isAi ? 'bg-emerald-500/10 text-emerald-400' : isAuthor ? 'bg-purple-500/10 text-purple-400' : 'bg-slate-800 text-slate-400'}`,
                                children: isAi ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bot$3e$__["Bot"], {
                                    size: 10
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                                    lineNumber: 193,
                                    columnNumber: 33
                                }, this) : isAuthor ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__["User"], {
                                    size: 10
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                                    lineNumber: 193,
                                    columnNumber: 65
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chef$2d$hat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChefHat$3e$__["ChefHat"], {
                                    size: 10
                                }, void 0, false, {
                                    fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                                    lineNumber: 193,
                                    columnNumber: 86
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                                lineNumber: 192,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `text-[10px] font-medium truncate ${isAi ? 'text-emerald-300' : isAuthor ? 'text-purple-300' : 'text-slate-500'}`,
                                children: displayAuthorName
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                                lineNumber: 195,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                        lineNumber: 191,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/RecipeCard.tsx",
                lineNumber: 174,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/RecipeCard.tsx",
        lineNumber: 151,
        columnNumber: 9
    }, this);
}
_c1 = CardContent;
var _c, _c1;
__turbopack_context__.k.register(_c, "RecipeCard");
__turbopack_context__.k.register(_c1, "CardContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/RecipeFeed.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RecipeFeed",
    ()=>RecipeFeed
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$RecipeCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/recipes/components/RecipeCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)"); // ✅
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function RecipeFeed({ recipes, userId, userRatings, totalPages, currentPage }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])(); // ✅
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const createPageUrl = (pageNumber)=>{
        const params = new URLSearchParams(searchParams.toString());
        params.set('page', pageNumber.toString());
        return `?${params.toString()}`;
    };
    const containerVariants = {
        hidden: {
            opacity: 0
        },
        show: {
            opacity: 1,
            transition: {
                staggerChildren: 0.05
            }
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-8 pb-12",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                variants: containerVariants,
                initial: "hidden",
                animate: "show",
                className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4",
                children: recipes.map((recipe, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$recipes$2f$components$2f$RecipeCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RecipeCard"], {
                        recipe: recipe,
                        userId: userId,
                        userRating: userRatings[recipe.id] || 0
                    }, recipe.id || index, false, {
                        fileName: "[project]/features/recipes/components/RecipeFeed.tsx",
                        lineNumber: 44,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/RecipeFeed.tsx",
                lineNumber: 37,
                columnNumber: 7
            }, this),
            recipes.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center py-20 bg-slate-900/30 rounded-3xl border border-dashed border-slate-800",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-6xl mb-4 grayscale opacity-50",
                        children: "🥣"
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/RecipeFeed.tsx",
                        lineNumber: 56,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-slate-400 font-medium",
                        children: t.community.empty_state
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/RecipeFeed.tsx",
                        lineNumber: 57,
                        columnNumber: 13
                    }, this),
                    " "
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/RecipeFeed.tsx",
                lineNumber: 55,
                columnNumber: 9
            }, this),
            totalPages > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-center items-center gap-4 mt-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: currentPage > 1 ? createPageUrl(currentPage - 1) : '#',
                        className: `w-10 h-10 flex items-center justify-center font-bold text-white bg-slate-800 rounded-full hover:bg-slate-700 transition-all ${currentPage === 1 ? 'opacity-30 pointer-events-none' : ''}`,
                        children: "←"
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/RecipeFeed.tsx",
                        lineNumber: 64,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-xs text-slate-500 font-mono",
                        children: [
                            t.community.pagination.page,
                            " ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-white",
                                children: currentPage
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/RecipeFeed.tsx",
                                lineNumber: 72,
                                columnNumber: 44
                            }, this),
                            " ",
                            t.community.pagination.of,
                            " ",
                            totalPages
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/RecipeFeed.tsx",
                        lineNumber: 71,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: currentPage < totalPages ? createPageUrl(currentPage + 1) : '#',
                        className: `w-10 h-10 flex items-center justify-center font-bold text-white bg-slate-800 rounded-full hover:bg-slate-700 transition-all ${currentPage === totalPages ? 'opacity-30 pointer-events-none' : ''}`,
                        children: "→"
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/RecipeFeed.tsx",
                        lineNumber: 75,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/RecipeFeed.tsx",
                lineNumber: 63,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/RecipeFeed.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}
_s(RecipeFeed, "A8PmbbCu6aBgbdgcuyXnrK9n3t4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = RecipeFeed;
var _c;
__turbopack_context__.k.register(_c, "RecipeFeed");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/FilterBar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FilterBar",
    ()=>FilterBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$use$2d$debounce$40$10$2e$0$2e$6_react$40$19$2e$2$2e$3$2f$node_modules$2f$use$2d$debounce$2f$dist$2f$index$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/use-debounce@10.0.6_react@19.2.3/node_modules/use-debounce/dist/index.module.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// ARXIU: src/components/recipes/FilterBar.tsx
'use client';
;
;
;
function FilterBar({ currentFilter, currentSearch, currentMode = 'ALL' }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    // Actualitza paràmetres mantenint els altres
    const updateParam = (key, value)=>{
        const params = new URLSearchParams(searchParams.toString());
        if (value && value !== 'ALL') params.set(key, value);
        else params.delete(key);
        params.set('page', '1'); // Reset paginació
        router.push(`?${params.toString()}`);
    };
    const handleSearch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$use$2d$debounce$40$10$2e$0$2e$6_react$40$19$2e$2$2e$3$2f$node_modules$2f$use$2d$debounce$2f$dist$2f$index$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedCallback"])({
        "FilterBar.useDebouncedCallback[handleSearch]": (term)=>{
            updateParam('q', term);
        }
    }["FilterBar.useDebouncedCallback[handleSearch]"], 300);
    const handleModeChange = (mode)=>{
        const params = new URLSearchParams(searchParams.toString());
        if (mode === 'ALL') params.delete('mode');
        else params.set('mode', mode);
        // Si canviem de mode, potser volem netejar els filtres de tags? 
        // De moment els mantenim per si vols buscar "Les meves receptes Veganes"
        params.set('page', '1');
        router.push(`?${params.toString()}`);
    };
    const filters = [
        {
            id: 'ALL',
            label: t.community.filters.all,
            icon: '🌍'
        },
        {
            id: 'FAST',
            label: t.community.filters.fast,
            icon: '⚡'
        },
        {
            id: 'VEGGIE',
            label: t.community.filters.veggie,
            icon: '🥗'
        },
        {
            id: 'VEGAN',
            label: t.community.filters.vegan,
            icon: '🌱'
        },
        {
            id: 'GLUTEN_FREE',
            label: t.community.filters.gluten_free,
            icon: '🌾🚫'
        },
        {
            id: 'DAIRY_FREE',
            label: t.community.filters.dairy_free,
            icon: '🥛🚫'
        },
        {
            id: 'DESSERT',
            label: t.community.filters.dessert,
            icon: '🍰'
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col gap-4 sticky top-4 z-40",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex p-1 bg-slate-900/90 backdrop-blur-xl rounded-xl border border-slate-800 w-full sm:w-fit self-start shadow-lg",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>handleModeChange('ALL'),
                        className: `flex-1 sm:flex-none px-4 py-2 text-xs font-bold rounded-lg transition-all ${currentMode === 'ALL' ? 'bg-slate-800 text-white shadow ring-1 ring-slate-700' : 'text-slate-500 hover:text-slate-300'}`,
                        children: "🌍 Comunitat"
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/FilterBar.tsx",
                        lineNumber: 61,
                        columnNumber: 10
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>handleModeChange('FAVORITES'),
                        className: `flex-1 sm:flex-none px-4 py-2 text-xs font-bold rounded-lg transition-all ${currentMode === 'FAVORITES' ? 'bg-slate-800 text-purple-400 shadow ring-1 ring-purple-900/50' : 'text-slate-500 hover:text-slate-300'}`,
                        children: "❤️ Favorits"
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/FilterBar.tsx",
                        lineNumber: 67,
                        columnNumber: 10
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>handleModeChange('MINE'),
                        className: `flex-1 sm:flex-none px-4 py-2 text-xs font-bold rounded-lg transition-all ${currentMode === 'MINE' ? 'bg-slate-800 text-emerald-400 shadow ring-1 ring-emerald-900/50' : 'text-slate-500 hover:text-slate-300'}`,
                        children: "👨‍🍳 Les Meves"
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/FilterBar.tsx",
                        lineNumber: 73,
                        columnNumber: 10
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/FilterBar.tsx",
                lineNumber: 60,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col lg:flex-row gap-4 justify-between items-center bg-slate-900/80 backdrop-blur-xl p-2 pr-2 rounded-[2rem] border border-slate-800 shadow-xl",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex p-1 w-full lg:w-auto overflow-x-auto no-scrollbar mask-linear-fade gap-1",
                        children: filters.map((f)=>{
                            const isActive = currentFilter === f.id || f.id === 'ALL' && !currentFilter;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>updateParam('filter', f.id),
                                className: `relative px-4 py-2 rounded-full text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2
                            ${isActive ? 'bg-slate-100 text-slate-900 shadow-lg scale-105' : 'text-slate-400 hover:text-white hover:bg-white/5'}
                        `,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: f.icon
                                    }, void 0, false, {
                                        fileName: "[project]/features/recipes/components/FilterBar.tsx",
                                        lineNumber: 96,
                                        columnNumber: 25
                                    }, this),
                                    f.label
                                ]
                            }, f.id, true, {
                                fileName: "[project]/features/recipes/components/FilterBar.tsx",
                                lineNumber: 89,
                                columnNumber: 21
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/features/recipes/components/FilterBar.tsx",
                        lineNumber: 85,
                        columnNumber: 10
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative w-full lg:w-auto min-w-[250px] group",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute inset-y-0 left-4 flex items-center pointer-events-none text-base grayscale opacity-50",
                                children: "🔍"
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/FilterBar.tsx",
                                lineNumber: 105,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                placeholder: t.community.search_placeholder,
                                defaultValue: currentSearch,
                                onChange: (e)=>handleSearch(e.target.value),
                                className: "w-full bg-black/40 border border-slate-700/50 rounded-full pl-10 pr-6 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 transition-all shadow-inner"
                            }, void 0, false, {
                                fileName: "[project]/features/recipes/components/FilterBar.tsx",
                                lineNumber: 106,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/recipes/components/FilterBar.tsx",
                        lineNumber: 104,
                        columnNumber: 10
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/recipes/components/FilterBar.tsx",
                lineNumber: 82,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/recipes/components/FilterBar.tsx",
        lineNumber: 57,
        columnNumber: 5
    }, this);
}
_s(FilterBar, "FCeHtBpg0IDS7YUsnZ8qedT7AXI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$use$2d$debounce$40$10$2e$0$2e$6_react$40$19$2e$2$2e$3$2f$node_modules$2f$use$2d$debounce$2f$dist$2f$index$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedCallback"]
    ];
});
_c = FilterBar;
var _c;
__turbopack_context__.k.register(_c, "FilterBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/BackButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BackButton",
    ()=>BackButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/navigation.js [app-client] (ecmascript)"); // 👈 Importem el router
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function BackButton({ href, label = "Tornar", className = "", preferReferrer = false, fallbackHref }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const storageKey = ("TURBOPACK compile-time truthy", 1) ? `back-origin:${window.location.pathname}` : "TURBOPACK unreachable";
    // Definim els estils comuns per no repetir codi
    const buttonStyles = `
    flex items-center justify-center gap-2 
    bg-slate-800 hover:bg-slate-700 
    text-white 
    border border-slate-700 hover:border-purple-500/50
    transition-colors shadow-lg
    cursor-pointer
    
    /* MÒBIL: Rodó i petit */
    w-10 h-10 rounded-full
    
    /* ESCRIPTORI: Allargat i amb text */
    sm:w-auto sm:h-auto sm:px-4 sm:py-2 sm:rounded-full
    
    ${className}
  `;
    // Contingut visual del botó (Icona + Text)
    const content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-xl sm:text-lg leading-none pb-1 sm:pb-0",
                children: "🔙"
            }, void 0, false, {
                fileName: "[project]/components/ui/BackButton.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "hidden sm:inline text-xs font-bold uppercase tracking-wide",
                children: label
            }, void 0, false, {
                fileName: "[project]/components/ui/BackButton.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
    // CAS 1: Si tenim una ruta específica (href), fem servir Link (millor per SEO i prefetching)
    if (href) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: href,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                whileHover: {
                    scale: 1.05
                },
                whileTap: {
                    scale: 0.95
                },
                className: buttonStyles,
                children: content
            }, void 0, false, {
                fileName: "[project]/components/ui/BackButton.tsx",
                lineNumber: 58,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/ui/BackButton.tsx",
            lineNumber: 57,
            columnNumber: 7
        }, this);
    }
    // CAS 2: Si volem tornar a l'origen (fora d'aquesta ruta), usem el referrer guardat
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
        type: "button",
        onClick: ()=>{
            if (preferReferrer && ("TURBOPACK compile-time value", "object") !== "undefined" && storageKey) {
                const storedOrigin = sessionStorage.getItem(storageKey);
                if (storedOrigin) {
                    router.push(storedOrigin);
                    return;
                }
                if (fallbackHref) {
                    router.push(fallbackHref);
                    return;
                }
            }
            router.back();
        },
        whileHover: {
            scale: 1.05
        },
        whileTap: {
            scale: 0.95
        },
        className: buttonStyles,
        children: content
    }, void 0, false, {
        fileName: "[project]/components/ui/BackButton.tsx",
        lineNumber: 72,
        columnNumber: 5
    }, this);
}
_s(BackButton, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = BackButton;
var _c;
__turbopack_context__.k.register(_c, "BackButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/CreateRecipeButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CreateRecipeButton",
    ()=>CreateRecipeButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.23.26_reac_b75e9981d053c7985282bd491e2a6f69/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
function CreateRecipeButton() {
    // JA NO NECESSITEM ESTAT NI MODAL
    // Simplement naveguem a la pàgina del Wizard
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: "/recipes/create",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$23$2e$26_reac_b75e9981d053c7985282bd491e2a6f69$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
            whileHover: {
                scale: 1.1,
                rotate: 90
            },
            whileTap: {
                scale: 0.9
            },
            "data-testid": "create-recipe-button",
            // Nota: Assegura't de fer servir 'bg-gradient-to-r' en lloc de 'bg-linear-to-r' si uses Tailwind standard
            className: "fixed bottom-6 right-6 z-50 w-14 h-14 bg-linear-to-r from-purple-600 to-pink-600 text-white rounded-full shadow-xl shadow-purple-900/40 flex items-center justify-center border-2 border-white/20",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                size: 32
            }, void 0, false, {
                fileName: "[project]/features/recipes/components/CreateRecipeButton.tsx",
                lineNumber: 20,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/features/recipes/components/CreateRecipeButton.tsx",
            lineNumber: 13,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/features/recipes/components/CreateRecipeButton.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, this);
}
_c = CreateRecipeButton;
var _c;
__turbopack_context__.k.register(_c, "CreateRecipeButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/recipes/components/CommunityHeader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CommunityHeader",
    ()=>CommunityHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.2_b924c198cd2b895136e6af67e07b63c7/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
function CommunityHeader() {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex-1",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            className: "text-2xl sm:text-3xl font-black text-white tracking-tight leading-tight",
            children: [
                t.community.title,
                " ",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$2_b924c198cd2b895136e6af67e07b63c7$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-transparent bg-clip-text bg-linear-to-r from-purple-400 to-pink-400",
                    children: t.community.title_suffix
                }, void 0, false, {
                    fileName: "[project]/features/recipes/components/CommunityHeader.tsx",
                    lineNumber: 11,
                    columnNumber: 29
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/features/recipes/components/CommunityHeader.tsx",
            lineNumber: 10,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/features/recipes/components/CommunityHeader.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
_s(CommunityHeader, "ot2YhC7pP10gRrIouBKIa40vomw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = CommunityHeader;
var _c;
__turbopack_context__.k.register(_c, "CommunityHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_734d2bc7._.js.map