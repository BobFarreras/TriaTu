(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_c2bd3a57._.js",
  "static/chunks/_c418c7e1._.js"
],
    source: "dynamic"
});
