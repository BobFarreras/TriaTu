(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/06bae_next_dist_4c8ef15d._.js",
  "static/chunks/_f48083cd._.js"
],
    source: "dynamic"
});
